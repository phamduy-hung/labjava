LAB 11 - MINH HOA GIAO DIEN

Cac anh PNG trong thu muc nay duoc render tu chinh cac template HTML/CSS cua project de kiem tra bo cuc truoc khi chay runtime.
Theo yeu cau Lab 11, khi nop bai nen thay cac anh nay bang anh chup that sau khi chay `mvn spring-boot:run` tai cac URL:
- http://localhost:8080/
- http://localhost:8080/about
- http://localhost:8080/students
- http://localhost:8080/courses
- http://localhost:8080/contact

Luu y: Neu Apache Tomcat cua Lab 10 dang chay cong 8080, hay Stop server do truoc khi chay Spring Boot Lab 11.
