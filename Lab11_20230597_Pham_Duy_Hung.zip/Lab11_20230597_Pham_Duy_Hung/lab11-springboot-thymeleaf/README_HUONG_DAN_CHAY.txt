LAB 11 - SPRING BOOT + THYMELEAF

Yeu cau:
- JDK 17 hoac JDK 21
- Maven 3.x

Luu y: Spring Boot dung Tomcat nhung san. Neu Apache Tomcat ngoai dang chay cong 8080 (vi du Lab 10), hay Stop server do truoc khi chay Lab 11.

Lenh:
1. mvn clean package
2. mvn spring-boot:run

Truy cap:
- http://localhost:8080/
- http://localhost:8080/about
- http://localhost:8080/students
- http://localhost:8080/courses
- http://localhost:8080/contact

Project bam theo Lab 11, Chuong 4: Spring Boot, Spring MVC co ban, Thymeleaf, Maven.
