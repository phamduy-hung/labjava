package vn.edu.eaut.lab11.controller;

import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import vn.edu.eaut.lab11.model.Course;

@Controller
public class CourseController {

    @GetMapping("/courses")
    public String listCourses(Model model) {
        List<Course> courses = List.of(
            new Course("MH001", "Lập trình Java", 3),
            new Course("MH002", "Cơ sở dữ liệu", 3),
            new Course("MH003", "Công nghệ Web", 3),
            new Course("MH004", "Phân tích thiết kế hệ thống", 3),
            new Course("MH005", "Kiểm thử phần mềm", 2)
        );
        model.addAttribute("courses", courses);
        return "courses";
    }
}
