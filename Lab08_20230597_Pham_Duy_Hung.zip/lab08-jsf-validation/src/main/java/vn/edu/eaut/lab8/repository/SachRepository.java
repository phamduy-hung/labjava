package vn.edu.eaut.lab8.repository;

import vn.edu.eaut.lab8.model.Sach;
import java.util.ArrayList;
import java.util.List;

public class SachRepository {
    private static final List<Sach> data = new ArrayList<>();
    private static int autoId = 2;

    static {
        data.add(new Sach(1, "S001", "Lập trình Java căn bản", "Nguyễn Văn A", "NXB Giáo dục", 2024));
    }

    public List<Sach> findAll() { return data; }
    public void add(Sach sach) { sach.setId(autoId++); data.add(sach); }
    public void delete(int id) { data.removeIf(x -> x.getId() == id); }
}
