package vn.edu.eaut.lab8.repository;

import vn.edu.eaut.lab8.model.SanPham;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class SanPhamRepository {
    private static final List<SanPham> data = new ArrayList<>();
    private static int autoId = 2;

    static {
        data.add(new SanPham(1, "SP001", "Bàn phím cơ", "Bàn phím dùng cho học tập và làm việc",
                new BigDecimal("650000"), 10));
    }

    public List<SanPham> findAll() { return data; }
    public void add(SanPham sp) { sp.setId(autoId++); data.add(sp); }
    public void delete(int id) { data.removeIf(x -> x.getId() == id); }
}
