package vn.edu.eaut.lab8.bean;

import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import vn.edu.eaut.lab8.model.SanPham;
import vn.edu.eaut.lab8.repository.SanPhamRepository;

import java.io.Serializable;
import java.util.List;

@Named("sanPhamBean")
@SessionScoped
public class SanPhamBean implements Serializable {
    private static final long serialVersionUID = 1L;
    private SanPham sanPham = new SanPham();
    private final SanPhamRepository repo = new SanPhamRepository();

    public String save() {
        repo.add(sanPham);
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Thành công", "Đã lưu sản phẩm"));
        sanPham = new SanPham();
        return "sanpham-list?faces-redirect=true";
    }

    public void delete(int id) {
        repo.delete(id);
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Thành công", "Đã xóa sản phẩm"));
    }

    public SanPham getSanPham() { return sanPham; }
    public void setSanPham(SanPham sanPham) { this.sanPham = sanPham; }
    public List<SanPham> getDsSanPham() { return repo.findAll(); }
}
