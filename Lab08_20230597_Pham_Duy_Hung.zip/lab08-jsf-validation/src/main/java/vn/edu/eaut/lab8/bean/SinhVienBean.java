package vn.edu.eaut.lab8.bean;

import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import vn.edu.eaut.lab8.model.SinhVien;
import vn.edu.eaut.lab8.repository.SinhVienRepository;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

@Named("sinhVienBean")
@SessionScoped
public class SinhVienBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private SinhVien sinhVien = new SinhVien();
    private final SinhVienRepository repo = new SinhVienRepository();
    private String keyword = "";
    private boolean editing = false;

    public String save() {
        if (editing && sinhVien.getId() > 0) {
            repo.update(sinhVien);
            addInfo("Thành công", "Đã cập nhật sinh viên");
        } else {
            repo.add(sinhVien);
            addInfo("Thành công", "Đã lưu sinh viên");
        }
        sinhVien = new SinhVien();
        editing = false;
        return "sinhvien-list?faces-redirect=true";
    }

    public String edit(int id) {
        SinhVien old = repo.findById(id);
        if (old != null) {
            sinhVien = new SinhVien(old);
            editing = true;
            return "sinhvien-form?faces-redirect=true";
        }
        addError("Không tìm thấy", "Sinh viên cần sửa không tồn tại");
        return null;
    }

    public void delete(int id) {
        repo.delete(id);
        addInfo("Thành công", "Đã xóa sinh viên");
    }

    public String createNew() {
        sinhVien = new SinhVien();
        editing = false;
        return "sinhvien-form?faces-redirect=true";
    }

    public List<SinhVien> getDsSinhVien() {
        return repo.search(keyword);
    }

    public void search() {
        // getDsSinhVien() sẽ tự lọc theo keyword khi JSF render lại bảng.
    }

    public void clearSearch() {
        keyword = "";
    }

    public List<String> getDanhSachLop() {
        return Arrays.asList("DCCNTT14.2", "DCCNTT15.10.1", "DCCNTT15.10.2", "DCCNTT16.1");
    }

    private void addInfo(String summary, String detail) {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, summary, detail));
    }

    private void addError(String summary, String detail) {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, detail));
    }

    public SinhVien getSinhVien() { return sinhVien; }
    public void setSinhVien(SinhVien sinhVien) { this.sinhVien = sinhVien; }
    public String getKeyword() { return keyword; }
    public void setKeyword(String keyword) { this.keyword = keyword; }
    public boolean isEditing() { return editing; }
}
