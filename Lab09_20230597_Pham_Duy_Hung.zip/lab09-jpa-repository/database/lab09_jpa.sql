CREATE DATABASE IF NOT EXISTS lab09_jpa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lab09_jpa;

CREATE TABLE IF NOT EXISTS lop_hoc (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ma_lop VARCHAR(30) NOT NULL UNIQUE,
  ten_lop VARCHAR(100) NOT NULL,
  co_van VARCHAR(100)
);
CREATE TABLE IF NOT EXISTS sinh_vien (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ma_sinh_vien VARCHAR(20) NOT NULL UNIQUE,
  ho_ten VARCHAR(100) NOT NULL,
  email VARCHAR(100),
  lop_id INT,
  ngay_sinh DATE,
  CONSTRAINT fk_sv_lop FOREIGN KEY (lop_id) REFERENCES lop_hoc(id)
);
CREATE TABLE IF NOT EXISTS mon_hoc (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ma_mon VARCHAR(20) NOT NULL UNIQUE,
  ten_mon VARCHAR(100) NOT NULL
);
CREATE TABLE IF NOT EXISTS diem (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sinh_vien_id INT NOT NULL,
  mon_hoc_id INT NOT NULL,
  chuyen_can DOUBLE DEFAULT 0,
  giua_ky DOUBLE DEFAULT 0,
  cuoi_ky DOUBLE DEFAULT 0,
  UNIQUE(sinh_vien_id, mon_hoc_id),
  FOREIGN KEY (sinh_vien_id) REFERENCES sinh_vien(id),
  FOREIGN KEY (mon_hoc_id) REFERENCES mon_hoc(id)
);
CREATE TABLE IF NOT EXISTS sach (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ma_sach VARCHAR(30) NOT NULL UNIQUE,
  ten_sach VARCHAR(150) NOT NULL,
  tac_gia VARCHAR(120) NOT NULL,
  nha_xuat_ban VARCHAR(120),
  nam_xuat_ban INT
);
CREATE TABLE IF NOT EXISTS san_pham (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ma_sp VARCHAR(30) NOT NULL UNIQUE,
  ten_sp VARCHAR(150) NOT NULL,
  mo_ta VARCHAR(255),
  gia DECIMAL(12,2) NOT NULL,
  so_luong INT NOT NULL
);
CREATE TABLE IF NOT EXISTS role (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ten_role VARCHAR(30) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS nguoi_dung (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL,
  ho_ten VARCHAR(100) NOT NULL,
  role_id INT NOT NULL,
  FOREIGN KEY (role_id) REFERENCES role(id)
);

INSERT IGNORE INTO lop_hoc(ma_lop,ten_lop,co_van) VALUES
('DCCNTT14.2','Công nghệ thông tin 14.2','Nguyễn Văn Minh'),
('DCCNTT15.1','Công nghệ thông tin 15.1','Trần Thu Hà');
INSERT IGNORE INTO mon_hoc(ma_mon,ten_mon) VALUES ('JAVA','Công nghệ Java'),('CSDL','Cơ sở dữ liệu');
INSERT IGNORE INTO role(ten_role) VALUES ('ADMIN'),('USER');
INSERT IGNORE INTO nguoi_dung(username,password,ho_ten,role_id)
SELECT 'admin','123456','Quản trị viên',id FROM role WHERE ten_role='ADMIN';

INSERT IGNORE INTO sinh_vien(ma_sinh_vien,ho_ten,email,lop_id,ngay_sinh)
SELECT '20230597','Phạm Duy Hưng','hung.20230597@eaut.edu.vn',id,'2005-05-18' FROM lop_hoc WHERE ma_lop='DCCNTT14.2';
INSERT IGNORE INTO sinh_vien(ma_sinh_vien,ho_ten,email,lop_id,ngay_sinh)
SELECT '20240001','Nguyễn Văn An','an@gmail.com',id,'2005-01-10' FROM lop_hoc WHERE ma_lop='DCCNTT15.1';
INSERT IGNORE INTO sach(ma_sach,ten_sach,tac_gia,nha_xuat_ban,nam_xuat_ban) VALUES
('S001','Lập trình Java căn bản','Nguyễn Minh Tuấn','NXB Giáo dục',2024),
('S002','Jakarta EE thực hành','Trần Quốc Anh','NXB Khoa học',2025);
INSERT IGNORE INTO san_pham(ma_sp,ten_sp,mo_ta,gia,so_luong) VALUES
('SP001','Bàn phím cơ','Bàn phím dùng cho phòng máy',650000,12),
('SP002','Chuột không dây','Chuột văn phòng',280000,25);
