package vn.edu.eaut.lab9.listener;

import jakarta.persistence.*; import jakarta.servlet.*; import jakarta.servlet.annotation.WebListener;
import vn.edu.eaut.lab9.config.JPAUtil; import vn.edu.eaut.lab9.model.*;

@WebListener
public class AppDataSeeder implements ServletContextListener{
 public void contextInitialized(ServletContextEvent sce){EntityManager em=JPAUtil.getEntityManagerFactory().createEntityManager();EntityTransaction tx=em.getTransaction();try{tx.begin();
  if(em.createQuery("SELECT COUNT(l) FROM LopHoc l",Long.class).getSingleResult()==0){em.persist(new LopHoc("DCCNTT14.2","Công nghệ thông tin 14.2","Nguyễn Văn Minh"));em.persist(new LopHoc("DCCNTT15.1","Công nghệ thông tin 15.1","Trần Thu Hà"));}
  if(em.createQuery("SELECT COUNT(m) FROM MonHoc m",Long.class).getSingleResult()==0){em.persist(new MonHoc("JAVA","Công nghệ Java"));em.persist(new MonHoc("CSDL","Cơ sở dữ liệu"));}
  if(em.createQuery("SELECT COUNT(r) FROM Role r",Long.class).getSingleResult()==0){Role admin=new Role("ADMIN");Role user=new Role("USER");em.persist(admin);em.persist(user);NguoiDung nd=new NguoiDung();nd.setUsername("admin");nd.setPassword("123456");nd.setHoTen("Quản trị viên");nd.setRole(admin);em.persist(nd);}
  tx.commit();System.out.println("Lab 9: seed dữ liệu mẫu hoàn tất");}catch(RuntimeException ex){if(tx.isActive())tx.rollback();throw ex;}finally{em.close();}}
 public void contextDestroyed(ServletContextEvent sce){JPAUtil.close();}
}
