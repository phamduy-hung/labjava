package vn.edu.eaut.lab9.model;

import jakarta.persistence.*;

@Entity
@Table(name="diem", uniqueConstraints=@UniqueConstraint(columnNames={"sinh_vien_id","mon_hoc_id"}))
public class Diem {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    @ManyToOne(fetch=FetchType.EAGER) @JoinColumn(name="sinh_vien_id", nullable=false)
    private SinhVien sinhVien;
    @ManyToOne(fetch=FetchType.EAGER) @JoinColumn(name="mon_hoc_id", nullable=false)
    private MonHoc monHoc;
    @Column(name="chuyen_can") private Double chuyenCan=0.0;
    @Column(name="giua_ky") private Double giuaKy=0.0;
    @Column(name="cuoi_ky") private Double cuoiKy=0.0;

    public Diem(){}
    public Diem(SinhVien sinhVien, MonHoc monHoc){this.sinhVien=sinhVien;this.monHoc=monHoc;}
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public SinhVien getSinhVien(){return sinhVien;} public void setSinhVien(SinhVien sinhVien){this.sinhVien=sinhVien;}
    public MonHoc getMonHoc(){return monHoc;} public void setMonHoc(MonHoc monHoc){this.monHoc=monHoc;}
    public Double getChuyenCan(){return chuyenCan;} public void setChuyenCan(Double chuyenCan){this.chuyenCan=chuyenCan;}
    public Double getGiuaKy(){return giuaKy;} public void setGiuaKy(Double giuaKy){this.giuaKy=giuaKy;}
    public Double getCuoiKy(){return cuoiKy;} public void setCuoiKy(Double cuoiKy){this.cuoiKy=cuoiKy;}
    public double getTongKet(){return chuyenCan*0.1+giuaKy*0.3+cuoiKy*0.6;}
    public String getXepLoai(){double x=getTongKet(); return x>=8.5?"A":x>=7?"B":x>=5.5?"C":x>=4?"D":"F";}
}
