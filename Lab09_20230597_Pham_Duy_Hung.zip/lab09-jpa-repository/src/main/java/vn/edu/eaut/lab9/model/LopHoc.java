package vn.edu.eaut.lab9.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "lop_hoc")
public class LopHoc {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name="ma_lop", nullable=false, unique=true, length=30)
    private String maLop;
    @Column(name="ten_lop", nullable=false, length=100)
    private String tenLop;
    @Column(name="co_van", length=100)
    private String coVan;
    @OneToMany(mappedBy="lopHoc", fetch=FetchType.LAZY)
    private List<SinhVien> sinhViens = new ArrayList<>();

    public LopHoc() {}
    public LopHoc(String maLop, String tenLop, String coVan) { this.maLop=maLop; this.tenLop=tenLop; this.coVan=coVan; }
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getMaLop(){return maLop;} public void setMaLop(String maLop){this.maLop=maLop;}
    public String getTenLop(){return tenLop;} public void setTenLop(String tenLop){this.tenLop=tenLop;}
    public String getCoVan(){return coVan;} public void setCoVan(String coVan){this.coVan=coVan;}
    public List<SinhVien> getSinhViens(){return sinhViens;} public void setSinhViens(List<SinhVien> sinhViens){this.sinhViens=sinhViens;}
}
