package vn.edu.eaut.lab9.service;

import jakarta.persistence.*;
import vn.edu.eaut.lab9.config.JPAUtil;
import vn.edu.eaut.lab9.model.*;
import vn.edu.eaut.lab9.repository.SinhVienRepository;
import java.util.List;
import java.util.regex.Pattern;

public class SinhVienService {
    private final SinhVienRepository repo=new SinhVienRepository();
    private static final Pattern EMAIL=Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
    public List<SinhVien> findPage(String keyword,int page,int size){return repo.searchPage(keyword,page,size);}
    public long count(String keyword){return repo.countSearch(keyword);}
    public SinhVien findById(Integer id){return repo.findById(id);}
    public void saveOrUpdate(SinhVien sv){
        validate(sv);
        if(repo.existsByCode(sv.getMaSinhVien(),sv.getId())) throw new IllegalArgumentException("Mã sinh viên đã tồn tại");
        try{if(sv.getId()==null) repo.save(sv); else repo.update(sv);}
        catch(PersistenceException ex){throw new IllegalArgumentException("Không thể lưu dữ liệu. Kiểm tra mã sinh viên và ràng buộc CSDL.");}
    }
    public void delete(Integer id){repo.delete(id);}
    private void validate(SinhVien sv){
        if(sv.getMaSinhVien()==null||sv.getMaSinhVien().isBlank()) throw new IllegalArgumentException("Mã sinh viên không được để trống");
        if(sv.getHoTen()==null||sv.getHoTen().isBlank()) throw new IllegalArgumentException("Họ tên không được để trống");
        if(sv.getEmail()!=null&&!sv.getEmail().isBlank()&&!EMAIL.matcher(sv.getEmail()).matches()) throw new IllegalArgumentException("Email không đúng định dạng");
    }
    // Bài 11: sinh viên và điểm mặc định được tạo trong cùng một transaction.
    public void createWithDefaultScore(SinhVien sv,Integer monHocId){
        validate(sv);
        EntityManager em=JPAUtil.getEntityManagerFactory().createEntityManager(); EntityTransaction tx=em.getTransaction();
        try{tx.begin(); em.persist(sv); MonHoc mh=em.find(MonHoc.class,monHocId); if(mh==null) throw new IllegalArgumentException("Môn học không tồn tại");
            em.persist(new Diem(sv,mh)); tx.commit();}
        catch(RuntimeException ex){if(tx.isActive())tx.rollback(); throw ex;} finally{em.close();}
    }
}
