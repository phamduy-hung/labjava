package vn.edu.eaut.lab9.repository;

import jakarta.persistence.EntityManager;
import vn.edu.eaut.lab9.model.SinhVien;
import java.util.List;

public class SinhVienRepository extends BaseRepository<SinhVien,Integer> {
    public SinhVienRepository(){super(SinhVien.class);}
    @Override public List<SinhVien> findAll(){
        EntityManager em=createEntityManager();
        try{return em.createQuery("SELECT s FROM SinhVien s LEFT JOIN FETCH s.lopHoc ORDER BY s.id DESC",SinhVien.class).getResultList();}
        finally{em.close();}
    }
    public List<SinhVien> search(String keyword){return searchPage(keyword,1,1000);}
    public List<SinhVien> searchPage(String keyword,int page,int size){
        EntityManager em=createEntityManager();
        try{
            String k=keyword==null?"":keyword.trim().toLowerCase();
            String jpql="SELECT s FROM SinhVien s LEFT JOIN FETCH s.lopHoc l WHERE LOWER(s.hoTen) LIKE :kw OR LOWER(l.maLop) LIKE :kw ORDER BY s.id DESC";
            return em.createQuery(jpql,SinhVien.class).setParameter("kw","%"+k+"%")
                    .setFirstResult(Math.max(0,(page-1)*size)).setMaxResults(size).getResultList();
        }finally{em.close();}
    }
    public long countSearch(String keyword){
        EntityManager em=createEntityManager();
        try{String k=keyword==null?"":keyword.trim().toLowerCase();
            return em.createQuery("SELECT COUNT(s) FROM SinhVien s LEFT JOIN s.lopHoc l WHERE LOWER(s.hoTen) LIKE :kw OR LOWER(l.maLop) LIKE :kw",Long.class)
                    .setParameter("kw","%"+k+"%").getSingleResult();
        }finally{em.close();}
    }
    public boolean existsByCode(String code,Integer ignoreId){
        EntityManager em=createEntityManager();
        try{String jpql="SELECT COUNT(s) FROM SinhVien s WHERE s.maSinhVien=:code"+(ignoreId==null?"":" AND s.id<>:id");
            var q=em.createQuery(jpql,Long.class).setParameter("code",code);
            if(ignoreId!=null) q.setParameter("id",ignoreId);
            return q.getSingleResult()>0;
        }finally{em.close();}
    }
}
