package vn.edu.eaut.lab9.model;

import jakarta.persistence.*;

@Entity
@Table(name="role")
public class Role {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    @Column(name="ten_role", nullable=false, unique=true, length=30)
    private String tenRole;
    public Role(){}
    public Role(String tenRole){this.tenRole=tenRole;}
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getTenRole(){return tenRole;} public void setTenRole(String tenRole){this.tenRole=tenRole;}
}
