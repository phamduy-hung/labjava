package vn.edu.eaut.lab9.service;
import vn.edu.eaut.lab9.model.Sach; import vn.edu.eaut.lab9.repository.SachRepository; import java.util.*;
public class SachService{private final SachRepository repo=new SachRepository();
 public List<Sach> search(String k){return repo.search(k);} public Sach find(Integer id){return repo.findById(id);} public void delete(Integer id){repo.delete(id);}
 public void save(Sach s){if(s.getMaSach()==null||s.getMaSach().isBlank())throw new IllegalArgumentException("Mã sách bắt buộc"); if(s.getTenSach()==null||s.getTenSach().isBlank())throw new IllegalArgumentException("Tên sách bắt buộc"); if(s.getTacGia()==null||s.getTacGia().isBlank())throw new IllegalArgumentException("Tác giả bắt buộc"); if(s.getNamXuatBan()!=null&&(s.getNamXuatBan()<1900||s.getNamXuatBan()>2100))throw new IllegalArgumentException("Năm xuất bản không hợp lệ"); if(s.getId()==null)repo.save(s);else repo.update(s);}}
