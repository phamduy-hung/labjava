package vn.edu.eaut.lab9.model;

import jakarta.persistence.*;

@Entity
@Table(name="nguoi_dung")
public class NguoiDung {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable=false, unique=true, length=50)
    private String username;
    @Column(nullable=false, length=100)
    private String password;
    @Column(name="ho_ten", nullable=false, length=100)
    private String hoTen;
    @ManyToOne(fetch=FetchType.EAGER) @JoinColumn(name="role_id", nullable=false)
    private Role role;
    public NguoiDung(){}
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getUsername(){return username;} public void setUsername(String username){this.username=username;}
    public String getPassword(){return password;} public void setPassword(String password){this.password=password;}
    public String getHoTen(){return hoTen;} public void setHoTen(String hoTen){this.hoTen=hoTen;}
    public Role getRole(){return role;} public void setRole(Role role){this.role=role;}
}
