package vn.edu.eaut.lab9.repository;
import vn.edu.eaut.lab9.model.LopHoc;
public class LopHocRepository extends BaseRepository<LopHoc,Integer>{public LopHocRepository(){super(LopHoc.class);}}
