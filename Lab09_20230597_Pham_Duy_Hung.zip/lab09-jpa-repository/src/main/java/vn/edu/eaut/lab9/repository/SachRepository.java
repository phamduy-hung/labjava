package vn.edu.eaut.lab9.repository;
import jakarta.persistence.EntityManager;
import vn.edu.eaut.lab9.model.Sach;
import java.util.List;
public class SachRepository extends BaseRepository<Sach,Integer>{
    public SachRepository(){super(Sach.class);}
    public List<Sach> search(String keyword){EntityManager em=createEntityManager(); try{String k=keyword==null?"":keyword.toLowerCase();
        return em.createQuery("SELECT s FROM Sach s WHERE LOWER(s.tenSach) LIKE :kw OR LOWER(s.tacGia) LIKE :kw ORDER BY s.id DESC",Sach.class)
                .setParameter("kw","%"+k+"%").getResultList();}finally{em.close();}}
}
