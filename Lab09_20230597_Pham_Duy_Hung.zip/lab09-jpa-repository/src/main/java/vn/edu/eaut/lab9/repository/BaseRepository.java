package vn.edu.eaut.lab9.repository;

import jakarta.persistence.*;
import vn.edu.eaut.lab9.config.JPAUtil;
import java.util.List;

public abstract class BaseRepository<T, ID> {
    private final Class<T> entityClass;
    protected BaseRepository(Class<T> entityClass){this.entityClass=entityClass;}
    protected EntityManager createEntityManager(){return JPAUtil.getEntityManagerFactory().createEntityManager();}
    public List<T> findAll(){
        EntityManager em=createEntityManager();
        try{return em.createQuery("SELECT e FROM "+entityClass.getSimpleName()+" e", entityClass).getResultList();}
        finally{em.close();}
    }
    public T findById(ID id){EntityManager em=createEntityManager(); try{return em.find(entityClass,id);} finally{em.close();}}
    public void save(T entity){executeWrite(em->em.persist(entity));}
    public T update(T entity){final Object[] out=new Object[1]; executeWrite(em->out[0]=em.merge(entity)); return entityClass.cast(out[0]);}
    public void delete(ID id){executeWrite(em->{T e=em.find(entityClass,id); if(e!=null) em.remove(e);});}
    protected void executeWrite(java.util.function.Consumer<EntityManager> work){
        EntityManager em=createEntityManager(); EntityTransaction tx=em.getTransaction();
        try{tx.begin(); work.accept(em); tx.commit();}
        catch(RuntimeException ex){if(tx.isActive()) tx.rollback(); throw ex;}
        finally{em.close();}
    }
}
