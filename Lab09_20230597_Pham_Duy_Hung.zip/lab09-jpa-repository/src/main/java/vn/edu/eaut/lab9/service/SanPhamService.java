package vn.edu.eaut.lab9.service;
import vn.edu.eaut.lab9.model.SanPham; import vn.edu.eaut.lab9.repository.SanPhamRepository; import java.math.BigDecimal; import java.util.*;
public class SanPhamService{private final SanPhamRepository repo=new SanPhamRepository();
 public List<SanPham> search(String k){return repo.search(k);} public SanPham find(Integer id){return repo.findById(id);} public void delete(Integer id){repo.delete(id);}
 public void save(SanPham p){if(p.getMaSp()==null||p.getMaSp().isBlank())throw new IllegalArgumentException("Mã sản phẩm bắt buộc"); if(p.getTenSp()==null||p.getTenSp().isBlank())throw new IllegalArgumentException("Tên sản phẩm bắt buộc"); if(p.getGia()==null||p.getGia().compareTo(BigDecimal.ZERO)<=0)throw new IllegalArgumentException("Giá phải lớn hơn 0"); if(p.getSoLuong()==null||p.getSoLuong()<0)throw new IllegalArgumentException("Số lượng phải lớn hơn hoặc bằng 0"); if(p.getId()==null)repo.save(p);else repo.update(p);}}
