package vn.edu.eaut.lab9.model;

import jakarta.persistence.*;

@Entity
@Table(name="sach")
public class Sach {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    @Column(name="ma_sach", nullable=false, unique=true, length=30)
    private String maSach;
    @Column(name="ten_sach", nullable=false, length=150)
    private String tenSach;
    @Column(name="tac_gia", nullable=false, length=120)
    private String tacGia;
    @Column(name="nha_xuat_ban", length=120)
    private String nhaXuatBan;
    @Column(name="nam_xuat_ban")
    private Integer namXuatBan;
    public Sach(){}
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getMaSach(){return maSach;} public void setMaSach(String maSach){this.maSach=maSach;}
    public String getTenSach(){return tenSach;} public void setTenSach(String tenSach){this.tenSach=tenSach;}
    public String getTacGia(){return tacGia;} public void setTacGia(String tacGia){this.tacGia=tacGia;}
    public String getNhaXuatBan(){return nhaXuatBan;} public void setNhaXuatBan(String nhaXuatBan){this.nhaXuatBan=nhaXuatBan;}
    public Integer getNamXuatBan(){return namXuatBan;} public void setNamXuatBan(Integer namXuatBan){this.namXuatBan=namXuatBan;}
}
