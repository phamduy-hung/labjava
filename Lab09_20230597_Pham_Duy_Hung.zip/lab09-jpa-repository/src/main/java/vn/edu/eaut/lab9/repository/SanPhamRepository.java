package vn.edu.eaut.lab9.repository;
import jakarta.persistence.EntityManager;
import vn.edu.eaut.lab9.model.SanPham;
import java.util.List;
public class SanPhamRepository extends BaseRepository<SanPham,Integer>{
    public SanPhamRepository(){super(SanPham.class);}
    public List<SanPham> search(String keyword){EntityManager em=createEntityManager(); try{String k=keyword==null?"":keyword.toLowerCase();
        return em.createQuery("SELECT p FROM SanPham p WHERE LOWER(p.tenSp) LIKE :kw OR LOWER(p.maSp) LIKE :kw ORDER BY p.id DESC",SanPham.class)
                .setParameter("kw","%"+k+"%").getResultList();}finally{em.close();}}
}
