package vn.edu.eaut.lab9.model;

import jakarta.persistence.*;

@Entity
@Table(name="mon_hoc")
public class MonHoc {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    @Column(name="ma_mon", nullable=false, unique=true, length=20)
    private String maMon;
    @Column(name="ten_mon", nullable=false, length=100)
    private String tenMon;
    public MonHoc(){}
    public MonHoc(String maMon,String tenMon){this.maMon=maMon;this.tenMon=tenMon;}
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getMaMon(){return maMon;} public void setMaMon(String maMon){this.maMon=maMon;}
    public String getTenMon(){return tenMon;} public void setTenMon(String tenMon){this.tenMon=tenMon;}
}
