package vn.edu.eaut.lab9.repository;
import vn.edu.eaut.lab9.model.Diem;
public class DiemRepository extends BaseRepository<Diem,Integer>{public DiemRepository(){super(Diem.class);}}
