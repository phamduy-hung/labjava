package vn.edu.eaut.lab9.controller;

import jakarta.servlet.*; import jakarta.servlet.annotation.WebServlet; import jakarta.servlet.http.*;
import vn.edu.eaut.lab9.model.*; import vn.edu.eaut.lab9.repository.LopHocRepository; import vn.edu.eaut.lab9.service.SinhVienService;
import java.io.IOException; import java.time.LocalDate;

@WebServlet("/sinh-vien")
public class SinhVienController extends HttpServlet{
 private final SinhVienService service=new SinhVienService(); private final LopHocRepository lopRepo=new LopHocRepository();
 protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
  req.setCharacterEncoding("UTF-8"); String action=req.getParameter("action");
  try{
   if("delete".equals(action)){service.delete(Integer.valueOf(req.getParameter("id"))); flash(req,"success","Đã xóa sinh viên"); resp.sendRedirect(req.getContextPath()+"/sinh-vien");return;}
   if("new".equals(action)||"edit".equals(action)){if("edit".equals(action))req.setAttribute("sv",service.findById(Integer.valueOf(req.getParameter("id")))); req.setAttribute("lopList",lopRepo.findAll()); req.getRequestDispatcher("/views/sinhvien/form.jsp").forward(req,resp);return;}
   String keyword=req.getParameter("keyword"); int page=parsePage(req.getParameter("page")); int size=5; long total=service.count(keyword); int totalPages=(int)Math.max(1,Math.ceil(total/(double)size)); if(page>totalPages)page=totalPages;
   req.setAttribute("dsSinhVien",service.findPage(keyword,page,size)); req.setAttribute("keyword",keyword==null?"":keyword); req.setAttribute("page",page); req.setAttribute("totalPages",totalPages); req.getRequestDispatcher("/views/sinhvien/list.jsp").forward(req,resp);
  }catch(Exception ex){flash(req,"error",ex.getMessage());resp.sendRedirect(req.getContextPath()+"/sinh-vien");}
 }
 protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
  req.setCharacterEncoding("UTF-8"); SinhVien sv=new SinhVien(); String id=req.getParameter("id"); if(id!=null&&!id.isBlank())sv.setId(Integer.valueOf(id)); sv.setMaSinhVien(req.getParameter("maSinhVien")); sv.setHoTen(req.getParameter("hoTen")); sv.setEmail(req.getParameter("email")); String ns=req.getParameter("ngaySinh"); if(ns!=null&&!ns.isBlank())sv.setNgaySinh(LocalDate.parse(ns)); String lopId=req.getParameter("lopId"); if(lopId!=null&&!lopId.isBlank())sv.setLopHoc(lopRepo.findById(Integer.valueOf(lopId)));
  try{service.saveOrUpdate(sv);flash(req,"success","Lưu sinh viên thành công");resp.sendRedirect(req.getContextPath()+"/sinh-vien");}
  catch(Exception ex){req.setAttribute("error",ex.getMessage());req.setAttribute("sv",sv);req.setAttribute("lopList",lopRepo.findAll());req.getRequestDispatcher("/views/sinhvien/form.jsp").forward(req,resp);}
 }
 private int parsePage(String p){try{return Math.max(1,Integer.parseInt(p));}catch(Exception e){return 1;}}
 private void flash(HttpServletRequest req,String key,String value){req.getSession().setAttribute(key,value);}
}
