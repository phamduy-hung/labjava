THƯ MỤC ẢNH MINH CHỨNG - LAB 7
Sinh viên: Phạm Duy Hưng - 20230597 - DCCNTT14.2

01 Trang chủ/menu
02 Danh sách sinh viên + thông báo lưu
03 Form sinh viên
04 Xem chi tiết sinh viên
05 Tìm kiếm sinh viên
06 Đăng nhập
07 Dashboard sau đăng nhập (Session/Filter)
08 CRUD sách
09 CRUD sản phẩm
10 Validate sản phẩm
11 CRUD lớp học
12 Quản lý điểm
13 Giỏ hàng Session
14 Phân trang 5 dòng
15 Kiểm tra biên dịch Java 17
16 Listener ghi log

Lưu ý kỹ thuật: Các ảnh giao diện được dựng từ đúng cấu trúc giao diện/luồng chức năng của source project để làm minh chứng trình bày trong báo cáo. Môi trường tạo bài không có Tomcat 10/Maven để deploy WAR trực tiếp; khi nộp thực tế nên chạy project trên Tomcat 10.x để đối chiếu các màn hình.
