<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html><head><title>Trang chủ Lab 7</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head><body><div class="container"><%@ include file="/WEB-INF/header.jspf" %>

<h1>Lab 7 - CRUD bằng Servlet + JSP, dùng MVC đơn giản</h1>
<p class="muted">Ứng dụng thực hành mô hình MVC/Model 2 với dữ liệu lưu trong bộ nhớ.</p>
<div class="menu-grid">
<div class="card"><h3>Quản lý sinh viên</h3><p>CRUD, chi tiết, tìm kiếm và phân trang 5 dòng/trang.</p><a href="${pageContext.request.contextPath}/sinh-vien">Mở module</a></div>
<div class="card"><h3>Quản lý sách</h3><p>CRUD sách, tìm theo tên sách hoặc tác giả.</p><a href="${pageContext.request.contextPath}/sach">Mở module</a></div>
<div class="card"><h3>Quản lý sản phẩm</h3><p>CRUD sản phẩm, validate giá và số lượng.</p><a href="${pageContext.request.contextPath}/san-pham">Mở module</a></div>
<div class="card"><h3>Đăng nhập</h3><p>Session đăng nhập và Filter bảo vệ /admin/*.</p><a href="${pageContext.request.contextPath}/login.jsp">Đăng nhập</a></div>
<div class="card"><h3>Quản lý lớp học</h3><p>CRUD lớp học, tìm theo mã hoặc tên lớp.</p><a href="${pageContext.request.contextPath}/lop-hoc">Mở module</a></div>
<div class="card"><h3>Điểm & giỏ hàng</h3><p>Nhập điểm, xếp loại và quản lý giỏ hàng bằng Session.</p><a href="${pageContext.request.contextPath}/diem">Điểm</a> | <a href="${pageContext.request.contextPath}/gio-hang">Giỏ hàng</a></div>
</div>

<%@ include file="/WEB-INF/footer.jspf" %></div></body></html>