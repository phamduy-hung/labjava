package vn.edu.eaut.lab7.repository;
import vn.edu.eaut.lab7.model.LopHoc; import java.util.*; import java.util.stream.Collectors;
public class LopHocRepository {
    private static final List<LopHoc> data=new ArrayList<>(); private static int autoId=4;
    static{data.add(new LopHoc(1,"CNTT15101","CNTT 15.10.1","ThS. Nguyễn Văn Hải",42));data.add(new LopHoc(2,"CNTT15102","CNTT 15.10.2","ThS. Trần Thu Hà",40));data.add(new LopHoc(3,"CNTT142","DCCNTT14.2","ThS. Phạm Minh Anh",38));}
    public List<LopHoc> findAll(){return data;} public LopHoc findById(int id){return data.stream().filter(x->x.getId()==id).findFirst().orElse(null);} public void add(LopHoc x){x.setId(autoId++);data.add(x);} public void update(LopHoc x){LopHoc o=findById(x.getId());if(o!=null){o.setMaLop(x.getMaLop());o.setTenLop(x.getTenLop());o.setCoVanHocTap(x.getCoVanHocTap());o.setSoLuongSinhVien(x.getSoLuongSinhVien());}} public void delete(int id){data.removeIf(x->x.getId()==id);} public List<LopHoc> search(String key){if(key==null||key.isBlank())return new ArrayList<>(data);String k=key.toLowerCase();return data.stream().filter(x->x.getMaLop().toLowerCase().contains(k)||x.getTenLop().toLowerCase().contains(k)).collect(Collectors.toList());}
}
