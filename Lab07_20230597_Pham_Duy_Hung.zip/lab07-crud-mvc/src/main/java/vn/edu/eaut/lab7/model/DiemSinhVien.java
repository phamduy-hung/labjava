package vn.edu.eaut.lab7.model;
public class DiemSinhVien {
    private int id; private String maSinhVien; private String hoTen; private double chuyenCan; private double giuaKy; private double cuoiKy;
    public DiemSinhVien() {}
    public DiemSinhVien(int id,String maSinhVien,String hoTen,double chuyenCan,double giuaKy,double cuoiKy){this.id=id;this.maSinhVien=maSinhVien;this.hoTen=hoTen;this.chuyenCan=chuyenCan;this.giuaKy=giuaKy;this.cuoiKy=cuoiKy;}
    public int getId(){return id;} public void setId(int v){id=v;}
    public String getMaSinhVien(){return maSinhVien;} public void setMaSinhVien(String v){maSinhVien=v;}
    public String getHoTen(){return hoTen;} public void setHoTen(String v){hoTen=v;}
    public double getChuyenCan(){return chuyenCan;} public void setChuyenCan(double v){chuyenCan=v;}
    public double getGiuaKy(){return giuaKy;} public void setGiuaKy(double v){giuaKy=v;}
    public double getCuoiKy(){return cuoiKy;} public void setCuoiKy(double v){cuoiKy=v;}
    public double getTongKet(){ return Math.round(((chuyenCan + giuaKy + cuoiKy) / 3.0) * 100.0) / 100.0; }
    public String getXepLoai(){ double d=getTongKet(); if(d>=8.5)return "A"; if(d>=7.0)return "B"; if(d>=5.5)return "C"; if(d>=4.0)return "D"; return "F"; }
}
