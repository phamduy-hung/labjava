package vn.edu.eaut.lab7.controller;
import jakarta.servlet.*; import jakarta.servlet.annotation.WebServlet; import jakarta.servlet.http.*;
import vn.edu.eaut.lab7.model.SinhVien; import vn.edu.eaut.lab7.repository.SinhVienRepository;
import java.io.IOException; import java.util.*;
@WebServlet("/sinh-vien")
public class SinhVienController extends HttpServlet {
    private final SinhVienRepository repo=new SinhVienRepository();
    protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        req.setCharacterEncoding("UTF-8"); String action=req.getParameter("action");
        if("new".equals(action)){req.getRequestDispatcher("/views/sinhvien/form.jsp").forward(req,resp);return;}
        if("edit".equals(action)){req.setAttribute("sv",repo.findById(Integer.parseInt(req.getParameter("id"))));req.getRequestDispatcher("/views/sinhvien/form.jsp").forward(req,resp);return;}
        if("detail".equals(action)){req.setAttribute("sv",repo.findById(Integer.parseInt(req.getParameter("id"))));req.getRequestDispatcher("/views/sinhvien/detail.jsp").forward(req,resp);return;}
        if("delete".equals(action)){repo.delete(Integer.parseInt(req.getParameter("id")));resp.sendRedirect(req.getContextPath()+"/sinh-vien?msg=deleted");return;}
        List<SinhVien> all=repo.search(req.getParameter("keyword")); int page=parseInt(req.getParameter("page"),1); int pageSize=5; int totalPages=Math.max(1,(int)Math.ceil(all.size()/(double)pageSize)); if(page<1)page=1;if(page>totalPages)page=totalPages; int from=(page-1)*pageSize; int to=Math.min(from+pageSize,all.size());
        req.setAttribute("dsSinhVien",from<to?all.subList(from,to):Collections.emptyList());req.setAttribute("currentPage",page);req.setAttribute("totalPages",totalPages);req.setAttribute("keyword",req.getParameter("keyword"));
        req.getRequestDispatcher("/views/sinhvien/list.jsp").forward(req,resp);
    }
    protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException,ServletException{
        req.setCharacterEncoding("UTF-8"); String id=req.getParameter("id"); String ma=req.getParameter("maSinhVien"); String ten=req.getParameter("hoTen"); String email=req.getParameter("email"); String lop=req.getParameter("lop");
        if(ma==null||ma.isBlank()||ten==null||ten.isBlank()){req.setAttribute("error","Mã sinh viên và họ tên không được để trống");req.setAttribute("sv",new SinhVien(id==null||id.isBlank()?0:Integer.parseInt(id),ma,ten,email,lop));req.getRequestDispatcher("/views/sinhvien/form.jsp").forward(req,resp);return;}
        SinhVien sv=new SinhVien(id==null||id.isBlank()?0:Integer.parseInt(id),ma,ten,email,lop); if(sv.getId()==0)repo.add(sv);else repo.update(sv);resp.sendRedirect(req.getContextPath()+"/sinh-vien?msg=saved");
    }
    private int parseInt(String s,int d){try{return Integer.parseInt(s);}catch(Exception e){return d;}}
}
