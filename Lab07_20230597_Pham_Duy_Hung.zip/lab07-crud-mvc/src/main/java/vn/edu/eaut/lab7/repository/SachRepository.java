package vn.edu.eaut.lab7.repository;
import vn.edu.eaut.lab7.model.Sach; import java.util.*; import java.util.stream.Collectors;
public class SachRepository {
    private static final List<Sach> data=new ArrayList<>(); private static int autoId=5;
    static{data.add(new Sach(1,"S001","Lập trình Java căn bản","Nguyễn Văn A","NXB Giáo dục",2024));data.add(new Sach(2,"S002","Jakarta EE thực hành","Trần Minh B","NXB Thông tin",2025));data.add(new Sach(3,"S003","Cấu trúc dữ liệu","Lê Hoàng C","NXB Khoa học",2023));data.add(new Sach(4,"S004","Thiết kế Web Java","Phạm Anh D","NXB Công nghệ",2025));}
    public List<Sach> findAll(){return data;} public Sach findById(int id){return data.stream().filter(x->x.getId()==id).findFirst().orElse(null);} public void add(Sach x){x.setId(autoId++);data.add(x);} public void update(Sach x){Sach o=findById(x.getId());if(o!=null){o.setMaSach(x.getMaSach());o.setTenSach(x.getTenSach());o.setTacGia(x.getTacGia());o.setNhaXuatBan(x.getNhaXuatBan());o.setNamXuatBan(x.getNamXuatBan());}} public void delete(int id){data.removeIf(x->x.getId()==id);} public List<Sach> search(String key){if(key==null||key.isBlank())return new ArrayList<>(data);String k=key.toLowerCase();return data.stream().filter(x->x.getTenSach().toLowerCase().contains(k)||x.getTacGia().toLowerCase().contains(k)).collect(Collectors.toList());}
}
