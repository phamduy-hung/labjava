package vn.edu.eaut.lab7.model;
import java.math.BigDecimal;
public class CartItem {
    private SanPham sanPham; private int soLuong;
    public CartItem(SanPham sanPham,int soLuong){this.sanPham=sanPham;this.soLuong=soLuong;}
    public SanPham getSanPham(){return sanPham;} public void setSanPham(SanPham v){sanPham=v;}
    public int getSoLuong(){return soLuong;} public void setSoLuong(int v){soLuong=v;}
    public BigDecimal getThanhTien(){return sanPham.getGia().multiply(BigDecimal.valueOf(soLuong));}
}
