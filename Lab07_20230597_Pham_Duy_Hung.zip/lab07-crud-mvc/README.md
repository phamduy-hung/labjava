# Lab 7 - CRUD MVC Servlet + JSP

Sinh viên: Phạm Duy Hưng - MSSV 20230597 - Lớp DCCNTT14.2.

## Chạy project
1. Dùng JDK 17 hoặc 21, Maven và Tomcat 10.x.
2. Chạy `mvn clean package`.
3. Deploy `target/lab07-crud-mvc.war` lên Tomcat 10.x.
4. Truy cập `http://localhost:8080/lab07-crud-mvc/`.
5. Tài khoản thực hành của project: `admin / 123456`.

## Chức năng
- Bài 1-5 theo code gợi ý: trang chủ, MVC sinh viên, CRUD + JSTL, đăng nhập/Session/Filter.
- Bài 6-13: CRUD sách, sản phẩm, lớp học; điểm; giỏ hàng Session; phân trang 5 dòng; Listener; tổng hợp MVC.

Lưu ý: đề Lab 7 không quy định công thức điểm tổng kết và ngưỡng A/B/C/D/F. Project sử dụng trung bình cộng ba đầu điểm; A>=8.5, B>=7.0, C>=5.5, D>=4.0, còn lại F để hoàn thiện chức năng Bài 9.
