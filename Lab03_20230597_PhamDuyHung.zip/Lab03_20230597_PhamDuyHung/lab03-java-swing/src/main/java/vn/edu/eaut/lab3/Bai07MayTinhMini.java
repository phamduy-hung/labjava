package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;

public class Bai07MayTinhMini extends JFrame {
    private final JTextField txtNum1 = new JTextField();
    private final JTextField txtNum2 = new JTextField();
    private final JTextField txtResult = new JTextField();
    private final JTextArea txtHistory = new JTextArea(6, 30);

    public Bai07MayTinhMini() {
        setTitle("Bài 7 - Máy tính Mini");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        inputPanel.add(new JLabel("Số thứ 1:"));
        inputPanel.add(txtNum1);
        inputPanel.add(new JLabel("Số thứ 2:"));
        inputPanel.add(txtNum2);
        inputPanel.add(new JLabel("Kết quả:"));
        txtResult.setEditable(false);
        inputPanel.add(txtResult);

        JPanel btnPanel = new JPanel(new FlowLayout());
        JButton btnAdd = new JButton("+");
        JButton btnSub = new JButton("-");
        JButton btnMul = new JButton("*");
        JButton btnDiv = new JButton("/");
        JButton btnClear = new JButton("Clear");

        btnPanel.add(btnAdd);
        btnPanel.add(btnSub);
        btnPanel.add(btnMul);
        btnPanel.add(btnDiv);
        btnPanel.add(btnClear);

        btnAdd.addActionListener(e -> calculate('+'));
        btnSub.addActionListener(e -> calculate('-'));
        btnMul.addActionListener(e -> calculate('*'));
        btnDiv.addActionListener(e -> calculate('/'));
        btnClear.addActionListener(e -> clearForm());

        txtHistory.setEditable(false);

        add(inputPanel, BorderLayout.NORTH);
        add(btnPanel, BorderLayout.CENTER);
        add(new JScrollPane(txtHistory), BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
    }

    private void calculate(char op) {
        try {
            double n1 = Double.parseDouble(txtNum1.getText().trim());
            double n2 = Double.parseDouble(txtNum2.getText().trim());
            double res = 0;

            if (op == '/' && Math.abs(n2) < 1e-9) {
                JOptionPane.showMessageDialog(this, "Không thể chia cho 0!", "Lỗi toán học", JOptionPane.ERROR_MESSAGE);
                return;
            }

            switch (op) {
                case '+' -> res = n1 + n2;
                case '-' -> res = n1 - n2;
                case '*' -> res = n1 * n2;
                case '/' -> res = n1 / n2;
            }

            String record = String.format("%.2f %c %.2f = %.2f\n", n1, op, n2, res);
            txtResult.setText(String.format("%.2f", res));
            txtHistory.append(record);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập định dạng số hợp lệ!", "Lỗi nhập liệu", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        txtNum1.setText("");
        txtNum2.setText("");
        txtResult.setText("");
        txtNum1.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai07MayTinhMini().setVisible(true));
    }
}