package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;

public class Bai06LoginForm extends JFrame {
    private final JTextField txtUsername = new JTextField(15);
    private final JPasswordField txtPassword = new JPasswordField(15);
    private final JComboBox<String> cboRole = new JComboBox<>(new String[]{"Admin", "User"});
    private final JCheckBox chkShowPass = new JCheckBox("Hiển thị mật khẩu");

    public Bai06LoginForm() {
        setTitle("Bài 6 - Form Đăng Nhập");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel pnlForm = new JPanel(new GridLayout(4, 2, 8, 8));
        pnlForm.add(new JLabel("Tài khoản:"));
        pnlForm.add(txtUsername);
        pnlForm.add(new JLabel("Mật khẩu:"));
        pnlForm.add(txtPassword);
        pnlForm.add(new JLabel("Vai trò:"));
        pnlForm.add(cboRole);
        pnlForm.add(new JLabel(""));
        pnlForm.add(chkShowPass);

        JButton btnLogin = new JButton("Đăng nhập");
        
        chkShowPass.addActionListener(e -> {
            if (chkShowPass.isSelected()) {
                txtPassword.setEchoChar((char) 0);
            } else {
                txtPassword.setEchoChar('•');
            }
        });

        btnLogin.addActionListener(e -> handleLogin());

        add(pnlForm, BorderLayout.CENTER);
        add(btnLogin, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null);
    }

    private void handleLogin() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());
        String role = (String) cboRole.getSelectedItem();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (("admin".equals(username) && "123456".equals(password) && "Admin".equals(role)) ||
            ("user".equals(username) && "123456".equals(password) && "User".equals(role))) {
            JOptionPane.showMessageDialog(this, "Đăng nhập thành công với vai trò " + role + "!");
        } else {
            JOptionPane.showMessageDialog(this, "Tài khoản, mật khẩu hoặc vai trò không chính xác!", "Lỗi đăng nhập", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai06LoginForm().setVisible(true));
    }
}