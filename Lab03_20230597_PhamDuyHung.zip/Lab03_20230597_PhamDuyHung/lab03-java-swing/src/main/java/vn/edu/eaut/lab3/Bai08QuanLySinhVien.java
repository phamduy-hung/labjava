package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Bai08QuanLySinhVien extends JFrame {
    private final JTextField txtId = new JTextField();
    private final JTextField txtName = new JTextField();
    private final JTextField txtGpa = new JTextField();
    
    private final DefaultTableModel tableModel = new DefaultTableModel(
        new Object[]{"Mã SV", "Họ Tên", "Điểm TB", "Xếp Loại"}, 0
    );
    private final JTable table = new JTable(tableModel);

    public Bai08QuanLySinhVien() {
        setTitle("Bài 8 - Quản Lý Sinh Viên");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel pnlInput = new JPanel(new GridLayout(3, 2, 8, 8));
        pnlInput.add(new JLabel("Mã SV:"));
        pnlInput.add(txtId);
        pnlInput.add(new JLabel("Họ tên:"));
        pnlInput.add(txtName);
        pnlInput.add(new JLabel("Điểm TB:"));
        pnlInput.add(txtGpa);

        JPanel pnlButtons = new JPanel(new FlowLayout());
        JButton btnAdd = new JButton("Thêm");
        JButton btnEdit = new JButton("Sửa");
        JButton btnDelete = new JButton("Xóa");
        JButton btnClear = new JButton("Làm mới");

        pnlButtons.add(btnAdd);
        pnlButtons.add(btnEdit);
        pnlButtons.add(btnDelete);
        pnlButtons.add(btnClear);

        JPanel pnlTop = new JPanel(new BorderLayout());
        pnlTop.add(pnlInput, BorderLayout.CENTER);
        pnlTop.add(pnlButtons, BorderLayout.SOUTH);

        add(pnlTop, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnAdd.addActionListener(e -> addStudent());
        btnEdit.addActionListener(e -> editStudent());
        btnDelete.addActionListener(e -> deleteStudent());
        btnClear.addActionListener(e -> clearInput());

        table.getSelectionModel().addListSelectionListener(e -> fillToForm());

        setSize(550, 400);
        setLocationRelativeTo(null);
    }

    private void addStudent() {
        try {
            String id = txtId.getText().trim();
            String name = txtName.getText().trim();
            double gpa = Double.parseDouble(txtGpa.getText().trim());

            if (id.isEmpty() || name.isEmpty() || gpa < 0 || gpa > 10) {
                JOptionPane.showMessageDialog(this, "Dữ liệu không hợp lệ!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Student s = new Student(id, name, gpa);
            tableModel.addRow(new Object[]{s.getId(), s.getName(), s.getGpa(), s.getRank()});
            clearInput();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Điểm GPA phải là số từ 0.0 đến 10.0!");
        }
    }

    private void editStudent() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Chọn dòng cần sửa!");
            return;
        }
        try {
            String id = txtId.getText().trim();
            String name = txtName.getText().trim();
            double gpa = Double.parseDouble(txtGpa.getText().trim());

            Student s = new Student(id, name, gpa);
            tableModel.setValueAt(s.getId(), row, 0);
            tableModel.setValueAt(s.getName(), row, 1);
            tableModel.setValueAt(s.getGpa(), row, 2);
            tableModel.setValueAt(s.getRank(), row, 3);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật dữ liệu!");
        }
    }

    private void deleteStudent() {
        int row = table.getSelectedRow();
        if (row != -1) {
            tableModel.removeRow(row);
            clearInput();
        } else {
            JOptionPane.showMessageDialog(this, "Chọn dòng cần xóa!");
        }
    }

    private void fillToForm() {
        int row = table.getSelectedRow();
        if (row != -1) {
            txtId.setText(tableModel.getValueAt(row, 0).toString());
            txtName.setText(tableModel.getValueAt(row, 1).toString());
            txtGpa.setText(tableModel.getValueAt(row, 2).toString());
        }
    }

    private void clearInput() {
        txtId.setText("");
        txtName.setText("");
        txtGpa.setText("");
        table.clearSelection();
        txtId.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai08QuanLySinhVien().setVisible(true));
    }
}