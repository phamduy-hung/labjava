package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ProductLoaderFrame extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JButton btnLoad;

    public ProductLoaderFrame() {
        setTitle("Bài 9 - Tải danh sách sản phẩm giả lập");
        setSize(500, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        model = new DefaultTableModel(new String[]{"Mã SP", "Tên sản phẩm", "Giá (VNĐ)"}, 0);
        table = new JTable(model);
        btnLoad = new JButton("Tải dữ liệu");

        JPanel topPanel = new JPanel();
        topPanel.add(btnLoad);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnLoad.addActionListener(e -> loadProducts());
    }

    private void loadProducts() {
        model.setRowCount(0);
        btnLoad.setEnabled(false);

        SwingWorker<Void, Object[]> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                Object[][] sampleData = {
                    {"SP01", "Laptop Dell XPS 13", "32,000,000"},
                    {"SP02", "iPhone 15 Pro Max", "34,990,000"},
                    {"SP03", "Bàn phím Cơ Keychron", "2,100,000"},
                    {"SP04", "Chuột Logitech MX Master 3S", "2,450,000"},
                    {"SP05", "Màn hình LG UltraGear 27 inch", "7,800,000"}
                };

                for (Object[] row : sampleData) {
                    publish(row);
                    Thread.sleep(600); // Giả lập độ trễ nạp từng dòng
                }
                return null;
            }

            @Override
            protected void process(java.util.List<Object[]> chunks) {
                for (Object[] row : chunks) {
                    model.addRow(row);
                }
            }

            @Override
            protected void done() {
                btnLoad.setEnabled(true);
            }
        };
        worker.execute();
    }

    public static void main(String[] args) {
        App.setNiceUI();
        SwingUtilities.invokeLater(() -> new ProductLoaderFrame().setVisible(true));
    }
}