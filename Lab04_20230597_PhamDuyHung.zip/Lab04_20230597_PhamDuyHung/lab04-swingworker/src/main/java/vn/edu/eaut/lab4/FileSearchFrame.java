package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class FileSearchFrame extends JFrame {
    private JTextField txtDir, txtKeyword;
    private JButton btnSearch;
    private JTextArea txtResult;

    public FileSearchFrame() {
        setTitle("Bài 7 - Tìm kiếm File trong thư mục");
        setSize(550, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel topPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        topPanel.add(new JLabel("Thư mục:"));
        txtDir = new JTextField(System.getProperty("user.dir"));
        topPanel.add(txtDir);

        topPanel.add(new JLabel("Từ khóa tên file:"));
        txtKeyword = new JTextField(".java");
        topPanel.add(txtKeyword);

        btnSearch = new JButton("Tìm kiếm");
        txtResult = new JTextArea();
        txtResult.setEditable(false);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(txtResult), BorderLayout.CENTER);
        add(btnSearch, BorderLayout.SOUTH);

        btnSearch.addActionListener(e -> searchFiles());
    }

    private void searchFiles() {
        File dir = new File(txtDir.getText().trim());
        String keyword = txtKeyword.getText().trim().toLowerCase();

        if (!dir.exists() || !dir.isDirectory()) {
            JOptionPane.showMessageDialog(this, "Thư mục không tồn tại!");
            return;
        }

        txtResult.setText("");
        btnSearch.setEnabled(false);

        SwingWorker<Void, String> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() {
                searchRecursive(dir, keyword);
                return null;
            }

            private void searchRecursive(File folder, String kw) {
                File[] files = folder.listFiles();
                if (files != null) {
                    for (File f : files) {
                        if (f.isDirectory()) {
                            searchRecursive(f, kw);
                        } else if (f.getName().toLowerCase().contains(kw)) {
                            publish(f.getAbsolutePath());
                        }
                    }
                }
            }

            @Override
            protected void process(java.util.List<String> chunks) {
                for (String path : chunks) {
                    txtResult.append(path + "\n");
                }
            }

            @Override
            protected void done() {
                txtResult.append("\n=== HOÀN THÀNH TÌM KIẾM ===");
                btnSearch.setEnabled(true);
            }
        };
        worker.execute();
    }

    public static void main(String[] args) {
        App.setNiceUI();
        SwingUtilities.invokeLater(() -> new FileSearchFrame().setVisible(true));
    }
}