package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;

public class PrimeSumFrame extends JFrame {
    private JTextField txtN;
    private JButton btnCalc;
    private JLabel lblResult;

    public PrimeSumFrame() {
        setTitle("Bài 3 - Tính tổng số nguyên tố");
        setSize(420, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

        add(new JLabel("Nhập N:"));
        txtN = new JTextField(12);
        btnCalc = new JButton("Tính tổng");
        lblResult = new JLabel("Kết quả: ");
        lblResult.setFont(new Font("Segoe UI", Font.BOLD, 14));

        add(txtN);
        add(btnCalc);
        add(lblResult);

        btnCalc.addActionListener(e -> calculateSum());
    }

    private void calculateSum() {
        try {
            long n = Long.parseLong(txtN.getText().trim());
            btnCalc.setEnabled(false);
            lblResult.setText("Đang tính toán...");

            SwingWorker<Long, Void> worker = new SwingWorker<>() {
                @Override
                protected Long doInBackground() {
                    long sum = 0;
                    for (long i = 2; i <= n; i++) {
                        if (isPrime(i)) sum += i;
                    }
                    return sum;
                }

                @Override
                protected void done() {
                    try {
                        lblResult.setText("Tổng SNT <= " + n + " là: " + get());
                    } catch (Exception ex) {
                        lblResult.setText("Có lỗi xảy ra!");
                    }
                    btnCalc.setEnabled(true);
                }
            };
            worker.execute();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số nguyên hợp lệ!");
        }
    }

    private boolean isPrime(long num) {
        if (num < 2) return false;
        for (long i = 2; i * i <= num; i++) {
            if (num % i == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        App.setNiceUI();
        SwingUtilities.invokeLater(() -> new PrimeSumFrame().setVisible(true));
    }
}