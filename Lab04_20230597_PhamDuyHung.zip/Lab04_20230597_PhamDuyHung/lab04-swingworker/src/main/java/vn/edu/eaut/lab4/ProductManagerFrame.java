package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ProductManagerFrame extends JFrame {
    private JTextField txtCode, txtName, txtPrice;
    private JButton btnAdd;
    private JTable table;
    private DefaultTableModel model;

    public ProductManagerFrame() {
        setTitle("Bài 10 - Quản lý Sản Phẩm");
        setSize(600, 380);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel inputPanel = new JPanel(new GridLayout(2, 4, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        inputPanel.add(new JLabel("Mã SP:"));
        txtCode = new JTextField();
        inputPanel.add(txtCode);

        inputPanel.add(new JLabel("Tên SP:"));
        txtName = new JTextField();
        inputPanel.add(txtName);

        inputPanel.add(new JLabel("Giá SP:"));
        txtPrice = new JTextField();
        inputPanel.add(txtPrice);

        btnAdd = new JButton("Thêm SP");
        inputPanel.add(btnAdd);

        model = new DefaultTableModel(new String[]{"Mã SP", "Tên SP", "Giá (VNĐ)"}, 0);
        table = new JTable(model);

        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnAdd.addActionListener(e -> addProduct());
    }

    private void addProduct() {
        String code = txtCode.getText().trim();
        String name = txtName.getText().trim();
        String price = txtPrice.getText().trim();

        if (code.isEmpty() || name.isEmpty() || price.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
            return;
        }

        btnAdd.setEnabled(false);

        SwingWorker<Object[], Void> worker = new SwingWorker<>() {
            @Override
            protected Object[] doInBackground() throws Exception {
                Thread.sleep(400); // Giả lập xử lý lưu vào CSDL/File
                return new Object[]{code, name, price};
            }

            @Override
            protected void done() {
                try {
                    model.addRow(get());
                    txtCode.setText("");
                    txtName.setText("");
                    txtPrice.setText("");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(ProductManagerFrame.this, "Lỗi thêm sản phẩm!");
                }
                btnAdd.setEnabled(true);
            }
        };
        worker.execute();
    }

    public static void main(String[] args) {
        App.setNiceUI();
        SwingUtilities.invokeLater(() -> new ProductManagerFrame().setVisible(true));
    }
}