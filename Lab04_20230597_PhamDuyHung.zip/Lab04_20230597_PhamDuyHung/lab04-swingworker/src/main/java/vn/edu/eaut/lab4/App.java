package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;

public class App {
    public static void setNiceUI() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        Font defaultFont = new Font("Segoe UI", Font.PLAIN, 14);
        UIManager.put("Button.font", defaultFont);
        UIManager.put("Label.font", defaultFont);
        UIManager.put("TextField.font", defaultFont);
        UIManager.put("TextArea.font", defaultFont);
        UIManager.put("Table.font", defaultFont);
        UIManager.put("TableHeader.font", new Font("Segoe UI", Font.BOLD, 14));
        UIManager.put("ProgressBar.font", defaultFont);
    }

    public static void main(String[] args) {
        setNiceUI();
        SwingUtilities.invokeLater(() -> {
            // Mở CountdownFrame mặc định, bạn có thể đổi thành các Bài khác
            new CountdownFrame().setVisible(true);
        });
    }
}