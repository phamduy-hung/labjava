package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.SwingWorker; // Thêm import này
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;

public class StudentCsvFrame extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JButton btnLoad;
    private JLabel lblStat;

    public StudentCsvFrame() {
        setTitle("Bài 8 - Đọc CSV & Thống kê sinh viên");
        setSize(550, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        model = new DefaultTableModel(new String[]{"Mã SV", "Họ Tên", "Điểm"}, 0);
        table = new JTable(model);
        btnLoad = new JButton("Đọc file CSV");
        lblStat = new JLabel("Thống kê: Chưa có dữ liệu");

        JPanel topPanel = new JPanel();
        topPanel.add(btnLoad);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(lblStat, BorderLayout.SOUTH);

        btnLoad.addActionListener(e -> loadCsvData());
    }

    private void loadCsvData() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

        File csvFile = chooser.getSelectedFile();
        model.setRowCount(0);
        btnLoad.setEnabled(false);

        SwingWorker<double[], Object[]> worker = new SwingWorker<>() {
            @Override
            protected double[] doInBackground() throws Exception {
                double total = 0;
                int count = 0;
                double maxScore = -1;

                try (BufferedReader reader = Files.newBufferedReader(csvFile.toPath(), StandardCharsets.UTF_8)) {
                    String line = reader.readLine(); // Bỏ qua tiêu đề
                    while ((line = reader.readLine()) != null) {
                        String[] parts = line.split(",");
                        if (parts.length >= 3) {
                            String id = parts[0].trim();
                            String name = parts[1].trim();
                            double score = Double.parseDouble(parts[2].trim());

                            publish(new Object[]{id, name, score});

                            total += score;
                            count++;
                            if (score > maxScore) {
                                maxScore = score;
                            }
                        }
                    }
                }
                return new double[]{count == 0 ? 0 : total / count, maxScore};
            }

            @Override
            protected void process(List<Object[]> chunks) {
                for (Object[] row : chunks) {
                    model.addRow(row);
                }
            }

            @Override
            protected void done() {
                try {
                    double[] res = get();
                    lblStat.setText(String.format("Điểm trung bình: %.2f | Điểm cao nhất: %.1f", res[0], res[1]));
                } catch (Exception ex) {
                    lblStat.setText("Lỗi đọc file CSV");
                }
                btnLoad.setEnabled(true);
            }
        };
        worker.execute();
    }

    public static void main(String[] args) {
        App.setNiceUI();
        SwingUtilities.invokeLater(() -> new StudentCsvFrame().setVisible(true));
    }
}