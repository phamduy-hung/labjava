package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;

public class ProgressDemoFrame extends JFrame {
    private JProgressBar progressBar;
    private JButton btnStart;
    private JLabel lblStatus;

    public ProgressDemoFrame() {
        setTitle("Bài 2 - Tiến trình công việc");
        setSize(400, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));

        progressBar = new JProgressBar(0, 100);
        progressBar.setPreferredSize(new Dimension(340, 30));
        progressBar.setStringPainted(true);

        btnStart = new JButton("Bắt đầu xử lý");
        lblStatus = new JLabel("Trạng thái: Sẵn sàng");

        add(progressBar);
        add(btnStart);
        add(lblStatus);

        btnStart.addActionListener(e -> startProcess());
    }

    private void startProcess() {
        btnStart.setEnabled(false);
        progressBar.setValue(0);

        SwingWorker<Void, Integer> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                for (int i = 0; i <= 100; i++) {
                    publish(i);
                    Thread.sleep(50);
                }
                return null;
            }

            @Override
            protected void process(java.util.List<Integer> chunks) {
                int val = chunks.get(chunks.size() - 1);
                progressBar.setValue(val);
                lblStatus.setText("Đã hoàn thành: " + val + "%");
            }

            @Override
            protected void done() {
                lblStatus.setText("Trạng thái: Hoàn thành xuất sắc!");
                btnStart.setEnabled(true);
            }
        };
        worker.execute();
    }

    public static void main(String[] args) {
        App.setNiceUI();
        SwingUtilities.invokeLater(() -> new ProgressDemoFrame().setVisible(true));
    }
}