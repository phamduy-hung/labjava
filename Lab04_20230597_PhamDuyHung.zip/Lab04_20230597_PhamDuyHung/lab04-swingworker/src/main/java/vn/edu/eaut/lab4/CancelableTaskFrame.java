package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;

public class CancelableTaskFrame extends JFrame {
    private JProgressBar progressBar;
    private JButton btnStart, btnCancel;
    private JLabel lblStatus;
    private SwingWorker<Void, Integer> worker;

    public CancelableTaskFrame() {
        setTitle("Bài 6 - Tiến trình có thể hủy");
        setSize(420, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

        progressBar = new JProgressBar(0, 100);
        progressBar.setPreferredSize(new Dimension(360, 30));
        progressBar.setStringPainted(true);

        btnStart = new JButton("Bắt đầu");
        btnCancel = new JButton("Hủy bỏ");
        btnCancel.setEnabled(false);

        lblStatus = new JLabel("Trạng thái: Sẵn sàng");

        add(progressBar);
        add(btnStart);
        add(btnCancel);
        add(lblStatus);

        btnStart.addActionListener(e -> startTask());
        btnCancel.addActionListener(e -> cancelTask());
    }

    private void startTask() {
        btnStart.setEnabled(false);
        btnCancel.setEnabled(true);
        progressBar.setValue(0);

        worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                for (int i = 0; i <= 100; i++) {
                    if (isCancelled()) break;
                    publish(i);
                    Thread.sleep(100);
                }
                return null;
            }

            @Override
            protected void process(java.util.List<Integer> chunks) {
                int val = chunks.get(chunks.size() - 1);
                progressBar.setValue(val);
                lblStatus.setText("Đang chạy: " + val + "%");
            }

            @Override
            protected void done() {
                if (isCancelled()) {
                    lblStatus.setText("Trạng thái: Đã bị hủy!");
                } else {
                    lblStatus.setText("Trạng thái: Đã hoàn thành!");
                }
                btnStart.setEnabled(true);
                btnCancel.setEnabled(false);
            }
        };
        worker.execute();
    }

    private void cancelTask() {
        if (worker != null && !worker.isDone()) {
            worker.cancel(true);
        }
    }

    public static void main(String[] args) {
        App.setNiceUI();
        SwingUtilities.invokeLater(() -> new CancelableTaskFrame().setVisible(true));
    }
}