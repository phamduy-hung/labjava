package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class FileLineCounterFrame extends JFrame {
    private JButton btnChoose;
    private JLabel lblResult;

    public FileLineCounterFrame() {
        setTitle("Bài 5 - Đếm số dòng trong file");
        setSize(450, 180);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout(FlowLayout.CENTER, 15, 20));

        btnChoose = new JButton("Chọn File");
        lblResult = new JLabel("Số dòng: Chưa chọn file");

        add(btnChoose);
        add(lblResult);

        btnChoose.addActionListener(e -> countLines());
    }

    private void countLines() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

        File file = chooser.getSelectedFile();
        btnChoose.setEnabled(false);
        lblResult.setText("Đang đếm số dòng...");

        SwingWorker<Long, Void> worker = new SwingWorker<>() {
            @Override
            protected Long doInBackground() throws Exception {
                long lines = 0;
                try (BufferedReader reader = Files.newBufferedReader(file.toPath(), StandardCharsets.UTF_8)) {
                    while (reader.readLine() != null) {
                        lines++;
                    }
                }
                return lines;
            }

            @Override
            protected void done() {
                try {
                    lblResult.setText("Số dòng trong file '" + file.getName() + "': " + get());
                } catch (Exception ex) {
                    lblResult.setText("Lỗi khi đọc file!");
                }
                btnChoose.setEnabled(true);
            }
        };
        worker.execute();
    }

    public static void main(String[] args) {
        App.setNiceUI();
        SwingUtilities.invokeLater(() -> new FileLineCounterFrame().setVisible(true));
    }
}