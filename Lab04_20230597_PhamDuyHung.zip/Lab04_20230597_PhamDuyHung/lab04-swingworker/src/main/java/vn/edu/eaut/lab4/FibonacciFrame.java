package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;

public class FibonacciFrame extends JFrame {
    private JTextField txtN;
    private JButton btnCalc;
    private JLabel lblResult;

    public FibonacciFrame() {
        setTitle("Bài 4 - Tìm số Fibonacci thứ N");
        setSize(420, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

        add(new JLabel("Nhập N:"));
        txtN = new JTextField(12);
        btnCalc = new JButton("Tính Fibonacci");
        lblResult = new JLabel("Kết quả: ");
        lblResult.setFont(new Font("Segoe UI", Font.BOLD, 14));

        add(txtN);
        add(btnCalc);
        add(lblResult);

        btnCalc.addActionListener(e -> calculateFib());
    }

    private void calculateFib() {
        try {
            int n = Integer.parseInt(txtN.getText().trim());
            btnCalc.setEnabled(false);
            lblResult.setText("Đang tính toán...");

            SwingWorker<Long, Void> worker = new SwingWorker<>() {
                @Override
                protected Long doInBackground() {
                    if (n <= 0) return 0L;
                    if (n == 1) return 1L;
                    long a = 0, b = 1, c = 0;
                    for (int i = 2; i <= n; i++) {
                        c = a + b;
                        a = b;
                        b = c;
                    }
                    return b;
                }

                @Override
                protected void done() {
                    try {
                        lblResult.setText("Fibonacci thứ " + n + " là: " + get());
                    } catch (Exception ex) {
                        lblResult.setText("Có lỗi xảy ra!");
                    }
                    btnCalc.setEnabled(true);
                }
            };
            worker.execute();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số nguyên hợp lệ!");
        }
    }

    public static void main(String[] args) {
        App.setNiceUI();
        SwingUtilities.invokeLater(() -> new FibonacciFrame().setVisible(true));
    }
}