package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;

public class CountdownFrame extends JFrame {
    private JLabel lblTime;
    private JButton btnStart;

    public CountdownFrame() {
        setTitle("Bài 1 - Đếm ngược thời gian");
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());

        lblTime = new JLabel("10", SwingConstants.CENTER);
        lblTime.setFont(new Font("Segoe UI", Font.BOLD, 48));

        btnStart = new JButton("Bắt đầu đếm ngược");

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0; gbc.insets = new Insets(10, 10, 10, 10);
        add(lblTime, gbc);

        gbc.gridy = 1;
        add(btnStart, gbc);

        btnStart.addActionListener(e -> startCountdown());
    }

    private void startCountdown() {
        btnStart.setEnabled(false);
        SwingWorker<Void, Integer> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                for (int i = 10; i >= 0; i--) {
                    publish(i);
                    Thread.sleep(1000);
                }
                return null;
            }

            @Override
            protected void process(java.util.List<Integer> chunks) {
                int latest = chunks.get(chunks.size() - 1);
                lblTime.setText(String.valueOf(latest));
            }

            @Override
            protected void done() {
                lblTime.setText("Hoàn thành!");
                btnStart.setEnabled(true);
            }
        };
        worker.execute();
    }

    public static void main(String[] args) {
        App.setNiceUI();
        SwingUtilities.invokeLater(() -> new CountdownFrame().setVisible(true));
    }
}