LAB 5 - MINI SHOP - JAVA SWING + JDBC
Sinh vien: Pham Duy Hung
MSSV: 20230597
Lop: DCCNTT14.2

Cach chay:
1. Mo MySQL va chay file database/minishop_db.sql.
2. Neu MySQL root co mat khau, sua PASSWORD trong DBHelper.java.
3. Mo project bang IntelliJ/Eclipse/NetBeans, Maven reload dependency mysql-connector-j 8.4.0.
4. Chay vn.edu.eaut.lab5.App.

Tai khoan mau:
- admin / 123456
- nhanvien / 123456
- ketoan / 123456
