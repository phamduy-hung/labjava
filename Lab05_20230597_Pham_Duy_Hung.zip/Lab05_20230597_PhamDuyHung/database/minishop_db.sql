CREATE DATABASE minishop_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE minishop_db;

CREATE TABLE san_pham (
    ma_sp INT AUTO_INCREMENT PRIMARY KEY,
    ten_sp VARCHAR(100) NOT NULL,
    don_gia DECIMAL(12,2) NOT NULL,
    so_luong INT NOT NULL DEFAULT 0
);

CREATE TABLE khach_hang (
    ma_kh INT AUTO_INCREMENT PRIMARY KEY,
    ten_kh VARCHAR(100) NOT NULL,
    sdt VARCHAR(10) NOT NULL,
    dia_chi VARCHAR(255)
);

CREATE TABLE hoa_don (
    ma_hd INT AUTO_INCREMENT PRIMARY KEY,
    ngay_lap DATE NOT NULL,
    ma_kh INT NOT NULL,
    tong_tien DECIMAL(12,2) DEFAULT 0,
    FOREIGN KEY (ma_kh) REFERENCES khach_hang(ma_kh)
);

CREATE TABLE chi_tiet_hoa_don (
    ma_hd INT NOT NULL,
    ma_sp INT NOT NULL,
    so_luong INT NOT NULL,
    don_gia DECIMAL(12,2) NOT NULL,
    thanh_tien DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (ma_hd, ma_sp),
    FOREIGN KEY (ma_hd) REFERENCES hoa_don(ma_hd),
    FOREIGN KEY (ma_sp) REFERENCES san_pham(ma_sp)
);

INSERT INTO san_pham(ten_sp, don_gia, so_luong) VALUES
('Ban phim Logitech K120', 180000, 50),
('Chuot khong day Rapoo', 220000, 40),
('USB Kingston 32GB', 150000, 100),
('Tai nghe Sony Basic', 350000, 30);

INSERT INTO khach_hang(ten_kh, sdt, dia_chi) VALUES
('Nguyen Van An', '0912345678', 'Ha Noi'),
('Tran Thi Binh', '0987654321', 'Bac Ninh'),
('Le Van Cuong', '0901111222', 'Hai Duong');

-- Bài 6: mở rộng danh mục sản phẩm
CREATE TABLE danh_muc (
    ma_dm INT AUTO_INCREMENT PRIMARY KEY,
    ten_dm VARCHAR(100) NOT NULL
);

ALTER TABLE san_pham
ADD ma_dm INT NULL,
ADD FOREIGN KEY (ma_dm) REFERENCES danh_muc(ma_dm);

INSERT INTO danh_muc(ten_dm) VALUES
('Ban phim'), ('Chuot'), ('Luu tru'), ('Tai nghe');

UPDATE san_pham SET ma_dm = 1 WHERE ma_sp = 1;
UPDATE san_pham SET ma_dm = 2 WHERE ma_sp = 2;
UPDATE san_pham SET ma_dm = 3 WHERE ma_sp = 3;
UPDATE san_pham SET ma_dm = 4 WHERE ma_sp = 4;

-- Bài 10: đăng nhập và phân quyền
CREATE TABLE tai_khoan (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(100) NOT NULL,
    ho_ten VARCHAR(100) NOT NULL,
    vai_tro VARCHAR(20) NOT NULL
);

INSERT INTO tai_khoan(username, password, ho_ten, vai_tro) VALUES
('admin', '123456', 'Quan tri vien', 'ADMIN'),
('nhanvien', '123456', 'Nhan vien ban hang', 'NHANVIEN'),
('ketoan', '123456', 'Nhan vien ke toan', 'KETOAN');
