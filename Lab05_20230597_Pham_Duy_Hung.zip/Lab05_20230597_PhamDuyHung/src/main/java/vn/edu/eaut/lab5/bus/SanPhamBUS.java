package vn.edu.eaut.lab5.bus;

import vn.edu.eaut.lab5.dal.SanPhamDAL;
import vn.edu.eaut.lab5.model.SanPham;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class SanPhamBUS {
    private final SanPhamDAL sanPhamDAL=new SanPhamDAL();
    public List<SanPham> findAll() throws SQLException { return sanPhamDAL.findAll(); }
    public boolean save(SanPham sp) throws SQLException { validate(sp); return sp.getMaSp()==0?sanPhamDAL.insert(sp):sanPhamDAL.update(sp); }
    public boolean delete(int maSp) throws SQLException { if(maSp<=0) throw new IllegalArgumentException("Ma san pham khong hop le"); return sanPhamDAL.delete(maSp); }
    public List<SanPham> searchByName(String keyword) throws SQLException { return sanPhamDAL.searchByName(keyword); }
    public List<SanPham> searchAdvanced(String kw,BigDecimal minG,BigDecimal maxG,Integer minSl,Integer maxSl,Integer maDm,int page,int size) throws SQLException { return sanPhamDAL.searchAdvanced(kw,minG,maxG,minSl,maxSl,maDm,page,size); }
    public int countAdvanced(String kw,BigDecimal minG,BigDecimal maxG,Integer minSl,Integer maxSl,Integer maDm) throws SQLException { return sanPhamDAL.countAdvanced(kw,minG,maxG,minSl,maxSl,maDm); }
    private void validate(SanPham sp){
        if(sp.getTenSp()==null||sp.getTenSp().trim().isEmpty()) throw new IllegalArgumentException("Ten san pham khong duoc rong");
        if(sp.getDonGia()==null||sp.getDonGia().compareTo(BigDecimal.ZERO)<=0) throw new IllegalArgumentException("Don gia phai lon hon 0");
        if(sp.getSoLuong()<0) throw new IllegalArgumentException("So luong khong duoc am");
    }
}
