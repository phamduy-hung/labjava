package vn.edu.eaut.lab5.bus;

import vn.edu.eaut.lab5.dal.TaiKhoanDAL;
import vn.edu.eaut.lab5.model.TaiKhoan;
import java.sql.SQLException;
import java.util.List;

public class TaiKhoanBUS {
    private final TaiKhoanDAL dal=new TaiKhoanDAL();
    public TaiKhoan login(String username,String password)throws SQLException{
        if(username==null||username.isBlank()||password==null||password.isBlank()) throw new IllegalArgumentException("Username va password khong duoc rong");
        return dal.login(username.trim(),password);
    }
    public List<TaiKhoan> findAll() throws SQLException { return dal.findAll(); }
    public boolean save(TaiKhoan tk, boolean isNew) throws SQLException {
        if(tk.getUsername()==null||tk.getUsername().isBlank()) throw new IllegalArgumentException("Username khong duoc rong");
        if(tk.getPassword()==null||tk.getPassword().isBlank()) throw new IllegalArgumentException("Password khong duoc rong");
        if(tk.getHoTen()==null||tk.getHoTen().isBlank()) throw new IllegalArgumentException("Ho ten khong duoc rong");
        if(!List.of("ADMIN","NHANVIEN","KETOAN").contains(tk.getVaiTro())) throw new IllegalArgumentException("Vai tro khong hop le");
        return isNew?dal.insert(tk):dal.update(tk);
    }
    public boolean delete(String username) throws SQLException {
        if(username==null||username.isBlank()) throw new IllegalArgumentException("Chua chon tai khoan");
        return dal.delete(username);
    }
}
