package vn.edu.eaut.lab5.bus;

import vn.edu.eaut.lab5.dal.HoaDonDAL;
import vn.edu.eaut.lab5.model.ChiTietHoaDon;
import vn.edu.eaut.lab5.model.HoaDon;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class HoaDonBUS {
    private final HoaDonDAL dal=new HoaDonDAL();
    public int lapHoaDon(int maKh,List<ChiTietHoaDon> list)throws SQLException{
        if(maKh<=0)throw new IllegalArgumentException("Chua chon khach hang");
        if(list==null||list.isEmpty())throw new IllegalArgumentException("Hoa don phai co it nhat mot san pham");
        for(ChiTietHoaDon ct:list) if(ct.getSoLuong()<=0) throw new IllegalArgumentException("So luong ban phai lon hon 0");
        return dal.insertHoaDon(maKh,list);
    }
    public List<HoaDon> search(LocalDate from,LocalDate to,Integer maKh,BigDecimal minTong,BigDecimal maxTong)throws SQLException{return dal.search(from,to,maKh,minTong,maxTong);}
}
