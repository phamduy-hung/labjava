package vn.edu.eaut.lab5.ui;

import vn.edu.eaut.lab5.bus.TaiKhoanBUS;
import vn.edu.eaut.lab5.model.TaiKhoan;
import vn.edu.eaut.lab5.util.MessageUtil;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private final JTextField txtUser=new JTextField(18);
    private final JPasswordField txtPass=new JPasswordField(18);
    private final TaiKhoanBUS bus=new TaiKhoanBUS();
    public LoginFrame(){
        setTitle("MiniShop - Dang nhap"); setDefaultCloseOperation(EXIT_ON_CLOSE); setSize(420,230); setLocationRelativeTo(null);
        JPanel form=new JPanel(new GridLayout(3,2,8,8)); form.setBorder(BorderFactory.createEmptyBorder(30,35,30,35));
        form.add(new JLabel("Username:")); form.add(txtUser); form.add(new JLabel("Password:")); form.add(txtPass);
        JButton btn=new JButton("Dang nhap"); form.add(new JLabel()); form.add(btn); add(form);
        btn.addActionListener(e->login()); getRootPane().setDefaultButton(btn);
    }
    private void login(){
        try{
            TaiKhoan tk=bus.login(txtUser.getText(),new String(txtPass.getPassword()));
            if(tk==null){MessageUtil.info(this,"Sai username hoac password");return;}
            dispose(); new MainFrame(tk).setVisible(true);
        }catch(Exception ex){MessageUtil.error(this,ex);}
    }
}
