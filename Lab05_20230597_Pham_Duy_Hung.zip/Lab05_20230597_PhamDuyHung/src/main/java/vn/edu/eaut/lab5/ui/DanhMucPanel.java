package vn.edu.eaut.lab5.ui;

import vn.edu.eaut.lab5.bus.DanhMucBUS;import vn.edu.eaut.lab5.model.DanhMuc;import vn.edu.eaut.lab5.util.MessageUtil;import javax.swing.*;import javax.swing.table.DefaultTableModel;import java.awt.*;

public class DanhMucPanel extends JPanel {
    private final DanhMucBUS bus=new DanhMucBUS();private final JTextField txtMa=new JTextField(6),txtTen=new JTextField(20);private final DefaultTableModel model=new DefaultTableModel(new Object[]{"Ma","Ten danh muc"},0){public boolean isCellEditable(int r,int c){return false;}};private final JTable table=new JTable(model);
    public DanhMucPanel(){setLayout(new BorderLayout());txtMa.setEditable(false);JPanel p=new JPanel();p.add(new JLabel("Ma:"));p.add(txtMa);p.add(new JLabel("Ten:"));p.add(txtTen);JButton save=new JButton("Them/Sua"),del=new JButton("Xoa"),clear=new JButton("Lam moi");p.add(save);p.add(del);p.add(clear);add(p,BorderLayout.NORTH);add(new JScrollPane(table),BorderLayout.CENTER);save.addActionListener(e->save());del.addActionListener(e->delete());clear.addActionListener(e->clear());table.getSelectionModel().addListSelectionListener(e->fill());load();}
    private void load(){try{model.setRowCount(0);for(DanhMuc d:bus.findAll())model.addRow(new Object[]{d.getMaDm(),d.getTenDm()});}catch(Exception e){MessageUtil.error(this,e);}}
    private void save(){try{DanhMuc d=new DanhMuc(txtMa.getText().isBlank()?0:Integer.parseInt(txtMa.getText()),txtTen.getText());bus.save(d);MessageUtil.info(this,"Luu danh muc thanh cong");clear();load();}catch(Exception e){MessageUtil.error(this,e);}}
    private void delete(){try{if(txtMa.getText().isBlank())throw new IllegalArgumentException("Chua chon danh muc");if(MessageUtil.confirm(this,"Xoa danh muc dang chon?")){bus.delete(Integer.parseInt(txtMa.getText()));clear();load();}}catch(Exception e){MessageUtil.error(this,e);}}
    private void clear(){txtMa.setText("");txtTen.setText("");table.clearSelection();}private void fill(){int r=table.getSelectedRow();if(r>=0){txtMa.setText(model.getValueAt(r,0).toString());txtTen.setText(model.getValueAt(r,1).toString());}}
}
