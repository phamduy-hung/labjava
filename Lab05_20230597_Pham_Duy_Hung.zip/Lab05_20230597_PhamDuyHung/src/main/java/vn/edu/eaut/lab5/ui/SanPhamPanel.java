package vn.edu.eaut.lab5.ui;

import vn.edu.eaut.lab5.bus.DanhMucBUS;
import vn.edu.eaut.lab5.bus.SanPhamBUS;
import vn.edu.eaut.lab5.model.DanhMuc;
import vn.edu.eaut.lab5.model.SanPham;
import vn.edu.eaut.lab5.util.MessageUtil;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

public class SanPhamPanel extends JPanel {
    private final SanPhamBUS bus=new SanPhamBUS(); private final DanhMucBUS dmBus=new DanhMucBUS();
    private final JTextField txtMa=new JTextField(6),txtTen=new JTextField(18),txtGia=new JTextField(10),txtSl=new JTextField(8);
    private final JComboBox<DanhMuc> cboDm=new JComboBox<>();
    private final JTextField txtSearch=new JTextField(12),txtMinGia=new JTextField(7),txtMaxGia=new JTextField(7),txtMinSl=new JTextField(5),txtMaxSl=new JTextField(5);
    private final JComboBox<Object> cboFilterDm=new JComboBox<>();
    private final DefaultTableModel model=new DefaultTableModel(new Object[]{"Ma","Ten san pham","Don gia","So luong","Danh muc","Canh bao"},0){public boolean isCellEditable(int r,int c){return false;}};
    private final JTable table=new JTable(model); private int page=1; private final int pageSize=10; private final JLabel lblPage=new JLabel("Trang 1");
    public SanPhamPanel(){setLayout(new BorderLayout(8,8));build();loadDanhMuc();loadData();}
    private void build(){
        txtMa.setEditable(false);
        JPanel form=new JPanel(new FlowLayout(FlowLayout.LEFT)); form.add(new JLabel("Ma:"));form.add(txtMa);form.add(new JLabel("Ten:"));form.add(txtTen);form.add(new JLabel("Gia:"));form.add(txtGia);form.add(new JLabel("SL:"));form.add(txtSl);form.add(new JLabel("Danh muc:"));form.add(cboDm);
        JButton btnSave=new JButton("Them/Sua"),btnDel=new JButton("Xoa"),btnNew=new JButton("Lam moi");form.add(btnSave);form.add(btnDel);form.add(btnNew); table.setAutoCreateRowSorter(true);
        JPanel search=new JPanel(new FlowLayout(FlowLayout.LEFT));search.add(new JLabel("Ten:"));search.add(txtSearch);search.add(new JLabel("Gia tu:"));search.add(txtMinGia);search.add(new JLabel("den:"));search.add(txtMaxGia);search.add(new JLabel("SL tu:"));search.add(txtMinSl);search.add(new JLabel("den:"));search.add(txtMaxSl);search.add(new JLabel("DM:"));search.add(cboFilterDm);JButton btnSearch=new JButton("Tim");search.add(btnSearch);
        JPanel north=new JPanel(new GridLayout(2,1));north.add(form);north.add(search);add(north,BorderLayout.NORTH);add(new JScrollPane(table),BorderLayout.CENTER);
        JPanel nav=new JPanel();JButton first=new JButton("Dau"),prev=new JButton("Truoc"),next=new JButton("Sau"),last=new JButton("Cuoi");nav.add(first);nav.add(prev);nav.add(lblPage);nav.add(next);nav.add(last);add(nav,BorderLayout.SOUTH);
        btnSave.addActionListener(e->save());btnDel.addActionListener(e->delete());btnNew.addActionListener(e->{clear();loadDanhMuc();loadData();});btnSearch.addActionListener(e->{page=1;loadData();});
        table.getSelectionModel().addListSelectionListener(e->fill()); first.addActionListener(e->{page=1;loadData();});prev.addActionListener(e->{if(page>1)page--;loadData();});next.addActionListener(e->{page++;loadData();});last.addActionListener(e->{try{int n=count();page=Math.max(1,(n+pageSize-1)/pageSize);loadData();}catch(Exception ex){MessageUtil.error(this,ex);}});
    }
    private BigDecimal dec(String s){return s.isBlank()?null:new BigDecimal(s.trim());} private Integer integer(String s){return s.isBlank()?null:Integer.valueOf(s.trim());}
    private int count()throws Exception{return bus.countAdvanced(txtSearch.getText(),dec(txtMinGia.getText()),dec(txtMaxGia.getText()),integer(txtMinSl.getText()),integer(txtMaxSl.getText()),selectedFilterDm());}
    private Integer selectedFilterDm(){Object o=cboFilterDm.getSelectedItem();return o instanceof DanhMuc?((DanhMuc)o).getMaDm():null;}
    private void loadDanhMuc(){try{List<DanhMuc> list=dmBus.findAll();cboDm.removeAllItems();cboFilterDm.removeAllItems();cboFilterDm.addItem("Tat ca");for(DanhMuc d:list){cboDm.addItem(d);cboFilterDm.addItem(d);}}catch(Exception e){MessageUtil.error(this,e);}}
    private void loadData(){
        final String kw=txtSearch.getText();
        final BigDecimal minG,maxG; final Integer minS,maxS,dm;
        try{minG=dec(txtMinGia.getText());maxG=dec(txtMaxGia.getText());minS=integer(txtMinSl.getText());maxS=integer(txtMaxSl.getText());dm=selectedFilterDm();}
        catch(Exception e){MessageUtil.error(this,e);return;}
        new SwingWorker<Object[],Void>(){
            protected Object[] doInBackground() throws Exception {
                int n=bus.countAdvanced(kw,minG,maxG,minS,maxS,dm);
                int last=Math.max(1,(n+pageSize-1)/pageSize);
                int target=Math.min(page,last);
                List<SanPham> list=bus.searchAdvanced(kw,minG,maxG,minS,maxS,dm,target,pageSize);
                return new Object[]{n,last,target,list};
            }
            @SuppressWarnings("unchecked") protected void done(){
                try{Object[] r=get();page=(Integer)r[2];List<SanPham> list=(List<SanPham>)r[3];model.setRowCount(0);for(SanPham sp:list)model.addRow(new Object[]{sp.getMaSp(),sp.getTenSp(),sp.getDonGia(),sp.getSoLuong(),sp.getTenDm(),sp.getSoLuong()<5?"Ton kho thap":""});lblPage.setText("Trang "+page+"/"+r[1]);}
                catch(Exception e){MessageUtil.error(SanPhamPanel.this,e);}
            }
        }.execute();
    }
    public void refreshData(){loadDanhMuc();loadData();}
    private void save(){try{SanPham sp=new SanPham();sp.setMaSp(txtMa.getText().isBlank()?0:Integer.parseInt(txtMa.getText()));sp.setTenSp(txtTen.getText());sp.setDonGia(new BigDecimal(txtGia.getText().trim()));sp.setSoLuong(Integer.parseInt(txtSl.getText().trim()));DanhMuc dm=(DanhMuc)cboDm.getSelectedItem();sp.setMaDm(dm==null?null:dm.getMaDm());bus.save(sp);MessageUtil.info(this,"Luu san pham thanh cong");clear();loadData();}catch(Exception e){MessageUtil.error(this,e);}}
    private void delete(){try{if(txtMa.getText().isBlank())throw new IllegalArgumentException("Chua chon san pham");if(MessageUtil.confirm(this,"Xoa san pham dang chon?")){bus.delete(Integer.parseInt(txtMa.getText()));clear();loadData();}}catch(Exception e){MessageUtil.error(this,e);}}
    private void clear(){txtMa.setText("");txtTen.setText("");txtGia.setText("");txtSl.setText("");table.clearSelection();}
    private void fill(){int r=table.getSelectedRow();if(r<0)return;txtMa.setText(model.getValueAt(r,0).toString());txtTen.setText(model.getValueAt(r,1).toString());txtGia.setText(model.getValueAt(r,2).toString());txtSl.setText(model.getValueAt(r,3).toString());String dm=String.valueOf(model.getValueAt(r,4));for(int i=0;i<cboDm.getItemCount();i++)if(cboDm.getItemAt(i).toString().equals(dm))cboDm.setSelectedIndex(i);}
}
