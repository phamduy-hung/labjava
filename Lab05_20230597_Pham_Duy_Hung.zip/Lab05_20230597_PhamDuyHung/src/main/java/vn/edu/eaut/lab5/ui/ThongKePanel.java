package vn.edu.eaut.lab5.ui;

import vn.edu.eaut.lab5.bus.ThongKeBUS;import vn.edu.eaut.lab5.util.MessageUtil;import vn.edu.eaut.lab5.worker.DoanhThuWorker;import javax.swing.*;import java.awt.*;import java.time.LocalDate;

public class ThongKePanel extends JPanel {
    private final ThongKeBUS bus=new ThongKeBUS();private final JTextField txtFrom=new JTextField(10),txtTo=new JTextField(10);private final JLabel lblRevenue=new JLabel("Doanh thu: 0 VND"),lblMax=new JLabel("Hoa don cao nhat: "),lblBest=new JLabel("San pham ban chay: ");
    public ThongKePanel(){setLayout(new BorderLayout());JPanel top=new JPanel();top.add(new JLabel("Tu ngay yyyy-MM-dd:"));top.add(txtFrom);top.add(new JLabel("Den ngay:"));top.add(txtTo);JButton btn=new JButton("Thong ke doanh thu");top.add(btn);add(top,BorderLayout.NORTH);JPanel center=new JPanel(new GridLayout(3,1,8,8));center.setBorder(BorderFactory.createEmptyBorder(25,25,25,25));center.add(lblRevenue);center.add(lblMax);center.add(lblBest);add(center,BorderLayout.CENTER);JButton refresh=new JButton("Cap nhat HD cao nhat va SP ban chay");add(refresh,BorderLayout.SOUTH);btn.addActionListener(e->revenue());refresh.addActionListener(e->summary());}
    private void revenue(){try{LocalDate a=LocalDate.parse(txtFrom.getText().trim()),b=LocalDate.parse(txtTo.getText().trim());new DoanhThuWorker(a,b,bus,lblRevenue).execute();}catch(Exception e){MessageUtil.error(this,e);}}
    private void summary(){new SwingWorker<String[],Void>(){protected String[] doInBackground()throws Exception{return new String[]{bus.hoaDonCaoNhat(),bus.sanPhamBanChay()};}protected void done(){try{String[] r=get();lblMax.setText("Hoa don cao nhat: "+r[0]);lblBest.setText("San pham ban chay: "+r[1]);}catch(Exception e){MessageUtil.error(ThongKePanel.this,e);}}}.execute();}
}
