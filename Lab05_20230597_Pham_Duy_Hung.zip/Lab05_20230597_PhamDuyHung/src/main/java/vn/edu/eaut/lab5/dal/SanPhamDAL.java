package vn.edu.eaut.lab5.dal;

import vn.edu.eaut.lab5.config.DBHelper;
import vn.edu.eaut.lab5.model.SanPham;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SanPhamDAL {
    private SanPham map(ResultSet rs) throws SQLException {
        SanPham sp = new SanPham();
        sp.setMaSp(rs.getInt("ma_sp"));
        sp.setTenSp(rs.getString("ten_sp"));
        sp.setDonGia(rs.getBigDecimal("don_gia"));
        sp.setSoLuong(rs.getInt("so_luong"));
        int maDm = rs.getInt("ma_dm");
        sp.setMaDm(rs.wasNull() ? null : maDm);
        sp.setTenDm(rs.getString("ten_dm"));
        return sp;
    }

    public List<SanPham> findAll() throws SQLException {
        return searchAdvanced("", null, null, null, null, null, 1, 1000);
    }

    public boolean insert(SanPham sp) throws SQLException {
        String sql = "INSERT INTO san_pham(ten_sp, don_gia, so_luong, ma_dm) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBHelper.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, sp.getTenSp());
            ps.setBigDecimal(2, sp.getDonGia());
            ps.setInt(3, sp.getSoLuong());
            if (sp.getMaDm() == null) ps.setNull(4, Types.INTEGER); else ps.setInt(4, sp.getMaDm());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean update(SanPham sp) throws SQLException {
        String sql = "UPDATE san_pham SET ten_sp=?, don_gia=?, so_luong=?, ma_dm=? WHERE ma_sp=?";
        try (Connection conn = DBHelper.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, sp.getTenSp());
            ps.setBigDecimal(2, sp.getDonGia());
            ps.setInt(3, sp.getSoLuong());
            if (sp.getMaDm() == null) ps.setNull(4, Types.INTEGER); else ps.setInt(4, sp.getMaDm());
            ps.setInt(5, sp.getMaSp());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int maSp) throws SQLException {
        String sql = "DELETE FROM san_pham WHERE ma_sp=?";
        try (Connection conn = DBHelper.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maSp);
            return ps.executeUpdate() > 0;
        }
    }

    public List<SanPham> searchByName(String keyword) throws SQLException {
        return searchAdvanced(keyword, null, null, null, null, null, 1, 1000);
    }

    public List<SanPham> searchAdvanced(String keyword, BigDecimal minGia, BigDecimal maxGia,
                                        Integer minSl, Integer maxSl, Integer maDm,
                                        int page, int pageSize) throws SQLException {
        List<SanPham> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT sp.ma_sp, sp.ten_sp, sp.don_gia, sp.so_luong, sp.ma_dm, dm.ten_dm " +
                "FROM san_pham sp LEFT JOIN danh_muc dm ON sp.ma_dm=dm.ma_dm WHERE sp.ten_sp LIKE ?");
        List<Object> params = new ArrayList<>();
        params.add("%" + (keyword == null ? "" : keyword) + "%");
        if (minGia != null) { sql.append(" AND sp.don_gia>=?"); params.add(minGia); }
        if (maxGia != null) { sql.append(" AND sp.don_gia<=?"); params.add(maxGia); }
        if (minSl != null) { sql.append(" AND sp.so_luong>=?"); params.add(minSl); }
        if (maxSl != null) { sql.append(" AND sp.so_luong<=?"); params.add(maxSl); }
        if (maDm != null) { sql.append(" AND sp.ma_dm=?"); params.add(maDm); }
        sql.append(" ORDER BY sp.ma_sp LIMIT ? OFFSET ?");
        params.add(pageSize);
        params.add((page - 1) * pageSize);

        try (Connection conn = DBHelper.getConnection(); PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            setParams(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    public int countAdvanced(String keyword, BigDecimal minGia, BigDecimal maxGia,
                             Integer minSl, Integer maxSl, Integer maDm) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM san_pham WHERE ten_sp LIKE ?");
        List<Object> params = new ArrayList<>();
        params.add("%" + (keyword == null ? "" : keyword) + "%");
        if (minGia != null) { sql.append(" AND don_gia>=?"); params.add(minGia); }
        if (maxGia != null) { sql.append(" AND don_gia<=?"); params.add(maxGia); }
        if (minSl != null) { sql.append(" AND so_luong>=?"); params.add(minSl); }
        if (maxSl != null) { sql.append(" AND so_luong<=?"); params.add(maxSl); }
        if (maDm != null) { sql.append(" AND ma_dm=?"); params.add(maDm); }
        try (Connection conn = DBHelper.getConnection(); PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            setParams(ps, params);
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1); }
        }
    }

    private void setParams(PreparedStatement ps, List<Object> params) throws SQLException {
        for (int i = 0; i < params.size(); i++) {
            Object p = params.get(i);
            if (p instanceof BigDecimal) ps.setBigDecimal(i + 1, (BigDecimal) p);
            else if (p instanceof Integer) ps.setInt(i + 1, (Integer) p);
            else ps.setString(i + 1, String.valueOf(p));
        }
    }
}
