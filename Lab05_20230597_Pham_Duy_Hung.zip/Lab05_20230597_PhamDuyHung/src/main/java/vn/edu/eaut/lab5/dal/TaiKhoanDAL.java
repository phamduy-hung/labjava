package vn.edu.eaut.lab5.dal;

import vn.edu.eaut.lab5.config.DBHelper;
import vn.edu.eaut.lab5.model.TaiKhoan;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TaiKhoanDAL {
    private TaiKhoan map(ResultSet rs) throws SQLException {
        TaiKhoan tk=new TaiKhoan();
        tk.setUsername(rs.getString("username"));
        tk.setPassword(rs.getString("password"));
        tk.setHoTen(rs.getString("ho_ten"));
        tk.setVaiTro(rs.getString("vai_tro"));
        return tk;
    }
    public TaiKhoan login(String username,String password) throws SQLException {
        String sql="SELECT username,password,ho_ten,vai_tro FROM tai_khoan WHERE username=? AND password=?";
        try(Connection c=DBHelper.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,username); ps.setString(2,password);
            try(ResultSet rs=ps.executeQuery()){ return rs.next()?map(rs):null; }
        }
    }
    public List<TaiKhoan> findAll() throws SQLException {
        List<TaiKhoan> list=new ArrayList<>();
        try(Connection c=DBHelper.getConnection(); PreparedStatement ps=c.prepareStatement("SELECT username,password,ho_ten,vai_tro FROM tai_khoan ORDER BY username"); ResultSet rs=ps.executeQuery()){
            while(rs.next()) list.add(map(rs));
        }
        return list;
    }
    public boolean insert(TaiKhoan tk) throws SQLException {
        try(Connection c=DBHelper.getConnection(); PreparedStatement ps=c.prepareStatement("INSERT INTO tai_khoan(username,password,ho_ten,vai_tro) VALUES(?,?,?,?)")){
            ps.setString(1,tk.getUsername()); ps.setString(2,tk.getPassword()); ps.setString(3,tk.getHoTen()); ps.setString(4,tk.getVaiTro()); return ps.executeUpdate()>0;
        }
    }
    public boolean update(TaiKhoan tk) throws SQLException {
        try(Connection c=DBHelper.getConnection(); PreparedStatement ps=c.prepareStatement("UPDATE tai_khoan SET password=?,ho_ten=?,vai_tro=? WHERE username=?")){
            ps.setString(1,tk.getPassword()); ps.setString(2,tk.getHoTen()); ps.setString(3,tk.getVaiTro()); ps.setString(4,tk.getUsername()); return ps.executeUpdate()>0;
        }
    }
    public boolean delete(String username) throws SQLException {
        try(Connection c=DBHelper.getConnection(); PreparedStatement ps=c.prepareStatement("DELETE FROM tai_khoan WHERE username=?")){
            ps.setString(1,username); return ps.executeUpdate()>0;
        }
    }
}
