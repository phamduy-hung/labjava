package vn.edu.eaut.lab5.ui;

import vn.edu.eaut.lab5.bus.TaiKhoanBUS;
import vn.edu.eaut.lab5.model.TaiKhoan;
import vn.edu.eaut.lab5.util.MessageUtil;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class TaiKhoanPanel extends JPanel {
    private final TaiKhoanBUS bus=new TaiKhoanBUS();
    private final JTextField txtUser=new JTextField(10),txtPass=new JTextField(10),txtName=new JTextField(16);
    private final JComboBox<String> cboRole=new JComboBox<>(new String[]{"ADMIN","NHANVIEN","KETOAN"});
    private final DefaultTableModel model=new DefaultTableModel(new Object[]{"Username","Ho ten","Vai tro"},0){public boolean isCellEditable(int r,int c){return false;}};
    private final JTable table=new JTable(model);
    public TaiKhoanPanel(){
        setLayout(new BorderLayout());
        JPanel p=new JPanel(); p.add(new JLabel("Username:"));p.add(txtUser);p.add(new JLabel("Password:"));p.add(txtPass);p.add(new JLabel("Ho ten:"));p.add(txtName);p.add(new JLabel("Vai tro:"));p.add(cboRole);
        JButton save=new JButton("Them/Sua"),del=new JButton("Xoa"),clear=new JButton("Lam moi");p.add(save);p.add(del);p.add(clear);add(p,BorderLayout.NORTH);add(new JScrollPane(table),BorderLayout.CENTER);
        save.addActionListener(e->save());del.addActionListener(e->delete());clear.addActionListener(e->clear());table.getSelectionModel().addListSelectionListener(e->fill());load();
    }
    private void load(){try{model.setRowCount(0);for(TaiKhoan t:bus.findAll())model.addRow(new Object[]{t.getUsername(),t.getHoTen(),t.getVaiTro()});}catch(Exception e){MessageUtil.error(this,e);}}
    private void save(){try{boolean isNew=txtUser.isEditable();TaiKhoan t=new TaiKhoan();t.setUsername(txtUser.getText().trim());t.setPassword(txtPass.getText());t.setHoTen(txtName.getText());t.setVaiTro((String)cboRole.getSelectedItem());bus.save(t,isNew);MessageUtil.info(this,"Luu tai khoan thanh cong");clear();load();}catch(Exception e){MessageUtil.error(this,e);}}
    private void delete(){try{String u=txtUser.getText().trim();if(MessageUtil.confirm(this,"Xoa tai khoan "+u+"?")){bus.delete(u);clear();load();}}catch(Exception e){MessageUtil.error(this,e);}}
    private void clear(){txtUser.setText("");txtPass.setText("");txtName.setText("");cboRole.setSelectedIndex(0);txtUser.setEditable(true);table.clearSelection();}
    private void fill(){int r=table.getSelectedRow();if(r<0)return;txtUser.setText(model.getValueAt(r,0).toString());txtName.setText(model.getValueAt(r,1).toString());cboRole.setSelectedItem(model.getValueAt(r,2).toString());txtPass.setText("");txtUser.setEditable(false);}
}
