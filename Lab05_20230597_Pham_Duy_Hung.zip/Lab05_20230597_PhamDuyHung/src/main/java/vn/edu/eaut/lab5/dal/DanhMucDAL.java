package vn.edu.eaut.lab5.dal;

import vn.edu.eaut.lab5.config.DBHelper;
import vn.edu.eaut.lab5.model.DanhMuc;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DanhMucDAL {
    public List<DanhMuc> findAll() throws SQLException {
        List<DanhMuc> list=new ArrayList<>();
        try(Connection c=DBHelper.getConnection(); PreparedStatement ps=c.prepareStatement("SELECT ma_dm,ten_dm FROM danh_muc ORDER BY ma_dm"); ResultSet rs=ps.executeQuery()){
            while(rs.next()) list.add(new DanhMuc(rs.getInt(1),rs.getString(2)));
        }
        return list;
    }
    public boolean insert(DanhMuc dm) throws SQLException {
        try(Connection c=DBHelper.getConnection(); PreparedStatement ps=c.prepareStatement("INSERT INTO danh_muc(ten_dm) VALUES(?)")){
            ps.setString(1,dm.getTenDm()); return ps.executeUpdate()>0;
        }
    }
    public boolean update(DanhMuc dm) throws SQLException {
        try(Connection c=DBHelper.getConnection(); PreparedStatement ps=c.prepareStatement("UPDATE danh_muc SET ten_dm=? WHERE ma_dm=?")){
            ps.setString(1,dm.getTenDm()); ps.setInt(2,dm.getMaDm()); return ps.executeUpdate()>0;
        }
    }
    public boolean hasProducts(int maDm) throws SQLException {
        try(Connection c=DBHelper.getConnection(); PreparedStatement ps=c.prepareStatement("SELECT COUNT(*) FROM san_pham WHERE ma_dm=?")){
            ps.setInt(1,maDm); try(ResultSet rs=ps.executeQuery()){ rs.next(); return rs.getInt(1)>0; }
        }
    }
    public boolean delete(int maDm) throws SQLException {
        try(Connection c=DBHelper.getConnection(); PreparedStatement ps=c.prepareStatement("DELETE FROM danh_muc WHERE ma_dm=?")){
            ps.setInt(1,maDm); return ps.executeUpdate()>0;
        }
    }
}
