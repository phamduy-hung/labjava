package vn.edu.eaut.lab5.ui;

import vn.edu.eaut.lab5.model.TaiKhoan;
import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    public MainFrame(TaiKhoan tk){
        setTitle("MiniShop - "+tk.getHoTen()+" ["+tk.getVaiTro()+"]"); setDefaultCloseOperation(EXIT_ON_CLOSE); setSize(1100,720); setLocationRelativeTo(null);
        JTabbedPane tabs=new JTabbedPane();
        switch(tk.getVaiTro()){
            case "ADMIN" -> {tabs.addTab("San pham",new SanPhamPanel());tabs.addTab("Khach hang",new KhachHangPanel());tabs.addTab("Hoa don",new HoaDonPanel(true));tabs.addTab("Thong ke",new ThongKePanel());tabs.addTab("Danh muc",new DanhMucPanel());tabs.addTab("Tai khoan",new TaiKhoanPanel());}
            case "NHANVIEN" -> {tabs.addTab("San pham",new SanPhamPanel());tabs.addTab("Khach hang",new KhachHangPanel());tabs.addTab("Hoa don",new HoaDonPanel(true));}
            case "KETOAN" -> {tabs.addTab("Hoa don",new HoaDonPanel(false));tabs.addTab("Thong ke",new ThongKePanel());}
            default -> tabs.addTab("Thong ke",new ThongKePanel());
        }
        tabs.addChangeListener(e->{Component c=tabs.getSelectedComponent();if(c instanceof SanPhamPanel)((SanPhamPanel)c).refreshData();});
        JButton logout=new JButton("Dang xuat"); logout.addActionListener(e->{dispose();new LoginFrame().setVisible(true);});
        JPanel top=new JPanel(new BorderLayout()); top.add(new JLabel("Nguoi dung: "+tk.getHoTen()+" - Vai tro: "+tk.getVaiTro()),BorderLayout.WEST); top.add(logout,BorderLayout.EAST);
        add(top,BorderLayout.NORTH); add(tabs,BorderLayout.CENTER);
    }
}
