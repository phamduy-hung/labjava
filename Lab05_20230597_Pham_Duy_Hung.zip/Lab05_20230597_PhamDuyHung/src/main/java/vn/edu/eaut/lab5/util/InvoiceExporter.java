package vn.edu.eaut.lab5.util;

import vn.edu.eaut.lab5.model.ChiTietHoaDon;
import vn.edu.eaut.lab5.model.KhachHang;
import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.List;

public class InvoiceExporter {
    public static File exportCsv(int maHd,KhachHang kh,List<ChiTietHoaDon> list)throws IOException{
        File dir=new File("exports"); if(!dir.exists())dir.mkdirs();
        File file=new File(dir,"HoaDon_"+maHd+".csv");
        try(PrintWriter out=new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8))){
            out.println("Ma hoa don,"+maHd);
            out.println("Ngay lap,"+ LocalDate.now());
            out.println("Khach hang,\""+kh.getTenKh()+"\"");
            out.println("So dien thoai,"+kh.getSdt());
            out.println("Ten san pham,So luong,Don gia,Thanh tien");
            BigDecimal tong=BigDecimal.ZERO;
            for(ChiTietHoaDon ct:list){
                out.printf("\"%s\",%d,%s,%s%n",ct.getTenSp().replace("\"","\"\""),ct.getSoLuong(),ct.getDonGia(),ct.getThanhTien());
                tong=tong.add(ct.getThanhTien());
            }
            out.println("Tong tien,,,"+tong);
        }
        return file;
    }
}
