package vn.edu.eaut.lab5.ui;

import vn.edu.eaut.lab5.bus.KhachHangBUS;
import vn.edu.eaut.lab5.model.KhachHang;
import vn.edu.eaut.lab5.util.MessageUtil;
import vn.edu.eaut.lab5.util.PhoneDocumentFilter;
import javax.swing.*;import javax.swing.table.DefaultTableModel;import javax.swing.text.AbstractDocument;import java.awt.*;

public class KhachHangPanel extends JPanel {
    private final KhachHangBUS bus=new KhachHangBUS(); private final JTextField txtMa=new JTextField(5),txtTen=new JTextField(16),txtSdt=new JTextField(10),txtDiaChi=new JTextField(16); private final JTextField sTen=new JTextField(10),sSdt=new JTextField(9),sDc=new JTextField(10);
    private final DefaultTableModel model=new DefaultTableModel(new Object[]{"Ma","Ten","SDT","Dia chi"},0){public boolean isCellEditable(int r,int c){return false;}}; private final JTable table=new JTable(model);
    public KhachHangPanel(){setLayout(new BorderLayout(8,8));txtMa.setEditable(false);((AbstractDocument)txtSdt.getDocument()).setDocumentFilter(new PhoneDocumentFilter());JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT));p.add(new JLabel("Ma:"));p.add(txtMa);p.add(new JLabel("Ten:"));p.add(txtTen);p.add(new JLabel("SDT:"));p.add(txtSdt);p.add(new JLabel("Dia chi:"));p.add(txtDiaChi);JButton save=new JButton("Them/Sua"),del=new JButton("Xoa"),clear=new JButton("Lam moi");p.add(save);p.add(del);p.add(clear);JPanel s=new JPanel(new FlowLayout(FlowLayout.LEFT));s.add(new JLabel("Tim ten:"));s.add(sTen);s.add(new JLabel("SDT:"));s.add(sSdt);s.add(new JLabel("Dia chi:"));s.add(sDc);JButton find=new JButton("Tim");s.add(find);JPanel north=new JPanel(new GridLayout(2,1));north.add(p);north.add(s);add(north,BorderLayout.NORTH);add(new JScrollPane(table),BorderLayout.CENTER);save.addActionListener(e->save());del.addActionListener(e->delete());clear.addActionListener(e->clear());find.addActionListener(e->load());table.getSelectionModel().addListSelectionListener(e->fill());load();}
    private void load(){try{model.setRowCount(0);for(KhachHang k:bus.search(sTen.getText(),sSdt.getText(),sDc.getText()))model.addRow(new Object[]{k.getMaKh(),k.getTenKh(),k.getSdt(),k.getDiaChi()});}catch(Exception e){MessageUtil.error(this,e);}}
    private void save(){try{KhachHang k=new KhachHang();k.setMaKh(txtMa.getText().isBlank()?0:Integer.parseInt(txtMa.getText()));k.setTenKh(txtTen.getText());k.setSdt(txtSdt.getText());k.setDiaChi(txtDiaChi.getText());bus.save(k);MessageUtil.info(this,"Luu khach hang thanh cong");clear();load();}catch(Exception e){MessageUtil.error(this,e);}}
    private void delete(){try{if(txtMa.getText().isBlank())throw new IllegalArgumentException("Chua chon khach hang");if(MessageUtil.confirm(this,"Xoa khach hang dang chon?")){bus.delete(Integer.parseInt(txtMa.getText()));clear();load();}}catch(Exception e){MessageUtil.error(this,e);}}
    private void clear(){txtMa.setText("");txtTen.setText("");txtSdt.setText("");txtDiaChi.setText("");table.clearSelection();}
    private void fill(){int r=table.getSelectedRow();if(r<0)return;txtMa.setText(model.getValueAt(r,0).toString());txtTen.setText(model.getValueAt(r,1).toString());txtSdt.setText(model.getValueAt(r,2).toString());txtDiaChi.setText(String.valueOf(model.getValueAt(r,3)));}
}
