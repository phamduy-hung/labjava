package vn.edu.eaut.lab5.dal;

import vn.edu.eaut.lab5.config.DBHelper;
import vn.edu.eaut.lab5.model.ChiTietHoaDon;
import vn.edu.eaut.lab5.model.HoaDon;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class HoaDonDAL {
    public int insertHoaDon(int maKh, List<ChiTietHoaDon> chiTietList) throws SQLException {
        String sqlHoaDon="INSERT INTO hoa_don(ngay_lap,ma_kh,tong_tien) VALUES(?,?,?)";
        String sqlChiTiet="INSERT INTO chi_tiet_hoa_don(ma_hd,ma_sp,so_luong,don_gia,thanh_tien) VALUES(?,?,?,?,?)";
        String sqlTruKho="UPDATE san_pham SET so_luong=so_luong-? WHERE ma_sp=? AND so_luong>=?";
        Connection conn=null;
        try {
            conn=DBHelper.getConnection();
            conn.setAutoCommit(false);
            BigDecimal tongTien=tinhTongTien(chiTietList);
            int maHd;
            try(PreparedStatement ps=conn.prepareStatement(sqlHoaDon,Statement.RETURN_GENERATED_KEYS)){
                ps.setDate(1,Date.valueOf(LocalDate.now())); ps.setInt(2,maKh); ps.setBigDecimal(3,tongTien); ps.executeUpdate();
                try(ResultSet rs=ps.getGeneratedKeys()){
                    if(rs.next()) maHd=rs.getInt(1); else throw new SQLException("Khong lay duoc ma hoa don");
                }
            }
            try(PreparedStatement psKho=conn.prepareStatement(sqlTruKho); PreparedStatement psCt=conn.prepareStatement(sqlChiTiet)){
                for(ChiTietHoaDon ct:chiTietList){
                    psKho.setInt(1,ct.getSoLuong()); psKho.setInt(2,ct.getMaSp()); psKho.setInt(3,ct.getSoLuong());
                    if(psKho.executeUpdate()==0) throw new SQLException("Ton kho khong du cho san pham ma "+ct.getMaSp());
                    psCt.setInt(1,maHd); psCt.setInt(2,ct.getMaSp()); psCt.setInt(3,ct.getSoLuong()); psCt.setBigDecimal(4,ct.getDonGia()); psCt.setBigDecimal(5,ct.getThanhTien()); psCt.addBatch();
                }
                psCt.executeBatch();
            }
            conn.commit();
            return maHd;
        } catch(SQLException e){
            if(conn!=null) conn.rollback();
            throw e;
        } finally {
            if(conn!=null){ conn.setAutoCommit(true); conn.close(); }
        }
    }

    private BigDecimal tinhTongTien(List<ChiTietHoaDon> list){
        return list.stream().map(ChiTietHoaDon::getThanhTien).reduce(BigDecimal.ZERO,BigDecimal::add);
    }

    public List<HoaDon> search(LocalDate tuNgay, LocalDate denNgay, Integer maKh, BigDecimal minTong, BigDecimal maxTong) throws SQLException {
        List<HoaDon> list=new ArrayList<>();
        StringBuilder sql=new StringBuilder("SELECT hd.ma_hd,hd.ngay_lap,hd.ma_kh,kh.ten_kh,hd.tong_tien FROM hoa_don hd JOIN khach_hang kh ON hd.ma_kh=kh.ma_kh WHERE 1=1");
        List<Object> params=new ArrayList<>();
        if(tuNgay!=null){sql.append(" AND hd.ngay_lap>=?");params.add(Date.valueOf(tuNgay));}
        if(denNgay!=null){sql.append(" AND hd.ngay_lap<=?");params.add(Date.valueOf(denNgay));}
        if(maKh!=null){sql.append(" AND hd.ma_kh=?");params.add(maKh);}
        if(minTong!=null){sql.append(" AND hd.tong_tien>=?");params.add(minTong);}
        if(maxTong!=null){sql.append(" AND hd.tong_tien<=?");params.add(maxTong);}
        sql.append(" ORDER BY hd.ma_hd DESC");
        try(Connection c=DBHelper.getConnection(); PreparedStatement ps=c.prepareStatement(sql.toString())){
            for(int i=0;i<params.size();i++) ps.setObject(i+1,params.get(i));
            try(ResultSet rs=ps.executeQuery()){
                while(rs.next()){
                    HoaDon hd=new HoaDon(); hd.setMaHd(rs.getInt("ma_hd")); hd.setNgayLap(rs.getDate("ngay_lap").toLocalDate()); hd.setMaKh(rs.getInt("ma_kh")); hd.setTenKh(rs.getString("ten_kh")); hd.setTongTien(rs.getBigDecimal("tong_tien")); list.add(hd);
                }
            }
        }
        return list;
    }
}
