package vn.edu.eaut.hotelmanagement.model.enums;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Kiểm thử tự động các state machine nghiệp vụ cốt lõi.
 * Không cần kết nối CSDL; chỉ kiểm tra các quy tắc chuyển trạng thái.
 */
class StateMachineTest {

    @Test
    void roomFlowAllowsOnlyValidOperationalTransitions() {
        assertTrue(TrangThaiPhong.TRONG.canTransitionTo(TrangThaiPhong.DA_DAT));
        assertTrue(TrangThaiPhong.DA_DAT.canTransitionTo(TrangThaiPhong.DANG_O));
        assertTrue(TrangThaiPhong.DANG_O.canTransitionTo(TrangThaiPhong.DANG_DON));
        assertTrue(TrangThaiPhong.DANG_DON.canTransitionTo(TrangThaiPhong.TRONG));
        assertTrue(TrangThaiPhong.TRONG.canTransitionTo(TrangThaiPhong.BAO_TRI));
        assertTrue(TrangThaiPhong.BAO_TRI.canTransitionTo(TrangThaiPhong.TRONG));
    }

    @Test
    void roomFlowRejectsInvalidShortcuts() {
        assertFalse(TrangThaiPhong.TRONG.canTransitionTo(TrangThaiPhong.DANG_O));
        assertFalse(TrangThaiPhong.TRONG.canTransitionTo(TrangThaiPhong.DANG_DON));
        assertFalse(TrangThaiPhong.DA_DAT.canTransitionTo(TrangThaiPhong.TRONG));
        assertFalse(TrangThaiPhong.DANG_O.canTransitionTo(TrangThaiPhong.TRONG));
        assertFalse(TrangThaiPhong.DANG_DON.canTransitionTo(TrangThaiPhong.DANG_O));
        assertFalse(TrangThaiPhong.BAO_TRI.canTransitionTo(TrangThaiPhong.DANG_O));
        assertFalse(TrangThaiPhong.TRONG.canTransitionTo(null));
    }

    @Test
    void bookingFlowAllowsExpectedTransitions() {
        assertTrue(TrangThaiDatPhong.CHO_XAC_NHAN.canTransitionTo(TrangThaiDatPhong.DA_XAC_NHAN));
        assertTrue(TrangThaiDatPhong.DA_XAC_NHAN.canTransitionTo(TrangThaiDatPhong.DA_NHAN_PHONG));
        assertTrue(TrangThaiDatPhong.DA_NHAN_PHONG.canTransitionTo(TrangThaiDatPhong.DA_TRA_PHONG));
        assertTrue(TrangThaiDatPhong.DA_XAC_NHAN.canTransitionTo(TrangThaiDatPhong.DA_HUY));
        assertTrue(TrangThaiDatPhong.DA_XAC_NHAN.canTransitionTo(TrangThaiDatPhong.KHONG_DEN));
    }

    @Test
    void bookingFlowRejectsChangesAfterFinalState() {
        assertFalse(TrangThaiDatPhong.DA_TRA_PHONG.canTransitionTo(TrangThaiDatPhong.DA_XAC_NHAN));
        assertFalse(TrangThaiDatPhong.DA_HUY.canTransitionTo(TrangThaiDatPhong.DA_NHAN_PHONG));
        assertFalse(TrangThaiDatPhong.KHONG_DEN.canTransitionTo(TrangThaiDatPhong.DA_NHAN_PHONG));
        assertTrue(TrangThaiDatPhong.DA_TRA_PHONG.isFinal());
        assertTrue(TrangThaiDatPhong.DA_HUY.isFinal());
        assertTrue(TrangThaiDatPhong.KHONG_DEN.isFinal());
    }

    @Test
    void invoiceFlowRejectsChangesAfterClosedState() {
        assertTrue(TrangThaiHoaDon.CHUA_THANH_TOAN.canTransitionTo(TrangThaiHoaDon.THANH_TOAN_MOT_PHAN));
        assertTrue(TrangThaiHoaDon.THANH_TOAN_MOT_PHAN.canTransitionTo(TrangThaiHoaDon.DA_THANH_TOAN));
        assertTrue(TrangThaiHoaDon.CHUA_THANH_TOAN.canTransitionTo(TrangThaiHoaDon.DA_HUY));
        assertFalse(TrangThaiHoaDon.DA_THANH_TOAN.canTransitionTo(TrangThaiHoaDon.CHUA_THANH_TOAN));
        assertFalse(TrangThaiHoaDon.DA_HUY.canTransitionTo(TrangThaiHoaDon.DA_THANH_TOAN));
    }

    @Test
    void housekeepingFlowIsMonotonicUntilCompletion() {
        assertTrue(TrangThaiNhiemVu.CHO_XU_LY.canTransitionTo(TrangThaiNhiemVu.DANG_XU_LY));
        assertTrue(TrangThaiNhiemVu.DANG_XU_LY.canTransitionTo(TrangThaiNhiemVu.HOAN_THANH));
        assertTrue(TrangThaiNhiemVu.CHO_XU_LY.canTransitionTo(TrangThaiNhiemVu.DA_HUY));
        assertFalse(TrangThaiNhiemVu.HOAN_THANH.canTransitionTo(TrangThaiNhiemVu.DANG_XU_LY));
        assertFalse(TrangThaiNhiemVu.DA_HUY.canTransitionTo(TrangThaiNhiemVu.CHO_XU_LY));
    }
}
