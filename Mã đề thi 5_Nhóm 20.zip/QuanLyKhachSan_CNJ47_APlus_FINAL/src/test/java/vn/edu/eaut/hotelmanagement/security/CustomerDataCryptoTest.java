package vn.edu.eaut.hotelmanagement.security;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerDataCryptoTest {

    @Test
    void encryptDecryptRoundTripSupportsVietnameseText() {
        String plaintext = "Nguyễn Văn Ánh - 0912345678 - Hà Nội";
        String encrypted = CustomerDataCrypto.encrypt(plaintext);

        assertTrue(CustomerDataCrypto.isEncrypted(encrypted));
        assertNotEquals(plaintext, encrypted);
        assertEquals(plaintext, CustomerDataCrypto.decrypt(encrypted));
    }

    @Test
    void samePlaintextGetsDifferentCiphertextBecauseIvIsRandom() {
        String first = CustomerDataCrypto.encrypt("0901234567");
        String second = CustomerDataCrypto.encrypt("0901234567");

        assertNotEquals(first, second);
        assertEquals("0901234567", CustomerDataCrypto.decrypt(first));
        assertEquals("0901234567", CustomerDataCrypto.decrypt(second));
    }

    @Test
    void plaintextIsBackwardCompatibleDuringMigration() {
        assertEquals("legacy@example.com", CustomerDataCrypto.decrypt("legacy@example.com"));
        assertFalse(CustomerDataCrypto.isEncrypted("legacy@example.com"));
    }
}
