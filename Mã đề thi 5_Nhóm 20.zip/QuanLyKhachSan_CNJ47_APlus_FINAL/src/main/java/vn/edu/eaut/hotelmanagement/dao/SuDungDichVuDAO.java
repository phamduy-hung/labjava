package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.SuDungDichVu;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SuDungDichVuDAO {

    private static final String SELECT_COLUMNS =
            "sd.id, sd.chi_tiet_dat_phong_id, sd.dich_vu_id, sd.thoi_gian_su_dung, sd.so_luong, sd.don_gia, "
                    + "sd.thanh_tien, sd.nhan_vien_ghi_nhan_id, sd.ghi_chu";

    public int insert(SuDungDichVu usage) throws SQLException {
        String sql = "INSERT INTO su_dung_dich_vu(chi_tiet_dat_phong_id, dich_vu_id, thoi_gian_su_dung, so_luong, don_gia, nhan_vien_ghi_nhan_id, ghi_chu) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, usage, false);
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    usage.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của lần sử dụng dịch vụ vừa thêm.");
    }

    public boolean update(SuDungDichVu usage) throws SQLException {
        String sql = "UPDATE su_dung_dich_vu SET chi_tiet_dat_phong_id = ?, dich_vu_id = ?, thoi_gian_su_dung = ?, "
                + "so_luong = ?, don_gia = ?, nhan_vien_ghi_nhan_id = ?, ghi_chu = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            bind(statement, usage, true);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteById(int id) throws SQLException {
        String sql = "DELETE FROM su_dung_dich_vu WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    public Optional<SuDungDichVu> findById(int id) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM su_dung_dich_vu sd WHERE sd.id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<SuDungDichVu> findAll() throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM su_dung_dich_vu sd ORDER BY sd.thoi_gian_su_dung DESC, sd.id DESC";
        return executeList(sql);
    }

    public List<SuDungDichVu> findByBookingDetailId(int bookingDetailId) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM su_dung_dich_vu sd WHERE sd.chi_tiet_dat_phong_id = ? ORDER BY sd.thoi_gian_su_dung, sd.id";
        List<SuDungDichVu> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingDetailId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public List<SuDungDichVu> findByBookingId(int bookingId) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM su_dung_dich_vu sd "
                + "JOIN chi_tiet_dat_phong ct ON ct.id = sd.chi_tiet_dat_phong_id "
                + "WHERE ct.dat_phong_id = ? ORDER BY sd.thoi_gian_su_dung, sd.id";
        List<SuDungDichVu> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public BigDecimal calculateTotalByBookingId(int bookingId) throws SQLException {
        String sql = "SELECT COALESCE(SUM(sd.thanh_tien), 0) AS tong_tien FROM su_dung_dich_vu sd "
                + "JOIN chi_tiet_dat_phong ct ON ct.id = sd.chi_tiet_dat_phong_id WHERE ct.dat_phong_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getBigDecimal("tong_tien") : BigDecimal.ZERO;
            }
        }
    }

    private List<SuDungDichVu> executeList(String sql) throws SQLException {
        List<SuDungDichVu> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(mapRow(resultSet));
            }
        }
        return result;
    }

    private void bind(PreparedStatement statement, SuDungDichVu usage, boolean includeId) throws SQLException {
        LocalDateTime usageTime = usage.getThoiGianSuDung() == null ? LocalDateTime.now() : usage.getThoiGianSuDung();
        statement.setInt(1, usage.getChiTietDatPhongId());
        statement.setInt(2, usage.getDichVuId());
        statement.setTimestamp(3, Timestamp.valueOf(usageTime));
        statement.setBigDecimal(4, usage.getSoLuong());
        statement.setBigDecimal(5, usage.getDonGia());
        JdbcDataAccessSupport.setNullableInteger(statement, 6, usage.getNhanVienGhiNhanId());
        statement.setString(7, usage.getGhiChu());
        if (includeId) {
            statement.setInt(8, usage.getId());
        }
    }

    private SuDungDichVu mapRow(ResultSet resultSet) throws SQLException {
        SuDungDichVu usage = new SuDungDichVu();
        usage.setId(resultSet.getInt("id"));
        usage.setChiTietDatPhongId(resultSet.getInt("chi_tiet_dat_phong_id"));
        usage.setDichVuId(resultSet.getInt("dich_vu_id"));
        usage.setThoiGianSuDung(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "thoi_gian_su_dung"));
        usage.setSoLuong(resultSet.getBigDecimal("so_luong"));
        usage.setDonGia(resultSet.getBigDecimal("don_gia"));
        usage.setThanhTien(resultSet.getBigDecimal("thanh_tien"));
        int employeeId = resultSet.getInt("nhan_vien_ghi_nhan_id");
        usage.setNhanVienGhiNhanId(resultSet.wasNull() ? null : employeeId);
        usage.setGhiChu(resultSet.getString("ghi_chu"));
        return usage;
    }
}
