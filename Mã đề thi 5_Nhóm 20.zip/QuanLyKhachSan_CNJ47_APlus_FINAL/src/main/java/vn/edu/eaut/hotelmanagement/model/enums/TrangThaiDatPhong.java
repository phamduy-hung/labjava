package vn.edu.eaut.hotelmanagement.model.enums;

/**
 * Vòng đời của một booking.
 * Các chuyển tiếp nhạy cảm (check-in/check-out) phải dùng transaction chuyên dụng.
 */
public enum TrangThaiDatPhong {
    CHO_XAC_NHAN("Chờ xác nhận"),
    DA_XAC_NHAN("Đã xác nhận"),
    DA_NHAN_PHONG("Đã nhận phòng"),
    DA_TRA_PHONG("Đã trả phòng"),
    DA_HUY("Đã hủy"),
    KHONG_DEN("Không đến");

    private final String hienThi;

    TrangThaiDatPhong(String hienThi) {
        this.hienThi = hienThi;
    }

    public boolean canTransitionTo(TrangThaiDatPhong target) {
        if (target == null) {
            return false;
        }
        if (this == target) {
            return true;
        }
        return switch (this) {
            case CHO_XAC_NHAN -> target == DA_XAC_NHAN || target == DA_HUY || target == KHONG_DEN;
            case DA_XAC_NHAN -> target == DA_NHAN_PHONG || target == DA_HUY || target == KHONG_DEN;
            case DA_NHAN_PHONG -> target == DA_TRA_PHONG;
            case DA_TRA_PHONG, DA_HUY, KHONG_DEN -> false;
        };
    }

    public boolean isFinal() {
        return this == DA_TRA_PHONG || this == DA_HUY || this == KHONG_DEN;
    }

    @Override
    public String toString() {
        return hienThi;
    }
}
