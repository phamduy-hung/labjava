package vn.edu.eaut.hotelmanagement.view;

import vn.edu.eaut.hotelmanagement.controller.LoginController;
import vn.edu.eaut.hotelmanagement.service.AuthenticationException;
import vn.edu.eaut.hotelmanagement.session.LoginSession;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

/**
 * Màn hình đăng nhập hệ thống quản lý khách sạn.
 *
 * View chỉ chịu trách nhiệm:
 * - Hiển thị giao diện.
 * - Kiểm tra dữ liệu nhập.
 * - Gọi LoginController.
 * - Chuyển sang MainView sau khi đăng nhập thành công.
 */
public class LoginView extends JFrame {

    private static final Color PRIMARY_COLOR = new Color(26, 83, 155);
    private static final Color PRIMARY_DARK_COLOR = new Color(17, 55, 105);
    private static final Color PRIMARY_LIGHT_COLOR = new Color(40, 133, 220);

    private static final Color BACKGROUND_COLOR = new Color(244, 247, 251);
    private static final Color CARD_COLOR = Color.WHITE;
    private static final Color BORDER_COLOR = new Color(218, 226, 236);

    private static final Color TEXT_COLOR = new Color(38, 49, 64);
    private static final Color SECONDARY_TEXT_COLOR = new Color(105, 117, 133);

    private static final Color ERROR_COLOR = new Color(190, 50, 60);
    private static final Color SUCCESS_COLOR = new Color(37, 137, 88);

    private static final Font TITLE_FONT =
            new Font("Segoe UI", Font.BOLD, 30);

    private static final Font FIELD_FONT =
            new Font("Segoe UI", Font.PLAIN, 14);

    private static final Font LABEL_FONT =
            new Font("Segoe UI", Font.BOLD, 13);

    private final LoginController loginController;
    private final Consumer<LoginSession> loginSuccessHandler;

    private final JTextField txtUsername = new JTextField();
    private final JPasswordField txtPassword = new JPasswordField();

    private final JCheckBox chkShowPassword =
            new JCheckBox("Hiển thị mật khẩu");

    private final JButton btnLogin =
            new JButton("ĐĂNG NHẬP");

    private final JButton btnExit =
            new JButton("Thoát");

    private final JProgressBar progressBar =
            new JProgressBar();

    private final JLabel lblStatus =
            new JLabel(" ");

    private char defaultPasswordEchoChar;

    public LoginView() {
        this(new LoginController(), null);
    }

    public LoginView(LoginController loginController) {
        this(loginController, null);
    }

    public LoginView(
            LoginController loginController,
            Consumer<LoginSession> loginSuccessHandler
    ) {
        if (loginController == null) {
            throw new IllegalArgumentException(
                    "LoginController không được để trống."
            );
        }

        this.loginController = loginController;
        this.loginSuccessHandler = loginSuccessHandler;

        initializeFrame();
        initializeComponents();
        registerEvents();
    }

    /**
     * Thiết lập cửa sổ chính của màn hình đăng nhập.
     */
    private void initializeFrame() {
        setTitle("Hotel Management - Đăng nhập");
        setDefaultCloseOperation(
                WindowConstants.EXIT_ON_CLOSE
        );

        setMinimumSize(
                new Dimension(900, 560)
        );

        setSize(
                new Dimension(1100, 680)
        );

        setLocationRelativeTo(null);
        setResizable(true);
    }

    /**
     * Khởi tạo toàn bộ thành phần giao diện.
     */
    private void initializeComponents() {
        JPanel rootPanel =
                new JPanel(new BorderLayout());

        rootPanel.setBackground(
                BACKGROUND_COLOR
        );

        rootPanel.add(
                createBrandPanel(),
                BorderLayout.WEST
        );

        rootPanel.add(
                createLoginArea(),
                BorderLayout.CENTER
        );

        setContentPane(rootPanel);

        defaultPasswordEchoChar =
                txtPassword.getEchoChar();

        getRootPane().setDefaultButton(btnLogin);

        SwingUtilities.invokeLater(() ->
                txtUsername.requestFocusInWindow()
        );
    }

    /**
     * Tạo khu vực thương hiệu bên trái.
     */
    private JPanel createBrandPanel() {
        GradientPanel brandPanel =
                new GradientPanel();

        brandPanel.setPreferredSize(
                new Dimension(440, 680)
        );

        brandPanel.setLayout(
                new GridBagLayout()
        );

        brandPanel.setBorder(
                new EmptyBorder(
                        50,
                        48,
                        45,
                        48
                )
        );

        GridBagConstraints constraints =
                new GridBagConstraints();

        constraints.gridx = 0;
        constraints.weightx = 1;
        constraints.fill =
                GridBagConstraints.HORIZONTAL;

        constraints.anchor =
                GridBagConstraints.WEST;

        JLabel lblLogo =
                createLogoLabel();

        constraints.gridy = 0;
        constraints.fill =
                GridBagConstraints.NONE;

        constraints.anchor =
                GridBagConstraints.WEST;

        constraints.insets =
                new Insets(0, 0, 30, 0);

        brandPanel.add(
                lblLogo,
                constraints
        );

        JLabel lblTitle =
                new JLabel("HOTEL MANAGEMENT");

        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        29
                )
        );

        constraints.gridy = 1;
        constraints.fill =
                GridBagConstraints.HORIZONTAL;

        constraints.insets =
                new Insets(0, 0, 8, 0);

        brandPanel.add(
                lblTitle,
                constraints
        );

        JLabel lblSubtitle =
                new JLabel(
                        "Hệ thống quản lý lễ tân và buồng phòng"
                );

        lblSubtitle.setForeground(
                new Color(225, 238, 255)
        );

        lblSubtitle.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        15
                )
        );

        constraints.gridy = 2;
        constraints.insets =
                new Insets(0, 0, 34, 0);

        brandPanel.add(
                lblSubtitle,
                constraints
        );

        JSeparator separator =
                new JSeparator();

        separator.setForeground(
                new Color(255, 255, 255, 90)
        );

        separator.setBackground(
                new Color(255, 255, 255, 90)
        );

        constraints.gridy = 3;
        constraints.insets =
                new Insets(0, 0, 30, 0);

        brandPanel.add(
                separator,
                constraints
        );

        constraints.gridy = 4;
        constraints.insets =
                new Insets(0, 0, 16, 0);

        brandPanel.add(
                createFeatureLabel(
                        "01",
                        "Quản lý đặt phòng và lễ tân"
                ),
                constraints
        );

        constraints.gridy = 5;

        brandPanel.add(
                createFeatureLabel(
                        "02",
                        "Theo dõi trạng thái buồng phòng"
                ),
                constraints
        );

        constraints.gridy = 6;

        brandPanel.add(
                createFeatureLabel(
                        "03",
                        "Hóa đơn, thanh toán và báo cáo"
                ),
                constraints
        );

        return brandPanel;
    }

    /**
     * Tạo logo H.
     */
    private JLabel createLogoLabel() {
        JLabel lblLogo =
                new JLabel(
                        "H",
                        SwingConstants.CENTER
                );

        lblLogo.setOpaque(true);
        lblLogo.setBackground(Color.WHITE);
        lblLogo.setForeground(PRIMARY_COLOR);

        lblLogo.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        38
                )
        );

        lblLogo.setPreferredSize(
                new Dimension(82, 82)
        );

        lblLogo.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        255,
                                        255,
                                        255,
                                        190
                                ),
                                2
                        ),
                        new EmptyBorder(
                                5,
                                5,
                                5,
                                5
                        )
                )
        );

        return lblLogo;
    }

    /**
     * Tạo từng chức năng nổi bật.
     */
    private JPanel createFeatureLabel(
            String number,
            String text
    ) {
        JPanel panel =
                new JPanel(
                        new BorderLayout(
                                14,
                                0
                        )
                );

        panel.setOpaque(false);

        JLabel lblNumber =
                new JLabel(
                        number,
                        SwingConstants.CENTER
                );

        lblNumber.setPreferredSize(
                new Dimension(42, 42)
        );

        lblNumber.setOpaque(true);

        lblNumber.setBackground(
                new Color(
                        255,
                        255,
                        255,
                        35
                )
        );

        lblNumber.setForeground(
                Color.WHITE
        );

        lblNumber.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        lblNumber.setBorder(
                BorderFactory.createLineBorder(
                        new Color(
                                255,
                                255,
                                255,
                                100
                        )
                )
        );

        JLabel lblText =
                new JLabel(text);

        lblText.setForeground(
                Color.WHITE
        );

        lblText.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        15
                )
        );

        panel.add(
                lblNumber,
                BorderLayout.WEST
        );

        panel.add(
                lblText,
                BorderLayout.CENTER
        );

        return panel;
    }
    /**
     * Tạo khu vực đăng nhập bên phải.
     */
    private JPanel createLoginArea() {
        JPanel outerPanel =
                new JPanel(
                        new GridBagLayout()
                );

        outerPanel.setBackground(
                BACKGROUND_COLOR
        );

        outerPanel.setBorder(
                new EmptyBorder(
                        45,
                        55,
                        45,
                        55
                )
        );

        JPanel loginCard =
                new JPanel(
                        new GridBagLayout()
                );

        loginCard.setBackground(
                CARD_COLOR
        );

        loginCard.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                BORDER_COLOR
                        ),
                        new EmptyBorder(
                                45,
                                48,
                                40,
                                48
                        )
                )
        );

        GridBagConstraints constraints =
                new GridBagConstraints();

        constraints.gridx = 0;
        constraints.weightx = 1;
        constraints.fill =
                GridBagConstraints.HORIZONTAL;

        constraints.anchor =
                GridBagConstraints.WEST;

        JLabel lblWelcome =
                new JLabel("Xin chào!");

        lblWelcome.setForeground(
                TEXT_COLOR
        );

        lblWelcome.setFont(
                TITLE_FONT
        );

        constraints.gridy = 0;
        constraints.insets =
                new Insets(
                        0,
                        0,
                        8,
                        0
                );

        loginCard.add(
                lblWelcome,
                constraints
        );

        JLabel lblInstruction =
                new JLabel(
                        "Đăng nhập để tiếp tục vào hệ thống."
                );

        lblInstruction.setForeground(
                SECONDARY_TEXT_COLOR
        );

        lblInstruction.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );

        constraints.gridy = 1;
        constraints.insets =
                new Insets(
                        0,
                        0,
                        34,
                        0
                );

        loginCard.add(
                lblInstruction,
                constraints
        );

        JLabel lblUsername =
                createFieldLabel(
                        "Tên đăng nhập"
                );

        constraints.gridy = 2;
        constraints.insets =
                new Insets(
                        0,
                        0,
                        8,
                        0
                );

        loginCard.add(
                lblUsername,
                constraints
        );

        styleTextField(txtUsername);

        txtUsername.setToolTipText(
                "Nhập tên đăng nhập"
        );

        constraints.gridy = 3;
        constraints.insets =
                new Insets(
                        0,
                        0,
                        20,
                        0
                );

        loginCard.add(
                txtUsername,
                constraints
        );

        JLabel lblPassword =
                createFieldLabel(
                        "Mật khẩu"
                );

        constraints.gridy = 4;
        constraints.insets =
                new Insets(
                        0,
                        0,
                        8,
                        0
                );

        loginCard.add(
                lblPassword,
                constraints
        );

        styleTextField(txtPassword);

        txtPassword.setToolTipText(
                "Nhập mật khẩu"
        );

        constraints.gridy = 5;
        constraints.insets =
                new Insets(
                        0,
                        0,
                        9,
                        0
                );

        loginCard.add(
                txtPassword,
                constraints
        );

        chkShowPassword.setOpaque(false);

        chkShowPassword.setForeground(
                SECONDARY_TEXT_COLOR
        );

        chkShowPassword.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        13
                )
        );

        chkShowPassword.setFocusPainted(
                false
        );

        constraints.gridy = 6;
        constraints.insets =
                new Insets(
                        0,
                        0,
                        24,
                        0
                );

        loginCard.add(
                chkShowPassword,
                constraints
        );

        stylePrimaryButton(btnLogin);

        btnLogin.setMnemonic(
                KeyEvent.VK_D
        );

        btnLogin.setToolTipText(
                "Đăng nhập vào hệ thống - Enter"
        );

        constraints.gridy = 7;
        constraints.insets =
                new Insets(
                        0,
                        0,
                        12,
                        0
                );

        loginCard.add(
                btnLogin,
                constraints
        );

        styleSecondaryButton(btnExit);

        btnExit.setToolTipText(
                "Thoát chương trình"
        );

        constraints.gridy = 8;
        constraints.insets =
                new Insets(
                        0,
                        0,
                        18,
                        0
                );

        loginCard.add(
                btnExit,
                constraints
        );

        progressBar.setIndeterminate(
                true
        );

        progressBar.setVisible(false);

        progressBar.setPreferredSize(
                new Dimension(
                        100,
                        5
                )
        );

        constraints.gridy = 9;
        constraints.insets =
                new Insets(
                        0,
                        0,
                        9,
                        0
                );

        loginCard.add(
                progressBar,
                constraints
        );

        lblStatus.setForeground(
                SECONDARY_TEXT_COLOR
        );

        lblStatus.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        12
                )
        );

        lblStatus.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        constraints.gridy = 10;
        constraints.insets =
                new Insets(0, 0, 0, 0);

        loginCard.add(
                lblStatus,
                constraints
        );

        GridBagConstraints outerConstraints =
                new GridBagConstraints();

        outerConstraints.gridx = 0;
        outerConstraints.gridy = 0;
        outerConstraints.weightx = 1;
        outerConstraints.weighty = 1;

        outerConstraints.fill =
                GridBagConstraints.NONE;

        outerPanel.add(
                loginCard,
                outerConstraints
        );

        return outerPanel;
    }

    /**
     * Tạo nhãn cho ô nhập liệu.
     */
    private JLabel createFieldLabel(
            String text
    ) {
        JLabel label =
                new JLabel(text);

        label.setForeground(
                TEXT_COLOR
        );

        label.setFont(
                LABEL_FONT
        );

        return label;
    }

    /**
     * Chuẩn hóa ô nhập liệu.
     */
    private void styleTextField(
            JTextField textField
    ) {
        textField.setFont(
                FIELD_FONT
        );

        textField.setForeground(
                TEXT_COLOR
        );

        textField.setBackground(
                Color.WHITE
        );

        textField.setCaretColor(
                PRIMARY_COLOR
        );

        textField.setPreferredSize(
                new Dimension(
                        360,
                        44
                )
        );

        textField.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        198,
                                        207,
                                        218
                                )
                        ),
                        new EmptyBorder(
                                8,
                                12,
                                8,
                                12
                        )
                )
        );
    }

    /**
     * Nút chính.
     */
    private void stylePrimaryButton(
            JButton button
    ) {
        button.setPreferredSize(
                new Dimension(
                        360,
                        45
                )
        );

        button.setBackground(
                PRIMARY_COLOR
        );

        button.setForeground(
                Color.WHITE
        );

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        14
                )
        );

        button.setFocusPainted(
                false
        );

        button.setBorderPainted(
                false
        );

        button.setCursor(
                Cursor.getPredefinedCursor(
                        Cursor.HAND_CURSOR
                )
        );

        button.setBorder(
                BorderFactory.createEmptyBorder(
                        10,
                        15,
                        10,
                        15
                )
        );
    }

    /**
     * Nút phụ.
     */
    private void styleSecondaryButton(
            JButton button
    ) {
        button.setPreferredSize(
                new Dimension(
                        360,
                        40
                )
        );

        button.setBackground(
                Color.WHITE
        );

        button.setForeground(
                PRIMARY_COLOR
        );

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        button.setFocusPainted(
                false
        );

        button.setCursor(
                Cursor.getPredefinedCursor(
                        Cursor.HAND_CURSOR
                )
        );

        button.setBorder(
                BorderFactory.createLineBorder(
                        new Color(
                                188,
                                202,
                                220
                        )
                )
        );
    }

    /**
     * Đăng ký các sự kiện.
     */
    private void registerEvents() {
        btnLogin.addActionListener(
                event -> handleLogin()
        );

        btnExit.addActionListener(
                event -> handleExit()
        );

        chkShowPassword.addActionListener(
                event -> {
                    if (chkShowPassword.isSelected()) {
                        txtPassword.setEchoChar(
                                (char) 0
                        );
                    } else {
                        txtPassword.setEchoChar(
                                defaultPasswordEchoChar
                        );
                    }
                }
        );

        txtUsername.addActionListener(
                event -> txtPassword.requestFocusInWindow()
        );
    }

    /**
     * Xử lý đăng nhập.
     */
    private void handleLogin() {
        String username =
                txtUsername.getText().trim();

        char[] password =
                txtPassword.getPassword();

        if (!validateInput(
                username,
                password
        )) {
            Arrays.fill(
                    password,
                    '\0'
            );
            return;
        }

        setBusy(
                true,
                "Đang kiểm tra thông tin đăng nhập..."
        );

        SwingWorker<LoginSession, Void> worker =
                new SwingWorker<>() {

                    @Override
                    protected LoginSession doInBackground()
                            throws Exception {
                        return loginController.login(
                                username,
                                password
                        );
                    }

                    @Override
                    protected void done() {
                        try {
                            LoginSession session =
                                    get();

                            setBusy(
                                    false,
                                    "Đăng nhập thành công."
                            );

                            handleLoginSuccess(
                                    session
                            );

                        } catch (InterruptedException exception) {
                            Thread.currentThread().interrupt();

                            setBusy(
                                    false,
                                    "Đăng nhập đã bị gián đoạn."
                            );

                            showErrorDialog(
                                    "Đăng nhập bị gián đoạn",
                                    "Quá trình đăng nhập đã bị gián đoạn. Vui lòng thử lại."
                            );

                        } catch (ExecutionException exception) {
                            setBusy(
                                    false,
                                    "Không thể đăng nhập."
                            );

                            handleLoginFailure(
                                    exception.getCause()
                            );

                        } finally {
                            Arrays.fill(
                                    password,
                                    '\0'
                            );

                            txtPassword.setText("");
                        }
                    }
                };

        worker.execute();
    }

    /**
     * Kiểm tra dữ liệu đăng nhập.
     */
    private boolean validateInput(
            String username,
            char[] password
    ) {
        resetFieldBorders();

        if (username.isBlank()) {
            markInvalid(txtUsername);

            showValidationDialog(
                    "Vui lòng nhập tên đăng nhập."
            );

            txtUsername.requestFocusInWindow();

            return false;
        }

        if (username.length() < 3
                || username.length() > 50) {

            markInvalid(txtUsername);

            showValidationDialog(
                    "Tên đăng nhập phải có từ 3 đến 50 ký tự."
            );

            txtUsername.requestFocusInWindow();

            return false;
        }

        if (!username.matches(
                "[A-Za-z0-9._-]+"
        )) {
            markInvalid(txtUsername);

            showValidationDialog(
                    "Tên đăng nhập chỉ được chứa chữ cái không dấu, chữ số, dấu chấm, gạch dưới hoặc gạch ngang."
            );

            txtUsername.requestFocusInWindow();

            return false;
        }

        if (password == null
                || password.length == 0) {

            markInvalid(txtPassword);

            showValidationDialog(
                    "Vui lòng nhập mật khẩu."
            );

            txtPassword.requestFocusInWindow();

            return false;
        }

        if (password.length > 100) {
            markInvalid(txtPassword);

            showValidationDialog(
                    "Mật khẩu không được vượt quá 100 ký tự."
            );

            txtPassword.requestFocusInWindow();

            return false;
        }

        return true;
    }
    /**
     * Đưa đường viền ô nhập liệu về trạng thái bình thường.
     */
    private void resetFieldBorders() {
        styleTextField(txtUsername);
        styleTextField(txtPassword);
    }

    /**
     * Đánh dấu ô nhập liệu không hợp lệ.
     */
    private void markInvalid(
            JTextField field
    ) {
        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                ERROR_COLOR,
                                2
                        ),
                        new EmptyBorder(
                                7,
                                11,
                                7,
                                11
                        )
                )
        );
    }

    /**
     * Khóa giao diện trong thời gian đăng nhập.
     */
    private void setBusy(
            boolean busy,
            String statusText
    ) {
        txtUsername.setEnabled(!busy);
        txtPassword.setEnabled(!busy);
        chkShowPassword.setEnabled(!busy);
        btnLogin.setEnabled(!busy);
        btnExit.setEnabled(!busy);

        progressBar.setVisible(busy);

        lblStatus.setText(
                statusText == null
                        || statusText.isBlank()
                        ? " "
                        : statusText
        );

        lblStatus.setForeground(
                busy
                        ? PRIMARY_COLOR
                        : SECONDARY_TEXT_COLOR
        );

        setCursor(
                busy
                        ? Cursor.getPredefinedCursor(
                                Cursor.WAIT_CURSOR
                        )
                        : Cursor.getDefaultCursor()
        );
    }

    /**
     * Xử lý khi đăng nhập thành công.
     */
    private void handleLoginSuccess(
            LoginSession session
    ) {

        setVisible(false);

        try {
            if (loginSuccessHandler != null) {
                loginSuccessHandler.accept(
                        session
                );
            } else {
                MainView mainView =
                        new MainView(session);

                mainView.setVisible(true);
            }

            dispose();

        } catch (RuntimeException exception) {
            setVisible(true);

            showErrorDialog(
                    "Không thể mở màn hình chính",
                    "Đăng nhập đã thành công nhưng không thể mở màn hình chính.\n\n"
                    + "Chi tiết: "
                    + getReadableMessage(exception)
            );
        }
    }

    /**
     * Xử lý lỗi đăng nhập.
     */
    private void handleLoginFailure(
            Throwable cause
    ) {
        if (cause instanceof AuthenticationException) {
            AuthenticationException exception =
                    (AuthenticationException) cause;

            showErrorDialog(
                    "Đăng nhập không thành công",
                    exception.getMessage()
            );

            txtPassword.requestFocusInWindow();

            return;
        }

        if (cause instanceof SQLException) {
            SQLException exception =
                    (SQLException) cause;

            showErrorDialog(
                    "Không thể kết nối cơ sở dữ liệu",
                    "Không thể kiểm tra tài khoản với MySQL.\n"
                    + "Vui lòng kiểm tra MySQL Server, "
                    + "database.properties và CSDL "
                    + "hotel_management_db.\n\n"
                    + "Chi tiết: "
                    + safeDatabaseMessage(exception)
            );

            return;
        }

        showErrorDialog(
                "Lỗi hệ thống",
                "Đã xảy ra lỗi ngoài dự kiến khi đăng nhập.\n"
                + "Vui lòng kiểm tra cấu hình chương trình."
        );
    }

    /**
     * Giới hạn thông báo lỗi SQL hiển thị trên giao diện.
     */
    private String safeDatabaseMessage(
            SQLException exception
    ) {
        String message =
                exception.getMessage();

        if (message == null
                || message.isBlank()) {
            return "SQLException không có thông báo chi tiết.";
        }

        return message.length() > 220
                ? message.substring(
                        0,
                        220
                ) + "..."
                : message;
    }

    /**
     * Xử lý nút Thoát.
     */
    private void handleExit() {
        int choice =
                JOptionPane.showConfirmDialog(
                        this,
                        "Bạn có chắc chắn muốn thoát khỏi chương trình?",
                        "Xác nhận thoát",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

        if (choice
                == JOptionPane.YES_OPTION) {

            dispose();
            System.exit(0);
        }
    }

    /**
     * Hiển thị cảnh báo dữ liệu.
     */
    private void showValidationDialog(
            String message
    ) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Dữ liệu chưa hợp lệ",
                JOptionPane.WARNING_MESSAGE
        );
    }

    /**
     * Hiển thị lỗi.
     */
    private void showErrorDialog(
            String title,
            String message
    ) {
        JOptionPane.showMessageDialog(
                this,
                message,
                title,
                JOptionPane.ERROR_MESSAGE
        );
    }

    /**
     * Lấy nội dung lỗi dễ đọc.
     */
    private String getReadableMessage(
            Throwable throwable
    ) {
        if (throwable == null) {
            return "Không xác định.";
        }

        String message =
                throwable.getMessage();

        if (message == null
                || message.isBlank()) {
            return throwable
                    .getClass()
                    .getSimpleName();
        }

        return message;
    }

    /**
     * Panel gradient thương hiệu.
     *
     * Lưu ý:
     * Không gọi super.paintComponent() sau khi
     * vẽ gradient vì có thể ghi đè nền gradient.
     */
    private static final class GradientPanel
            extends JPanel {

        @Override
        protected void paintComponent(
                Graphics graphics
        ) {
            Graphics2D graphics2D =
                    (Graphics2D) graphics.create();

            try {
                graphics2D.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );

                int width =
                        getWidth();

                int height =
                        getHeight();

                GradientPaint gradientPaint =
                        new GradientPaint(
                                0,
                                0,
                                PRIMARY_DARK_COLOR,
                                width,
                                height,
                                PRIMARY_LIGHT_COLOR
                        );

                graphics2D.setPaint(
                        gradientPaint
                );

                graphics2D.fillRect(
                        0,
                        0,
                        width,
                        height
                );

                graphics2D.setColor(
                        new Color(
                                255,
                                255,
                                255,
                                25
                        )
                );

                graphics2D.setStroke(
                        new BasicStroke(2f)
                );

                graphics2D.drawOval(
                        -100,
                        height - 270,
                        330,
                        330
                );

                graphics2D.drawOval(
                        width - 170,
                        -100,
                        300,
                        300
                );

                graphics2D.drawOval(
                        width - 80,
                        height - 180,
                        240,
                        240
                );

            } finally {
                graphics2D.dispose();
            }
        }

        @Override
        public boolean isOpaque() {
            return true;
        }
    }
}