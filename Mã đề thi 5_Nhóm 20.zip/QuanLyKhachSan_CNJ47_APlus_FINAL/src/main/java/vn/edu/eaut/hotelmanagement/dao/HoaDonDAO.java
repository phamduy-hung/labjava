package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.HoaDon;
import vn.edu.eaut.hotelmanagement.model.enums.PhuongThucThanhToan;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiDatPhong;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiHoaDon;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiPhong;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * DAO quản lý hóa đơn.
 *
 * Ngoài CRUD thông thường, lớp này cung cấp nghiệp vụ checkoutAndPay(...)
 * để bảo đảm các bước lập/cập nhật hóa đơn, ghi thanh toán, cập nhật booking
 * và chuyển phòng sang DANG_DON được thực hiện trong CÙNG MỘT TRANSACTION.
 */
public class HoaDonDAO {

    private static final String SELECT_COLUMNS =
            "hd.id, hd.ma_hoa_don, hd.dat_phong_id, hd.tong_tien_phong, hd.tong_tien_dich_vu, hd.phu_thu, hd.giam_gia, "
                    + "hd.tong_thanh_toan, hd.trang_thai, hd.nhan_vien_lap_id, hd.thoi_gian_lap, hd.ghi_chu";

    private static final DateTimeFormatter CODE_FORMATTER =
            DateTimeFormatter.ofPattern("yyMMddHHmmssSSS");

    public int insert(HoaDon hoaDon) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            return insert(connection, hoaDon);
        }
    }

    private int insert(Connection connection, HoaDon hoaDon) throws SQLException {
        String sql = "INSERT INTO hoa_don(ma_hoa_don, dat_phong_id, tong_tien_phong, tong_tien_dich_vu, phu_thu, giam_gia, "
                + "trang_thai, nhan_vien_lap_id, thoi_gian_lap, ghi_chu) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, hoaDon, false);
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    hoaDon.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của hóa đơn vừa thêm.");
    }

    public boolean update(HoaDon hoaDon) throws SQLException {
        if (hoaDon == null || hoaDon.getId() == null || hoaDon.getId() <= 0) {
            throw new IllegalArgumentException("Thông tin hóa đơn không hợp lệ.");
        }

        String currentSql = "SELECT trang_thai FROM hoa_don WHERE id = ?";
        String sql = "UPDATE hoa_don SET ma_hoa_don = ?, dat_phong_id = ?, tong_tien_phong = ?, tong_tien_dich_vu = ?, "
                + "phu_thu = ?, giam_gia = ?, nhan_vien_lap_id = ?, thoi_gian_lap = ?, ghi_chu = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection()) {
            TrangThaiHoaDon currentStatus;
            try (PreparedStatement statement = connection.prepareStatement(currentSql)) {
                statement.setInt(1, hoaDon.getId());
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (!resultSet.next()) {
                        throw new SQLException("Không tìm thấy hóa đơn cần cập nhật.");
                    }
                    currentStatus = TrangThaiHoaDon.valueOf(resultSet.getString("trang_thai"));
                }
            }

            if (hoaDon.getTrangThai() != null && hoaDon.getTrangThai() != currentStatus) {
                throw new SQLException(
                        "Không được thay đổi trạng thái hóa đơn bằng chức năng Sửa. "
                                + "Hãy dùng nghiệp vụ thanh toán/hủy hóa đơn."
                );
            }

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, hoaDon.getMaHoaDon());
                statement.setInt(2, hoaDon.getDatPhongId());
                statement.setBigDecimal(3, hoaDon.getTongTienPhong());
                statement.setBigDecimal(4, hoaDon.getTongTienDichVu());
                statement.setBigDecimal(5, hoaDon.getPhuThu());
                statement.setBigDecimal(6, hoaDon.getGiamGia());
                JdbcDataAccessSupport.setNullableInteger(statement, 7, hoaDon.getNhanVienLapId());
                JdbcDataAccessSupport.setNullableLocalDateTime(statement, 8, hoaDon.getThoiGianLap());
                statement.setString(9, hoaDon.getGhiChu());
                statement.setInt(10, hoaDon.getId());
                boolean updated = statement.executeUpdate() == 1;
                hoaDon.setTrangThai(currentStatus);
                return updated;
            }
        }
    }

    public boolean updateStatus(int invoiceId, TrangThaiHoaDon targetStatus) throws SQLException {
        if (invoiceId <= 0 || targetStatus == null) {
            throw new IllegalArgumentException("Hóa đơn hoặc trạng thái không hợp lệ.");
        }

        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            TrangThaiHoaDon currentStatus;
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT trang_thai FROM hoa_don WHERE id = ? FOR UPDATE")) {
                statement.setInt(1, invoiceId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (!resultSet.next()) {
                        throw new SQLException("Không tìm thấy hóa đơn.");
                    }
                    currentStatus = TrangThaiHoaDon.valueOf(resultSet.getString("trang_thai"));
                }
            }

            if (currentStatus == targetStatus) {
                connection.commit();
                return true;
            }
            if (!currentStatus.canTransitionTo(targetStatus)) {
                throw new SQLException(
                        "Không được chuyển hóa đơn từ " + currentStatus + " sang " + targetStatus + "."
                );
            }

            String sql = "UPDATE hoa_don SET trang_thai = ? WHERE id = ? AND trang_thai = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, targetStatus.name());
                statement.setInt(2, invoiceId);
                statement.setString(3, currentStatus.name());
                boolean updated = statement.executeUpdate() == 1;
                if (!updated) {
                    throw new SQLException("Hóa đơn đã thay đổi bởi thao tác khác. Vui lòng tải lại dữ liệu.");
                }
                connection.commit();
                return true;
            }
        } catch (SQLException | RuntimeException exception) {
            if (connection != null) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackException) {
                    exception.addSuppressed(rollbackException);
                }
            }
            throw exception;
        } finally {
            if (connection != null) {
                try {
                    connection.setAutoCommit(true);
                } catch (SQLException ignored) {
                }
                try {
                    connection.close();
                } catch (SQLException ignored) {
                }
            }
        }
    }

    public boolean deleteById(int id) throws SQLException {
        String sql = "DELETE FROM hoa_don WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    public Optional<HoaDon> findById(int id) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM hoa_don hd WHERE hd.id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public Optional<HoaDon> findByBookingId(int bookingId) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM hoa_don hd WHERE hd.dat_phong_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<HoaDon> findAll() throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM hoa_don hd ORDER BY hd.thoi_gian_lap DESC, hd.id DESC";
        return executeList(sql);
    }

    public List<HoaDon> findByStatus(TrangThaiHoaDon status) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM hoa_don hd WHERE hd.trang_thai = ? ORDER BY hd.thoi_gian_lap DESC";
        List<HoaDon> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, status.name());
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public List<HoaDon> search(String keyword) throws SQLException {
        String candidate = keyword == null ? "" : keyword.trim();
        String searchValue = "%" + candidate + "%";

        List<Integer> customerIds = new KhachHangDAO().search(candidate).stream()
                .map(vn.edu.eaut.hotelmanagement.model.KhachHang::getId)
                .filter(java.util.Objects::nonNull)
                .toList();

        StringBuilder sql = new StringBuilder(
                "SELECT " + SELECT_COLUMNS + " FROM hoa_don hd "
                        + "WHERE hd.ma_hoa_don LIKE ? "
                        + "OR hd.dat_phong_id IN (SELECT dp.id FROM dat_phong dp WHERE dp.ma_dat_phong LIKE ?)");
        if (!customerIds.isEmpty()) {
            sql.append(" OR hd.dat_phong_id IN (SELECT dp2.id FROM dat_phong dp2 WHERE dp2.khach_hang_id IN (");
            sql.append("?,".repeat(customerIds.size()));
            sql.setLength(sql.length() - 1);
            sql.append("))");
        }
        sql.append(" ORDER BY hd.thoi_gian_lap DESC, hd.id DESC");

        List<HoaDon> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {
            int index = 1;
            statement.setString(index++, searchValue);
            statement.setString(index++, searchValue);
            for (Integer customerId : customerIds) {
                statement.setInt(index++, customerId);
            }
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public BigDecimal getPaidAmount(int invoiceId) throws SQLException {
        String sql = "SELECT COALESCE(SUM(so_tien), 0) AS da_thanh_toan FROM thanh_toan WHERE hoa_don_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, invoiceId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getBigDecimal("da_thanh_toan") : BigDecimal.ZERO;
            }
        }
    }

    /**
     * Checkout và thanh toán nguyên tử.
     *
     * Các bước trong một transaction:
     * 1) Khóa booking và xác nhận booking đang DA_NHAN_PHONG.
     * 2) Tính lại số ngày, tiền phòng và tiền dịch vụ trực tiếp từ CSDL.
     * 3) Tạo hoặc cập nhật hóa đơn.
     * 4) Ghi khoản thanh toán còn thiếu.
     * 5) Chuyển hóa đơn sang DA_THANH_TOAN.
     * 6) Chuyển booking sang DA_TRA_PHONG, ghi thời gian trả thực tế.
     * 7) Chuyển toàn bộ phòng của booking sang DANG_DON.
     * 8) Ghi nhật ký hệ thống.
     *
     * Nếu bất kỳ bước nào lỗi, toàn bộ transaction bị rollback.
     */
    public CheckoutResult checkoutAndPay(
            int bookingId,
            BigDecimal surcharge,
            BigDecimal discount,
            Integer employeeId,
            PhuongThucThanhToan paymentMethod,
            String referenceCode,
            String note) throws SQLException {

        if (bookingId <= 0) {
            throw new IllegalArgumentException("Booking không hợp lệ.");
        }
        if (surcharge == null || surcharge.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Phụ thu không được âm.");
        }
        if (discount == null || discount.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Giảm giá không được âm.");
        }
        if (paymentMethod == null) {
            throw new IllegalArgumentException("Phương thức thanh toán không được để trống.");
        }

        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            LocalDateTime checkoutTime = LocalDateTime.now();
            BookingCheckoutInfo bookingInfo = lockBookingForCheckout(connection, bookingId);

            if (bookingInfo.status != TrangThaiDatPhong.DA_NHAN_PHONG) {
                throw new SQLException("Chỉ có thể trả phòng cho booking đang ở trạng thái Đã nhận phòng.");
            }
            if (bookingInfo.actualCheckIn == null) {
                throw new SQLException("Booking chưa có thời gian nhận phòng thực tế.");
            }

            int billableDays = calculateBillableDays(bookingInfo.actualCheckIn, checkoutTime);
            RoomChargeInfo roomChargeInfo = calculateRoomCharge(connection, bookingId, billableDays);
            if (roomChargeInfo.roomIds.isEmpty()) {
                throw new SQLException("Booking không có phòng để thực hiện trả phòng.");
            }

            for (Integer roomId : roomChargeInfo.roomIds) {
                TrangThaiPhong roomStatus = lockRoomStatus(connection, roomId);
                if (roomStatus != TrangThaiPhong.DANG_O) {
                    throw new SQLException(
                            "Có phòng trong booking không còn ở trạng thái Có khách. "
                                    + "Vui lòng tải lại dữ liệu trước khi thanh toán."
                    );
                }
            }

            BigDecimal serviceTotal = calculateServiceTotal(connection, bookingId);
            BigDecimal preDiscountTotal = roomChargeInfo.roomTotal
                    .add(serviceTotal)
                    .add(surcharge);

            if (discount.compareTo(preDiscountTotal) > 0) {
                throw new IllegalArgumentException("Giảm giá không được lớn hơn tổng tiền trước giảm giá.");
            }

            HoaDon invoice = findInvoiceByBookingForUpdate(connection, bookingId).orElse(null);
            if (invoice == null) {
                invoice = new HoaDon();
                invoice.setMaHoaDon(generateInvoiceCode());
                invoice.setDatPhongId(bookingId);
                invoice.setTongTienPhong(roomChargeInfo.roomTotal);
                invoice.setTongTienDichVu(serviceTotal);
                invoice.setPhuThu(surcharge);
                invoice.setGiamGia(discount);
                invoice.setTrangThai(TrangThaiHoaDon.CHUA_THANH_TOAN);
                invoice.setNhanVienLapId(employeeId);
                invoice.setThoiGianLap(checkoutTime);
                invoice.setGhiChu(normalizeText(note));
                insert(connection, invoice);
            } else {
                if (invoice.getTrangThai() == TrangThaiHoaDon.DA_HUY) {
                    throw new SQLException("Hóa đơn của booking đã bị hủy, không thể thanh toán.");
                }
                invoice.setTongTienPhong(roomChargeInfo.roomTotal);
                invoice.setTongTienDichVu(serviceTotal);
                invoice.setPhuThu(surcharge);
                invoice.setGiamGia(discount);
                invoice.setNhanVienLapId(employeeId);
                invoice.setGhiChu(normalizeText(note));
                updateInvoiceWithinTransaction(connection, invoice);
            }

            invoice = loadInvoiceWithinTransaction(connection, invoice.getId());
            BigDecimal invoiceTotal = nonNull(invoice.getTongThanhToan());
            BigDecimal paidBefore = calculatePaidAmount(connection, invoice.getId());
            BigDecimal remaining = invoiceTotal.subtract(paidBefore);
            if (remaining.compareTo(BigDecimal.ZERO) < 0) {
                remaining = BigDecimal.ZERO;
            }

            BigDecimal paidNow = BigDecimal.ZERO;
            String paymentCode = null;
            if (remaining.compareTo(BigDecimal.ZERO) > 0) {
                paymentCode = generatePaymentCode();
                insertPayment(
                        connection,
                        paymentCode,
                        invoice.getId(),
                        remaining,
                        paymentMethod,
                        normalizeText(referenceCode),
                        employeeId,
                        checkoutTime,
                        normalizeText(note)
                );
                paidNow = remaining;
            }

            BigDecimal totalPaid = paidBefore.add(paidNow);
            TrangThaiHoaDon finalInvoiceStatus = totalPaid.compareTo(invoiceTotal) >= 0
                    ? TrangThaiHoaDon.DA_THANH_TOAN
                    : TrangThaiHoaDon.THANH_TOAN_MOT_PHAN;

            updateInvoiceStatus(connection, invoice.getId(), finalInvoiceStatus);

            if (finalInvoiceStatus != TrangThaiHoaDon.DA_THANH_TOAN) {
                throw new SQLException("Hóa đơn chưa được thanh toán đủ nên chưa thể hoàn tất trả phòng.");
            }

            updateBookingAsCheckedOut(connection, bookingId, employeeId, checkoutTime);
            updateRoomsToCleaning(connection, roomChargeInfo.roomIds);
            createCleaningTasks(connection, roomChargeInfo.roomIds, employeeId, checkoutTime);
            insertAuditLog(
                    connection,
                    employeeId,
                    "THANH_TOAN_TRA_PHONG",
                    "HOA_DON",
                    String.valueOf(invoice.getId()),
                    "Thanh toán và trả phòng booking " + bookingInfo.bookingCode
                            + ", hóa đơn " + invoice.getMaHoaDon()
                            + ", tổng tiền " + invoiceTotal.toPlainString()
            );

            connection.commit();

            invoice.setTrangThai(finalInvoiceStatus);
            return new CheckoutResult(
                    invoice,
                    bookingInfo.bookingCode,
                    billableDays,
                    roomChargeInfo.roomTotal,
                    serviceTotal,
                    surcharge,
                    discount,
                    invoiceTotal,
                    paidBefore,
                    paidNow,
                    checkoutTime,
                    paymentCode,
                    roomChargeInfo.roomNumbers
            );

        } catch (SQLException | RuntimeException exception) {
            rollbackQuietly(connection, exception);
            throw exception;
        } finally {
            closeTransactionalConnection(connection);
        }
    }

    private BookingCheckoutInfo lockBookingForCheckout(Connection connection, int bookingId) throws SQLException {
        String sql = "SELECT ma_dat_phong, trang_thai, ngay_nhan_thuc_te, tien_coc "
                + "FROM dat_phong WHERE id = ? FOR UPDATE";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new SQLException("Không tìm thấy booking có ID " + bookingId + ".");
                }
                BookingCheckoutInfo info = new BookingCheckoutInfo();
                info.bookingCode = resultSet.getString("ma_dat_phong");
                info.status = TrangThaiDatPhong.valueOf(resultSet.getString("trang_thai"));
                Timestamp actualCheckIn = resultSet.getTimestamp("ngay_nhan_thuc_te");
                info.actualCheckIn = actualCheckIn == null ? null : actualCheckIn.toLocalDateTime();
                info.deposit = nonNull(resultSet.getBigDecimal("tien_coc"));
                return info;
            }
        }
    }

    private int calculateBillableDays(LocalDateTime checkIn, LocalDateTime checkout) {
        LocalDate checkInDate = checkIn.toLocalDate();
        LocalDate checkoutDate = checkout.toLocalDate();
        long days = ChronoUnit.DAYS.between(checkInDate, checkoutDate);
        return (int) Math.max(1L, days);
    }

    private RoomChargeInfo calculateRoomCharge(Connection connection, int bookingId, int billableDays)
            throws SQLException {
        String sql = "SELECT ct.phong_id, p.so_phong, ct.gia_phong_thuc_te "
                + "FROM chi_tiet_dat_phong ct "
                + "JOIN phong p ON p.id = ct.phong_id "
                + "WHERE ct.dat_phong_id = ? ORDER BY p.so_phong FOR UPDATE";

        RoomChargeInfo info = new RoomChargeInfo();
        BigDecimal dailyTotal = BigDecimal.ZERO;
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int roomId = resultSet.getInt("phong_id");
                    String roomNumber = resultSet.getString("so_phong");
                    BigDecimal price = nonNull(resultSet.getBigDecimal("gia_phong_thuc_te"));
                    info.roomIds.add(roomId);
                    info.roomNumbers.add(roomNumber);
                    dailyTotal = dailyTotal.add(price);
                }
            }
        }
        info.roomTotal = dailyTotal.multiply(BigDecimal.valueOf(billableDays));
        return info;
    }

    private TrangThaiPhong lockRoomStatus(Connection connection, int roomId) throws SQLException {
        String sql = "SELECT trang_thai FROM phong WHERE id = ? FOR UPDATE";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, roomId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new SQLException("Không tìm thấy phòng có ID " + roomId + ".");
                }
                return TrangThaiPhong.valueOf(resultSet.getString("trang_thai"));
            }
        }
    }

    private BigDecimal calculateServiceTotal(Connection connection, int bookingId) throws SQLException {
        String sql = "SELECT COALESCE(SUM(sd.thanh_tien), 0) AS tong_dich_vu "
                + "FROM su_dung_dich_vu sd "
                + "JOIN chi_tiet_dat_phong ct ON ct.id = sd.chi_tiet_dat_phong_id "
                + "WHERE ct.dat_phong_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? nonNull(resultSet.getBigDecimal("tong_dich_vu")) : BigDecimal.ZERO;
            }
        }
    }

    private Optional<HoaDon> findInvoiceByBookingForUpdate(Connection connection, int bookingId) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM hoa_don hd WHERE hd.dat_phong_id = ? FOR UPDATE";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    private void updateInvoiceWithinTransaction(Connection connection, HoaDon invoice) throws SQLException {
        String sql = "UPDATE hoa_don SET tong_tien_phong = ?, tong_tien_dich_vu = ?, phu_thu = ?, giam_gia = ?, "
                + "nhan_vien_lap_id = ?, ghi_chu = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setBigDecimal(1, nonNull(invoice.getTongTienPhong()));
            statement.setBigDecimal(2, nonNull(invoice.getTongTienDichVu()));
            statement.setBigDecimal(3, nonNull(invoice.getPhuThu()));
            statement.setBigDecimal(4, nonNull(invoice.getGiamGia()));
            setNullableInteger(statement, 5, invoice.getNhanVienLapId());
            statement.setString(6, invoice.getGhiChu());
            statement.setInt(7, invoice.getId());
            if (statement.executeUpdate() != 1) {
                throw new SQLException("Không cập nhật được hóa đơn.");
            }
        }
    }

    private HoaDon loadInvoiceWithinTransaction(Connection connection, int invoiceId) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM hoa_don hd WHERE hd.id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, invoiceId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new SQLException("Không đọc lại được hóa đơn sau khi lưu.");
                }
                return mapRow(resultSet);
            }
        }
    }

    private BigDecimal calculatePaidAmount(Connection connection, int invoiceId) throws SQLException {
        String sql = "SELECT COALESCE(SUM(so_tien), 0) AS da_thanh_toan FROM thanh_toan WHERE hoa_don_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, invoiceId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? nonNull(resultSet.getBigDecimal("da_thanh_toan")) : BigDecimal.ZERO;
            }
        }
    }

    private void insertPayment(
            Connection connection,
            String paymentCode,
            int invoiceId,
            BigDecimal amount,
            PhuongThucThanhToan method,
            String referenceCode,
            Integer employeeId,
            LocalDateTime paymentTime,
            String note) throws SQLException {

        String sql = "INSERT INTO thanh_toan(ma_thanh_toan, hoa_don_id, so_tien, phuong_thuc, ma_tham_chieu, "
                + "nhan_vien_thu_id, thoi_gian_thanh_toan, ghi_chu) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, paymentCode);
            statement.setInt(2, invoiceId);
            statement.setBigDecimal(3, amount);
            statement.setString(4, method.name());
            statement.setString(5, referenceCode);
            setNullableInteger(statement, 6, employeeId);
            statement.setTimestamp(7, Timestamp.valueOf(paymentTime));
            statement.setString(8, note);
            if (statement.executeUpdate() != 1) {
                throw new SQLException("Không ghi được giao dịch thanh toán.");
            }
        }
    }

    private void updateInvoiceStatus(Connection connection, int invoiceId, TrangThaiHoaDon status) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "UPDATE hoa_don SET trang_thai = ? WHERE id = ?")) {
            statement.setString(1, status.name());
            statement.setInt(2, invoiceId);
            if (statement.executeUpdate() != 1) {
                throw new SQLException("Không cập nhật được trạng thái hóa đơn.");
            }
        }
    }

    private void updateBookingAsCheckedOut(
            Connection connection,
            int bookingId,
            Integer employeeId,
            LocalDateTime checkoutTime) throws SQLException {

        String sql = "UPDATE dat_phong SET ngay_tra_thuc_te = ?, nhan_vien_tra_phong_id = ?, "
                + "trang_thai = 'DA_TRA_PHONG' WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setTimestamp(1, Timestamp.valueOf(checkoutTime));
            setNullableInteger(statement, 2, employeeId);
            statement.setInt(3, bookingId);
            if (statement.executeUpdate() != 1) {
                throw new SQLException("Không cập nhật được trạng thái trả phòng của booking.");
            }
        }
    }

    private void createCleaningTasks(Connection connection, List<Integer> roomIds, Integer employeeId, LocalDateTime checkoutTime)
            throws SQLException {
        String existsSql = "SELECT id FROM nhiem_vu_buong_phong WHERE phong_id = ? "
                + "AND loai_nhiem_vu = 'DON_PHONG' AND trang_thai IN ('CHO_XU_LY','DANG_XU_LY') "
                + "LIMIT 1 FOR UPDATE";
        String insertSql = "INSERT INTO nhiem_vu_buong_phong("
                + "ma_nhiem_vu, phong_id, loai_nhiem_vu, muc_do_uu_tien, trang_thai, "
                + "nguoi_tao_id, nhan_vien_phu_trach_id, thoi_gian_tao, ghi_chu) "
                + "VALUES (?, ?, 'DON_PHONG', 'CAO', 'CHO_XU_LY', ?, NULL, ?, ?)";

        for (Integer roomId : roomIds) {
            boolean hasOpenTask;
            try (PreparedStatement statement = connection.prepareStatement(existsSql)) {
                statement.setInt(1, roomId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    hasOpenTask = resultSet.next();
                }
            }

            if (hasOpenTask) {
                continue;
            }

            String taskCode = "BP" + checkoutTime.format(CODE_FORMATTER) + roomId;
            if (taskCode.length() > 20) {
                taskCode = taskCode.substring(0, 20);
            }

            try (PreparedStatement statement = connection.prepareStatement(insertSql)) {
                statement.setString(1, taskCode);
                statement.setInt(2, roomId);
                if (employeeId == null) {
                    statement.setNull(3, Types.INTEGER);
                } else {
                    statement.setInt(3, employeeId);
                }
                statement.setTimestamp(4, Timestamp.valueOf(checkoutTime));
                statement.setString(5, "Tự động tạo sau khi checkout; chờ buồng phòng xác nhận hoàn tất.");
                statement.executeUpdate();
            }
        }
    }

    private void updateRoomsToCleaning(Connection connection, List<Integer> roomIds) throws SQLException {
        String sql = "UPDATE phong SET trang_thai = 'DANG_DON' WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            for (Integer roomId : roomIds) {
                statement.setInt(1, roomId);
                statement.addBatch();
            }
            int[] results = statement.executeBatch();
            for (int result : results) {
                if (result == Statement.EXECUTE_FAILED) {
                    throw new SQLException("Không chuyển được trạng thái phòng sang Đang dọn dẹp.");
                }
            }
        }
    }

    private void insertAuditLog(
            Connection connection,
            Integer accountId,
            String action,
            String objectType,
            String objectId,
            String content) throws SQLException {

        String sql = "INSERT INTO nhat_ky_he_thong(tai_khoan_id, hanh_dong, doi_tuong, doi_tuong_id, noi_dung, thoi_gian) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            setNullableInteger(statement, 1, accountId);
            statement.setString(2, action);
            statement.setString(3, objectType);
            statement.setString(4, objectId);
            statement.setString(5, content);
            statement.setTimestamp(6, Timestamp.valueOf(LocalDateTime.now()));
            statement.executeUpdate();
        }
    }

    private String generateInvoiceCode() {
        return "HD" + LocalDateTime.now().format(CODE_FORMATTER);
    }

    private String generatePaymentCode() {
        return "TT" + LocalDateTime.now().format(CODE_FORMATTER);
    }

    private String normalizeText(String value) {
        if (value == null) {
            return null;
        }
        String normalized = value.trim();
        return normalized.isEmpty() ? null : normalized;
    }

    private BigDecimal nonNull(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    private void setNullableInteger(PreparedStatement statement, int index, Integer value) throws SQLException {
        if (value == null) {
            statement.setNull(index, Types.INTEGER);
        } else {
            statement.setInt(index, value);
        }
    }

    private void rollbackQuietly(Connection connection, Exception originalException) {
        if (connection == null) {
            return;
        }
        try {
            connection.rollback();
        } catch (SQLException rollbackException) {
            originalException.addSuppressed(rollbackException);
        }
    }

    private void closeTransactionalConnection(Connection connection) {
        if (connection == null) {
            return;
        }
        try {
            connection.setAutoCommit(true);
        } catch (SQLException ignored) {
        }
        try {
            connection.close();
        } catch (SQLException ignored) {
        }
    }

    private List<HoaDon> executeList(String sql) throws SQLException {
        List<HoaDon> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(mapRow(resultSet));
            }
        }
        return result;
    }

    private void bind(PreparedStatement statement, HoaDon hoaDon, boolean includeId) throws SQLException {
        BigDecimal roomTotal = hoaDon.getTongTienPhong() == null ? BigDecimal.ZERO : hoaDon.getTongTienPhong();
        BigDecimal serviceTotal = hoaDon.getTongTienDichVu() == null ? BigDecimal.ZERO : hoaDon.getTongTienDichVu();
        BigDecimal surcharge = hoaDon.getPhuThu() == null ? BigDecimal.ZERO : hoaDon.getPhuThu();
        BigDecimal discount = hoaDon.getGiamGia() == null ? BigDecimal.ZERO : hoaDon.getGiamGia();
        TrangThaiHoaDon status = hoaDon.getTrangThai() == null ? TrangThaiHoaDon.CHUA_THANH_TOAN : hoaDon.getTrangThai();
        LocalDateTime invoiceTime = hoaDon.getThoiGianLap() == null ? LocalDateTime.now() : hoaDon.getThoiGianLap();

        statement.setString(1, hoaDon.getMaHoaDon());
        statement.setInt(2, hoaDon.getDatPhongId());
        statement.setBigDecimal(3, roomTotal);
        statement.setBigDecimal(4, serviceTotal);
        statement.setBigDecimal(5, surcharge);
        statement.setBigDecimal(6, discount);
        statement.setString(7, status.name());
        JdbcDataAccessSupport.setNullableInteger(statement, 8, hoaDon.getNhanVienLapId());
        statement.setTimestamp(9, Timestamp.valueOf(invoiceTime));
        statement.setString(10, hoaDon.getGhiChu());
        if (includeId) {
            statement.setInt(11, hoaDon.getId());
        }
    }

    private HoaDon mapRow(ResultSet resultSet) throws SQLException {
        HoaDon invoice = new HoaDon();
        invoice.setId(resultSet.getInt("id"));
        invoice.setMaHoaDon(resultSet.getString("ma_hoa_don"));
        invoice.setDatPhongId(resultSet.getInt("dat_phong_id"));
        invoice.setTongTienPhong(resultSet.getBigDecimal("tong_tien_phong"));
        invoice.setTongTienDichVu(resultSet.getBigDecimal("tong_tien_dich_vu"));
        invoice.setPhuThu(resultSet.getBigDecimal("phu_thu"));
        invoice.setGiamGia(resultSet.getBigDecimal("giam_gia"));
        invoice.setTongThanhToan(resultSet.getBigDecimal("tong_thanh_toan"));
        invoice.setTrangThai(TrangThaiHoaDon.valueOf(resultSet.getString("trang_thai")));
        int employeeId = resultSet.getInt("nhan_vien_lap_id");
        invoice.setNhanVienLapId(resultSet.wasNull() ? null : employeeId);
        invoice.setThoiGianLap(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "thoi_gian_lap"));
        invoice.setGhiChu(resultSet.getString("ghi_chu"));
        return invoice;
    }

    public static final class CheckoutResult {
        private final HoaDon invoice;
        private final String bookingCode;
        private final int billableDays;
        private final BigDecimal roomTotal;
        private final BigDecimal serviceTotal;
        private final BigDecimal surcharge;
        private final BigDecimal discount;
        private final BigDecimal invoiceTotal;
        private final BigDecimal paidBefore;
        private final BigDecimal paidNow;
        private final LocalDateTime checkoutTime;
        private final String paymentCode;
        private final List<String> roomNumbers;

        private CheckoutResult(
                HoaDon invoice,
                String bookingCode,
                int billableDays,
                BigDecimal roomTotal,
                BigDecimal serviceTotal,
                BigDecimal surcharge,
                BigDecimal discount,
                BigDecimal invoiceTotal,
                BigDecimal paidBefore,
                BigDecimal paidNow,
                LocalDateTime checkoutTime,
                String paymentCode,
                List<String> roomNumbers) {
            this.invoice = invoice;
            this.bookingCode = bookingCode;
            this.billableDays = billableDays;
            this.roomTotal = roomTotal;
            this.serviceTotal = serviceTotal;
            this.surcharge = surcharge;
            this.discount = discount;
            this.invoiceTotal = invoiceTotal;
            this.paidBefore = paidBefore;
            this.paidNow = paidNow;
            this.checkoutTime = checkoutTime;
            this.paymentCode = paymentCode;
            this.roomNumbers = List.copyOf(roomNumbers);
        }

        public HoaDon getInvoice() { return invoice; }
        public String getBookingCode() { return bookingCode; }
        public int getBillableDays() { return billableDays; }
        public BigDecimal getRoomTotal() { return roomTotal; }
        public BigDecimal getServiceTotal() { return serviceTotal; }
        public BigDecimal getSurcharge() { return surcharge; }
        public BigDecimal getDiscount() { return discount; }
        public BigDecimal getInvoiceTotal() { return invoiceTotal; }
        public BigDecimal getPaidBefore() { return paidBefore; }
        public BigDecimal getPaidNow() { return paidNow; }
        public LocalDateTime getCheckoutTime() { return checkoutTime; }
        public String getPaymentCode() { return paymentCode; }
        public List<String> getRoomNumbers() { return roomNumbers; }
    }

    private static final class BookingCheckoutInfo {
        private String bookingCode;
        private TrangThaiDatPhong status;
        private LocalDateTime actualCheckIn;
        private BigDecimal deposit;
    }

    private static final class RoomChargeInfo {
        private final List<Integer> roomIds = new ArrayList<>();
        private final List<String> roomNumbers = new ArrayList<>();
        private BigDecimal roomTotal = BigDecimal.ZERO;
    }
}
