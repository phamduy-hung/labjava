package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * DAO phục vụ dữ liệu tổng quan cho Trang chủ.
 *
 * Các truy vấn được thực hiện tại CSDL và chỉ lấy đúng lượng dữ liệu cần
 * cho giao diện tổng quan; không tải toàn bộ lịch sử 5 năm lên bộ nhớ.
 */
public class DashboardDAO {

    public Map<String, Integer> demTrangThaiPhong() throws SQLException {
        String sql = "SELECT trang_thai, COUNT(*) AS so_luong "
                + "FROM phong WHERE dang_hoat_dong = TRUE "
                + "GROUP BY trang_thai ORDER BY trang_thai";

        Map<String, Integer> result = new LinkedHashMap<>();

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                result.put(
                        rs.getString("trang_thai"),
                        rs.getInt("so_luong")
                );
            }
        }

        return result;
    }

    public List<DoanhThuThang> doanhThu12ThangGanNhat()
            throws SQLException {

        YearMonth end = YearMonth.now();
        YearMonth start = end.minusMonths(11);

        String sql = "SELECT YEAR(thoi_gian_lap) AS nam, "
                + "MONTH(thoi_gian_lap) AS thang, "
                + "COALESCE(SUM(tong_thanh_toan), 0) AS doanh_thu "
                + "FROM hoa_don "
                + "WHERE trang_thai = 'DA_THANH_TOAN' "
                + "AND thoi_gian_lap >= ? "
                + "AND thoi_gian_lap < ? "
                + "GROUP BY YEAR(thoi_gian_lap), MONTH(thoi_gian_lap) "
                + "ORDER BY YEAR(thoi_gian_lap), MONTH(thoi_gian_lap)";

        Map<YearMonth, BigDecimal> values = new LinkedHashMap<>();
        for (int i = 0; i < 12; i++) {
            values.put(start.plusMonths(i), BigDecimal.ZERO);
        }

        LocalDateTime from = start.atDay(1).atStartOfDay();
        LocalDateTime to = end.plusMonths(1).atDay(1).atStartOfDay();

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setTimestamp(1, Timestamp.valueOf(from));
            statement.setTimestamp(2, Timestamp.valueOf(to));

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    YearMonth month = YearMonth.of(
                            rs.getInt("nam"),
                            rs.getInt("thang")
                    );
                    if (values.containsKey(month)) {
                        values.put(
                                month,
                                nonNull(rs.getBigDecimal("doanh_thu"))
                        );
                    }
                }
            }
        }

        List<DoanhThuThang> result = new ArrayList<>();
        for (Map.Entry<YearMonth, BigDecimal> entry : values.entrySet()) {
            result.add(
                    new DoanhThuThang(
                            entry.getKey(),
                            entry.getValue()
                    )
            );
        }
        return result;
    }

    /**
     * Tương thích ngược với các màn hình cũ.
     */
    public List<DoanhThuThang> doanhThu6ThangGanNhat()
            throws SQLException {
        List<DoanhThuThang> values = doanhThu12ThangGanNhat();
        int from = Math.max(0, values.size() - 6);
        return new ArrayList<>(values.subList(from, values.size()));
    }

    public List<HoatDongGanDay> hoatDongGanDay(int limit)
            throws SQLException {

        int safeLimit = Math.min(12, Math.max(4, limit));

        String sql = "SELECT nk.thoi_gian, tk.ten_dang_nhap, nk.hanh_dong, "
                + "nk.doi_tuong, nk.doi_tuong_id, nk.noi_dung "
                + "FROM nhat_ky_he_thong nk "
                + "LEFT JOIN tai_khoan tk ON tk.id = nk.tai_khoan_id "
                + "ORDER BY nk.thoi_gian DESC, nk.id DESC LIMIT ?";

        List<HoatDongGanDay> result = new ArrayList<>();

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, safeLimit);

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    Timestamp timestamp = rs.getTimestamp("thoi_gian");
                    result.add(
                            new HoatDongGanDay(
                                    timestamp == null
                                            ? null
                                            : timestamp.toLocalDateTime(),
                                    rs.getString("ten_dang_nhap"),
                                    rs.getString("hanh_dong"),
                                    rs.getString("doi_tuong"),
                                    rs.getString("doi_tuong_id"),
                                    rs.getString("noi_dung")
                            )
                    );
                }
            }
        }

        return result;
    }

    /**
     * Ảnh chụp vận hành tại thời điểm hiện tại, dùng cho Dashboard A+.
     * Không tải danh sách booking/phòng về bộ nhớ; mọi KPI được tính ngay tại MySQL.
     */
    public OperationalSnapshot getOperationalSnapshot() throws SQLException {
        String sql = "SELECT "
                + "(SELECT COUNT(*) FROM phong WHERE dang_hoat_dong = TRUE) AS tong_phong, "
                + "(SELECT COUNT(*) FROM phong WHERE dang_hoat_dong = TRUE AND trang_thai = 'TRONG') AS phong_trong, "
                + "(SELECT COUNT(*) FROM phong WHERE dang_hoat_dong = TRUE AND trang_thai = 'DA_DAT') AS phong_da_dat, "
                + "(SELECT COUNT(*) FROM phong WHERE dang_hoat_dong = TRUE AND trang_thai = 'DANG_O') AS phong_dang_o, "
                + "(SELECT COUNT(*) FROM phong WHERE dang_hoat_dong = TRUE AND trang_thai = 'DANG_DON') AS phong_dang_don, "
                + "(SELECT COUNT(*) FROM phong WHERE dang_hoat_dong = TRUE AND trang_thai = 'BAO_TRI') AS phong_bao_tri, "
                + "(SELECT COUNT(*) FROM dat_phong WHERE DATE(ngay_du_kien_nhan) = CURRENT_DATE "
                + "    AND trang_thai IN ('CHO_XAC_NHAN','DA_XAC_NHAN')) AS nhan_phong_hom_nay, "
                + "(SELECT COUNT(*) FROM dat_phong WHERE DATE(ngay_du_kien_tra) = CURRENT_DATE "
                + "    AND trang_thai = 'DA_NHAN_PHONG') AS tra_phong_hom_nay, "
                + "(SELECT COUNT(*) FROM nhiem_vu_buong_phong WHERE trang_thai IN ('CHO_XU_LY','DANG_XU_LY')) AS nhiem_vu_dang_mo, "
                + "(SELECT COUNT(*) FROM hoa_don WHERE trang_thai IN ('CHUA_THANH_TOAN','THANH_TOAN_MOT_PHAN')) AS hoa_don_con_no";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            if (!rs.next()) {
                return OperationalSnapshot.empty();
            }

            int totalRooms = rs.getInt("tong_phong");
            int occupiedRooms = rs.getInt("phong_dang_o");
            double occupancyRate = totalRooms <= 0
                    ? 0.0
                    : occupiedRooms * 100.0 / totalRooms;

            return new OperationalSnapshot(
                    totalRooms,
                    rs.getInt("phong_trong"),
                    rs.getInt("phong_da_dat"),
                    occupiedRooms,
                    rs.getInt("phong_dang_don"),
                    rs.getInt("phong_bao_tri"),
                    rs.getInt("nhan_phong_hom_nay"),
                    rs.getInt("tra_phong_hom_nay"),
                    rs.getInt("nhiem_vu_dang_mo"),
                    rs.getInt("hoa_don_con_no"),
                    occupancyRate
            );
        }
    }

    public static final class OperationalSnapshot {
        private final int totalRooms;
        private final int availableRooms;
        private final int reservedRooms;
        private final int occupiedRooms;
        private final int cleaningRooms;
        private final int maintenanceRooms;
        private final int arrivalsToday;
        private final int departuresToday;
        private final int openHousekeepingTasks;
        private final int outstandingInvoices;
        private final double occupancyRate;

        private OperationalSnapshot(
                int totalRooms,
                int availableRooms,
                int reservedRooms,
                int occupiedRooms,
                int cleaningRooms,
                int maintenanceRooms,
                int arrivalsToday,
                int departuresToday,
                int openHousekeepingTasks,
                int outstandingInvoices,
                double occupancyRate) {
            this.totalRooms = totalRooms;
            this.availableRooms = availableRooms;
            this.reservedRooms = reservedRooms;
            this.occupiedRooms = occupiedRooms;
            this.cleaningRooms = cleaningRooms;
            this.maintenanceRooms = maintenanceRooms;
            this.arrivalsToday = arrivalsToday;
            this.departuresToday = departuresToday;
            this.openHousekeepingTasks = openHousekeepingTasks;
            this.outstandingInvoices = outstandingInvoices;
            this.occupancyRate = occupancyRate;
        }

        public static OperationalSnapshot empty() {
            return new OperationalSnapshot(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.0);
        }

        public int getTotalRooms() { return totalRooms; }
        public int getAvailableRooms() { return availableRooms; }
        public int getReservedRooms() { return reservedRooms; }
        public int getOccupiedRooms() { return occupiedRooms; }
        public int getCleaningRooms() { return cleaningRooms; }
        public int getMaintenanceRooms() { return maintenanceRooms; }
        public int getArrivalsToday() { return arrivalsToday; }
        public int getDeparturesToday() { return departuresToday; }
        public int getOpenHousekeepingTasks() { return openHousekeepingTasks; }
        public int getOutstandingInvoices() { return outstandingInvoices; }
        public double getOccupancyRate() { return occupancyRate; }
    }

    private BigDecimal nonNull(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    public static final class DoanhThuThang {
        private final YearMonth thang;
        private final BigDecimal doanhThu;

        public DoanhThuThang(YearMonth thang, BigDecimal doanhThu) {
            this.thang = thang;
            this.doanhThu = doanhThu;
        }

        public YearMonth getThang() {
            return thang;
        }

        public BigDecimal getDoanhThu() {
            return doanhThu;
        }
    }

    public static final class HoatDongGanDay {
        private final LocalDateTime thoiGian;
        private final String taiKhoan;
        private final String hanhDong;
        private final String doiTuong;
        private final String maDoiTuong;
        private final String noiDung;

        public HoatDongGanDay(
                LocalDateTime thoiGian,
                String taiKhoan,
                String hanhDong,
                String doiTuong,
                String maDoiTuong,
                String noiDung) {
            this.thoiGian = thoiGian;
            this.taiKhoan = taiKhoan;
            this.hanhDong = hanhDong;
            this.doiTuong = doiTuong;
            this.maDoiTuong = maDoiTuong;
            this.noiDung = noiDung;
        }

        public LocalDateTime getThoiGian() {
            return thoiGian;
        }

        public String getTaiKhoan() {
            return taiKhoan;
        }

        public String getHanhDong() {
            return hanhDong;
        }

        public String getDoiTuong() {
            return doiTuong;
        }

        public String getMaDoiTuong() {
            return maDoiTuong;
        }

        public String getNoiDung() {
            return noiDung;
        }
    }
}
