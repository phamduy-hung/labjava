package vn.edu.eaut.hotelmanagement.model.enums;

public enum GioiTinh {
    NAM("Nam"),
    NU("Nữ"),
    KHAC("Khác");

    private final String hienThi;

    GioiTinh(String hienThi) {
        this.hienThi = hienThi;
    }

    @Override
    public String toString() {
        return hienThi;
    }
}
