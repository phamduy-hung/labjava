package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.LoaiPhong;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class LoaiPhongDAO {

    private static final String SELECT_COLUMNS =
            "id, ma_loai_phong, ten_loai_phong, suc_chua_tieu_chuan, suc_chua_toi_da, gia_co_ban, "
                    + "mo_ta, dang_hoat_dong, ngay_tao, ngay_cap_nhat";

    public int insert(LoaiPhong loaiPhong) throws SQLException {
        String sql = "INSERT INTO loai_phong(ma_loai_phong, ten_loai_phong, suc_chua_tieu_chuan, suc_chua_toi_da, "
                + "gia_co_ban, mo_ta, dang_hoat_dong) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, loaiPhong, false);
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    loaiPhong.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của loại phòng vừa thêm.");
    }

    public boolean update(LoaiPhong loaiPhong) throws SQLException {
        String sql = "UPDATE loai_phong SET ma_loai_phong = ?, ten_loai_phong = ?, suc_chua_tieu_chuan = ?, "
                + "suc_chua_toi_da = ?, gia_co_ban = ?, mo_ta = ?, dang_hoat_dong = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            bind(statement, loaiPhong, true);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteById(int id) throws SQLException {
        String sql = "DELETE FROM loai_phong WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    public Optional<LoaiPhong> findById(int id) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM loai_phong WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<LoaiPhong> findAll() throws SQLException {
        return findByActivity(null);
    }

    public List<LoaiPhong> findActive() throws SQLException {
        return findByActivity(Boolean.TRUE);
    }

    public List<LoaiPhong> search(String keyword) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM loai_phong WHERE ma_loai_phong LIKE ? OR ten_loai_phong LIKE ? OR mo_ta LIKE ? "
                + "ORDER BY gia_co_ban, ten_loai_phong";
        String searchValue = "%" + (keyword == null ? "" : keyword.trim()) + "%";
        List<LoaiPhong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, searchValue);
            statement.setString(2, searchValue);
            statement.setString(3, searchValue);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    private List<LoaiPhong> findByActivity(Boolean active) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM loai_phong"
                + (active == null ? "" : " WHERE dang_hoat_dong = ?")
                + " ORDER BY gia_co_ban, ten_loai_phong";
        List<LoaiPhong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            if (active != null) {
                statement.setBoolean(1, active);
            }
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    private void bind(PreparedStatement statement, LoaiPhong loaiPhong, boolean includeId) throws SQLException {
        statement.setString(1, loaiPhong.getMaLoaiPhong());
        statement.setString(2, loaiPhong.getTenLoaiPhong());
        statement.setInt(3, loaiPhong.getSucChuaTieuChuan());
        statement.setInt(4, loaiPhong.getSucChuaToiDa());
        statement.setBigDecimal(5, loaiPhong.getGiaCoBan());
        statement.setString(6, loaiPhong.getMoTa());
        statement.setBoolean(7, loaiPhong.isDangHoatDong());
        if (includeId) {
            statement.setInt(8, loaiPhong.getId());
        }
    }

    private LoaiPhong mapRow(ResultSet resultSet) throws SQLException {
        LoaiPhong loaiPhong = new LoaiPhong();
        loaiPhong.setId(resultSet.getInt("id"));
        loaiPhong.setMaLoaiPhong(resultSet.getString("ma_loai_phong"));
        loaiPhong.setTenLoaiPhong(resultSet.getString("ten_loai_phong"));
        loaiPhong.setSucChuaTieuChuan(resultSet.getInt("suc_chua_tieu_chuan"));
        loaiPhong.setSucChuaToiDa(resultSet.getInt("suc_chua_toi_da"));
        loaiPhong.setGiaCoBan(resultSet.getBigDecimal("gia_co_ban"));
        loaiPhong.setMoTa(resultSet.getString("mo_ta"));
        loaiPhong.setDangHoatDong(resultSet.getBoolean("dang_hoat_dong"));
        loaiPhong.setNgayTao(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_tao"));
        loaiPhong.setNgayCapNhat(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_cap_nhat"));
        return loaiPhong;
    }
}
