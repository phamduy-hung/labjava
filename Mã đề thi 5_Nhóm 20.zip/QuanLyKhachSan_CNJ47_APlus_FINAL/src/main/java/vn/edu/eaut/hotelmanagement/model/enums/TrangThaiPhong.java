package vn.edu.eaut.hotelmanagement.model.enums;

/**
 * Trạng thái tác nghiệp của phòng.
 *
 * Luồng nghiệp vụ chuẩn:
 * TRONG -> DA_DAT -> DANG_O -> DANG_DON -> TRONG.
 * BAO_TRI là trạng thái kỹ thuật, không được đi vào luồng lưu trú thông thường.
 */
public enum TrangThaiPhong {
    TRONG("Trống"),
    DA_DAT("Đã đặt"),
    DANG_O("Đang ở"),
    DANG_DON("Đang dọn"),
    BAO_TRI("Bảo trì");

    private final String hienThi;

    TrangThaiPhong(String hienThi) {
        this.hienThi = hienThi;
    }

    /**
     * Kiểm tra chuyển trạng thái tác nghiệp thông thường.
     * Không bao gồm các thao tác đặc biệt như check-in/check-out;
     * các nghiệp vụ đó vẫn phải đi qua DAO transaction chuyên dụng.
     */
    public boolean canTransitionTo(TrangThaiPhong target) {
        if (target == null) {
            return false;
        }
        if (this == target) {
            return true;
        }
        return switch (this) {
            case TRONG -> target == DA_DAT || target == BAO_TRI;
            case DA_DAT -> target == DANG_O;
            case DANG_O -> target == DANG_DON;
            case DANG_DON -> target == TRONG;
            case BAO_TRI -> target == TRONG;
        };
    }

    public boolean isAvailableForBooking() {
        return this == TRONG;
    }

    public boolean isOccupied() {
        return this == DANG_O;
    }

    public boolean isCleaning() {
        return this == DANG_DON;
    }

    @Override
    public String toString() {
        return hienThi;
    }
}
