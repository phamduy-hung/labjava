package vn.edu.eaut.hotelmanagement.view;

import vn.edu.eaut.hotelmanagement.dao.NhiemVuBuongPhongDAO;
import vn.edu.eaut.hotelmanagement.dao.PhongDAO;
import vn.edu.eaut.hotelmanagement.model.NhiemVuBuongPhong;
import vn.edu.eaut.hotelmanagement.model.Phong;
import vn.edu.eaut.hotelmanagement.model.enums.LoaiNhiemVuBuongPhong;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiNhiemVu;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiPhong;
import vn.edu.eaut.hotelmanagement.session.LoginSession;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

/** Nghiệp vụ dành riêng cho nhân viên buồng phòng. */
public class BuongPhongView extends JPanel {
    private static final Color BG = new Color(244,247,251);
    private static final Color CARD = Color.WHITE;
    private static final Color BORDER = new Color(221,228,236);
    private static final Color TEXT = new Color(38,49,64);
    private static final Color SECONDARY = new Color(105,117,133);
    private static final Color PRIMARY = new Color(26,83,155);
    private static final Color SUCCESS = new Color(37,137,88);
    private static final Color WARNING = new Color(193,124,31);
    private static final Color DANGER = new Color(184,55,55);
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("dd/MM HH:mm");

    private final LoginSession loginSession;
    private final NhiemVuBuongPhongDAO taskDAO = new NhiemVuBuongPhongDAO();
    private final PhongDAO phongDAO = new PhongDAO();
    private final JTextField txtSearch = new JTextField(18);
    private final JComboBox<Object> cboStatus = new JComboBox<>();
    private final JButton btnSearch = new JButton("Tìm kiếm");
    private final JButton btnRefresh = new JButton("Tải lại");
    private final JButton btnClaim = new JButton("Nhận nhiệm vụ");
    private final JButton btnStart = new JButton("Bắt đầu xử lý");
    private final JButton btnComplete = new JButton("Hoàn thành");
    private final JLabel lblSummary = new JLabel("Đang tải...");
    private final JLabel lblWaiting = new JLabel("—");
    private final JLabel lblWorking = new JLabel("—");
    private final JLabel lblCompleted = new JLabel("—");
    private final JLabel lblTotal = new JLabel("—");
    private final JLabel lblStatus = new JLabel("Sẵn sàng");
    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"Mã nhiệm vụ","Phòng","Loại","Ưu tiên","Trạng thái","Tạo lúc","Phụ trách","Ghi chú"},0) {
        @Override public boolean isCellEditable(int r,int c){ return false; }
    };
    private final JTable table = new JTable(model);
    private final Map<Integer,NhiemVuBuongPhong> tasks = new HashMap<>();
    private final Map<Integer,Phong> rooms = new HashMap<>();
    private boolean busy;

    public BuongPhongView(LoginSession loginSession) {
        this.loginSession = Objects.requireNonNull(loginSession,"Phiên đăng nhập không được để trống.");
        buildUI(); registerEvents(); loadData();
    }

    private void buildUI() {
        setLayout(new BorderLayout(0,14)); setBackground(BG); setBorder(new EmptyBorder(18,20,18,20));
        add(createHeader(),BorderLayout.NORTH); add(createContent(),BorderLayout.CENTER); add(createStatus(),BorderLayout.SOUTH);
        configureTable(); configureButtons();
    }

    private JPanel createHeader() {
        JPanel p=card(new BorderLayout(12,6)); p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER),new EmptyBorder(16,18,16,18)));
        JPanel title=new JPanel(new BorderLayout(0,5)); title.setOpaque(false);
        JLabel h=label("NGHIỆP VỤ BUỒNG PHÒNG",21,Font.BOLD,TEXT);
        JLabel d=label("Nhận nhiệm vụ, theo dõi tiến độ và xác nhận phòng đã dọn xong.",12,Font.PLAIN,SECONDARY);
        title.add(h,BorderLayout.NORTH); title.add(d,BorderLayout.SOUTH);
        JPanel user=new JPanel(new GridLayout(2,1,0,3)); user.setOpaque(false);
        JLabel r=label("NHÂN VIÊN BUỒNG PHÒNG",11,Font.BOLD,PRIMARY); r.setHorizontalAlignment(SwingConstants.RIGHT);
        JLabel n=label(loginSession.getTaiKhoan().getHoTen(),12,Font.PLAIN,SECONDARY); n.setHorizontalAlignment(SwingConstants.RIGHT);
        user.add(r); user.add(n); p.add(title,BorderLayout.CENTER); p.add(user,BorderLayout.EAST); return p;
    }

    private JPanel createContent() {
        JPanel p=card(new BorderLayout(0,12)); p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER),new EmptyBorder(14,16,14,16)));
        JPanel bar=new JPanel(new BorderLayout(10,0)); bar.setOpaque(false);
        JPanel filters=new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); filters.setOpaque(false);
        filters.add(label("Tìm kiếm:",12,Font.BOLD,TEXT)); filters.add(txtSearch);
        cboStatus.addItem("Tất cả trạng thái"); for(TrangThaiNhiemVu s:TrangThaiNhiemVu.values()) cboStatus.addItem(s);
        filters.add(label("Trạng thái:",12,Font.BOLD,TEXT)); filters.add(cboStatus); filters.add(btnSearch); filters.add(btnRefresh); bar.add(filters,BorderLayout.WEST);
        JPanel actions=new JPanel(new FlowLayout(FlowLayout.RIGHT,8,0)); actions.setOpaque(false); actions.add(btnClaim); actions.add(btnStart); actions.add(btnComplete); bar.add(actions,BorderLayout.EAST);
        p.add(bar,BorderLayout.NORTH);
        JPanel operationalStrip = new JPanel(new GridLayout(1,4,8,0));
        operationalStrip.setOpaque(false);
        operationalStrip.add(summaryCard("CHỜ XỬ LÝ", WARNING, lblWaiting));
        operationalStrip.add(summaryCard("ĐANG XỬ LÝ", PRIMARY, lblWorking));
        operationalStrip.add(summaryCard("HOÀN THÀNH", SUCCESS, lblCompleted));
        operationalStrip.add(summaryCard("TỔNG NHIỆM VỤ", TEXT, lblTotal));
        p.add(operationalStrip,BorderLayout.SOUTH);
        JScrollPane scroll=new JScrollPane(table); scroll.setBorder(BorderFactory.createLineBorder(BORDER)); p.add(scroll,BorderLayout.CENTER); return p;
    }

    private JPanel summaryCard(String title, Color color, JLabel value) {
        JPanel card = card(new BorderLayout());
        card.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER),new EmptyBorder(6,8,6,8)));
        value.setForeground(color);
        value.setFont(new Font(Font.SANS_SERIF,Font.BOLD,18));
        value.setHorizontalAlignment(SwingConstants.CENTER);
        JLabel text = label(title,9,Font.BOLD,SECONDARY);
        text.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(value,BorderLayout.CENTER);
        card.add(text,BorderLayout.SOUTH);
        return card;
    }

    private JPanel createStatus(){ JPanel p=new JPanel(new BorderLayout()); p.setOpaque(false); lblStatus.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,12)); lblStatus.setForeground(SECONDARY); p.add(lblStatus,BorderLayout.WEST); return p; }

    private void configureTable(){
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); table.setRowHeight(31); table.setAutoCreateRowSorter(true);
        table.getTableHeader().setReorderingAllowed(false); table.getTableHeader().setFont(new Font(Font.SANS_SERIF,Font.BOLD,12));
        table.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,12));
        table.setDefaultRenderer(Object.class,new DefaultTableCellRenderer(){
            @Override public Component getTableCellRendererComponent(JTable t,Object v,boolean s,boolean f,int r,int c){
                Component x=super.getTableCellRendererComponent(t,v,s,f,r,c);
                if(!s && c==4 && v!=null){ String q=v.toString(); if(q.equals("Chờ xử lý"))x.setForeground(WARNING); else if(q.equals("Đang xử lý"))x.setForeground(PRIMARY); else if(q.equals("Hoàn thành"))x.setForeground(SUCCESS); else if(q.equals("Đã hủy"))x.setForeground(DANGER); else x.setForeground(TEXT); }
                else if(!s)x.setForeground(TEXT); return x;
            }
        });
    }

    private void configureButtons(){ style(btnSearch,PRIMARY); style(btnRefresh,Color.WHITE); style(btnClaim,PRIMARY); style(btnStart,WARNING); style(btnComplete,SUCCESS); btnRefresh.setForeground(TEXT); updateButtons(); }
    private void style(JButton b,Color bg){ b.setFont(new Font(Font.SANS_SERIF,Font.BOLD,12)); b.setFocusPainted(false); b.setOpaque(true); b.setBackground(bg); b.setForeground(bg==Color.WHITE?TEXT:Color.WHITE); b.setBorder(BorderFactory.createEmptyBorder(8,13,8,13)); b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); }

    private void registerEvents(){
        btnSearch.addActionListener(e->loadData()); btnRefresh.addActionListener(e->{txtSearch.setText("");cboStatus.setSelectedIndex(0);loadData();});
        txtSearch.addActionListener(e->loadData()); table.getSelectionModel().addListSelectionListener(e->{if(!e.getValueIsAdjusting())updateButtons();});
        btnClaim.addActionListener(e->claim()); btnStart.addActionListener(e->start()); btnComplete.addActionListener(e->complete());
    }

    private void loadData(){
        if(busy)return; busy=true; setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        String key=txtSearch.getText().trim(); TrangThaiNhiemVu status=cboStatus.getSelectedItem() instanceof TrangThaiNhiemVu?(TrangThaiNhiemVu)cboStatus.getSelectedItem():null;
        new SwingWorker<Object[],Void>(){
            @Override protected Object[] doInBackground() throws Exception { return new Object[]{phongDAO.findAll(),taskDAO.search(key,status)}; }
            @Override protected void done(){
                try{
                    Object[] a=get(); @SuppressWarnings("unchecked") List<Phong> ps=(List<Phong>)a[0]; @SuppressWarnings("unchecked") List<NhiemVuBuongPhong> ts=(List<NhiemVuBuongPhong>)a[1];
                    rooms.clear(); for(Phong p:ps)rooms.put(p.getId(),p); tasks.clear(); model.setRowCount(0);
                    for(NhiemVuBuongPhong t:ts){tasks.put(t.getId(),t); Phong p=rooms.get(t.getPhongId()); model.addRow(new Object[]{t.getMaNhiemVu(),p==null?"#"+t.getPhongId():p.getSoPhong(),t.getLoaiNhiemVu(),t.getMucDoUuTien(),t.getTrangThai(),format(t.getThoiGianTao()),assignee(t),t.getGhiChu()});}
                    long waiting=ts.stream().filter(t->t.getTrangThai()==TrangThaiNhiemVu.CHO_XU_LY).count(); long working=ts.stream().filter(t->t.getTrangThai()==TrangThaiNhiemVu.DANG_XU_LY).count(); long completed=ts.stream().filter(t->t.getTrangThai()==TrangThaiNhiemVu.HOAN_THANH).count(); long open=waiting+working; lblWaiting.setText(String.valueOf(waiting)); lblWorking.setText(String.valueOf(working)); lblCompleted.setText(String.valueOf(completed)); lblTotal.setText(String.valueOf(ts.size())); lblSummary.setText("Tổng "+ts.size()+" nhiệm vụ • "+open+" nhiệm vụ đang mở"); lblStatus.setText("Đã tải lúc "+LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))); updateButtons();
                }catch(InterruptedException e){Thread.currentThread().interrupt();error("Tác vụ bị gián đoạn.");}catch(ExecutionException e){error(rootMessage(e));}finally{busy=false;setCursor(Cursor.getDefaultCursor());}
            }
        }.execute();
    }

    private NhiemVuBuongPhong selected(){ int vr=table.getSelectedRow(); if(vr<0)return null; int r=table.convertRowIndexToModel(vr); Object code=model.getValueAt(r,0); for(NhiemVuBuongPhong t:tasks.values())if(t.getMaNhiemVu().equals(code))return t; return null; }
    private void updateButtons(){ NhiemVuBuongPhong t=selected(); boolean mine=t!=null&&Integer.valueOf(loginSession.getTaiKhoan().getId()).equals(t.getNhanVienPhuTrachId()); boolean free=t!=null&&t.getNhanVienPhuTrachId()==null; btnClaim.setEnabled(!busy&&free&&t.getTrangThai()==TrangThaiNhiemVu.CHO_XU_LY); btnStart.setEnabled(!busy&&mine&&t.getTrangThai()==TrangThaiNhiemVu.CHO_XU_LY); btnComplete.setEnabled(!busy&&mine&&t.getTrangThai()==TrangThaiNhiemVu.DANG_XU_LY); }
    private void claim(){ NhiemVuBuongPhong t=selected();if(t==null)return; action(()->taskDAO.claimTask(t.getId(),loginSession.getTaiKhoan().getId()),"Nhận nhiệm vụ thành công.","Nhiệm vụ đã được người khác nhận hoặc không còn chờ xử lý."); }
    private void start(){ NhiemVuBuongPhong t=selected();if(t==null)return; action(()->taskDAO.startTask(t.getId(),loginSession.getTaiKhoan().getId()),"Đã bắt đầu xử lý nhiệm vụ.","Không thể bắt đầu nhiệm vụ."); }
    private void complete(){
        NhiemVuBuongPhong t=selected();if(t==null)return;
        if(t.getLoaiNhiemVu()==LoaiNhiemVuBuongPhong.DON_PHONG){
            Phong p=rooms.get(t.getPhongId()); if(p==null||p.getTrangThai()!=TrangThaiPhong.DANG_DON){error("Nhiệm vụ dọn phòng chỉ hoàn thành khi phòng đang ở trạng thái ĐANG DỌN.");return;}
            if(JOptionPane.showConfirmDialog(this,"Xác nhận phòng "+p.getSoPhong()+" đã được dọn sạch và sẵn sàng đón khách?","Hoàn thành dọn phòng",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE)!=JOptionPane.YES_OPTION)return;
            action(()->phongDAO.completeCleaning(p.getId(),loginSession.getTaiKhoan().getId()),"Đã hoàn thành dọn phòng. Phòng đã chuyển sang TRỐNG.","Không thể hoàn thành. Phòng hoặc nhiệm vụ đã thay đổi.");
        }else action(()->taskDAO.completeTask(t.getId(),loginSession.getTaiKhoan().getId()),"Đã hoàn thành nhiệm vụ.","Nhiệm vụ không còn xử lý hoặc không thuộc về bạn.");
    }

    @FunctionalInterface private interface Action { boolean run() throws Exception; }
    private void action(Action a,String ok,String fail){ if(busy)return; busy=true; lblStatus.setText("Đang xử lý..."); setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR)); new SwingWorker<Boolean,Void>(){
        @Override protected Boolean doInBackground() throws Exception{return a.run();}
        @Override protected void done(){try{boolean result=get(); busy=false; setCursor(Cursor.getDefaultCursor()); if(result){lblStatus.setText(ok);loadData();}else error(fail);}catch(InterruptedException e){Thread.currentThread().interrupt();busy=false;setCursor(Cursor.getDefaultCursor());error("Tác vụ bị gián đoạn.");}catch(ExecutionException e){busy=false;setCursor(Cursor.getDefaultCursor());error(rootMessage(e));}}
    }.execute(); }
    private String assignee(NhiemVuBuongPhong t){if(t.getNhanVienPhuTrachId()==null)return "Chưa nhận";return t.getNhanVienPhuTrachId().equals(loginSession.getTaiKhoan().getId())?"Tôi":"Nhân viên #"+t.getNhanVienPhuTrachId();}
    private String format(LocalDateTime t){return t==null?"—":t.format(TIME);}
    private String rootMessage(Throwable t){Throwable x=t;while(x.getCause()!=null)x=x.getCause();return x.getMessage()==null?x.toString():x.getMessage();}
    private void error(String s){JOptionPane.showMessageDialog(this,s,"Buồng phòng",JOptionPane.ERROR_MESSAGE);}
    private JPanel card(LayoutManager l){JPanel p=new JPanel(l);p.setBackground(CARD);return p;}
    private JLabel label(String s,int size,int style,Color c){JLabel l=new JLabel(s);l.setFont(new Font(Font.SANS_SERIF,style,size));l.setForeground(c);return l;}
}
