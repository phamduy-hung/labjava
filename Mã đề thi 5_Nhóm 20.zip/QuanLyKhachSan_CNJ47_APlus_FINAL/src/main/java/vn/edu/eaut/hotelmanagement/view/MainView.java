package vn.edu.eaut.hotelmanagement.view;

import vn.edu.eaut.hotelmanagement.dao.DashboardDAO;
import vn.edu.eaut.hotelmanagement.dao.ThongKeDAO;
import vn.edu.eaut.hotelmanagement.dao.ThongKeDAO.ThongKeTongHop;
import vn.edu.eaut.hotelmanagement.service.AuditLogService;
import vn.edu.eaut.hotelmanagement.session.LoginSession;
import vn.edu.eaut.hotelmanagement.utils.UITheme;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.RoundRectangle2D;
import java.awt.geom.Ellipse2D;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/**
 * Khung giao diện chính của hệ thống quản lý khách sạn.
 *
 * Kiến trúc giao diện:
 * - BorderLayout ở khung chính.
 * - BorderLayout.WEST: thanh điều hướng cố định.
 * - BorderLayout.CENTER: vùng làm việc dùng CardLayout.
 * - Các màn hình nghiệp vụ đều là JPanel và được nạp theo nhu cầu.
 *
 * Mục tiêu:
 * - Không mở nhiều JFrame con cho từng nghiệp vụ.
 * - Giữ nguyên DAO, Model, Service và luồng xử lý CSDL hiện có.
 * - Chuyển đổi màn hình ngay trong cùng một cửa sổ.
 * - Tách hoàn toàn thanh điều hướng khỏi nội dung nghiệp vụ.
 */
public class MainView extends JFrame {

    private static final long serialVersionUID = 1L;

    private static final Color SIDEBAR_COLOR = new Color(247, 250, 253);
    private static final Color SIDEBAR_BORDER = new Color(220, 228, 238);
    private static final Color PRIMARY = new Color(31, 111, 214);
    private static final Color PRIMARY_DARK = new Color(24, 74, 137);
    private static final Color PRIMARY_SOFT = new Color(225, 239, 255);
    private static final Color BACKGROUND = new Color(247, 249, 252);
    private static final Color CARD = Color.WHITE;
    private static final Color BORDER = new Color(218, 226, 236);
    private static final Color TEXT = new Color(30, 42, 58);
    private static final Color MUTED = new Color(105, 120, 140);
    private static final Color SUCCESS = new Color(37, 137, 88);
    private static final Color DANGER = new Color(205, 55, 55);
    private static final Color DISABLED = new Color(155, 164, 176);

    private static final String CARD_DASHBOARD = "dashboard";
    private static final String CARD_DAT_PHONG = "datPhong";
    private static final String CARD_KHACH_HANG = "khachHang";
    private static final String CARD_PHONG = "phong";
    private static final String CARD_LE_TAN = "leTan";
    private static final String CARD_BUONG_PHONG = "buongPhong";
    private static final String CARD_HOA_DON = "hoaDon";
    private static final String CARD_THONG_KE = "thongKe";
    private static final String CARD_NHAT_KY = "nhatKy";
    private static final String CARD_QUAN_TRI = "quanTri";

    private final LoginSession loginSession;
    private final AuditLogService auditLogService = new AuditLogService();
    private final ThongKeDAO thongKeDAO = new ThongKeDAO();
    private final DashboardDAO dashboardDAO = new DashboardDAO();

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel contentPanel = new JPanel(cardLayout);

    private final JLabel lblModuleTitle = new JLabel("Trang chủ");
    private final JLabel lblModuleHint = new JLabel("Tổng quan vận hành khách sạn 2021–2026");
    private final JLabel lblCurrentTime = new JLabel();

    private final JLabel lblDoanhThuThang = new JLabel("Đang tải...");
    private final JLabel lblCongSuatPhong = new JLabel("Đang tải...");
    private final JLabel lblNhanPhongHomNay = new JLabel("Đang tải...");
    private final JLabel lblTraPhongHomNay = new JLabel("Đang tải...");
    private final JLabel lblHoaDonConNo = new JLabel("Đang tải...");
    private final JLabel lblNhiemVuMo = new JLabel("Đang tải...");

    private final Map<String, JButton> navigationButtons =
            new LinkedHashMap<>();

    private final Timer clockTimer;

    private JPanel dashboardPanel;
    private JPanel phongView;
    private JPanel khachHangView;
    private JPanel datPhongView;
    private JPanel buongPhongView;
    private JPanel hoaDonView;
    private JPanel thongKeView;
    private JPanel nhatKyView;

    private RoomStatusPanel roomStatusPanel;
    private RevenueTrendPanel revenueTrendPanel;
    private RecentActivityPanel recentActivityPanel;

    private boolean roomAllowed;
    private boolean customerAllowed;
    private boolean receptionAllowed;
    private boolean housekeepingAllowed;
    private boolean checkoutAllowed;
    private boolean revenueAllowed;
    private boolean auditLogAllowed;
    private boolean adminAllowed;

    public MainView(LoginSession loginSession) {
        this.loginSession = Objects.requireNonNull(
                loginSession,
                "Phiên đăng nhập không được để trống."
        );

        validateSession();
        initializePermissions();
        initializeFrame();
        initializeComponents();
        registerEvents();

        clockTimer = new Timer(
                1000,
                event -> updateClock()
        );
        clockTimer.setInitialDelay(0);
        clockTimer.start();

        loadDashboardStatistics();
    }

    private void validateSession() {
        if (loginSession.getTaiKhoan() == null) {
            throw new IllegalArgumentException(
                    "Phiên đăng nhập không có thông tin tài khoản."
            );
        }

        if (loginSession.getVaiTro() == null) {
            throw new IllegalArgumentException(
                    "Phiên đăng nhập không có thông tin vai trò."
            );
        }

        if (loginSession.getVaiTro().getMaVaiTro() == null
                || loginSession.getVaiTro().getMaVaiTro().isBlank()) {
            throw new IllegalArgumentException(
                    "Mã vai trò của tài khoản không hợp lệ."
            );
        }
    }

    private void initializePermissions() {
        String roleCode = loginSession.getVaiTro()
                .getMaVaiTro()
                .trim()
                .toUpperCase(Locale.ROOT);

        roomAllowed = false;
        customerAllowed = false;
        receptionAllowed = false;
        housekeepingAllowed = false;
        checkoutAllowed = false;
        revenueAllowed = false;
        auditLogAllowed = false;
        adminAllowed = false;

        switch (roleCode) {
            case "ADMIN" -> {
                roomAllowed = true;
                customerAllowed = true;
                receptionAllowed = true;
                housekeepingAllowed = true;
                checkoutAllowed = true;
                revenueAllowed = true;
                auditLogAllowed = true;
                adminAllowed = true;
            }

            case "LE_TAN" -> {
                roomAllowed = true;
                customerAllowed = true;
                receptionAllowed = true;
                checkoutAllowed = true;
            }

            case "BUONG_PHONG" -> {
                housekeepingAllowed = true;
            }

            case "KE_TOAN" -> {
                checkoutAllowed = true;
                revenueAllowed = true;
            }

            default -> {
                // Không cấp quyền nếu mã vai trò không được định nghĩa.
            }
        }
    }

    private void initializeFrame() {
        setTitle("Hotel Management - Hệ thống quản lý khách sạn");
        setDefaultCloseOperation(
                WindowConstants.DO_NOTHING_ON_CLOSE
        );
        setMinimumSize(new Dimension(1180, 720));
        setSize(1440, 900);
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    private void initializeComponents() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BACKGROUND);

        root.add(
                createSidebar(),
                BorderLayout.WEST
        );

        root.add(
                createWorkspace(),
                BorderLayout.CENTER
        );

        setContentPane(root);
    }

    /**
     * Thanh điều hướng cố định ở bên trái.
     */
    private JPanel createSidebar() {
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(SIDEBAR_COLOR);
        sidebar.setBorder(
                BorderFactory.createMatteBorder(
                        0, 0, 0, 1, SIDEBAR_BORDER
                )
        );
        sidebar.setPreferredSize(new Dimension(282, 0));

        sidebar.add(
                createSidebarBrand(),
                BorderLayout.NORTH
        );

        JPanel navigationWrapper = new JPanel(
                new BorderLayout()
        );
        navigationWrapper.setOpaque(false);
        navigationWrapper.setBorder(
                new EmptyBorder(8, 8, 8, 8)
        );

        JPanel navigation = new JPanel();
        navigation.setOpaque(false);
        navigation.setLayout(
                new javax.swing.BoxLayout(
                        navigation,
                        javax.swing.BoxLayout.Y_AXIS
                )
        );

        addNavigationButton(
                navigation,
                "Trang chủ",
                "home",
                CARD_DASHBOARD,
                true,
                true
        );

        addNavigationButton(
                navigation,
                "Đặt phòng",
                "booking",
                CARD_DAT_PHONG,
                receptionAllowed,
                false
        );

        addNavigationButton(
                navigation,
                "Khách hàng",
                "customer",
                CARD_KHACH_HANG,
                customerAllowed,
                false
        );

        addNavigationButton(
                navigation,
                "Quản lý phòng",
                "room",
                CARD_PHONG,
                roomAllowed,
                false
        );

        addNavigationButton(
                navigation,
                "Lễ tân",
                "reception",
                CARD_LE_TAN,
                receptionAllowed,
                false
        );

        addNavigationButton(
                navigation,
                "Buồng phòng",
                "housekeeping",
                CARD_BUONG_PHONG,
                housekeepingAllowed,
                false
        );

        addNavigationButton(
                navigation,
                "Hóa đơn",
                "invoice",
                CARD_HOA_DON,
                checkoutAllowed,
                false
        );

        addNavigationButton(
                navigation,
                "Thống kê",
                "chart",
                CARD_THONG_KE,
                revenueAllowed,
                false
        );

        addNavigationButton(
                navigation,
                "Nhật ký hệ thống",
                "audit",
                CARD_NHAT_KY,
                auditLogAllowed,
                false
        );

        addNavigationButton(
                navigation,
                "Quản trị hệ thống",
                "settings",
                CARD_QUAN_TRI,
                adminAllowed,
                false
        );

        navigationWrapper.add(
                navigation,
                BorderLayout.NORTH
        );

        JScrollPane navigationScroll = new JScrollPane(
                navigationWrapper
        );
        navigationScroll.setBorder(null);
        navigationScroll.setOpaque(false);
        navigationScroll.getViewport().setOpaque(false);
        navigationScroll.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
        );
        navigationScroll.getVerticalScrollBar().setUnitIncrement(14);

        sidebar.add(
                navigationScroll,
                BorderLayout.CENTER
        );

        sidebar.add(
                createSidebarAccountArea(),
                BorderLayout.SOUTH
        );

        return sidebar;
    }

    private JPanel createSidebarBrand() {
        JPanel brand = new JPanel(
                new BorderLayout(12, 0)
        );
        brand.setOpaque(false);
        brand.setBorder(
                new EmptyBorder(18, 18, 18, 14)
        );

        JLabel logo = new JLabel(
                "H",
                SwingConstants.CENTER
        );
        logo.setPreferredSize(
                new Dimension(48, 48)
        );
        logo.setOpaque(true);
        logo.setBackground(Color.WHITE);
        logo.setForeground(PRIMARY);
        logo.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        26
                )
        );
        logo.setBorder(
                BorderFactory.createLineBorder(
                        new Color(215, 225, 238)
                )
        );

        JPanel text = new JPanel(
                new GridLayout(2, 1, 0, 2)
        );
        text.setOpaque(false);

        JLabel title = new JLabel(
                "HOTEL MANAGEMENT"
        );
        title.setForeground(PRIMARY_DARK);
        title.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        16
                )
        );

        JLabel subtitle = new JLabel(
                "Quản lý khách sạn"
        );
        subtitle.setForeground(MUTED);
        subtitle.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        11
                )
        );

        text.add(title);
        text.add(subtitle);

        brand.add(logo, BorderLayout.WEST);
        brand.add(text, BorderLayout.CENTER);

        return brand;
    }

    private void addNavigationButton(
            JPanel navigation,
            String text,
            String iconType,
            String cardName,
            boolean allowed,
            boolean active) {

        JButton button = createNavigationButton(
                text,
                iconType,
                cardName,
                allowed,
                active
        );

        navigationButtons.put(
                text,
                button
        );

        navigation.add(button);
        navigation.add(
                javax.swing.Box.createVerticalStrut(4)
        );
    }

    private JButton createNavigationButton(
            String text,
            String iconType,
            String cardName,
            boolean allowed,
            boolean active) {

        JButton button = new JButton(
                text,
                new SidebarIcon(iconType, active)
        );
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI());

        button.setHorizontalAlignment(
                SwingConstants.LEFT
        );
        button.setIconTextGap(13);

        button.setPreferredSize(
                new Dimension(262, 46)
        );
        button.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        44
                )
        );

        button.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        active
                                ? Font.BOLD
                                : Font.PLAIN,
                        13
                )
        );

        button.setBorder(
                new EmptyBorder(
                        0, 14, 0, 10
                )
        );

        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(true);
        button.setOpaque(true);
        button.setCursor(
                Cursor.getPredefinedCursor(
                        allowed
                                ? Cursor.HAND_CURSOR
                                : Cursor.DEFAULT_CURSOR
                )
        );

        button.putClientProperty(
                "navAllowed",
                allowed
        );
        button.putClientProperty(
                "navIconType",
                iconType
        );
        button.putClientProperty(
                "navCard",
                cardName
        );

        applyNavigationState(
                button,
                active,
                allowed
        );

        if (allowed) {
            button.addActionListener(
                    event -> showModule(cardName)
            );
        } else {
            button.setToolTipText(
                    "Tài khoản hiện tại không có quyền truy cập chức năng này."
            );
        }

        return button;
    }

    private void applyNavigationState(
            JButton button,
            boolean active,
            boolean allowed) {

        if (active && allowed) {
            button.setBackground(PRIMARY_SOFT);
            button.setForeground(PRIMARY);
            button.setFont(
                    new Font(
                            UITheme.FONT_NAME,
                            Font.BOLD,
                            13
                    )
            );
            button.setBorder(
                    BorderFactory.createCompoundBorder(
                            BorderFactory.createMatteBorder(
                                    0, 4, 0, 0, PRIMARY
                            ),
                            new EmptyBorder(
                                    0, 10, 0, 10
                            )
                    )
            );
        } else {
            button.setBackground(SIDEBAR_COLOR);
            button.setForeground(
                    allowed ? TEXT : DISABLED
            );
            button.setFont(
                    new Font(
                            UITheme.FONT_NAME,
                            Font.PLAIN,
                            13
                    )
            );
            button.setBorder(
                    new EmptyBorder(
                            0, 14, 0, 10
                    )
            );
        }

        String iconType = (String) button.getClientProperty(
                "navIconType"
        );

        button.setIcon(
                new SidebarIcon(
                        iconType,
                        active && allowed
                )
        );
    }

    private JPanel createSidebarAccountArea() {
        JPanel bottom = new JPanel(
                new BorderLayout(0, 8)
        );
        bottom.setOpaque(false);
        bottom.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(
                                1, 0, 0, 0, SIDEBAR_BORDER
                        ),
                        new EmptyBorder(
                                12, 14, 12, 14
                        )
                )
        );

        JPanel account = new JPanel(
                new BorderLayout(10, 0)
        );
        account.setOpaque(false);

        JLabel icon = new JLabel(
                new UserIcon(PRIMARY_DARK)
        );
        icon.setPreferredSize(
                new Dimension(34, 34)
        );

        JPanel info = new JPanel(
                new GridLayout(2, 1, 0, 2)
        );
        info.setOpaque(false);

        JLabel name = new JLabel(
                loginSession.getTaiKhoan().getTenDangNhap()
        );
        name.setForeground(TEXT);
        name.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        12
                )
        );

        JLabel role = new JLabel(
                loginSession.getVaiTro().getTenVaiTro()
        );
        role.setForeground(MUTED);
        role.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        11
                )
        );

        info.add(name);
        info.add(role);

        account.add(icon, BorderLayout.WEST);
        account.add(info, BorderLayout.CENTER);

        JButton logout = new JButton(
                "Đăng xuất",
                new LogoutIcon(DANGER)
        );
        logout.setHorizontalAlignment(
                SwingConstants.LEFT
        );
        logout.setIconTextGap(12);
        logout.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        12
                )
        );
        logout.setForeground(DANGER);
        logout.setBackground(SIDEBAR_COLOR);
        logout.setBorder(
                new EmptyBorder(7, 4, 7, 4)
        );
        logout.setFocusPainted(false);
        logout.setBorderPainted(false);
        logout.setContentAreaFilled(false);
        logout.setCursor(
                Cursor.getPredefinedCursor(
                        Cursor.HAND_CURSOR
                )
        );
        logout.addActionListener(
                event -> handleLogout()
        );

        bottom.add(account, BorderLayout.NORTH);
        bottom.add(logout, BorderLayout.SOUTH);

        return bottom;
    }

    /**
     * Vùng làm việc chính.
     */
    private JPanel createWorkspace() {
        JPanel workspace = new JPanel(
                new BorderLayout()
        );
        workspace.setBackground(BACKGROUND);

        workspace.add(
                createWorkspaceHeader(),
                BorderLayout.NORTH
        );

        contentPanel.setBackground(BACKGROUND);

        contentPanel.add(
                createDashboardPanel(),
                CARD_DASHBOARD
        );

        workspace.add(
                contentPanel,
                BorderLayout.CENTER
        );

        return workspace;
    }

    private JPanel createWorkspaceHeader() {
        JPanel header = new JPanel(
                new BorderLayout(15, 0)
        );
        header.setBackground(BACKGROUND);
        header.setBorder(
                new EmptyBorder(
                        20, 24, 12, 24
                )
        );

        JPanel title = new JPanel(
                new GridLayout(2, 1, 0, 3)
        );
        title.setOpaque(false);

        lblModuleTitle.setForeground(TEXT);
        lblModuleTitle.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        24
                )
        );

        lblModuleHint.setForeground(MUTED);
        lblModuleHint.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        12
                )
        );

        title.add(lblModuleTitle);
        title.add(lblModuleHint);

        JPanel accountInfo = new JPanel(
                new GridLayout(2, 1, 0, 2)
        );
        accountInfo.setOpaque(false);

        JLabel user = new JLabel(
                loginSession.getTaiKhoan().getHoTen(),
                SwingConstants.RIGHT
        );
        user.setForeground(PRIMARY_DARK);
        user.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        12
                )
        );

        lblCurrentTime.setForeground(MUTED);
        lblCurrentTime.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        10
                )
        );
        lblCurrentTime.setHorizontalAlignment(
                SwingConstants.RIGHT
        );

        accountInfo.add(user);
        accountInfo.add(lblCurrentTime);

        header.add(title, BorderLayout.CENTER);
        header.add(accountInfo, BorderLayout.EAST);

        return header;
    }

    /**
     * Dashboard mới: không còn lưới nút chức năng lớn như giao diện cũ.
     */
    private JPanel createDashboardPanel() {
        dashboardPanel = new JPanel(
                new BorderLayout(0, 16)
        );
        dashboardPanel.setBackground(BACKGROUND);
        dashboardPanel.setBorder(
                new EmptyBorder(
                        0, 24, 24, 24
                )
        );

        dashboardPanel.add(
                createWelcomeCard(),
                BorderLayout.NORTH
        );

        JPanel center = new JPanel(
                new BorderLayout(0, 14)
        );
        center.setOpaque(false);

        center.add(
                createSummaryPanel(),
                BorderLayout.NORTH
        );

        center.add(
                createOperationalOverview(),
                BorderLayout.CENTER
        );

        dashboardPanel.add(
                center,
                BorderLayout.CENTER
        );

        return dashboardPanel;
    }

    private JPanel createWelcomeCard() {
        JPanel card = new RoundedPanel(
                CARD,
                BORDER,
                12
        );
        card.setLayout(
                new BorderLayout(18, 0)
        );
        card.setBorder(
                new EmptyBorder(
                        18, 20, 18, 20
                )
        );

        JPanel info = new JPanel(
                new GridLayout(3, 1, 0, 4)
        );
        info.setOpaque(false);

        JLabel welcome = new JLabel(
                "Xin chào, "
                        + loginSession.getTaiKhoan().getHoTen()
                        + "!"
        );
        welcome.setForeground(TEXT);
        welcome.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        24
                )
        );

        JLabel role = new JLabel(
                "Vai trò hiện tại: "
                        + loginSession.getVaiTro().getTenVaiTro()
        );
        role.setForeground(PRIMARY);
        role.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        12
                )
        );

        JLabel hint = new JLabel(
                "Dashboard kết hợp dữ liệu lịch sử 2021–2026 với trạng thái vận hành hiện tại của khách sạn."
        );
        hint.setForeground(MUTED);
        hint.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        12
                )
        );

        info.add(welcome);
        info.add(role);
        info.add(hint);

        JPanel status = new RoundedPanel(
                new Color(232, 247, 239),
                new Color(190, 224, 204),
                10
        );
        status.setPreferredSize(
                new Dimension(190, 62)
        );
        status.setLayout(
                new BorderLayout()
        );

        JLabel statusText = new JLabel(
                "HỆ THỐNG SẴN SÀNG",
                SwingConstants.CENTER
        );
        statusText.setForeground(SUCCESS);
        statusText.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        11
                )
        );

        status.add(
                statusText,
                BorderLayout.CENTER
        );

        card.add(info, BorderLayout.CENTER);
        card.add(status, BorderLayout.EAST);

        return card;
    }

    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(
                new GridLayout(1, 6, 10, 0)
        );
        panel.setOpaque(false);

        panel.add(
                createSummaryCard(
                        "DOANH THU THÁNG",
                        lblDoanhThuThang,
                        "Hóa đơn đã thanh toán"
                )
        );

        panel.add(
                createSummaryCard(
                        "CÔNG SUẤT PHÒNG",
                        lblCongSuatPhong,
                        "Phòng đang có khách"
                )
        );

        panel.add(
                createSummaryCard(
                        "CHECK-IN HÔM NAY",
                        lblNhanPhongHomNay,
                        "Booking dự kiến nhận"
                )
        );

        panel.add(
                createSummaryCard(
                        "CHECK-OUT HÔM NAY",
                        lblTraPhongHomNay,
                        "Khách dự kiến trả"
                )
        );

        panel.add(
                createSummaryCard(
                        "HÓA ĐƠN CÒN NỢ",
                        lblHoaDonConNo,
                        "Chưa thanh toán đủ"
                )
        );

        panel.add(
                createSummaryCard(
                        "NHIỆM VỤ MỞ",
                        lblNhiemVuMo,
                        "Buồng phòng / bảo trì"
                )
        );

        return panel;
    }

    private JPanel createSummaryCard(
            String title,
            JLabel value,
            String description) {

        JPanel card = new RoundedPanel(
                CARD,
                BORDER,
                10
        );
        card.setLayout(
                new BorderLayout(0, 3)
        );
        card.setBorder(
                new EmptyBorder(
                        12, 15, 12, 15
                )
        );

        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(MUTED);
        titleLabel.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        10
                )
        );

        value.setForeground(PRIMARY);
        value.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        18
                )
        );

        JLabel descriptionLabel = new JLabel(
                description
        );
        descriptionLabel.setForeground(MUTED);
        descriptionLabel.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        10
                )
        );

        JPanel text = new JPanel(
                new GridLayout(3, 1, 0, 1)
        );
        text.setOpaque(false);
        text.add(titleLabel);
        text.add(value);
        text.add(descriptionLabel);

        card.add(text, BorderLayout.CENTER);

        return card;
    }

    /**
     * Khu vực vận hành thực tế của khách sạn.
     * Thay cho ba thẻ mô tả tĩnh, màn hình hiển thị trạng thái phòng,
     * xu hướng doanh thu và các hoạt động mới nhất.
     */
    private JPanel createOperationalOverview() {
        JPanel wrapper = new JPanel(new BorderLayout(0, 12));
        wrapper.setOpaque(false);

        JPanel top = new JPanel(new GridLayout(1, 2, 12, 0));
        top.setOpaque(false);

        roomStatusPanel = new RoomStatusPanel();
        revenueTrendPanel = new RevenueTrendPanel();

        top.add(roomStatusPanel);
        top.add(revenueTrendPanel);

        recentActivityPanel = new RecentActivityPanel();

        wrapper.add(top, BorderLayout.CENTER);
        wrapper.add(recentActivityPanel, BorderLayout.SOUTH);
        return wrapper;
    }

    private JPanel createProcessOverview() {
        JPanel panel = new JPanel(
                new GridLayout(1, 3, 12, 0)
        );
        panel.setOpaque(false);

        panel.add(
                createProcessCard(
                        "01",
                        "Đặt phòng → Nhận phòng",
                        "Tiếp nhận khách, kiểm tra phòng còn trống, tạo đặt phòng và thực hiện check-in."
                )
        );

        panel.add(
                createProcessCard(
                        "02",
                        "Lưu trú → Dịch vụ",
                        "Theo dõi phòng đang có khách và ghi nhận các dịch vụ phát sinh trong thời gian lưu trú."
                )
        );

        panel.add(
                createProcessCard(
                        "03",
                        "Trả phòng → Buồng phòng",
                        "Thanh toán, trả phòng và chuyển trạng thái sang nghiệp vụ buồng phòng để dọn phòng."
                )
        );

        return panel;
    }

    private JPanel createProcessCard(
            String number,
            String title,
            String description) {

        JPanel card = new RoundedPanel(
                CARD,
                BORDER,
                10
        );
        card.setLayout(
                new BorderLayout(12, 8)
        );
        card.setBorder(
                new EmptyBorder(
                        18, 18, 18, 18
                )
        );

        JLabel badge = new JLabel(
                number,
                SwingConstants.CENTER
        );
        badge.setPreferredSize(
                new Dimension(44, 44)
        );
        badge.setOpaque(true);
        badge.setBackground(PRIMARY_SOFT);
        badge.setForeground(PRIMARY);
        badge.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        14
                )
        );

        JPanel text = new JPanel(
                new BorderLayout(0, 6)
        );
        text.setOpaque(false);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(TEXT);
        titleLabel.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        13
                )
        );

        JLabel descriptionLabel = new JLabel(
                "<html><body style='width:260px'>"
                        + description
                        + "</body></html>"
        );
        descriptionLabel.setForeground(MUTED);
        descriptionLabel.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        11
                )
        );

        text.add(titleLabel, BorderLayout.NORTH);
        text.add(descriptionLabel, BorderLayout.CENTER);

        card.add(badge, BorderLayout.WEST);
        card.add(text, BorderLayout.CENTER);

        return card;
    }

    /**
     * Mở phân hệ theo CardLayout.
     */
    private void showModule(String cardName) {
        if (CARD_DASHBOARD.equals(cardName)) {
            showDashboard();
            return;
        }

        if (CARD_DAT_PHONG.equals(cardName)
                || CARD_LE_TAN.equals(cardName)) {

            if (!receptionAllowed) {
                showAccessDenied("Lễ tân & Đặt phòng");
                return;
            }

            if (datPhongView == null) {
                datPhongView = new DatPhongView(
                        loginSession
                );
                contentPanel.add(
                        datPhongView,
                        CARD_DAT_PHONG
                );
            }

            cardLayout.show(
                    contentPanel,
                    CARD_DAT_PHONG
            );

            setModuleHeader(
                    "Lễ tân & Đặt phòng",
                    "Đặt phòng, tiếp nhận khách và thực hiện check-in."
            );

            setActiveNavigation(
                    CARD_LE_TAN.equals(cardName)
                            ? "Lễ tân"
                            : "Đặt phòng"
            );

            refreshWorkspace();
            return;
        }

        switch (cardName) {
            case CARD_KHACH_HANG -> {
                if (!customerAllowed) {
                    showAccessDenied("Quản lý khách hàng");
                    return;
                }

                if (khachHangView == null) {
                    khachHangView =
                            new KhachHangView(loginSession);

                    contentPanel.add(
                            khachHangView,
                            CARD_KHACH_HANG
                    );
                }

                cardLayout.show(
                        contentPanel,
                        CARD_KHACH_HANG
                );

                setModuleHeader(
                        "Khách hàng",
                        "Quản lý hồ sơ, giấy tờ và thông tin liên hệ của khách lưu trú."
                );

                setActiveNavigation("Khách hàng");
            }

            case CARD_PHONG -> {
                if (!roomAllowed) {
                    showAccessDenied("Quản lý phòng");
                    return;
                }

                if (phongView == null) {
                    phongView =
                            new PhongView(loginSession);

                    contentPanel.add(
                            phongView,
                            CARD_PHONG
                    );
                }

                cardLayout.show(
                        contentPanel,
                        CARD_PHONG
                );

                setModuleHeader(
                        "Quản lý phòng",
                        "Theo dõi phòng, loại phòng, giá và trạng thái khai thác."
                );

                setActiveNavigation("Quản lý phòng");
            }

            case CARD_BUONG_PHONG -> {
                if (!housekeepingAllowed) {
                    showAccessDenied("Buồng phòng");
                    return;
                }

                if (buongPhongView == null) {
                    buongPhongView =
                            new BuongPhongView(loginSession);

                    contentPanel.add(
                            buongPhongView,
                            CARD_BUONG_PHONG
                    );
                }

                cardLayout.show(
                        contentPanel,
                        CARD_BUONG_PHONG
                );

                setModuleHeader(
                        "Buồng phòng",
                        "Nhận nhiệm vụ, xử lý phòng và xác nhận phòng đã sẵn sàng."
                );

                setActiveNavigation("Buồng phòng");
            }

            case CARD_HOA_DON -> {
                if (!checkoutAllowed) {
                    showAccessDenied("Hóa đơn");
                    return;
                }

                if (hoaDonView == null) {
                    hoaDonView =
                            new HoaDonView(loginSession);

                    contentPanel.add(
                            hoaDonView,
                            CARD_HOA_DON
                    );
                }

                cardLayout.show(
                        contentPanel,
                        CARD_HOA_DON
                );

                setModuleHeader(
                        "Trả phòng & Thanh toán",
                        "Tổng hợp tiền phòng, dịch vụ, phụ thu và thanh toán."
                );

                setActiveNavigation("Hóa đơn");
            }

            case CARD_THONG_KE -> {
                if (!revenueAllowed) {
                    showAccessDenied("Thống kê");
                    return;
                }

                if (thongKeView == null) {
                    thongKeView =
                            new ThongKeView(loginSession);

                    contentPanel.add(
                            thongKeView,
                            CARD_THONG_KE
                    );
                }

                cardLayout.show(
                        contentPanel,
                        CARD_THONG_KE
                );

                setModuleHeader(
                        "Thống kê",
                        "Theo dõi doanh thu, hóa đơn đã thanh toán và số liệu quản trị."
                );

                setActiveNavigation("Thống kê");
            }

            case CARD_NHAT_KY -> {
                if (!auditLogAllowed) {
                    showAccessDenied("Nhật ký hệ thống");
                    return;
                }

                if (nhatKyView == null) {
                    nhatKyView =
                            new NhatKyHeThongView(
                                    loginSession,
                                    this::showModule,
                                    this::handleLogout,
                                    false
                            );

                    contentPanel.add(
                            nhatKyView,
                            CARD_NHAT_KY
                    );
                }

                cardLayout.show(
                        contentPanel,
                        CARD_NHAT_KY
                );

                setModuleHeader(
                        "Nhật ký hệ thống",
                        "Theo dõi các thao tác của người dùng trong hệ thống."
                );

                setActiveNavigation(
                        "Nhật ký hệ thống"
                );
            }

            case CARD_QUAN_TRI -> {
                if (!adminAllowed) {
                    showAccessDenied(
                            "Quản trị hệ thống"
                    );
                    return;
                }

                JPanel adminPanel =
                        createAdminInfoPanel();

                contentPanel.add(
                        adminPanel,
                        CARD_QUAN_TRI
                );

                cardLayout.show(
                        contentPanel,
                        CARD_QUAN_TRI
                );

                setModuleHeader(
                        "Quản trị hệ thống",
                        "Thông tin phiên làm việc và quyền quản trị."
                );

                setActiveNavigation(
                        "Quản trị hệ thống"
                );
            }

            default -> showError(
                    "Không xác định được phân hệ cần mở."
            );
        }

        refreshWorkspace();
    }

    private JPanel createAdminInfoPanel() {
        JPanel outer = new JPanel(
                new BorderLayout()
        );
        outer.setBackground(BACKGROUND);
        outer.setBorder(
                new EmptyBorder(
                        0, 24, 24, 24
                )
        );

        JPanel card = new RoundedPanel(
                CARD,
                BORDER,
                12
        );
        card.setLayout(
                new BorderLayout(0, 14)
        );
        card.setBorder(
                new EmptyBorder(
                        22, 24, 22, 24
                )
        );

        JLabel title = new JLabel(
                "THÔNG TIN QUẢN TRỊ HỆ THỐNG"
        );
        title.setForeground(PRIMARY_DARK);
        title.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        18
                )
        );

        JPanel information = new JPanel(
                new GridLayout(0, 2, 12, 10)
        );
        information.setOpaque(false);

        addInfoRow(
                information,
                "Tài khoản",
                loginSession.getTaiKhoan().getTenDangNhap()
        );
        addInfoRow(
                information,
                "Họ tên",
                loginSession.getTaiKhoan().getHoTen()
        );
        addInfoRow(
                information,
                "Vai trò",
                loginSession.getVaiTro().getTenVaiTro()
        );
        addInfoRow(
                information,
                "Mã vai trò",
                loginSession.getVaiTro().getMaVaiTro()
        );
        addInfoRow(
                information,
                "Trạng thái tài khoản",
                loginSession.getTaiKhoan().isDangHoatDong()
                        ? "Đang hoạt động"
                        : "Đang khóa"
        );

        JLabel note = new JLabel(
                "<html>Khung giao diện quản trị đã được tích hợp vào hệ thống. "
                        + "Các chức năng quản lý chuyên sâu có thể tiếp tục mở rộng "
                        + "trên cùng kiến trúc CardLayout mà không cần tạo JFrame mới.</html>"
        );
        note.setForeground(MUTED);
        note.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        12
                )
        );

        card.add(title, BorderLayout.NORTH);
        card.add(information, BorderLayout.CENTER);
        card.add(note, BorderLayout.SOUTH);

        outer.add(card, BorderLayout.NORTH);
        return outer;
    }

    private void addInfoRow(
            JPanel panel,
            String label,
            String value) {

        JLabel left = new JLabel(label);
        left.setForeground(MUTED);
        left.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        12
                )
        );

        JLabel right = new JLabel(
                value == null || value.isBlank()
                        ? "-"
                        : value
        );
        right.setForeground(TEXT);
        right.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        12
                )
        );

        panel.add(left);
        panel.add(right);
    }

    private void showDashboard() {
        cardLayout.show(
                contentPanel,
                CARD_DASHBOARD
        );

        setModuleHeader(
                "Trang chủ",
                "Tổng quan vận hành: phòng, khách, doanh thu, check-in/check-out và buồng phòng."
        );

        setActiveNavigation("Trang chủ");
        refreshWorkspace();
    }

    private void setModuleHeader(
            String title,
            String hint) {

        lblModuleTitle.setText(title);
        lblModuleHint.setText(hint);
    }

    private void setActiveNavigation(
            String activeText) {

        for (Map.Entry<String, JButton> entry
                : navigationButtons.entrySet()) {

            JButton button = entry.getValue();

            boolean allowed =
                    Boolean.TRUE.equals(
                            button.getClientProperty(
                                    "navAllowed"
                            )
                    );

            applyNavigationState(
                    button,
                    entry.getKey().equals(activeText),
                    allowed
            );
        }
    }

    private void refreshWorkspace() {
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    /**
     * Giữ lại phương thức công khai để các lớp cũ có thể gọi khi cần.
     */
    public void openHoaDonView() {
        showModule(CARD_HOA_DON);
    }

    private void loadDashboardStatistics() {
        if (!revenueAllowed
                && !checkoutAllowed
                && !receptionAllowed
                && !housekeepingAllowed) {

            lblDoanhThuThang.setText("-");
            lblCongSuatPhong.setText("-");
            lblNhanPhongHomNay.setText("-");
            lblTraPhongHomNay.setText("-");
            lblHoaDonConNo.setText("-");
            lblNhiemVuMo.setText("-");
            return;
        }

        int year = YearMonth.now().getYear();
        int month = YearMonth.now().getMonthValue();

        new SwingWorker<DashboardSnapshot, Void>() {

            @Override
            protected DashboardSnapshot doInBackground()
                    throws Exception {

                return new DashboardSnapshot(
                        thongKeDAO.thongKeTheoThang(year, month),
                        dashboardDAO.demTrangThaiPhong(),
                        dashboardDAO.getOperationalSnapshot(),
                        dashboardDAO.doanhThu12ThangGanNhat(),
                        dashboardDAO.hoatDongGanDay(8)
                );
            }

            @Override
            protected void done() {
                try {
                    DashboardSnapshot snapshot = get();
                    ThongKeTongHop summary = snapshot.summary;

                    if (revenueAllowed || checkoutAllowed) {
                        lblDoanhThuThang.setText(
                                formatMoney(summary.getTongDoanhThu())
                        );
                        lblHoaDonConNo.setText(
                                String.valueOf(snapshot.operational.getOutstandingInvoices())
                        );
                    } else {
                        lblDoanhThuThang.setText("Ẩn");
                        lblHoaDonConNo.setText("Ẩn");
                    }

                    lblCongSuatPhong.setText(
                            String.format(Locale.ROOT, "%.0f%%", snapshot.operational.getOccupancyRate())
                    );
                    lblNhanPhongHomNay.setText(
                            String.valueOf(snapshot.operational.getArrivalsToday())
                    );
                    lblTraPhongHomNay.setText(
                            String.valueOf(snapshot.operational.getDeparturesToday())
                    );
                    lblNhiemVuMo.setText(
                            String.valueOf(snapshot.operational.getOpenHousekeepingTasks())
                    );

                    if (roomStatusPanel != null) {
                        roomStatusPanel.setData(snapshot.roomStatus);
                    }
                    if (revenueTrendPanel != null) {
                        revenueTrendPanel.setData(snapshot.revenue);
                    }
                    if (recentActivityPanel != null) {
                        recentActivityPanel.setData(snapshot.activities);
                    }

                } catch (Exception exception) {
                    lblDoanhThuThang.setText("Chưa có dữ liệu");
                    lblCongSuatPhong.setText("-");
                    lblNhanPhongHomNay.setText("-");
                    lblTraPhongHomNay.setText("-");
                    lblHoaDonConNo.setText("-");
                    lblNhiemVuMo.setText("-");

                    if (roomStatusPanel != null) {
                        roomStatusPanel.setData(Map.of());
                    }
                    if (revenueTrendPanel != null) {
                        revenueTrendPanel.setData(List.of());
                    }
                    if (recentActivityPanel != null) {
                        recentActivityPanel.setData(List.of());
                    }
                }
            }
        }.execute();
    }

    private static final class DashboardSnapshot {
        private final ThongKeTongHop summary;
        private final Map<String, Integer> roomStatus;
        private final DashboardDAO.OperationalSnapshot operational;
        private final List<DashboardDAO.DoanhThuThang> revenue;
        private final List<DashboardDAO.HoatDongGanDay> activities;

        private DashboardSnapshot(
                ThongKeTongHop summary,
                Map<String, Integer> roomStatus,
                DashboardDAO.OperationalSnapshot operational,
                List<DashboardDAO.DoanhThuThang> revenue,
                List<DashboardDAO.HoatDongGanDay> activities) {
            this.summary = summary;
            this.roomStatus = roomStatus;
            this.operational = operational;
            this.revenue = revenue;
            this.activities = activities;
        }
    }

    private void registerEvents() {
        addWindowListener(
                new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(
                            java.awt.event.WindowEvent event) {
                        handleExit();
                    }
                }
        );
    }

    private void handleLogout() {
        int choice = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc chắn muốn đăng xuất khỏi tài khoản hiện tại?",
                "Xác nhận đăng xuất",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        auditLogService.log(
                loginSession,
                "DANG_XUAT",
                "TAI_KHOAN",
                String.valueOf(
                        loginSession.getTaiKhoan().getId()
                ),
                "Đăng xuất khỏi hệ thống."
        );

        clockTimer.stop();
        dispose();

        SwingUtilities.invokeLater(
                () -> {
                    LoginView loginView =
                            new LoginView();
                    loginView.setVisible(true);
                }
        );
    }

    private void handleExit() {
        int choice = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc chắn muốn thoát hoàn toàn khỏi chương trình?",
                "Xác nhận thoát",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        auditLogService.log(
                loginSession,
                "THOAT_CHUONG_TRINH",
                "TAI_KHOAN",
                String.valueOf(
                        loginSession.getTaiKhoan().getId()
                ),
                "Đóng ứng dụng từ phiên đăng nhập hiện tại."
        );

        clockTimer.stop();
        dispose();
        System.exit(0);
    }

    private void showAccessDenied(
            String moduleName) {

        JOptionPane.showMessageDialog(
                this,
                "Tài khoản hiện tại không có quyền truy cập chức năng:\n"
                        + moduleName
                        + ".",
                "Không đủ quyền",
                JOptionPane.WARNING_MESSAGE
        );
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Lỗi hệ thống",
                JOptionPane.ERROR_MESSAGE
        );
    }

    private void updateClock() {
        lblCurrentTime.setText(
                LocalDateTime.now().format(
                        DateTimeFormatter.ofPattern(
                                "EEEE, dd/MM/yyyy - HH:mm:ss",
                                new Locale(
                                        "vi",
                                        "VN"
                                )
                        )
                )
        );
    }

    private String formatMoney(BigDecimal amount) {
        if (amount == null) {
            return "0 VNĐ";
        }

        NumberFormat formatter =
                NumberFormat.getNumberInstance(
                        new Locale(
                                "vi",
                                "VN"
                        )
                );

        return formatter.format(amount)
                + " VNĐ";
    }

    /**
     * Khung bo góc dùng cho các thẻ trong giao diện chính.
     */
    private static final class RoomStatusPanel extends RoundedPanel {

        private final JPanel body = new JPanel(new GridLayout(1, 5, 8, 0));
        private final JLabel hint = new JLabel();

        private RoomStatusPanel() {
            super(CARD, BORDER, 10);
            setLayout(new BorderLayout(0, 10));
            setBorder(new EmptyBorder(14, 16, 14, 16));

            JLabel title = new JLabel("TÌNH TRẠNG PHÒNG");
            title.setForeground(TEXT);
            title.setFont(new Font(UITheme.FONT_NAME, Font.BOLD, 13));

            hint.setForeground(MUTED);
            hint.setFont(new Font(UITheme.FONT_NAME, Font.PLAIN, 10));
            hint.setText("Đang tải trạng thái khai thác...");

            JPanel heading = new JPanel(new BorderLayout(0, 2));
            heading.setOpaque(false);
            heading.add(title, BorderLayout.NORTH);
            heading.add(hint, BorderLayout.SOUTH);

            body.setOpaque(false);
            add(heading, BorderLayout.NORTH);
            add(body, BorderLayout.CENTER);
        }

        private void setData(Map<String, Integer> values) {
            body.removeAll();
            int total = values.values().stream().mapToInt(Integer::intValue).sum();
            int occupied = values.getOrDefault("DANG_O", 0);
            hint.setText("Snapshot khai thác hiện tại • " + total + " phòng • " + occupied + " phòng đang có khách");

            addStatus("TRỐNG", "TRONG", values.getOrDefault("TRONG", 0), SUCCESS);
            addStatus("ĐÃ ĐẶT", "DA_DAT", values.getOrDefault("DA_DAT", 0), PRIMARY);
            addStatus("ĐANG Ở", "DANG_O", values.getOrDefault("DANG_O", 0), PRIMARY_DARK);
            addStatus("ĐANG DỌN", "DANG_DON", values.getOrDefault("DANG_DON", 0), new Color(218, 142, 20));
            addStatus("BẢO TRÌ", "BAO_TRI", values.getOrDefault("BAO_TRI", 0), DANGER);

            body.revalidate();
            body.repaint();
        }

        private void addStatus(String label, String ignoredCode, int value, Color color) {
            Color soft = new Color(248, 250, 253);
            JPanel item = new RoundedPanel(soft, BORDER, 8);
            item.setLayout(new BorderLayout(0, 3));
            item.setBorder(new EmptyBorder(10, 6, 9, 6));

            JLabel number = new JLabel(String.valueOf(value), SwingConstants.CENTER);
            number.setForeground(color);
            number.setFont(new Font(UITheme.FONT_NAME, Font.BOLD, 24));

            JLabel text = new JLabel(label, SwingConstants.CENTER);
            text.setForeground(MUTED);
            text.setFont(new Font(UITheme.FONT_NAME, Font.BOLD, 9));

            item.add(number, BorderLayout.CENTER);
            item.add(text, BorderLayout.SOUTH);
            body.add(item);
        }
    }

    private static final class RevenueTrendPanel extends RoundedPanel {

        private final RevenueChart chart = new RevenueChart();

        private RevenueTrendPanel() {
            super(CARD, BORDER, 10);
            setLayout(new BorderLayout(0, 6));
            setBorder(new EmptyBorder(14, 16, 12, 16));

            JLabel title = new JLabel("DOANH THU 12 THÁNG GẦN NHẤT");
            title.setForeground(TEXT);
            title.setFont(new Font(UITheme.FONT_NAME, Font.BOLD, 13));

            JLabel hint = new JLabel("Chỉ tính hóa đơn đã thanh toán");
            hint.setForeground(MUTED);
            hint.setFont(new Font(UITheme.FONT_NAME, Font.PLAIN, 10));

            JPanel heading = new JPanel(new BorderLayout(0, 2));
            heading.setOpaque(false);
            heading.add(title, BorderLayout.NORTH);
            heading.add(hint, BorderLayout.SOUTH);

            add(heading, BorderLayout.NORTH);
            add(chart, BorderLayout.CENTER);
        }

        private void setData(List<DashboardDAO.DoanhThuThang> values) {
            chart.setData(values);
        }
    }

    private static final class RevenueChart extends JPanel {

        private final List<DashboardDAO.DoanhThuThang> data = new ArrayList<>();

        private RevenueChart() {
            setOpaque(false);
            setPreferredSize(new Dimension(0, 145));
        }

        private void setData(List<DashboardDAO.DoanhThuThang> values) {
            data.clear();
            if (values != null) {
                data.addAll(values);
            }
            repaint();
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);

            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            int width = getWidth();
            int height = getHeight();
            int left = 10;
            int right = 10;
            int top = 8;
            int bottom = 28;

            if (data.isEmpty()) {
                g.setColor(MUTED);
                g.setFont(new Font(UITheme.FONT_NAME, Font.PLAIN, 11));
                g.drawString("Chưa có dữ liệu doanh thu.", left, height / 2);
                g.dispose();
                return;
            }

            BigDecimal max = BigDecimal.ZERO;
            for (DashboardDAO.DoanhThuThang item : data) {
                if (item.getDoanhThu().compareTo(max) > 0) {
                    max = item.getDoanhThu();
                }
            }

            int chartWidth = Math.max(1, width - left - right);
            int chartHeight = Math.max(1, height - top - bottom);
            int count = data.size();
            int gap = 10;
            int barWidth = Math.max(16, (chartWidth - gap * (count - 1)) / count);

            g.setColor(new Color(230, 235, 242));
            g.drawLine(left, top + chartHeight, width - right, top + chartHeight);

            for (int i = 0; i < count; i++) {
                DashboardDAO.DoanhThuThang item = data.get(i);
                double ratio = max.signum() == 0
                        ? 0
                        : item.getDoanhThu().doubleValue() / max.doubleValue();

                int barHeight = (int) Math.round(ratio * (chartHeight - 8));
                int x = left + i * (barWidth + gap);
                int y = top + chartHeight - barHeight;

                g.setColor(PRIMARY);
                g.fillRoundRect(x, y, barWidth, Math.max(2, barHeight), 6, 6);

                String month = String.format(
                        Locale.ROOT,
                        "%02d/%02d",
                        item.getThang().getMonthValue(),
                        item.getThang().getYear() % 100
                );
                g.setColor(MUTED);
                g.setFont(new Font(UITheme.FONT_NAME, Font.PLAIN, 9));
                int textWidth = g.getFontMetrics().stringWidth(month);
                g.drawString(month, x + (barWidth - textWidth) / 2, height - 8);

                if (barHeight > 18) {
                    String value = compactMoney(item.getDoanhThu());
                    g.setColor(Color.WHITE);
                    g.setFont(new Font(UITheme.FONT_NAME, Font.BOLD, 8));
                    int valueWidth = g.getFontMetrics().stringWidth(value);
                    g.drawString(value, x + (barWidth - valueWidth) / 2, y + 13);
                }
            }

            g.dispose();
        }

        private String compactMoney(BigDecimal amount) {
            double value = amount.doubleValue();
            if (value >= 1_000_000_000d) {
                return String.format(Locale.ROOT, "%.1fB", value / 1_000_000_000d);
            }
            if (value >= 1_000_000d) {
                return String.format(Locale.ROOT, "%.0fM", value / 1_000_000d);
            }
            if (value >= 1_000d) {
                return String.format(Locale.ROOT, "%.0fK", value / 1_000d);
            }
            return String.format(Locale.ROOT, "%.0f", value);
        }
    }

    private static final class RecentActivityPanel extends RoundedPanel {

        private final JPanel body = new JPanel();
        private final DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern("dd/MM HH:mm");

        private RecentActivityPanel() {
            super(CARD, BORDER, 10);
            setLayout(new BorderLayout(0, 8));
            setBorder(new EmptyBorder(12, 16, 12, 16));
            setPreferredSize(new Dimension(0, 202));

            JPanel heading = new JPanel(new BorderLayout());
            heading.setOpaque(false);

            JLabel title = new JLabel("HOẠT ĐỘNG GẦN ĐÂY");
            title.setForeground(TEXT);
            title.setFont(new Font(UITheme.FONT_NAME, Font.BOLD, 13));

            JLabel hint = new JLabel("Dữ liệu lấy trực tiếp từ nhật ký hệ thống");
            hint.setForeground(MUTED);
            hint.setFont(new Font(UITheme.FONT_NAME, Font.PLAIN, 10));

            heading.add(title, BorderLayout.WEST);
            heading.add(hint, BorderLayout.EAST);

            body.setOpaque(false);
            body.setLayout(new javax.swing.BoxLayout(body, javax.swing.BoxLayout.Y_AXIS));

            add(heading, BorderLayout.NORTH);
            add(body, BorderLayout.CENTER);
        }

        private void setData(List<DashboardDAO.HoatDongGanDay> values) {
            body.removeAll();

            if (values == null || values.isEmpty()) {
                JLabel empty = new JLabel("Chưa có hoạt động gần đây.");
                empty.setForeground(MUTED);
                empty.setFont(new Font(UITheme.FONT_NAME, Font.PLAIN, 11));
                body.add(empty);
            } else {
                for (DashboardDAO.HoatDongGanDay item : values) {
                    body.add(createRow(item));
                    body.add(javax.swing.Box.createVerticalStrut(3));
                }
            }

            body.revalidate();
            body.repaint();
        }

        private JPanel createRow(DashboardDAO.HoatDongGanDay item) {
            JPanel row = new JPanel(new BorderLayout(10, 0));
            row.setOpaque(false);
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 21));

            String time = item.getThoiGian() == null
                    ? "--/-- --:--"
                    : formatter.format(item.getThoiGian());

            JLabel timeLabel = new JLabel(time);
            timeLabel.setPreferredSize(new Dimension(90, 20));
            timeLabel.setForeground(MUTED);
            timeLabel.setFont(new Font(UITheme.FONT_NAME, Font.PLAIN, 9));

            JLabel accountLabel = new JLabel(
                    item.getTaiKhoan() == null ? "-" : item.getTaiKhoan()
            );
            accountLabel.setPreferredSize(new Dimension(80, 20));
            accountLabel.setForeground(TEXT);
            accountLabel.setFont(new Font(UITheme.FONT_NAME, Font.BOLD, 10));

            JLabel actionLabel = new JLabel(actionText(item.getHanhDong()));
            actionLabel.setPreferredSize(new Dimension(100, 20));
            actionLabel.setForeground(actionColor(item.getHanhDong()));
            actionLabel.setFont(new Font(UITheme.FONT_NAME, Font.BOLD, 10));

            String object = item.getMaDoiTuong() == null
                    ? "-"
                    : item.getMaDoiTuong();
            JLabel objectLabel = new JLabel(object);
            objectLabel.setPreferredSize(new Dimension(100, 20));
            objectLabel.setForeground(PRIMARY_DARK);
            objectLabel.setFont(new Font(UITheme.FONT_NAME, Font.BOLD, 10));

            String content = item.getNoiDung() == null
                    ? ""
                    : item.getNoiDung().replace("[DU_LIEU_5_NAM] ", "");
            JLabel contentLabel = new JLabel("<html><nobr>" + escapeHtml(content) + "</nobr></html>");
            contentLabel.setForeground(MUTED);
            contentLabel.setFont(new Font(UITheme.FONT_NAME, Font.PLAIN, 10));

            row.add(timeLabel, BorderLayout.WEST);
            row.add(accountLabel, BorderLayout.CENTER);

            JPanel middle = new JPanel(new BorderLayout(10, 0));
            middle.setOpaque(false);
            middle.add(actionLabel, BorderLayout.WEST);
            middle.add(objectLabel, BorderLayout.CENTER);
            middle.add(contentLabel, BorderLayout.EAST);

            row.add(middle, BorderLayout.EAST);
            return row;
        }

        private String actionText(String code) {
            if (code == null) return "Khác";
            return switch (code) {
                case "THEM_MOI" -> "Thêm mới";
                case "CAP_NHAT", "CAP_NHAT_NHIEM_VU" -> "Cập nhật";
                case "XEM" -> "Xem";
                case "XOA" -> "Xóa";
                case "XAC_NHAN" -> "Xác nhận";
                case "DANG_NHAP" -> "Đăng nhập";
                case "DANG_XUAT" -> "Đăng xuất";
                case "THANH_TOAN" -> "Thanh toán";
                default -> code;
            };
        }

        private Color actionColor(String code) {
            if (code == null) return MUTED;
            return switch (code) {
                case "THEM_MOI", "XAC_NHAN" -> SUCCESS;
                case "CAP_NHAT", "THANH_TOAN" -> PRIMARY;
                case "XEM" -> new Color(218, 142, 20);
                case "XOA", "DANG_XUAT" -> DANGER;
                case "DANG_NHAP" -> PRIMARY_DARK;
                default -> MUTED;
            };
        }

        private String escapeHtml(String text) {
            return text.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;");
        }
    }

    private static class RoundedPanel extends JPanel {

        private final Color backgroundColor;
        private final Color borderColor;
        private final int radius;

        RoundedPanel(
                Color backgroundColor,
                Color borderColor,
                int radius) {

            this.backgroundColor = backgroundColor;
            this.borderColor = borderColor;
            this.radius = radius;

            setOpaque(false);
        }

        @Override
        protected void paintComponent(
                Graphics graphics) {

            Graphics2D g =
                    (Graphics2D) graphics.create();

            try {
                g.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );

                Shape shape =
                        new RoundRectangle2D.Double(
                                0,
                                0,
                                getWidth() - 1,
                                getHeight() - 1,
                                radius,
                                radius
                        );

                g.setColor(backgroundColor);
                g.fill(shape);

                g.setColor(borderColor);
                g.setStroke(
                        new BasicStroke(1f)
                );
                g.draw(shape);

            } finally {
                g.dispose();
            }

            super.paintComponent(graphics);
        }
    }

    /**
     * Icon đơn giản cho thanh điều hướng.
     * Vẽ trực tiếp bằng Graphics2D, không cần thư viện ngoài.
     */
    private static class SidebarIcon
            implements javax.swing.Icon {

        private final String type;
        private final boolean active;

        SidebarIcon(
                String type,
                boolean active) {

            this.type = type;
            this.active = active;
        }

        @Override
        public int getIconWidth() {
            return 22;
        }

        @Override
        public int getIconHeight() {
            return 22;
        }

        @Override
        public void paintIcon(
                java.awt.Component component,
                Graphics graphics,
                int x,
                int y) {

            Graphics2D g =
                    (Graphics2D) graphics.create();

            try {
                g.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );

                Color color =
                        active
                                ? PRIMARY
                                : component != null
                                && component.isEnabled()
                                ? TEXT
                                : DISABLED;

                g.setColor(color);
                g.setStroke(
                        new BasicStroke(
                                1.8f,
                                BasicStroke.CAP_ROUND,
                                BasicStroke.JOIN_ROUND
                        )
                );

                int cx = x + 11;
                int cy = y + 11;

                switch (type) {
                    case "home" -> {
                        Polygon roof = new Polygon(
                                new int[]{
                                        x + 3,
                                        x + 11,
                                        x + 19
                                },
                                new int[]{
                                        y + 10,
                                        y + 3,
                                        y + 10
                                },
                                3
                        );
                        g.fill(roof);
                        g.fillRoundRect(
                                x + 6,
                                y + 9,
                                10,
                                9,
                                2,
                                2
                        );
                        g.setColor(
                                active
                                        ? PRIMARY_SOFT
                                        : SIDEBAR_COLOR
                        );
                        g.fillRect(
                                x + 10,
                                y + 13,
                                3,
                                5
                        );
                    }

                    case "booking" -> {
                        g.drawRoundRect(
                                x + 4,
                                y + 4,
                                14,
                                15,
                                3,
                                3
                        );
                        g.drawLine(
                                x + 4,
                                y + 9,
                                x + 18,
                                y + 9
                        );
                        g.drawLine(
                                x + 8,
                                y + 2,
                                x + 8,
                                y + 7
                        );
                        g.drawLine(
                                x + 14,
                                y + 2,
                                x + 14,
                                y + 7
                        );
                    }

                    case "customer" -> {
                        g.fill(
                                new Ellipse2D.Double(
                                        x + 7,
                                        y + 3,
                                        8,
                                        8
                                )
                        );
                        g.fillRoundRect(
                                x + 4,
                                y + 12,
                                14,
                                7,
                                7,
                                7
                        );
                    }

                    case "room" -> {
                        g.drawLine(
                                x + 4,
                                y + 16,
                                x + 19,
                                y + 16
                        );
                        g.drawLine(
                                x + 6,
                                y + 7,
                                x + 6,
                                y + 18
                        );
                        g.drawLine(
                                x + 6,
                                y + 8,
                                x + 16,
                                y + 8
                        );
                        g.drawRoundRect(
                                x + 8,
                                y + 9,
                                8,
                                5,
                                2,
                                2
                        );
                    }

                    case "reception" -> {
                        g.drawArc(
                                x + 3,
                                y + 4,
                                16,
                                12,
                                20,
                                140
                        );
                        g.drawLine(
                                x + 5,
                                y + 13,
                                x + 17,
                                y + 13
                        );
                        g.fillRoundRect(
                                x + 6,
                                y + 15,
                                10,
                                3,
                                2,
                                2
                        );
                    }

                    case "housekeeping" -> {
                        g.drawLine(
                                x + 7,
                                y + 4,
                                x + 17,
                                y + 14
                        );
                        g.drawLine(
                                x + 6,
                                y + 15,
                                x + 15,
                                y + 6
                        );
                        g.drawLine(
                                x + 4,
                                y + 18,
                                x + 10,
                                y + 12
                        );
                    }

                    case "invoice" -> {
                        g.drawRoundRect(
                                x + 5,
                                y + 3,
                                12,
                                17,
                                2,
                                2
                        );
                        g.drawLine(
                                x + 8,
                                y + 8,
                                x + 14,
                                y + 8
                        );
                        g.drawLine(
                                x + 8,
                                y + 12,
                                x + 14,
                                y + 12
                        );
                        g.drawLine(
                                x + 8,
                                y + 16,
                                x + 12,
                                y + 16
                        );
                    }

                    case "chart" -> {
                        g.fillRoundRect(
                                x + 4,
                                y + 12,
                                3,
                                7,
                                1,
                                1
                        );
                        g.fillRoundRect(
                                x + 10,
                                y + 8,
                                3,
                                11,
                                1,
                                1
                        );
                        g.fillRoundRect(
                                x + 16,
                                y + 4,
                                3,
                                15,
                                1,
                                1
                        );
                    }

                    case "audit" -> {
                        g.drawRoundRect(
                                x + 5,
                                y + 4,
                                13,
                                16,
                                2,
                                2
                        );
                        g.drawLine(
                                x + 9,
                                y + 8,
                                x + 15,
                                y + 8
                        );
                        g.drawLine(
                                x + 9,
                                y + 12,
                                x + 15,
                                y + 12
                        );
                        g.drawLine(
                                x + 9,
                                y + 16,
                                x + 13,
                                y + 16
                        );
                        g.drawRoundRect(
                                x + 8,
                                y + 2,
                                7,
                                4,
                                2,
                                2
                        );
                    }

                    case "settings" -> {
                        g.drawOval(
                                x + 5,
                                y + 5,
                                12,
                                12
                        );
                        g.fillOval(
                                x + 9,
                                y + 9,
                                4,
                                4
                        );
                        for (int i = 0; i < 8; i++) {
                            double a =
                                    Math.PI * i / 4.0;
                            int x1 =
                                    (int) (
                                            cx
                                                    + Math.cos(a)
                                                    * 8
                                    );
                            int y1 =
                                    (int) (
                                            cy
                                                    + Math.sin(a)
                                                    * 8
                                    );
                            int x2 =
                                    (int) (
                                            cx
                                                    + Math.cos(a)
                                                    * 10
                                    );
                            int y2 =
                                    (int) (
                                            cy
                                                    + Math.sin(a)
                                                    * 10
                                    );
                            g.drawLine(
                                    x1,
                                    y1,
                                    x2,
                                    y2
                            );
                        }
                    }

                    default -> {
                        g.drawOval(
                                x + 5,
                                y + 5,
                                12,
                                12
                        );
                    }
                }

            } finally {
                g.dispose();
            }
        }
    }

    private static class UserIcon
            implements javax.swing.Icon {

        private final Color color;

        UserIcon(Color color) {
            this.color = color;
        }

        @Override
        public int getIconWidth() {
            return 30;
        }

        @Override
        public int getIconHeight() {
            return 30;
        }

        @Override
        public void paintIcon(
                java.awt.Component component,
                Graphics graphics,
                int x,
                int y) {

            Graphics2D g =
                    (Graphics2D) graphics.create();

            try {
                g.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );
                g.setColor(color);
                g.fillOval(
                        x + 10,
                        y + 3,
                        10,
                        10
                );
                g.fillRoundRect(
                        x + 5,
                        y + 14,
                        20,
                        12,
                        7,
                        7
                );
            } finally {
                g.dispose();
            }
        }
    }

    private static class LogoutIcon
            implements javax.swing.Icon {

        private final Color color;

        LogoutIcon(Color color) {
            this.color = color;
        }

        @Override
        public int getIconWidth() {
            return 22;
        }

        @Override
        public int getIconHeight() {
            return 22;
        }

        @Override
        public void paintIcon(
                java.awt.Component component,
                Graphics graphics,
                int x,
                int y) {

            Graphics2D g =
                    (Graphics2D) graphics.create();

            try {
                g.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );
                g.setColor(color);
                g.setStroke(
                        new BasicStroke(
                                2f,
                                BasicStroke.CAP_ROUND,
                                BasicStroke.JOIN_ROUND
                        )
                );
                g.drawLine(
                        x + 3,
                        y + 11,
                        x + 15,
                        y + 11
                );
                g.drawLine(
                        x + 11,
                        y + 7,
                        x + 15,
                        y + 11
                );
                g.drawLine(
                        x + 11,
                        y + 15,
                        x + 15,
                        y + 11
                );
                g.drawRoundRect(
                        x + 7,
                        y + 4,
                        10,
                        14,
                        2,
                        2
                );
            } finally {
                g.dispose();
            }
        }
    }
}
