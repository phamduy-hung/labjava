package vn.edu.eaut.hotelmanagement.model.enums;

public enum LoaiGiayTo {
    CCCD("Căn cước công dân"),
    CMND("Chứng minh nhân dân"),
    HO_CHIEU("Hộ chiếu"),
    KHAC("Khác");

    private final String hienThi;

    LoaiGiayTo(String hienThi) {
        this.hienThi = hienThi;
    }

    @Override
    public String toString() {
        return hienThi;
    }
}
