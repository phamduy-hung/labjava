package vn.edu.eaut.hotelmanagement.service;

import org.mindrot.jbcrypt.BCrypt;
import vn.edu.eaut.hotelmanagement.dao.NhatKyHeThongDAO;
import vn.edu.eaut.hotelmanagement.dao.TaiKhoanDAO;
import vn.edu.eaut.hotelmanagement.dao.VaiTroDAO;
import vn.edu.eaut.hotelmanagement.model.NhatKyHeThong;
import vn.edu.eaut.hotelmanagement.model.TaiKhoan;
import vn.edu.eaut.hotelmanagement.model.VaiTro;
import vn.edu.eaut.hotelmanagement.session.LoginSession;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Tầng nghiệp vụ xác thực.
 * View không truy cập trực tiếp DAO và không tự kiểm tra BCrypt.
 */
public class AuthenticationService {

    private static final Logger LOGGER = Logger.getLogger(AuthenticationService.class.getName());

    private final TaiKhoanDAO taiKhoanDAO;
    private final VaiTroDAO vaiTroDAO;
    private final NhatKyHeThongDAO nhatKyHeThongDAO;

    public AuthenticationService() {
        this(new TaiKhoanDAO(), new VaiTroDAO(), new NhatKyHeThongDAO());
    }

    public AuthenticationService(
            TaiKhoanDAO taiKhoanDAO,
            VaiTroDAO vaiTroDAO,
            NhatKyHeThongDAO nhatKyHeThongDAO) {

        this.taiKhoanDAO = taiKhoanDAO;
        this.vaiTroDAO = vaiTroDAO;
        this.nhatKyHeThongDAO = nhatKyHeThongDAO;
    }

    public LoginSession authenticate(String tenDangNhap, char[] matKhau)
            throws SQLException, AuthenticationException {

        String normalizedUsername = normalizeUsername(tenDangNhap);

        if (matKhau == null || matKhau.length == 0) {
            throw new AuthenticationException("Vui lòng nhập mật khẩu.");
        }

        char[] passwordCopy = Arrays.copyOf(matKhau, matKhau.length);

        try {
            Optional<TaiKhoan> accountOptional = taiKhoanDAO.findByUsername(normalizedUsername);

            if (accountOptional.isEmpty()) {
                writeFailedLoginLog(null, normalizedUsername, "Tên đăng nhập không tồn tại.");
                throw new AuthenticationException("Tên đăng nhập hoặc mật khẩu không đúng.");
            }

            TaiKhoan taiKhoan = accountOptional.get();

            if (!taiKhoan.isDangHoatDong()) {
                writeFailedLoginLog(taiKhoan.getId(), normalizedUsername, "Tài khoản đang bị khóa.");
                throw new AuthenticationException(
                        "Tài khoản đã bị khóa. Vui lòng liên hệ quản trị viên."
                );
            }

            String rawPassword = new String(passwordCopy);
            boolean passwordMatches;

            try {
                passwordMatches = BCrypt.checkpw(rawPassword, taiKhoan.getMatKhauHash());
            } catch (IllegalArgumentException exception) {
                LOGGER.log(Level.SEVERE, "Mật khẩu băm trong CSDL không đúng định dạng BCrypt.", exception);
                throw new AuthenticationException(
                        "Dữ liệu tài khoản không hợp lệ. Vui lòng liên hệ quản trị viên."
                );
            }

            if (!passwordMatches) {
                writeFailedLoginLog(taiKhoan.getId(), normalizedUsername, "Mật khẩu không đúng.");
                throw new AuthenticationException("Tên đăng nhập hoặc mật khẩu không đúng.");
            }

            VaiTro vaiTro = vaiTroDAO.findById(taiKhoan.getVaiTroId())
                    .orElseThrow(() -> new AuthenticationException(
                            "Tài khoản chưa được gán vai trò hợp lệ."
                    ));

            if (!vaiTro.isDangHoatDong()) {
                throw new AuthenticationException(
                        "Vai trò của tài khoản đang bị khóa. Vui lòng liên hệ quản trị viên."
                );
            }

            LocalDateTime loginTime = LocalDateTime.now();
            taiKhoanDAO.updateLastLogin(taiKhoan.getId(), loginTime);
            taiKhoan.setLanDangNhapCuoi(loginTime);

            writeSuccessfulLoginLog(taiKhoan, vaiTro, loginTime);

            // Không đưa mật khẩu băm vào đối tượng phiên làm việc.
            taiKhoan.setMatKhauHash(null);

            return new LoginSession(taiKhoan, vaiTro, loginTime);

        } finally {
            Arrays.fill(passwordCopy, '\0');
            Arrays.fill(matKhau, '\0');
        }
    }

    private String normalizeUsername(String tenDangNhap) throws AuthenticationException {
        if (tenDangNhap == null || tenDangNhap.isBlank()) {
            throw new AuthenticationException("Vui lòng nhập tên đăng nhập.");
        }

        String normalized = tenDangNhap.trim();

        if (normalized.length() > 50) {
            throw new AuthenticationException("Tên đăng nhập không được vượt quá 50 ký tự.");
        }

        return normalized;
    }

    private void writeSuccessfulLoginLog(TaiKhoan taiKhoan, VaiTro vaiTro, LocalDateTime loginTime) {
        NhatKyHeThong log = new NhatKyHeThong();
        log.setTaiKhoanId(taiKhoan.getId());
        log.setHanhDong("DANG_NHAP");
        log.setDoiTuong("TAI_KHOAN");
        log.setDoiTuongId(String.valueOf(taiKhoan.getId()));
        log.setNoiDung(
                "Đăng nhập thành công: " + taiKhoan.getTenDangNhap()
                        + " - vai trò " + vaiTro.getMaVaiTro()
        );
        log.setThoiGian(loginTime);

        try {
            nhatKyHeThongDAO.insert(log);
        } catch (SQLException exception) {
            // Việc ghi log không được làm thất bại một phiên đăng nhập đã xác thực thành công.
            LOGGER.log(Level.WARNING, "Không thể ghi nhật ký đăng nhập thành công.", exception);
        }
    }

    private void writeFailedLoginLog(Integer accountId, String username, String reason) {
        NhatKyHeThong log = new NhatKyHeThong();
        log.setTaiKhoanId(accountId);
        log.setHanhDong("DANG_NHAP_THAT_BAI");
        log.setDoiTuong("TAI_KHOAN");
        log.setDoiTuongId(username);
        log.setNoiDung("Đăng nhập thất bại với tài khoản " + username + ". " + reason);
        log.setThoiGian(LocalDateTime.now());

        try {
            nhatKyHeThongDAO.insert(log);
        } catch (SQLException exception) {
            LOGGER.log(Level.WARNING, "Không thể ghi nhật ký đăng nhập thất bại.", exception);
        }
    }
}
