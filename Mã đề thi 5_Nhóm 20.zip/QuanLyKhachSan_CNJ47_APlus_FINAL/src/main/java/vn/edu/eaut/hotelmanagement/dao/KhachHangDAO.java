package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.KhachHang;
import vn.edu.eaut.hotelmanagement.model.enums.GioiTinh;
import vn.edu.eaut.hotelmanagement.model.enums.LoaiGiayTo;
import vn.edu.eaut.hotelmanagement.security.CustomerDataCrypto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * DAO quản lý khách hàng.
 *
 * <p>Các trường PII (họ tên, số giấy tờ, điện thoại, email, địa chỉ) được
 * mã hóa AES-256-GCM trước khi ghi xuống MySQL và giải mã tại lớp ứng dụng.
 * Vì ciphertext của GCM là ngẫu nhiên nên các thao tác tìm kiếm theo PII
 * được thực hiện sau khi giải mã trong bộ nhớ; mã khách hàng vẫn tìm kiếm
 * trực tiếp bằng SQL.</p>
 */
public class KhachHangDAO {

    private static final String SELECT_COLUMNS =
            "id, ma_khach_hang, ho_ten, gioi_tinh, ngay_sinh, loai_giay_to, so_giay_to, "
                    + "so_dien_thoai, email, quoc_tich, dia_chi, ghi_chu, ngay_tao, ngay_cap_nhat";

    public int insert(KhachHang khachHang) throws SQLException {
        String sql = "INSERT INTO khach_hang(ma_khach_hang, ho_ten, gioi_tinh, ngay_sinh, loai_giay_to, "
                + "so_giay_to, so_dien_thoai, email, quoc_tich, dia_chi, ghi_chu) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bindForWrite(statement, khachHang, false);
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    khachHang.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của khách hàng vừa thêm.");
    }

    public boolean update(KhachHang khachHang) throws SQLException {
        String sql = "UPDATE khach_hang SET ma_khach_hang = ?, ho_ten = ?, gioi_tinh = ?, ngay_sinh = ?, "
                + "loai_giay_to = ?, so_giay_to = ?, so_dien_thoai = ?, email = ?, quoc_tich = ?, dia_chi = ?, ghi_chu = ? "
                + "WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            bindForWrite(statement, khachHang, true);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteById(int id) throws SQLException {
        if (hasBookingHistory(id)) {
            throw new SQLException("Không thể xóa khách hàng vì đã phát sinh lịch sử đặt phòng.");
        }

        String sql = "DELETE FROM khach_hang WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean hasBookingHistory(int customerId) throws SQLException {
        String sql = "SELECT EXISTS (SELECT 1 FROM dat_phong WHERE khach_hang_id = ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, customerId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() && resultSet.getBoolean(1);
            }
        }
    }

    public List<CustomerHistoryRow> findHistoryByCustomerId(int customerId) throws SQLException {
        String sql = "SELECT dp.id, dp.ma_dat_phong, dp.ngay_du_kien_nhan, dp.ngay_du_kien_tra, "
                + "dp.ngay_nhan_thuc_te, dp.ngay_tra_thuc_te, dp.trang_thai, "
                + "COALESCE(GROUP_CONCAT(DISTINCT p.so_phong ORDER BY p.so_phong SEPARATOR ', '), '') AS so_phong, "
                + "COALESCE(hd.tong_thanh_toan, 0) AS tong_thanh_toan, "
                + "COALESCE((SELECT SUM(sd.thanh_tien) FROM su_dung_dich_vu sd "
                + "JOIN chi_tiet_dat_phong ct2 ON ct2.id = sd.chi_tiet_dat_phong_id "
                + "WHERE ct2.dat_phong_id = dp.id), 0) AS tong_dich_vu "
                + "FROM dat_phong dp "
                + "LEFT JOIN chi_tiet_dat_phong ct ON ct.dat_phong_id = dp.id "
                + "LEFT JOIN phong p ON p.id = ct.phong_id "
                + "LEFT JOIN hoa_don hd ON hd.dat_phong_id = dp.id "
                + "WHERE dp.khach_hang_id = ? "
                + "GROUP BY dp.id, dp.ma_dat_phong, dp.ngay_du_kien_nhan, dp.ngay_du_kien_tra, "
                + "dp.ngay_nhan_thuc_te, dp.ngay_tra_thuc_te, dp.trang_thai, hd.tong_thanh_toan "
                + "ORDER BY COALESCE(dp.ngay_nhan_thuc_te, dp.ngay_du_kien_nhan) DESC, dp.id DESC";

        List<CustomerHistoryRow> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, customerId);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    result.add(new CustomerHistoryRow(
                            rs.getInt("id"),
                            rs.getString("ma_dat_phong"),
                            rs.getTimestamp("ngay_du_kien_nhan").toLocalDateTime(),
                            rs.getTimestamp("ngay_du_kien_tra").toLocalDateTime(),
                            rs.getTimestamp("ngay_nhan_thuc_te") == null ? null : rs.getTimestamp("ngay_nhan_thuc_te").toLocalDateTime(),
                            rs.getTimestamp("ngay_tra_thuc_te") == null ? null : rs.getTimestamp("ngay_tra_thuc_te").toLocalDateTime(),
                            rs.getString("trang_thai"),
                            rs.getString("so_phong"),
                            rs.getBigDecimal("tong_thanh_toan"),
                            rs.getBigDecimal("tong_dich_vu")
                    ));
                }
            }
        }
        return result;
    }

    public record CustomerHistoryRow(
            int bookingId,
            String bookingCode,
            java.time.LocalDateTime expectedCheckIn,
            java.time.LocalDateTime expectedCheckOut,
            java.time.LocalDateTime actualCheckIn,
            java.time.LocalDateTime actualCheckOut,
            String bookingStatus,
            String roomNumbers,
            java.math.BigDecimal invoiceTotal,
            java.math.BigDecimal serviceTotal) {
    }

    public Optional<KhachHang> findById(int id) throws SQLException {
        return findSingle("SELECT " + SELECT_COLUMNS + " FROM khach_hang WHERE id = ?", id);
    }

    public Optional<KhachHang> findByCode(String customerCode) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM khach_hang WHERE ma_khach_hang = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, customerCode);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    /**
     * Tìm giấy tờ trong dữ liệu đã giải mã. Không so sánh ciphertext trực tiếp
     * vì AES-GCM dùng IV ngẫu nhiên cho từng bản ghi.
     */
    public Optional<KhachHang> findByIdentityDocument(LoaiGiayTo loaiGiayTo, String soGiayTo) throws SQLException {
        if (loaiGiayTo == null || soGiayTo == null) {
            return Optional.empty();
        }
        String candidate = soGiayTo.trim();
        for (KhachHang customer : findAll()) {
            if (loaiGiayTo == customer.getLoaiGiayTo()
                    && candidate.equalsIgnoreCase(safe(customer.getSoGiayTo()))) {
                return Optional.of(customer);
            }
        }
        return Optional.empty();
    }

    public List<KhachHang> findAll() throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM khach_hang ORDER BY id";
        List<KhachHang> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(mapRow(resultSet));
            }
        }
        result.sort(Comparator.comparing(
                (KhachHang customer) -> safe(customer.getHoTen()).toLowerCase(Locale.ROOT),
                Comparator.nullsLast(String::compareTo)
        ).thenComparing(KhachHang::getId));
        return result;
    }

    /**
     * Tìm kiếm PII sau khi giải mã trong JVM. Điều này tránh việc đặt plaintext
     * hoặc deterministic ciphertext vào điều kiện LIKE trong MySQL.
     */
    public List<KhachHang> search(String keyword) throws SQLException {
        String candidate = safe(keyword).trim().toLowerCase(Locale.ROOT);
        if (candidate.isBlank()) {
            return findAll();
        }

        List<KhachHang> result = new ArrayList<>();
        for (KhachHang customer : findAll()) {
            if (contains(customer.getMaKhachHang(), candidate)
                    || contains(customer.getHoTen(), candidate)
                    || contains(customer.getSoGiayTo(), candidate)
                    || contains(customer.getSoDienThoai(), candidate)
                    || contains(customer.getEmail(), candidate)
                    || contains(customer.getDiaChi(), candidate)) {
                result.add(customer);
            }
        }
        return result;
    }

    private Optional<KhachHang> findSingle(String sql, int id) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    private void bindForWrite(PreparedStatement statement, KhachHang khachHang, boolean includeId) throws SQLException {
        statement.setString(1, khachHang.getMaKhachHang());
        statement.setString(2, CustomerDataCrypto.encrypt(khachHang.getHoTen()));
        if (khachHang.getGioiTinh() == null) {
            statement.setNull(3, Types.VARCHAR);
        } else {
            statement.setString(3, khachHang.getGioiTinh().name());
        }
        JdbcDataAccessSupport.setNullableLocalDate(statement, 4, khachHang.getNgaySinh());
        statement.setString(5, khachHang.getLoaiGiayTo().name());
        statement.setString(6, CustomerDataCrypto.encrypt(khachHang.getSoGiayTo()));
        statement.setString(7, CustomerDataCrypto.encrypt(khachHang.getSoDienThoai()));
        statement.setString(8, CustomerDataCrypto.encrypt(khachHang.getEmail()));
        statement.setString(9, khachHang.getQuocTich());
        statement.setString(10, CustomerDataCrypto.encrypt(khachHang.getDiaChi()));
        statement.setString(11, khachHang.getGhiChu());
        if (includeId) {
            statement.setInt(12, khachHang.getId());
        }
    }

    private KhachHang mapRow(ResultSet resultSet) throws SQLException {
        KhachHang khachHang = new KhachHang();
        khachHang.setId(resultSet.getInt("id"));
        khachHang.setMaKhachHang(resultSet.getString("ma_khach_hang"));
        khachHang.setHoTen(CustomerDataCrypto.decrypt(resultSet.getString("ho_ten")));
        String gender = resultSet.getString("gioi_tinh");
        khachHang.setGioiTinh(gender == null ? null : GioiTinh.valueOf(gender));
        khachHang.setNgaySinh(JdbcDataAccessSupport.getNullableLocalDate(resultSet, "ngay_sinh"));
        khachHang.setLoaiGiayTo(LoaiGiayTo.valueOf(resultSet.getString("loai_giay_to")));
        khachHang.setSoGiayTo(CustomerDataCrypto.decrypt(resultSet.getString("so_giay_to")));
        khachHang.setSoDienThoai(CustomerDataCrypto.decrypt(resultSet.getString("so_dien_thoai")));
        khachHang.setEmail(CustomerDataCrypto.decrypt(resultSet.getString("email")));
        khachHang.setQuocTich(resultSet.getString("quoc_tich"));
        khachHang.setDiaChi(CustomerDataCrypto.decrypt(resultSet.getString("dia_chi")));
        khachHang.setGhiChu(resultSet.getString("ghi_chu"));
        khachHang.setNgayTao(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_tao"));
        khachHang.setNgayCapNhat(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_cap_nhat"));
        return khachHang;
    }

    private boolean contains(String value, String candidate) {
        return value != null && value.toLowerCase(Locale.ROOT).contains(candidate);
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}
