package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.ChiTietDatPhong;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ChiTietDatPhongDAO {

    private static final String SELECT_COLUMNS =
            "id, dat_phong_id, phong_id, gia_phong_thuc_te, so_nguoi_lon, so_tre_em, ghi_chu";

    public int insert(ChiTietDatPhong chiTiet) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            return insert(connection, chiTiet);
        }
    }

    int insert(Connection connection, ChiTietDatPhong chiTiet) throws SQLException {
        String sql = "INSERT INTO chi_tiet_dat_phong(dat_phong_id, phong_id, gia_phong_thuc_te, so_nguoi_lon, so_tre_em, ghi_chu) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setInt(1, chiTiet.getDatPhongId());
            statement.setInt(2, chiTiet.getPhongId());
            statement.setBigDecimal(3, chiTiet.getGiaPhongThucTe());
            statement.setInt(4, chiTiet.getSoNguoiLon());
            statement.setInt(5, chiTiet.getSoTreEm());
            statement.setString(6, chiTiet.getGhiChu());
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    chiTiet.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của chi tiết đặt phòng vừa thêm.");
    }

    public boolean update(ChiTietDatPhong chiTiet) throws SQLException {
        String sql = "UPDATE chi_tiet_dat_phong SET dat_phong_id = ?, phong_id = ?, gia_phong_thuc_te = ?, "
                + "so_nguoi_lon = ?, so_tre_em = ?, ghi_chu = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, chiTiet.getDatPhongId());
            statement.setInt(2, chiTiet.getPhongId());
            statement.setBigDecimal(3, chiTiet.getGiaPhongThucTe());
            statement.setInt(4, chiTiet.getSoNguoiLon());
            statement.setInt(5, chiTiet.getSoTreEm());
            statement.setString(6, chiTiet.getGhiChu());
            statement.setInt(7, chiTiet.getId());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteById(int id) throws SQLException {
        String sql = "DELETE FROM chi_tiet_dat_phong WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteByBookingId(int bookingId) throws SQLException {
        String sql = "DELETE FROM chi_tiet_dat_phong WHERE dat_phong_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            return statement.executeUpdate() > 0;
        }
    }

    public Optional<ChiTietDatPhong> findById(int id) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM chi_tiet_dat_phong WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<ChiTietDatPhong> findByBookingId(int bookingId) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM chi_tiet_dat_phong WHERE dat_phong_id = ? ORDER BY id";
        List<ChiTietDatPhong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public List<ChiTietDatPhong> findAll() throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM chi_tiet_dat_phong ORDER BY dat_phong_id, id";
        List<ChiTietDatPhong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(mapRow(resultSet));
            }
        }
        return result;
    }

    private ChiTietDatPhong mapRow(ResultSet resultSet) throws SQLException {
        ChiTietDatPhong detail = new ChiTietDatPhong();
        detail.setId(resultSet.getInt("id"));
        detail.setDatPhongId(resultSet.getInt("dat_phong_id"));
        detail.setPhongId(resultSet.getInt("phong_id"));
        detail.setGiaPhongThucTe(resultSet.getBigDecimal("gia_phong_thuc_te"));
        detail.setSoNguoiLon(resultSet.getInt("so_nguoi_lon"));
        detail.setSoTreEm(resultSet.getInt("so_tre_em"));
        detail.setGhiChu(resultSet.getString("ghi_chu"));
        return detail;
    }
}
