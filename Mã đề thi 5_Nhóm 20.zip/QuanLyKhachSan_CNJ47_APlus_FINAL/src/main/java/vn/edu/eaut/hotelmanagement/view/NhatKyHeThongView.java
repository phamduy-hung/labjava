package vn.edu.eaut.hotelmanagement.view;

import vn.edu.eaut.hotelmanagement.dao.NhatKyHeThongDAO;
import vn.edu.eaut.hotelmanagement.model.NhatKyHeThong;
import vn.edu.eaut.hotelmanagement.session.LoginSession;
import vn.edu.eaut.hotelmanagement.utils.ButtonUtils;
import vn.edu.eaut.hotelmanagement.utils.UITheme;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Màn hình Nhật ký hệ thống.
 *
 * Thiết kế theo hướng hiện đại:
 * - Sidebar chức năng.
 * - Bộ lọc tìm kiếm/lọc hành động/lọc tài khoản.
 * - JTable có màu dòng xen kẽ, tiêu đề tương phản cao.
 * - Icon hành động được vẽ bằng Graphics2D, không phụ thuộc thư viện icon ngoài.
 * - Phân trang tại CSDL.
 * - SwingWorker bảo đảm truy vấn CSDL không chặn giao diện.
 */
public class NhatKyHeThongView extends JPanel {

    private static final long serialVersionUID = 1L;

    private static final Color PRIMARY = new Color(31, 111, 214);
    private static final Color PRIMARY_DARK = new Color(25, 74, 137);
    private static final Color PRIMARY_SOFT = new Color(229, 240, 255);
    private static final Color SIDEBAR = new Color(247, 250, 253);
    private static final Color BACKGROUND = new Color(247, 249, 252);
    private static final Color CARD = Color.WHITE;
    private static final Color BORDER = new Color(218, 226, 236);
    private static final Color TEXT = new Color(30, 42, 58);
    private static final Color MUTED = new Color(105, 120, 140);
    private static final Color HEADER = new Color(232, 240, 249);
    private static final Color ROW_ALT = new Color(250, 252, 255);
    private static final Color SELECTED = new Color(219, 235, 255);

    private static final int PAGE_SIZE = 12;

    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern(
                    "dd/MM/yyyy HH:mm:ss"
            );

    private static final String[] COLUMNS = {
            "Thời gian",
            "Tài khoản",
            "Hành động",
            "Đối tượng",
            "Mã đối tượng",
            "Nội dung"
    };

    private static final List<ActionOption> ACTION_OPTIONS =
            List.of(
                    new ActionOption(
                            "Tất cả",
                            null
                    ),
                    new ActionOption(
                            "Thêm mới",
                            "THEM_MOI"
                    ),
                    new ActionOption(
                            "Cập nhật",
                            "CAP_NHAT"
                    ),
                    new ActionOption(
                            "Xem",
                            "XEM"
                    ),
                    new ActionOption(
                            "Xóa",
                            "XOA"
                    ),
                    new ActionOption(
                            "Xác nhận",
                            "XAC_NHAN"
                    ),
                    new ActionOption(
                            "Đăng nhập",
                            "DANG_NHAP"
                    ),
                    new ActionOption(
                            "Đăng xuất",
                            "DANG_XUAT"
                    ),
                    new ActionOption(
                            "Nhận phòng",
                            "NHAN_PHONG"
                    ),
                    new ActionOption(
                            "Trả phòng",
                            "TRA_PHONG"
                    ),
                    new ActionOption(
                            "Thanh toán",
                            "THANH_TOAN"
                    ),
                    new ActionOption(
                            "Cập nhật nhiệm vụ",
                            "CAP_NHAT_NHIEM_VU"
                    ),
                    new ActionOption(
                            "Thoát chương trình",
                            "THOAT_CHUONG_TRINH"
                    ),
                    new ActionOption(
                            "Đăng nhập thất bại",
                            "DANG_NHAP_THAT_BAI"
                    )
            );

    private final LoginSession loginSession;
    private final NhatKyHeThongDAO nhatKyHeThongDAO;
    private final Consumer<String> navigationHandler;
    private final Runnable logoutHandler;

    private final DefaultTableModel tableModel =
            new DefaultTableModel(COLUMNS, 0) {

                private static final long serialVersionUID = 1L;

                @Override
                public boolean isCellEditable(
                        int row,
                        int column) {

                    return false;
                }
            };

    private final JTable table =
            new JTable(tableModel);

    private final RoundedTextField txtSearch =
            new RoundedTextField(30);

    private final JComboBox<ActionOption> cboAction =
            new JComboBox<>();

    private final JComboBox<NhatKyHeThongDAO.AccountOption> cboAccount =
            new JComboBox<>();

    private final JPanel paginationPanel =
            new JPanel(
                    new FlowLayout(
                            FlowLayout.RIGHT,
                            6,
                            0
                    )
            );

    private final JLabel lblTotal =
            new JLabel("Tổng: 0 bản ghi");

    private final JLabel lblPageInfo =
            new JLabel("Trang 1/1");

    private final JLabel lblLoading =
            new JLabel(" ");

    private int currentPage = 1;
    private int totalPages = 1;
    private int requestSequence = 0;

    private Timer searchDebounceTimer;

    public NhatKyHeThongView(
            LoginSession loginSession) {

        this(
                loginSession,
                null,
                null
        );
    }

    public NhatKyHeThongView(
            LoginSession loginSession,
            Consumer<String> navigationHandler,
            Runnable logoutHandler) {
        this(
                loginSession,
                navigationHandler,
                logoutHandler,
                true
        );
    }

    /**
     * Constructor dùng khi màn hình Nhật ký được nhúng vào
     * khung CardLayout của MainView.
     *
     * Khi includeSidebar = false, màn hình chỉ dựng phần nội dung
     * Nhật ký, tránh tạo thêm một thanh điều hướng thứ hai.
     */
    public NhatKyHeThongView(
            LoginSession loginSession,
            Consumer<String> navigationHandler,
            Runnable logoutHandler,
            boolean includeSidebar) {

        if (loginSession == null) {
            throw new IllegalArgumentException(
                    "Phiên đăng nhập không được để trống."
            );
        }

        this.loginSession = loginSession;
        this.nhatKyHeThongDAO =
                new NhatKyHeThongDAO();
        this.navigationHandler =
                navigationHandler;
        this.logoutHandler =
                logoutHandler;

        initializePanel(includeSidebar);
        initializeFilters();
        initializeTable();
        initializeEvents();
        loadAccountOptions();
        loadPage(1);
    }

    private void initializePanel(boolean includeSidebar) {

        setLayout(
                new BorderLayout()
        );

        setBackground(BACKGROUND);

        if (includeSidebar) {
            add(
                    createSidebar(),
                    BorderLayout.WEST
            );
        }

        add(
                createMainContent(),
                BorderLayout.CENTER
        );
    }

    private JPanel createSidebar() {

        JPanel sidebar =
                new JPanel();

        sidebar.setLayout(
                new BoxLayout(
                        sidebar,
                        BoxLayout.Y_AXIS
                )
        );

        sidebar.setBackground(SIDEBAR);
        sidebar.setBorder(
                BorderFactory.createMatteBorder(
                        0,
                        0,
                        0,
                        1,
                        BORDER
                )
        );

        sidebar.setPreferredSize(
                new Dimension(235, 0)
        );

        JLabel brand =
                new JLabel(
                        "HOTEL MANAGEMENT"
                );

        brand.setForeground(
                PRIMARY_DARK
        );

        brand.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        18
                )
        );

        brand.setBorder(
                new EmptyBorder(
                        24,
                        22,
                        20,
                        12
                )
        );

        sidebar.add(brand);

        addNavigationButton(
                sidebar,
                "Trang chủ",
                "dashboard",
                false
        );

        addNavigationButton(
                sidebar,
                "Đặt phòng",
                "datPhong",
                false
        );

        addNavigationButton(
                sidebar,
                "Khách hàng",
                "khachHang",
                false
        );

        addNavigationButton(
                sidebar,
                "Quản lý phòng",
                "phong",
                false
        );

        addNavigationButton(
                sidebar,
                "Lễ tân",
                "datPhong",
                false
        );

        addNavigationButton(
                sidebar,
                "Buồng phòng",
                "phong",
                false
        );

        addNavigationButton(
                sidebar,
                "Hóa đơn",
                "hoaDon",
                false
        );

        addNavigationButton(
                sidebar,
                "Thống kê",
                "thongKe",
                false
        );

        addNavigationButton(
                sidebar,
                "Nhật ký hệ thống",
                null,
                true
        );

        JButton adminButton =
                createNavigationButton(
                        "Quản trị hệ thống",
                        null,
                        false
                );

        adminButton.setEnabled(false);
        sidebar.add(adminButton);

        sidebar.add(
                Box.createVerticalGlue()
        );

        JPanel accountPanel =
                new JPanel(
                        new BorderLayout(
                                10,
                                0
                        )
                );

        accountPanel.setOpaque(false);
        accountPanel.setBorder(
                new EmptyBorder(
                        14,
                        18,
                        10,
                        18
                )
        );

        JLabel accountIcon =
                new JLabel(
                        "A",
                        SwingConstants.CENTER
                );

        accountIcon.setPreferredSize(
                new Dimension(
                        36,
                        36
                )
        );

        accountIcon.setOpaque(true);
        accountIcon.setBackground(
                PRIMARY_SOFT
        );
        accountIcon.setForeground(
                PRIMARY_DARK
        );
        accountIcon.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        15
                )
        );

        JPanel accountText =
                new JPanel(
                        new GridLayout(
                                2,
                                1,
                                0,
                                2
                        )
                );

        accountText.setOpaque(false);

        JLabel lblUser =
                new JLabel(
                        loginSession
                                .getTaiKhoan()
                                .getTenDangNhap()
                );

        lblUser.setForeground(TEXT);
        lblUser.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        13
                )
        );

        JLabel lblRole =
                new JLabel(
                        loginSession
                                .getVaiTro()
                                .getTenVaiTro()
                );

        lblRole.setForeground(MUTED);
        lblRole.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        11
                )
        );

        accountText.add(lblUser);
        accountText.add(lblRole);

        accountPanel.add(
                accountIcon,
                BorderLayout.WEST
        );

        accountPanel.add(
                accountText,
                BorderLayout.CENTER
        );

        sidebar.add(accountPanel);

        JButton btnLogout =
                new JButton(
                        "Đăng xuất"
                );

        btnLogout.setHorizontalAlignment(
                SwingConstants.LEFT
        );

        btnLogout.setForeground(
                new Color(205, 55, 55)
        );

        btnLogout.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        13
                )
        );

        btnLogout.setBorder(
                new EmptyBorder(
                        12,
                        22,
                        20,
                        12
                )
        );

        btnLogout.setContentAreaFilled(false);
        btnLogout.setFocusPainted(false);
        btnLogout.setCursor(
                Cursor.getPredefinedCursor(
                        Cursor.HAND_CURSOR
                )
        );

        btnLogout.addActionListener(
                event -> {
                    if (logoutHandler != null) {
                        logoutHandler.run();
                    }
                }
        );

        sidebar.add(btnLogout);

        return sidebar;
    }

    private void addNavigationButton(
            JPanel sidebar,
            String text,
            String cardName,
            boolean active) {

        sidebar.add(
                createNavigationButton(
                        text,
                        cardName,
                        active
                )
        );
    }

    private JButton createNavigationButton(
            String text,
            String cardName,
            boolean active) {

        JButton button =
                new JButton(
                        new NavIcon(
                                text,
                                active
                        )
                );

        button.setText(text);
        button.setIconTextGap(12);
        button.setHorizontalAlignment(
                SwingConstants.LEFT
        );

        button.setPreferredSize(
                new Dimension(
                        235,
                        44
                )
        );

        button.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        44
                )
        );

        button.setBorder(
                new EmptyBorder(
                        0,
                        20,
                        0,
                        12
                )
        );

        button.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        active
                                ? Font.BOLD
                                : Font.PLAIN,
                        13
                )
        );

        button.setForeground(
                active
                        ? PRIMARY
                        : TEXT
        );

        button.setBackground(
                active
                        ? new Color(224, 238, 255)
                        : SIDEBAR
        );

        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(
                Cursor.getPredefinedCursor(
                        Cursor.HAND_CURSOR
                )
        );

        if (cardName != null
                && navigationHandler != null) {

            button.addActionListener(
                    event -> navigationHandler.accept(
                            cardName
                    )
            );
        }

        return button;
    }

    private JPanel createMainContent() {

        JPanel main =
                new JPanel(
                        new BorderLayout(
                                0,
                                0
                        )
                );

        main.setBackground(BACKGROUND);
        main.setBorder(
                new EmptyBorder(
                        20,
                        20,
                        18,
                        20
                )
        );

        main.add(
                createTitlePanel(),
                BorderLayout.NORTH
        );

        main.add(
                createCenterPanel(),
                BorderLayout.CENTER
        );

        return main;
    }

    private JPanel createTitlePanel() {

        JPanel titlePanel =
                new JPanel(
                        new BorderLayout(
                                14,
                                0
                        )
                );

        titlePanel.setOpaque(false);
        titlePanel.setBorder(
                new EmptyBorder(
                        0,
                        0,
                        18,
                        0
                )
        );

        JLabel icon =
                new JLabel(
                        new ClipboardIcon(
                                PRIMARY_DARK
                        )
                );

        icon.setPreferredSize(
                new Dimension(
                        54,
                        54
                )
        );

        JPanel text =
                new JPanel(
                        new GridLayout(
                                2,
                                1,
                                0,
                                2
                        )
                );

        text.setOpaque(false);

        JLabel title =
                new JLabel(
                        "Nhật ký hệ thống"
                );

        title.setForeground(PRIMARY_DARK);
        title.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        28
                )
        );

        JLabel subtitle =
                new JLabel(
                        "Theo dõi các thao tác của người dùng trong hệ thống"
                );

        subtitle.setForeground(MUTED);
        subtitle.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        13
                )
        );

        text.add(title);
        text.add(subtitle);

        titlePanel.add(
                icon,
                BorderLayout.WEST
        );

        titlePanel.add(
                text,
                BorderLayout.CENTER
        );

        return titlePanel;
    }

    private JPanel createCenterPanel() {

        JPanel center =
                new JPanel(
                        new BorderLayout(
                                0,
                                12
                        )
                );

        center.setOpaque(false);

        center.add(
                createFilterPanel(),
                BorderLayout.NORTH
        );

        JPanel tableCard =
                new RoundedPanel(
                        CARD,
                        BORDER,
                        10
                );

        tableCard.setLayout(
                new BorderLayout()
        );

        JScrollPane scrollPane =
                new JScrollPane(
                        table
                );

        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport()
                .setOpaque(true);

        scrollPane.getViewport()
                .setBackground(CARD);

        scrollPane.getVerticalScrollBar()
                .setUnitIncrement(18);

        tableCard.add(
                scrollPane,
                BorderLayout.CENTER
        );

        center.add(
                tableCard,
                BorderLayout.CENTER
        );

        JPanel bottom =
                new JPanel(
                        new BorderLayout(
                                12,
                                0
                        )
                );

        bottom.setOpaque(false);

        JPanel info =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.LEFT,
                                0,
                                0
                        )
                );

        info.setOpaque(false);

        lblTotal.setForeground(TEXT);
        lblTotal.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        12
                )
        );

        lblPageInfo.setForeground(MUTED);
        lblPageInfo.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        12
                )
        );

        info.add(lblTotal);
        info.add(Box.createHorizontalStrut(14));
        info.add(lblPageInfo);

        bottom.add(
                info,
                BorderLayout.WEST
        );

        paginationPanel.setOpaque(false);

        bottom.add(
                paginationPanel,
                BorderLayout.EAST
        );

        center.add(
                bottom,
                BorderLayout.SOUTH
        );

        return center;
    }

    private JPanel createFilterPanel() {

        RoundedPanel filter =
                new RoundedPanel(
                        CARD,
                        BORDER,
                        10
                );

        filter.setLayout(
                new GridBagLayout()
        );

        java.awt.GridBagConstraints gbc =
                new java.awt.GridBagConstraints();

        gbc.gridy = 0;
        gbc.insets =
                new Insets(
                        12,
                        12,
                        12,
                        8
                );

        gbc.anchor =
                java.awt.GridBagConstraints.WEST;

        JLabel lblSearch =
                createFilterLabel(
                        "Tìm kiếm:"
                );

        gbc.gridx = 0;
        gbc.weightx = 0;
        filter.add(
                lblSearch,
                gbc
        );

        txtSearch.setToolTipText(
                "Tìm theo tài khoản, hành động, đối tượng, mã đối tượng hoặc nội dung"
        );

        gbc.gridx = 1;
        gbc.weightx = 1;
        gbc.fill =
                java.awt.GridBagConstraints.HORIZONTAL;

        filter.add(
                txtSearch,
                gbc
        );

        JLabel lblAction =
                createFilterLabel(
                        "Lọc hành động:"
                );

        gbc.gridx = 2;
        gbc.weightx = 0;
        gbc.fill =
                java.awt.GridBagConstraints.NONE;

        filter.add(
                lblAction,
                gbc
        );

        gbc.gridx = 3;
        gbc.weightx = 0.35;
        gbc.fill =
                java.awt.GridBagConstraints.HORIZONTAL;

        gbc.insets =
                new Insets(
                        12,
                        0,
                        12,
                        8
                );

        filter.add(
                cboAction,
                gbc
        );

        JLabel lblAccount =
                createFilterLabel(
                        "Lọc tài khoản:"
                );

        gbc.gridx = 4;
        gbc.weightx = 0;
        gbc.fill =
                java.awt.GridBagConstraints.NONE;

        filter.add(
                lblAccount,
                gbc
        );

        gbc.gridx = 5;
        gbc.weightx = 0.35;
        gbc.fill =
                java.awt.GridBagConstraints.HORIZONTAL;

        filter.add(
                cboAccount,
                gbc
        );

        JButton btnRefresh =
                ButtonUtils.createPrimaryButton(
                        "⟳  Làm mới"
                );

        btnRefresh.setPreferredSize(
                new Dimension(
                        130,
                        40
                )
        );

        btnRefresh.addActionListener(
                event -> {
                    txtSearch.setText("");
                    cboAction.setSelectedIndex(0);
                    cboAccount.setSelectedIndex(0);
                    loadPage(1);
                }
        );

        gbc.gridx = 6;
        gbc.weightx = 0;
        gbc.fill =
                java.awt.GridBagConstraints.NONE;

        gbc.insets =
                new Insets(
                        12,
                        0,
                        12,
                        12
                );

        filter.add(
                btnRefresh,
                gbc
        );

        lblLoading.setForeground(PRIMARY);
        lblLoading.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.ITALIC,
                        11
                )
        );

        gbc.gridx = 7;
        gbc.weightx = 0;
        gbc.insets =
                new Insets(
                        12,
                        0,
                        12,
                        12
                );

        filter.add(
                lblLoading,
                gbc
        );

        return filter;
    }

    private JLabel createFilterLabel(
            String text) {

        JLabel label =
                new JLabel(text);

        label.setForeground(TEXT);
        label.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        12
                )
        );

        return label;
    }

    private void initializeFilters() {

        cboAction.setModel(
                new DefaultComboBoxModel<>(
                        ACTION_OPTIONS.toArray(
                                new ActionOption[0]
                        )
                )
        );

        cboAction.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        12
                )
        );

        cboAction.setBackground(CARD);
        cboAction.setForeground(TEXT);
        cboAction.setBorder(
                BorderFactory.createLineBorder(
                        BORDER
                )
        );

        cboAction.setPreferredSize(
                new Dimension(
                        180,
                        40
                )
        );

        cboAction.setRenderer(
                new ComboBoxTextRenderer()
        );

        DefaultComboBoxModel<
                NhatKyHeThongDAO.AccountOption
                > accountModel =
                new DefaultComboBoxModel<>();

        accountModel.addElement(
                new NhatKyHeThongDAO.AccountOption(
                        null,
                        "Tất cả",
                        "Tài khoản"
                )
        );

        cboAccount.setModel(
                accountModel
        );

        cboAccount.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        12
                )
        );

        cboAccount.setBackground(CARD);
        cboAccount.setForeground(TEXT);
        cboAccount.setBorder(
                BorderFactory.createLineBorder(
                        BORDER
                )
        );

        cboAccount.setPreferredSize(
                new Dimension(
                        200,
                        40
                )
        );

        cboAccount.setRenderer(
                new ComboBoxTextRenderer()
        );
    }

    private void initializeTable() {

        table.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.PLAIN,
                        13
                )
        );

        table.setRowHeight(42);

        table.setIntercellSpacing(
                new Dimension(
                        0,
                        1
                )
        );

        table.setShowGrid(true);
        table.setGridColor(
                new Color(224, 231, 240)
        );

        table.setShowVerticalLines(true);
        table.setShowHorizontalLines(true);

        table.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        table.setSelectionBackground(
                SELECTED
        );

        table.setSelectionForeground(
                TEXT
        );

        table.setFillsViewportHeight(true);

        JTableHeader header =
                table.getTableHeader();

        header.setPreferredSize(
                new Dimension(
                        0,
                        44
                )
        );

        header.setDefaultRenderer(
                new LogHeaderRenderer()
        );

        table.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(160);

        table.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(110);

        table.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(175);

        table.getColumnModel()
                .getColumn(3)
                .setPreferredWidth(165);

        table.getColumnModel()
                .getColumn(4)
                .setPreferredWidth(115);

        table.getColumnModel()
                .getColumn(5)
                .setPreferredWidth(520);

        table.getColumnModel()
                .getColumn(2)
                .setCellRenderer(
                        new ActionCellRenderer()
                );

        for (int column = 0;
             column < table.getColumnCount();
             column++) {

            if (column == 2) {
                continue;
            }

            table.getColumnModel()
                    .getColumn(column)
                    .setCellRenderer(
                            new LogBodyRenderer()
                    );
        }

        table.setAutoResizeMode(
                JTable.AUTO_RESIZE_LAST_COLUMN
        );
    }

    private void initializeEvents() {

        searchDebounceTimer =
                new Timer(
                        300,
                        event -> loadPage(1)
                );

        searchDebounceTimer.setRepeats(false);

        txtSearch.getDocument()
                .addDocumentListener(
                        new javax.swing.event.DocumentListener() {

                            @Override
                            public void insertUpdate(
                                    javax.swing.event.DocumentEvent event) {
                                restartSearchTimer();
                            }

                            @Override
                            public void removeUpdate(
                                    javax.swing.event.DocumentEvent event) {
                                restartSearchTimer();
                            }

                            @Override
                            public void changedUpdate(
                                    javax.swing.event.DocumentEvent event) {
                                restartSearchTimer();
                            }
                        }
                );

        cboAction.addActionListener(
                event -> {
                    if (cboAction.getSelectedIndex() >= 0) {
                        loadPage(1);
                    }
                }
        );

        cboAccount.addActionListener(
                event -> {
                    if (cboAccount.getSelectedIndex() >= 0) {
                        loadPage(1);
                    }
                }
        );
    }

    private void restartSearchTimer() {

        if (searchDebounceTimer != null) {
            searchDebounceTimer.restart();
        }
    }

    private void loadAccountOptions() {

        new SwingWorker<
                List<NhatKyHeThongDAO.AccountOption>,
                Void>() {

            @Override
            protected List<
                    NhatKyHeThongDAO.AccountOption
                    > doInBackground()
                    throws Exception {

                return nhatKyHeThongDAO
                        .findAccountOptions();
            }

            @Override
            protected void done() {

                try {

                    List<
                            NhatKyHeThongDAO.AccountOption
                            > accounts =
                            get();

                    NhatKyHeThongDAO.AccountOption selected =
                            (NhatKyHeThongDAO.AccountOption)
                                    cboAccount.getSelectedItem();

                    DefaultComboBoxModel<
                            NhatKyHeThongDAO.AccountOption
                            > model =
                            new DefaultComboBoxModel<>();

                    model.addElement(
                            new NhatKyHeThongDAO.AccountOption(
                                    null,
                                    "Tất cả",
                                    "Tài khoản"
                            )
                    );

                    for (
                            NhatKyHeThongDAO.AccountOption account
                            : accounts) {

                        model.addElement(account);
                    }

                    cboAccount.setModel(model);

                    if (selected != null
                            && selected.getId() != null) {

                        for (int i = 0;
                             i < model.getSize();
                             i++) {

                            NhatKyHeThongDAO.AccountOption option =
                                    model.getElementAt(i);

                            if (selected.getId()
                                    .equals(option.getId())) {

                                cboAccount
                                        .setSelectedIndex(i);

                                break;
                            }
                        }
                    }

                } catch (Exception exception) {

                    lblLoading.setText(
                            "Không tải được tài khoản"
                    );
                }
            }
        }.execute();
    }

    private void loadPage(int page) {

        final int requestId =
                ++requestSequence;

        currentPage =
                Math.max(
                        1,
                        page
                );

        lblLoading.setText(
                "Đang tải..."
        );

        setCursor(
                Cursor.getPredefinedCursor(
                        Cursor.WAIT_CURSOR
                )
        );

        String keyword =
                txtSearch.getText().trim();

        ActionOption action =
                (ActionOption)
                        cboAction.getSelectedItem();

        NhatKyHeThongDAO.AccountOption account =
                (NhatKyHeThongDAO.AccountOption)
                        cboAccount.getSelectedItem();

        String actionCode =
                action == null
                        ? null
                        : action.getCode();

        Integer accountId =
                account == null
                        ? null
                        : account.getId();

        new SwingWorker<
                NhatKyHeThongDAO.PageResult,
                Void>() {

            @Override
            protected NhatKyHeThongDAO.PageResult
            doInBackground()
                    throws Exception {

                return nhatKyHeThongDAO.findPage(
                        keyword,
                        actionCode,
                        accountId,
                        currentPage,
                        PAGE_SIZE
                );
            }

            @Override
            protected void done() {

                if (requestId != requestSequence) {
                    return;
                }

                try {

                    NhatKyHeThongDAO.PageResult result =
                            get();

                    applyPageResult(result);

                    lblLoading.setText(" ");

                } catch (Exception exception) {

                    tableModel.setRowCount(0);

                    lblTotal.setText(
                            "Không tải được dữ liệu"
                    );

                    lblPageInfo.setText(
                            "Trang 1/1"
                    );

                    paginationPanel.removeAll();
                    paginationPanel.revalidate();
                    paginationPanel.repaint();

                    lblLoading.setText(
                            "Lỗi kết nối CSDL"
                    );

                } finally {

                    setCursor(
                            Cursor.getDefaultCursor()
                    );
                }
            }
        }.execute();
    }

    private void applyPageResult(
            NhatKyHeThongDAO.PageResult result) {

        tableModel.setRowCount(0);

        for (
                NhatKyHeThongDAO.NhatKyHeThongRow row
                : result.getRows()) {

            NhatKyHeThong log =
                    row.getLog();

            tableModel.addRow(
                    new Object[] {
                            formatDateTime(
                                    log.getThoiGian()
                            ),
                            row.getTenDangNhap() == null
                                    ? "Không xác định"
                                    : row.getTenDangNhap(),
                            actionLabel(
                                    log.getHanhDong()
                            ),
                            objectLabel(
                                    log.getDoiTuong()
                            ),
                            safe(
                                    log.getDoiTuongId()
                            ),
                            safe(
                                    log.getNoiDung()
                            )
                    }
            );
        }

        currentPage =
                result.getPage();

        totalPages =
                result.getTotalPages();

        lblTotal.setText(
                "Tổng: "
                        + result.getTotalRecords()
                        + " bản ghi"
        );

        lblPageInfo.setText(
                "Trang "
                        + currentPage
                        + "/"
                        + totalPages
        );

        rebuildPagination();

        table.revalidate();
        table.repaint();
    }

    private void rebuildPagination() {

        paginationPanel.removeAll();

        JButton previous =
                createPageButton(
                        "‹",
                        currentPage > 1,
                        () -> loadPage(
                                currentPage - 1
                        )
                );

        paginationPanel.add(previous);

        List<Integer> pages =
                calculateVisiblePages(
                        currentPage,
                        totalPages
                );

        Integer previousPage = null;

        for (Integer page : pages) {

            if (previousPage != null
                    && page - previousPage > 1) {

                JButton dots =
                        createPageButton(
                                "…",
                                false,
                                null
                        );

                paginationPanel.add(dots);
            }

            JButton pageButton =
                    createPageButton(
                            String.valueOf(page),
                            true,
                            () -> loadPage(page)
                    );

            if (page == currentPage) {

                pageButton.setBackground(
                        PRIMARY
                );

                pageButton.setForeground(
                        Color.WHITE
                );

            } else {

                pageButton.setBackground(
                        CARD
                );

                pageButton.setForeground(
                        TEXT
                );
            }

            paginationPanel.add(pageButton);

            previousPage = page;
        }

        JButton next =
                createPageButton(
                        "›",
                        currentPage < totalPages,
                        () -> loadPage(
                                currentPage + 1
                        )
                );

        paginationPanel.add(next);

        paginationPanel.revalidate();
        paginationPanel.repaint();
    }

    private List<Integer> calculateVisiblePages(
            int current,
            int total) {

        if (total <= 7) {

            List<Integer> result =
                    new ArrayList<>();

            for (int i = 1; i <= total; i++) {
                result.add(i);
            }

            return result;
        }

        List<Integer> result =
                new ArrayList<>();

        result.add(1);

        if (current > 4) {
            result.add(current - 1);
        }

        if (current > 2
                && current < total - 1) {
            result.add(current);
        }

        if (current < total - 3) {
            result.add(current + 1);
        }

        result.add(total);

        return result.stream()
                .distinct()
                .sorted()
                .toList();
    }

    private JButton createPageButton(
            String text,
            boolean enabled,
            Runnable action) {

        JButton button =
                new JButton(text);

        button.setPreferredSize(
                new Dimension(
                        38,
                        38
                )
        );

        button.setFont(
                new Font(
                        UITheme.FONT_NAME,
                        Font.BOLD,
                        13
                )
        );

        button.setFocusPainted(false);
        button.setBorderPainted(true);
        button.setBorder(
                BorderFactory.createLineBorder(
                        BORDER
                )
        );

        button.setContentAreaFilled(true);
        button.setOpaque(true);

        button.setBackground(
                enabled
                        ? CARD
                        : new Color(241, 244, 248)
        );

        button.setForeground(
                enabled
                        ? TEXT
                        : new Color(175, 183, 194)
        );

        button.setEnabled(enabled);

        if (action != null
                && enabled) {

            button.setCursor(
                    Cursor.getPredefinedCursor(
                            Cursor.HAND_CURSOR
                    )
            );

            button.addActionListener(
                    event -> action.run()
            );
        }

        return button;
    }

    private String formatDateTime(
            LocalDateTime value) {

        return value == null
                ? "-"
                : value.format(
                        DATE_TIME_FORMATTER
                );
    }

    private String safe(String value) {
        return value == null || value.isBlank()
                ? "-"
                : value;
    }

    private String actionLabel(
            String action) {

        if (action == null) {
            return "";
        }

        return switch (action) {

            case "THEM_MOI" ->
                    "Thêm mới";

            case "CAP_NHAT" ->
                    "Cập nhật";

            case "XEM" ->
                    "Xem";

            case "XOA" ->
                    "Xóa";

            case "XAC_NHAN" ->
                    "Xác nhận";

            case "DANG_NHAP" ->
                    "Đăng nhập";

            case "DANG_NHAP_THAT_BAI" ->
                    "Đăng nhập thất bại";

            case "DANG_XUAT" ->
                    "Đăng xuất";

            case "NHAN_PHONG" ->
                    "Nhận phòng";

            case "TRA_PHONG" ->
                    "Trả phòng";

            case "THANH_TOAN" ->
                    "Thanh toán";

            case "CAP_NHAT_NHIEM_VU" ->
                    "Cập nhật nhiệm vụ";

            case "THOAT_CHUONG_TRINH" ->
                    "Thoát chương trình";

            default ->
                    action;
        };
    }

    private String objectLabel(
            String object) {

        if (object == null) {
            return "-";
        }

        return switch (object) {

            case "TAI_KHOAN" ->
                    "Tài khoản";

            case "KHACH_HANG" ->
                    "Khách hàng";

            case "DAT_PHONG" ->
                    "Đặt phòng";

            case "PHONG" ->
                    "Phòng";

            case "BUONG_PHONG",
                 "NHIEM_VU_BUONG_PHONG" ->
                    "Buồng phòng";

            case "DICH_VU" ->
                    "Dịch vụ";

            case "HOA_DON" ->
                    "Hóa đơn";

            case "HE_THONG" ->
                    "Hệ thống";

            default ->
                    object;
        };
    }

    /**
     * Renderer cho tiêu đề bảng.
     */
    private static final class LogHeaderRenderer
            extends DefaultTableCellRenderer {

        private static final long serialVersionUID = 1L;

        private LogHeaderRenderer() {

            setOpaque(true);
            setBackground(HEADER);
            setForeground(PRIMARY_DARK);

            setFont(
                    new Font(
                            UITheme.FONT_NAME,
                            Font.BOLD,
                            12
                    )
            );

            setBorder(
                    BorderFactory.createMatteBorder(
                            0,
                            0,
                            1,
                            1,
                            BORDER
                    )
            );

            setVerticalAlignment(
                    SwingConstants.CENTER
            );
        }

        @Override
        public Component getTableCellRendererComponent(
                JTable table,
                Object value,
                boolean selected,
                boolean focused,
                int row,
                int column) {

            super.getTableCellRendererComponent(
                    table,
                    value,
                    selected,
                    focused,
                    row,
                    column
            );

            setOpaque(true);
            setBackground(HEADER);
            setForeground(PRIMARY_DARK);

            setFont(
                    new Font(
                            UITheme.FONT_NAME,
                            Font.BOLD,
                            12
                    )
            );

            setBorder(
                    BorderFactory.createMatteBorder(
                            0,
                            0,
                            1,
                            1,
                            BORDER
                    )
            );

            return this;
        }
    }

    /**
     * Renderer thông thường cho các cột dữ liệu.
     */
    private static final class LogBodyRenderer
            extends DefaultTableCellRenderer {

        private static final long serialVersionUID = 1L;

        @Override
        public Component getTableCellRendererComponent(
                JTable table,
                Object value,
                boolean selected,
                boolean focused,
                int row,
                int column) {

            super.getTableCellRendererComponent(
                    table,
                    value,
                    selected,
                    focused,
                    row,
                    column
            );

            setOpaque(true);

            if (selected) {
                setBackground(SELECTED);
                setForeground(TEXT);
            } else {
                setBackground(
                        row % 2 == 0
                                ? CARD
                                : ROW_ALT
                );

                setForeground(TEXT);
            }

            setFont(
                    new Font(
                            UITheme.FONT_NAME,
                            Font.PLAIN,
                            12
                    )
            );

            setBorder(
                    new EmptyBorder(
                            0,
                            8,
                            0,
                            8
                    )
            );

            if (column == 0
                    || column == 4) {

                setHorizontalAlignment(
                        SwingConstants.CENTER
                );

            } else {

                setHorizontalAlignment(
                        SwingConstants.LEFT
                );
            }

            return this;
        }
    }

    /**
     * Renderer riêng cho cột hành động:
     * icon + chữ + màu tương ứng.
     */
    private final class ActionCellRenderer
            extends DefaultTableCellRenderer {

        private static final long serialVersionUID = 1L;

        @Override
        public Component getTableCellRendererComponent(
                JTable table,
                Object value,
                boolean selected,
                boolean focused,
                int row,
                int column) {

            String action =
                    value == null
                            ? ""
                            : value.toString();

            super.getTableCellRendererComponent(
                    table,
                    action,
                    selected,
                    focused,
                    row,
                    column
            );

            setOpaque(true);

            if (selected) {
                setBackground(SELECTED);
                setForeground(TEXT);
            } else {
                setBackground(
                        row % 2 == 0
                                ? CARD
                                : ROW_ALT
                );

                setForeground(
                        actionColor(action)
                );
            }

            setFont(
                    new Font(
                            UITheme.FONT_NAME,
                            Font.BOLD,
                            12
                    )
            );

            setIcon(
                    new ActionIcon(
                            action,
                            actionColor(action)
                    )
            );

            setIconTextGap(9);

            setHorizontalAlignment(
                    SwingConstants.LEFT
            );

            setBorder(
                    new EmptyBorder(
                            0,
                            8,
                            0,
                            8
                    )
            );

            return this;
        }
    }

    private static Color actionColor(
            String action) {

        return switch (action) {

            case "Thêm mới" ->
                    new Color(42, 171, 82);

            case "Cập nhật" ->
                    new Color(35, 111, 221);

            case "Xem" ->
                    new Color(239, 145, 19);

            case "Xóa" ->
                    new Color(220, 62, 62);

            case "Xác nhận" ->
                    new Color(47, 174, 87);

            case "Đăng nhập" ->
                    new Color(62, 132, 103);

            case "Đăng nhập thất bại" ->
                    new Color(220, 62, 62);

            case "Đăng xuất",
                 "Thoát chương trình" ->
                    new Color(220, 62, 62);

            case "Nhận phòng" ->
                    new Color(44, 128, 211);

            case "Trả phòng" ->
                    new Color(118, 89, 198);

            case "Thanh toán" ->
                    new Color(34, 143, 102);

            default ->
                    PRIMARY;
        };
    }

    private static final class ActionOption {

        private final String label;
        private final String code;

        private ActionOption(
                String label,
                String code) {

            this.label = label;
            this.code = code;
        }

        private String getCode() {
            return code;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    private static final class ComboBoxTextRenderer
            extends DefaultListCellRenderer {

        private static final long serialVersionUID = 1L;

        @Override
        public Component getListCellRendererComponent(
                javax.swing.JList<?> list,
                Object value,
                int index,
                boolean selected,
                boolean focused) {

            super.getListCellRendererComponent(
                    list,
                    value,
                    index,
                    selected,
                    focused
            );

            setFont(
                    new Font(
                            UITheme.FONT_NAME,
                            Font.PLAIN,
                            12
                    )
            );

            setBorder(
                    new EmptyBorder(
                            6,
                            8,
                            6,
                            8
                    )
            );

            setForeground(
                    selected
                            ? PRIMARY_DARK
                            : TEXT
            );

            return this;
        }
    }

    /**
     * Ô nhập liệu nền trắng, bo góc nhẹ và tự vẽ bằng Graphics2D.
     */
    private static final class RoundedTextField
            extends JTextField {

        private static final long serialVersionUID = 1L;

        private RoundedTextField(int columns) {

            super(columns);

            setOpaque(false);

            setFont(
                    new Font(
                            UITheme.FONT_NAME,
                            Font.PLAIN,
                            12
                    )
            );

            setForeground(TEXT);

            setCaretColor(PRIMARY);

            setBorder(
                    new EmptyBorder(
                            0,
                            12,
                            0,
                            12
                    )
            );

            setPreferredSize(
                    new Dimension(
                            360,
                            40
                    )
            );
        }

        @Override
        protected void paintComponent(
                Graphics graphics) {

            Graphics2D g =
                    (Graphics2D)
                            graphics.create();

            g.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g.setColor(Color.WHITE);

            g.fillRoundRect(
                    0,
                    0,
                    getWidth() - 1,
                    getHeight() - 1,
                    10,
                    10
            );

            g.dispose();

            super.paintComponent(graphics);
        }

        @Override
        protected void paintBorder(
                Graphics graphics) {

            Graphics2D g =
                    (Graphics2D)
                            graphics.create();

            g.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g.setColor(BORDER);

            g.drawRoundRect(
                    0,
                    0,
                    getWidth() - 1,
                    getHeight() - 1,
                    10,
                    10
            );

            g.dispose();
        }
    }

    /**
     * Panel bo góc bằng Graphics2D.
     */
    private static final class RoundedPanel
            extends JPanel {

        private static final long serialVersionUID = 1L;

        private final Color background;
        private final Color borderColor;
        private final int radius;

        private RoundedPanel(
                Color background,
                Color borderColor,
                int radius) {

            this.background = background;
            this.borderColor = borderColor;
            this.radius = radius;

            setOpaque(false);

            setBorder(
                    new EmptyBorder(
                            0,
                            0,
                            0,
                            0
                    )
            );
        }

        @Override
        protected void paintComponent(
                Graphics graphics) {

            Graphics2D g =
                    (Graphics2D)
                            graphics.create();

            g.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            Shape shape =
                    new java.awt.geom.RoundRectangle2D.Double(
                            0.5,
                            0.5,
                            getWidth() - 1,
                            getHeight() - 1,
                            radius,
                            radius
                    );

            g.setColor(background);
            g.fill(shape);

            g.setColor(borderColor);
            g.setStroke(
                    new BasicStroke(1f)
            );
            g.draw(shape);

            g.dispose();

            super.paintComponent(graphics);
        }
    }

    /**
     * Icon hành động được vẽ trực tiếp bằng Graphics2D.
     */
    private static final class ActionIcon
            implements Icon {

        private final String action;
        private final Color color;

        private ActionIcon(
                String action,
                Color color) {

            this.action = action;
            this.color = color;
        }

        @Override
        public int getIconWidth() {
            return 24;
        }

        @Override
        public int getIconHeight() {
            return 24;
        }

        @Override
        public void paintIcon(
                Component component,
                Graphics graphics,
                int x,
                int y) {

            Graphics2D g =
                    (Graphics2D)
                            graphics.create();

            g.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g.setColor(color);

            switch (action) {

                case "Thêm mới" -> {
                    g.fillOval(
                            x + 3,
                            y + 3,
                            18,
                            18
                    );

                    g.setColor(Color.WHITE);
                    g.setStroke(
                            new BasicStroke(
                                    2.2f,
                                    BasicStroke.CAP_ROUND,
                                    BasicStroke.JOIN_ROUND
                            )
                    );

                    g.drawLine(
                            x + 12,
                            y + 7,
                            x + 12,
                            y + 17
                    );

                    g.drawLine(
                            x + 7,
                            y + 12,
                            x + 17,
                            y + 12
                    );
                }

                case "Cập nhật",
                     "Cập nhật nhiệm vụ" -> {

                    g.setStroke(
                            new BasicStroke(
                                    4f,
                                    BasicStroke.CAP_ROUND,
                                    BasicStroke.JOIN_ROUND
                            )
                    );

                    g.drawLine(
                            x + 6,
                            y + 17,
                            x + 17,
                            y + 6
                    );

                    g.setStroke(
                            new BasicStroke(2f)
                    );

                    g.drawLine(
                            x + 5,
                            y + 19,
                            x + 9,
                            y + 18
                    );
                }

                case "Xem" -> {

                    g.fillOval(
                            x + 2,
                            y + 7,
                            20,
                            11
                    );

                    g.setColor(Color.WHITE);

                    g.fillOval(
                            x + 9,
                            y + 9,
                            6,
                            6
                    );

                    g.setColor(color);

                    g.fillOval(
                            x + 11,
                            y + 11,
                            2,
                            2
                    );
                }

                case "Xóa" -> {

                    g.fillRoundRect(
                            x + 7,
                            y + 7,
                            10,
                            14,
                            2,
                            2
                    );

                    g.fillRect(
                            x + 5,
                            y + 5,
                            14,
                            2
                    );

                    g.fillRect(
                            x + 10,
                            y + 3,
                            4,
                            2
                    );
                }

                case "Xác nhận" -> {

                    g.fillOval(
                            x + 3,
                            y + 3,
                            18,
                            18
                    );

                    g.setColor(Color.WHITE);

                    g.setStroke(
                            new BasicStroke(
                                    2.4f,
                                    BasicStroke.CAP_ROUND,
                                    BasicStroke.JOIN_ROUND
                            )
                    );

                    g.drawLine(
                            x + 7,
                            y + 12,
                            x + 11,
                            y + 16
                    );

                    g.drawLine(
                            x + 11,
                            y + 16,
                            x + 18,
                            y + 8
                    );
                }

                case "Đăng nhập",
                     "Nhận phòng" -> {

                    g.setStroke(
                            new BasicStroke(
                                    2.8f,
                                    BasicStroke.CAP_ROUND,
                                    BasicStroke.JOIN_ROUND
                            )
                    );

                    g.drawLine(
                            x + 4,
                            y + 12,
                            x + 18,
                            y + 12
                    );

                    g.drawLine(
                            x + 14,
                            y + 8,
                            x + 18,
                            y + 12
                    );

                    g.drawLine(
                            x + 14,
                            y + 16,
                            x + 18,
                            y + 12
                    );
                }

                case "Đăng nhập thất bại" -> {

                    g.setStroke(
                            new BasicStroke(
                                    2.8f,
                                    BasicStroke.CAP_ROUND,
                                    BasicStroke.JOIN_ROUND
                            )
                    );

                    g.drawLine(x + 7, y + 7, x + 17, y + 17);
                    g.drawLine(x + 17, y + 7, x + 7, y + 17);
                }

                case "Đăng xuất",
                     "Thoát chương trình" -> {

                    g.setStroke(
                            new BasicStroke(
                                    2.8f,
                                    BasicStroke.CAP_ROUND,
                                    BasicStroke.JOIN_ROUND
                            )
                    );

                    g.drawLine(
                            x + 20,
                            y + 12,
                            x + 6,
                            y + 12
                    );

                    g.drawLine(
                            x + 10,
                            y + 8,
                            x + 6,
                            y + 12
                    );

                    g.drawLine(
                            x + 10,
                            y + 16,
                            x + 6,
                            y + 12
                    );
                }

                default -> {

                    g.fillOval(
                            x + 5,
                            y + 5,
                            14,
                            14
                    );
                }
            }

            g.dispose();
        }
    }

    /**
     * Icon clipboard cho tiêu đề.
     */
    private static final class ClipboardIcon
            implements Icon {

        private final Color color;

        private ClipboardIcon(Color color) {
            this.color = color;
        }

        @Override
        public int getIconWidth() {
            return 54;
        }

        @Override
        public int getIconHeight() {
            return 54;
        }

        @Override
        public void paintIcon(
                Component component,
                Graphics graphics,
                int x,
                int y) {

            Graphics2D g =
                    (Graphics2D)
                            graphics.create();

            g.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g.setColor(color);

            g.fillRoundRect(
                    x + 9,
                    y + 7,
                    36,
                    42,
                    8,
                    8
            );

            g.setColor(Color.WHITE);

            g.fillRoundRect(
                    x + 15,
                    y + 13,
                    24,
                    30,
                    4,
                    4
            );

            g.setColor(color);

            g.fillRoundRect(
                    x + 21,
                    y + 3,
                    12,
                    10,
                    4,
                    4
            );

            g.setStroke(
                    new BasicStroke(2f)
            );

            for (int i = 0; i < 3; i++) {

                int yy =
                        y + 20 + i * 7;

                g.drawLine(
                        x + 20,
                        yy,
                        x + 35,
                        yy
                );
            }

            g.dispose();
        }
    }

    /**
     * Icon đơn giản cho thanh điều hướng.
     * Các biểu tượng được vẽ bằng Graphics2D để không phụ thuộc font/emoji.
     */
    private static final class NavIcon
            implements Icon {

        private final String text;
        private final boolean active;

        private NavIcon(
                String text,
                boolean active) {

            this.text = text;
            this.active = active;
        }

        @Override
        public int getIconWidth() {
            return 22;
        }

        @Override
        public int getIconHeight() {
            return 22;
        }

        @Override
        public void paintIcon(
                Component component,
                Graphics graphics,
                int x,
                int y) {

            Graphics2D g =
                    (Graphics2D)
                            graphics.create();

            g.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g.setColor(
                    active
                            ? PRIMARY
                            : new Color(61, 78, 99)
            );

            if (text.equals("Trang chủ")) {

                Polygon roof =
                        new Polygon(
                                new int[] {
                                        x + 2,
                                        x + 11,
                                        x + 20
                                },
                                new int[] {
                                        y + 10,
                                        y + 2,
                                        y + 10
                                },
                                3
                        );

                g.fill(roof);

                g.fillRoundRect(
                        x + 5,
                        y + 9,
                        12,
                        10,
                        2,
                        2
                );

            } else if (text.equals("Khách hàng")) {

                g.fillOval(
                        x + 7,
                        y + 2,
                        8,
                        8
                );

                g.fillOval(
                        x + 4,
                        y + 11,
                        14,
                        8
                );

            } else if (text.contains("phòng")) {

                g.fillRoundRect(
                        x + 3,
                        y + 10,
                        17,
                        7,
                        2,
                        2
                );

                g.fillRect(
                        x + 4,
                        y + 5,
                        2,
                        12
                );

                g.fillRoundRect(
                        x + 6,
                        y + 7,
                        10,
                        4,
                        2,
                        2
                );

            } else if (text.equals("Hóa đơn")) {

                g.fillRoundRect(
                        x + 4,
                        y + 2,
                        14,
                        18,
                        2,
                        2
                );

                g.setColor(Color.WHITE);

                for (int i = 0; i < 3; i++) {

                    g.drawLine(
                            x + 7,
                            y + 7 + i * 4,
                            x + 15,
                            y + 7 + i * 4
                    );
                }

            } else if (text.equals("Thống kê")) {

                g.fillRoundRect(
                        x + 3,
                        y + 12,
                        4,
                        8,
                        1,
                        1
                );

                g.fillRoundRect(
                        x + 9,
                        y + 8,
                        4,
                        12,
                        1,
                        1
                );

                g.fillRoundRect(
                        x + 15,
                        y + 3,
                        4,
                        17,
                        1,
                        1
                );

            } else if (text.equals("Nhật ký hệ thống")) {

                g.fillRoundRect(
                        x + 4,
                        y + 4,
                        14,
                        16,
                        2,
                        2
                );

                g.setColor(Color.WHITE);

                g.fillRect(
                        x + 7,
                        y + 8,
                        8,
                        2
                );

                g.fillRect(
                        x + 7,
                        y + 12,
                        8,
                        2
                );

                g.fillRect(
                        x + 7,
                        y + 16,
                        6,
                        2
                );

            } else if (text.equals("Quản trị hệ thống")) {

                g.fillOval(
                        x + 5,
                        y + 5,
                        12,
                        12
                );

                g.setColor(SIDEBAR);

                g.fillOval(
                        x + 9,
                        y + 9,
                        4,
                        4
                );

            } else {

                g.fillRoundRect(
                        x + 4,
                        y + 4,
                        14,
                        14,
                        3,
                        3
                );

            }

            g.dispose();
        }
    }
}
