package vn.edu.eaut.hotelmanagement.security;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Mã hóa dữ liệu cá nhân khách hàng tại lớp ứng dụng.
 *
 * <p>Sử dụng AES-256-GCM, có IV ngẫu nhiên cho từng giá trị. Dữ liệu trong
 * MySQL chỉ chứa chuỗi dạng v1:<IV>:<ciphertext+tag>; khóa không được lưu trong
 * CSDL. Khóa được lấy từ system property / environment variable / database.properties.</p>
 */
public final class CustomerDataCrypto {

    private static final String PREFIX = "v1:";
    private static final int IV_LENGTH_BYTES = 12;
    private static final int TAG_LENGTH_BITS = 128;
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final SecretKeySpec KEY = loadKey();

    private CustomerDataCrypto() {
    }

    public static String encrypt(String plaintext) {
        if (plaintext == null || plaintext.isEmpty()) {
            return plaintext;
        }
        if (isEncrypted(plaintext)) {
            return plaintext;
        }

        try {
            byte[] iv = new byte[IV_LENGTH_BYTES];
            RANDOM.nextBytes(iv);

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, KEY, new GCMParameterSpec(TAG_LENGTH_BITS, iv));
            byte[] ciphertext = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));

            return PREFIX
                    + Base64.getUrlEncoder().withoutPadding().encodeToString(iv)
                    + ":"
                    + Base64.getUrlEncoder().withoutPadding().encodeToString(ciphertext);
        } catch (GeneralSecurityException exception) {
            throw new IllegalStateException("Không thể mã hóa dữ liệu khách hàng.", exception);
        }
    }

    /**
     * Giải mã dữ liệu. Nếu gặp dữ liệu cũ chưa mã hóa, trả nguyên văn để hỗ trợ
     * chuyển đổi không gián đoạn; startup migration sẽ mã hóa phần dữ liệu này.
     */
    public static String decrypt(String value) {
        if (value == null || value.isEmpty() || !isEncrypted(value)) {
            return value;
        }

        try {
            String[] parts = value.split(":", -1);
            if (parts.length != 3 || !PREFIX.substring(0, PREFIX.length() - 1).equals(parts[0])) {
                throw new IllegalArgumentException("Định dạng dữ liệu mã hóa không hợp lệ.");
            }

            byte[] iv = Base64.getUrlDecoder().decode(parts[1]);
            byte[] ciphertext = Base64.getUrlDecoder().decode(parts[2]);
            if (iv.length != IV_LENGTH_BYTES) {
                throw new IllegalArgumentException("IV dữ liệu khách hàng không hợp lệ.");
            }

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, KEY, new GCMParameterSpec(TAG_LENGTH_BITS, iv));
            byte[] plaintext = cipher.doFinal(ciphertext);
            return new String(plaintext, StandardCharsets.UTF_8);
        } catch (GeneralSecurityException | IllegalArgumentException exception) {
            throw new IllegalStateException("Không thể giải mã dữ liệu khách hàng. Kiểm tra khóa mã hóa.", exception);
        }
    }

    public static boolean isEncrypted(String value) {
        return value != null && value.startsWith(PREFIX);
    }

    /** Hiển thị an toàn trong danh sách: giữ lại 4 ký tự cuối của giấy tờ/số điện thoại. */
    public static String maskIdentifier(String value) {
        if (value == null || value.isBlank()) {
            return value;
        }
        String normalized = value.trim();
        if (normalized.length() <= 4) {
            return "••••";
        }
        return "••••••" + normalized.substring(normalized.length() - 4);
    }

    /**
     * So sánh giá trị nhập với dữ liệu đã lưu mà không để lộ plaintext trong DB.
     */
    public static boolean matches(String storedValue, String candidate) {
        if (storedValue == null || candidate == null) {
            return storedValue == null && candidate == null;
        }
        return candidate.equals(decrypt(storedValue));
    }

    private static SecretKeySpec loadKey() {
        String configured = firstNonBlank(
                System.getProperty("customer.encryption.key"),
                System.getenv("HOTEL_CUSTOMER_ENCRYPTION_KEY"),
                readResourceProperty("customer.encryption.key")
        );

        if (configured == null) {
            throw new IllegalStateException(
                    "Thiếu khóa mã hóa khách hàng. Thiết lập customer.encryption.key "
                            + "hoặc biến môi trường HOTEL_CUSTOMER_ENCRYPTION_KEY."
            );
        }

        byte[] keyBytes = sha256(configured.getBytes(StandardCharsets.UTF_8));
        return new SecretKeySpec(keyBytes, "AES");
    }

    private static String readResourceProperty(String key) {
        try (var inputStream = CustomerDataCrypto.class.getResourceAsStream("/database.properties")) {
            if (inputStream == null) {
                return null;
            }
            java.util.Properties properties = new java.util.Properties();
            properties.load(inputStream);
            return properties.getProperty(key);
        } catch (Exception exception) {
            return null;
        }
    }

    private static String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value.trim();
            }
        }
        return null;
    }

    private static byte[] sha256(byte[] input) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(input);
        } catch (GeneralSecurityException exception) {
            throw new IllegalStateException("JRE không hỗ trợ SHA-256.", exception);
        }
    }
}
