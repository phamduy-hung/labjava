package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.NhiemVuBuongPhong;
import vn.edu.eaut.hotelmanagement.model.enums.LoaiNhiemVuBuongPhong;
import vn.edu.eaut.hotelmanagement.model.enums.MucDoUuTien;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiNhiemVu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class NhiemVuBuongPhongDAO {

    private static final String SELECT_COLUMNS =
            "nv.id, nv.ma_nhiem_vu, nv.phong_id, nv.loai_nhiem_vu, nv.muc_do_uu_tien, nv.trang_thai, "
                    + "nv.nguoi_tao_id, nv.nhan_vien_phu_trach_id, nv.thoi_gian_tao, nv.thoi_gian_bat_dau, "
                    + "nv.thoi_gian_hoan_thanh, nv.ghi_chu";

    public int insert(NhiemVuBuongPhong task) throws SQLException {
        String sql = "INSERT INTO nhiem_vu_buong_phong(ma_nhiem_vu, phong_id, loai_nhiem_vu, muc_do_uu_tien, trang_thai, "
                + "nguoi_tao_id, nhan_vien_phu_trach_id, thoi_gian_tao, thoi_gian_bat_dau, thoi_gian_hoan_thanh, ghi_chu) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, task, false);
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    task.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của nhiệm vụ buồng phòng vừa thêm.");
    }

    public boolean update(NhiemVuBuongPhong task) throws SQLException {
        if (task == null || task.getId() == null || task.getId() <= 0) {
            throw new IllegalArgumentException("Thông tin nhiệm vụ không hợp lệ.");
        }

        String currentSql = "SELECT trang_thai FROM nhiem_vu_buong_phong WHERE id = ?";
        String sql = "UPDATE nhiem_vu_buong_phong SET ma_nhiem_vu = ?, phong_id = ?, loai_nhiem_vu = ?, "
                + "muc_do_uu_tien = ?, nguoi_tao_id = ?, nhan_vien_phu_trach_id = ?, thoi_gian_tao = ?, "
                + "thoi_gian_bat_dau = ?, thoi_gian_hoan_thanh = ?, ghi_chu = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection()) {
            TrangThaiNhiemVu currentStatus;
            try (PreparedStatement statement = connection.prepareStatement(currentSql)) {
                statement.setInt(1, task.getId());
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (!resultSet.next()) {
                        throw new SQLException("Không tìm thấy nhiệm vụ cần cập nhật.");
                    }
                    currentStatus = TrangThaiNhiemVu.valueOf(resultSet.getString("trang_thai"));
                }
            }

            if (task.getTrangThai() != null && task.getTrangThai() != currentStatus) {
                throw new SQLException(
                        "Không được thay đổi trạng thái nhiệm vụ bằng chức năng Sửa. "
                                + "Hãy dùng nghiệp vụ bắt đầu/hoàn thành/hủy nhiệm vụ."
                );
            }

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, task.getMaNhiemVu());
                statement.setInt(2, task.getPhongId());
                statement.setString(3, task.getLoaiNhiemVu().name());
                statement.setString(4, task.getMucDoUuTien().name());
                JdbcDataAccessSupport.setNullableInteger(statement, 5, task.getNguoiTaoId());
                JdbcDataAccessSupport.setNullableInteger(statement, 6, task.getNhanVienPhuTrachId());
                JdbcDataAccessSupport.setNullableLocalDateTime(statement, 7, task.getThoiGianTao());
                JdbcDataAccessSupport.setNullableLocalDateTime(statement, 8, task.getThoiGianBatDau());
                JdbcDataAccessSupport.setNullableLocalDateTime(statement, 9, task.getThoiGianHoanThanh());
                statement.setString(10, task.getGhiChu());
                statement.setInt(11, task.getId());
                boolean updated = statement.executeUpdate() == 1;
                task.setTrangThai(currentStatus);
                return updated;
            }
        }
    }

    public boolean updateStatus(int taskId, TrangThaiNhiemVu targetStatus, LocalDateTime startTime, LocalDateTime completionTime)
            throws SQLException {
        if (taskId <= 0 || targetStatus == null) {
            throw new IllegalArgumentException("Nhiệm vụ hoặc trạng thái không hợp lệ.");
        }

        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            TrangThaiNhiemVu currentStatus;
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT trang_thai FROM nhiem_vu_buong_phong WHERE id = ? FOR UPDATE")) {
                statement.setInt(1, taskId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (!resultSet.next()) {
                        throw new SQLException("Không tìm thấy nhiệm vụ buồng phòng.");
                    }
                    currentStatus = TrangThaiNhiemVu.valueOf(resultSet.getString("trang_thai"));
                }
            }

            if (currentStatus == targetStatus) {
                connection.commit();
                return true;
            }
            if (!currentStatus.canTransitionTo(targetStatus)) {
                throw new SQLException(
                        "Không được chuyển nhiệm vụ từ " + currentStatus + " sang " + targetStatus + "."
                );
            }

            if (targetStatus == TrangThaiNhiemVu.DANG_XU_LY && startTime == null) {
                throw new IllegalArgumentException("Nhiệm vụ bắt đầu xử lý phải có thời gian bắt đầu.");
            }
            if (targetStatus == TrangThaiNhiemVu.HOAN_THANH && completionTime == null) {
                throw new IllegalArgumentException("Nhiệm vụ hoàn thành phải có thời gian hoàn thành.");
            }

            String sql = "UPDATE nhiem_vu_buong_phong "
                    + "SET trang_thai = ?, thoi_gian_bat_dau = ?, thoi_gian_hoan_thanh = ? "
                    + "WHERE id = ? AND trang_thai = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, targetStatus.name());
                JdbcDataAccessSupport.setNullableLocalDateTime(statement, 2, startTime);
                JdbcDataAccessSupport.setNullableLocalDateTime(statement, 3, completionTime);
                statement.setInt(4, taskId);
                statement.setString(5, currentStatus.name());
                boolean updated = statement.executeUpdate() == 1;
                if (!updated) {
                    throw new SQLException("Nhiệm vụ đã thay đổi bởi thao tác khác. Vui lòng tải lại dữ liệu.");
                }
                connection.commit();
                return true;
            }
        } catch (SQLException | RuntimeException exception) {
            if (connection != null) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackException) {
                    exception.addSuppressed(rollbackException);
                }
            }
            throw exception;
        } finally {
            if (connection != null) {
                try {
                    connection.setAutoCommit(true);
                } catch (SQLException ignored) {
                }
                try {
                    connection.close();
                } catch (SQLException ignored) {
                }
            }
        }
    }

    /** Nhân viên buồng phòng nhận một nhiệm vụ chưa được phân công. */
    public boolean claimTask(int taskId, int employeeId) throws SQLException {
        if (taskId <= 0 || employeeId <= 0) throw new IllegalArgumentException("Nhiệm vụ hoặc nhân viên không hợp lệ.");
        String sql = "UPDATE nhiem_vu_buong_phong SET nhan_vien_phu_trach_id = ? WHERE id = ? AND trang_thai = 'CHO_XU_LY' AND nhan_vien_phu_trach_id IS NULL";
        try (Connection connection = DatabaseConnection.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, employeeId); statement.setInt(2, taskId); return statement.executeUpdate() == 1;
        }
    }

    /** Bắt đầu nhiệm vụ đã được chính nhân viên nhận. */
    public boolean startTask(int taskId, int employeeId) throws SQLException {
        if (taskId <= 0 || employeeId <= 0) throw new IllegalArgumentException("Nhiệm vụ hoặc nhân viên không hợp lệ.");
        String sql = "UPDATE nhiem_vu_buong_phong SET trang_thai = 'DANG_XU_LY', thoi_gian_bat_dau = CURRENT_TIMESTAMP WHERE id = ? AND nhan_vien_phu_trach_id = ? AND trang_thai = 'CHO_XU_LY'";
        try (Connection connection = DatabaseConnection.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, taskId); statement.setInt(2, employeeId); return statement.executeUpdate() == 1;
        }
    }

    /** Hoàn thành nhiệm vụ không làm thay đổi trạng thái phòng. */
    public boolean completeTask(int taskId, int employeeId) throws SQLException {
        if (taskId <= 0 || employeeId <= 0) throw new IllegalArgumentException("Nhiệm vụ hoặc nhân viên không hợp lệ.");
        String sql = "UPDATE nhiem_vu_buong_phong SET trang_thai = 'HOAN_THANH', thoi_gian_hoan_thanh = CURRENT_TIMESTAMP WHERE id = ? AND nhan_vien_phu_trach_id = ? AND trang_thai = 'DANG_XU_LY'";
        try (Connection connection = DatabaseConnection.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, taskId); statement.setInt(2, employeeId); return statement.executeUpdate() == 1;
        }
    }

    public boolean deleteById(int id) throws SQLException {
        String sql = "DELETE FROM nhiem_vu_buong_phong WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    public Optional<NhiemVuBuongPhong> findById(int id) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM nhiem_vu_buong_phong nv WHERE nv.id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<NhiemVuBuongPhong> findAll() throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM nhiem_vu_buong_phong nv ORDER BY nv.thoi_gian_tao DESC, nv.id DESC";
        return executeList(sql);
    }

    public List<NhiemVuBuongPhong> findByAssignee(int employeeId) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM nhiem_vu_buong_phong nv WHERE nv.nhan_vien_phu_trach_id = ? "
                + "ORDER BY FIELD(nv.trang_thai, 'DANG_XU_LY', 'CHO_XU_LY', 'HOAN_THANH', 'DA_HUY'), nv.thoi_gian_tao DESC";
        List<NhiemVuBuongPhong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, employeeId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public List<NhiemVuBuongPhong> search(String keyword, TrangThaiNhiemVu status) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM nhiem_vu_buong_phong nv "
                + "JOIN phong p ON p.id = nv.phong_id "
                + "LEFT JOIN tai_khoan tk ON tk.id = nv.nhan_vien_phu_trach_id "
                + "WHERE (nv.ma_nhiem_vu LIKE ? OR p.so_phong LIKE ? OR tk.ho_ten LIKE ? OR nv.ghi_chu LIKE ?) "
                + (status == null ? "" : "AND nv.trang_thai = ? ")
                + "ORDER BY nv.thoi_gian_tao DESC, nv.id DESC";
        String searchValue = "%" + (keyword == null ? "" : keyword.trim()) + "%";
        List<NhiemVuBuongPhong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            for (int i = 1; i <= 4; i++) {
                statement.setString(i, searchValue);
            }
            if (status != null) {
                statement.setString(5, status.name());
            }
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    private List<NhiemVuBuongPhong> executeList(String sql) throws SQLException {
        List<NhiemVuBuongPhong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(mapRow(resultSet));
            }
        }
        return result;
    }

    private void bind(PreparedStatement statement, NhiemVuBuongPhong task, boolean includeId) throws SQLException {
        LocalDateTime createdTime = task.getThoiGianTao() == null ? LocalDateTime.now() : task.getThoiGianTao();
        statement.setString(1, task.getMaNhiemVu());
        statement.setInt(2, task.getPhongId());
        statement.setString(3, task.getLoaiNhiemVu().name());
        statement.setString(4, task.getMucDoUuTien().name());
        statement.setString(5, task.getTrangThai().name());
        JdbcDataAccessSupport.setNullableInteger(statement, 6, task.getNguoiTaoId());
        JdbcDataAccessSupport.setNullableInteger(statement, 7, task.getNhanVienPhuTrachId());
        statement.setTimestamp(8, Timestamp.valueOf(createdTime));
        JdbcDataAccessSupport.setNullableLocalDateTime(statement, 9, task.getThoiGianBatDau());
        JdbcDataAccessSupport.setNullableLocalDateTime(statement, 10, task.getThoiGianHoanThanh());
        statement.setString(11, task.getGhiChu());
        if (includeId) {
            statement.setInt(12, task.getId());
        }
    }

    private NhiemVuBuongPhong mapRow(ResultSet resultSet) throws SQLException {
        NhiemVuBuongPhong task = new NhiemVuBuongPhong();
        task.setId(resultSet.getInt("id"));
        task.setMaNhiemVu(resultSet.getString("ma_nhiem_vu"));
        task.setPhongId(resultSet.getInt("phong_id"));
        task.setLoaiNhiemVu(LoaiNhiemVuBuongPhong.valueOf(resultSet.getString("loai_nhiem_vu")));
        task.setMucDoUuTien(MucDoUuTien.valueOf(resultSet.getString("muc_do_uu_tien")));
        task.setTrangThai(TrangThaiNhiemVu.valueOf(resultSet.getString("trang_thai")));
        int creatorId = resultSet.getInt("nguoi_tao_id");
        task.setNguoiTaoId(resultSet.wasNull() ? null : creatorId);
        int assigneeId = resultSet.getInt("nhan_vien_phu_trach_id");
        task.setNhanVienPhuTrachId(resultSet.wasNull() ? null : assigneeId);
        task.setThoiGianTao(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "thoi_gian_tao"));
        task.setThoiGianBatDau(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "thoi_gian_bat_dau"));
        task.setThoiGianHoanThanh(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "thoi_gian_hoan_thanh"));
        task.setGhiChu(resultSet.getString("ghi_chu"));
        return task;
    }
}
