package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.Phong;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiPhong;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PhongDAO {

    private static final String SELECT_COLUMNS =
            "p.id, p.so_phong, p.loai_phong_id, p.tang, p.trang_thai, p.ghi_chu, p.dang_hoat_dong, p.ngay_tao, p.ngay_cap_nhat";

    public int insert(Phong phong) throws SQLException {
        if (phong == null) {
            throw new IllegalArgumentException("Thông tin phòng không được để trống.");
        }

        // Phòng mới luôn bắt đầu ở TRỐNG. Trạng thái không được nhận từ form.
        phong.setTrangThai(TrangThaiPhong.TRONG);

        String sql = "INSERT INTO phong(so_phong, loai_phong_id, tang, trang_thai, ghi_chu, dang_hoat_dong) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, phong, false);
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    phong.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của phòng vừa thêm.");
    }

    public boolean update(Phong phong) throws SQLException {
        if (phong == null || phong.getId() == null || phong.getId() <= 0) {
            throw new IllegalArgumentException("Thông tin phòng không hợp lệ.");
        }

        /*
         * CRUD chỉ được sửa thông tin mô tả/vận hành của phòng.
         * Không cho UPDATE trực tiếp cột trang_thai. Các chuyển trạng thái
         * phải đi qua nghiệp vụ check-in, checkout, đổi phòng hoặc dọn phòng.
         */
        String selectSql = "SELECT trang_thai, dang_hoat_dong FROM phong WHERE id = ? FOR UPDATE";
        String updateSql = "UPDATE phong SET so_phong = ?, loai_phong_id = ?, tang = ?, ghi_chu = ?, dang_hoat_dong = ? WHERE id = ?";

        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            TrangThaiPhong currentStatus;
            boolean currentActive;
            try (PreparedStatement statement = connection.prepareStatement(selectSql)) {
                statement.setInt(1, phong.getId());
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (!resultSet.next()) {
                        throw new SQLException("Không tìm thấy phòng cần cập nhật.");
                    }
                    currentStatus = TrangThaiPhong.valueOf(resultSet.getString("trang_thai"));
                    currentActive = resultSet.getBoolean("dang_hoat_dong");
                }
            }

            if (phong.getTrangThai() != null && phong.getTrangThai() != currentStatus) {
                throw new SQLException(
                        "Không được thay đổi trạng thái phòng bằng chức năng Sửa. "
                                + "Hãy sử dụng đúng nghiệp vụ Check-in, Check-out hoặc Buồng phòng."
                );
            }

            if (!phong.isDangHoatDong()
                    && currentStatus != TrangThaiPhong.TRONG
                    && currentStatus != TrangThaiPhong.BAO_TRI) {
                throw new SQLException(
                        "Không thể ngừng khai thác phòng đang ở trạng thái " + currentStatus + "."
                                + " Hãy hoàn tất nghiệp vụ lưu trú/dọn phòng trước."
                );
            }

            try (PreparedStatement statement = connection.prepareStatement(updateSql)) {
                statement.setString(1, phong.getSoPhong());
                statement.setInt(2, phong.getLoaiPhongId());
                statement.setInt(3, phong.getTang());
                statement.setString(4, phong.getGhiChu());
                statement.setBoolean(5, phong.isDangHoatDong());
                statement.setInt(6, phong.getId());
                boolean updated = statement.executeUpdate() == 1;
                connection.commit();
                phong.setTrangThai(currentStatus);
                return updated;
            }
        } catch (SQLException | RuntimeException exception) {
            rollbackQuietly(connection, exception);
            throw exception;
        } finally {
            closeTransactionalConnection(connection);
        }
    }

    /**
     * Hoàn tất vệ sinh phòng.
     *
     * Đây là chuyển trạng thái nghiệp vụ duy nhất được phép từ thao tác
     * "Xác nhận dọn phòng xong": DANG_DON -> TRONG.
     *
     * Không nhận trạng thái đích từ giao diện để tránh việc một màn hình
     * bất kỳ vô tình chuyển phòng sang trạng thái không hợp lệ.
     */
    public boolean completeCleaning(int roomId) throws SQLException {
        return completeCleaning(roomId, null);
    }

    /**
     * Hoàn tất dọn phòng theo transaction:
     * DANG_DON -> TRONG và nhiệm vụ DON_PHONG đang mở -> HOAN_THANH.
     */
    public boolean completeCleaning(int roomId, Integer employeeId) throws SQLException {
        if (roomId <= 0) {
            throw new IllegalArgumentException("ID phòng không hợp lệ.");
        }

        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            String taskSql;
            if (employeeId == null) {
                taskSql = "UPDATE nhiem_vu_buong_phong "
                        + "SET trang_thai = 'HOAN_THANH', thoi_gian_hoan_thanh = CURRENT_TIMESTAMP "
                        + "WHERE phong_id = ? AND loai_nhiem_vu = 'DON_PHONG' "
                        + "AND trang_thai = 'DANG_XU_LY'";
            } else {
                taskSql = "UPDATE nhiem_vu_buong_phong "
                        + "SET trang_thai = 'HOAN_THANH', thoi_gian_hoan_thanh = CURRENT_TIMESTAMP "
                        + "WHERE phong_id = ? AND loai_nhiem_vu = 'DON_PHONG' "
                        + "AND trang_thai = 'DANG_XU_LY' AND nhan_vien_phu_trach_id = ?";
            }
            try (PreparedStatement statement = connection.prepareStatement(taskSql)) {
                statement.setInt(1, roomId);
                if (employeeId != null) statement.setInt(2, employeeId);
                if (statement.executeUpdate() != 1) {
                    connection.rollback();
                    return false;
                }
            }

            String roomSql = "UPDATE phong SET trang_thai = ? "
                    + "WHERE id = ? AND trang_thai = ? AND dang_hoat_dong = TRUE";
            try (PreparedStatement statement = connection.prepareStatement(roomSql)) {
                statement.setString(1, TrangThaiPhong.TRONG.name());
                statement.setInt(2, roomId);
                statement.setString(3, TrangThaiPhong.DANG_DON.name());
                if (statement.executeUpdate() != 1) {
                    connection.rollback();
                    return false;
                }
            }

            connection.commit();
            return true;
        } catch (SQLException | RuntimeException exception) {
            rollbackQuietly(connection, exception);
            throw exception;
        } finally {
            closeTransactionalConnection(connection);
        }
    }

    public boolean deleteById(int id) throws SQLException {
        String sql = "DELETE FROM phong WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    public Optional<Phong> findById(int id) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM phong p WHERE p.id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public Optional<Phong> findByRoomNumber(String roomNumber) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM phong p WHERE p.so_phong = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, roomNumber);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<Phong> findAll() throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM phong p ORDER BY p.tang, p.so_phong";
        return executeList(sql);
    }

    public List<Phong> findByStatus(TrangThaiPhong status) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM phong p WHERE p.trang_thai = ? ORDER BY p.tang, p.so_phong";
        List<Phong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, status.name());
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public List<Phong> search(String keyword) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM phong p JOIN loai_phong lp ON lp.id = p.loai_phong_id "
                + "WHERE p.so_phong LIKE ? OR CAST(p.tang AS CHAR) LIKE ? OR lp.ma_loai_phong LIKE ? OR lp.ten_loai_phong LIKE ? "
                + "ORDER BY p.tang, p.so_phong";
        String searchValue = "%" + (keyword == null ? "" : keyword.trim()) + "%";
        List<Phong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            for (int i = 1; i <= 4; i++) {
                statement.setString(i, searchValue);
            }
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    /**
     * Tìm phòng không bị trùng lịch trong khoảng [ngày nhận, ngày trả).
     * Không chỉ dựa vào trạng thái hiện tại của phòng, vì trạng thái không đủ để kiểm tra lịch tương lai.
     */
    public List<Phong> findAvailable(LocalDateTime checkIn, LocalDateTime checkOut) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM phong p "
                + "WHERE p.dang_hoat_dong = TRUE AND p.trang_thai <> 'BAO_TRI' "
                + "AND NOT EXISTS ("
                + "  SELECT 1 FROM chi_tiet_dat_phong ct "
                + "  JOIN dat_phong dp ON dp.id = ct.dat_phong_id "
                + "  WHERE ct.phong_id = p.id "
                + "    AND dp.trang_thai IN ('CHO_XAC_NHAN','DA_XAC_NHAN','DA_NHAN_PHONG') "
                + "    AND dp.ngay_du_kien_nhan < ? AND dp.ngay_du_kien_tra > ?"
                + ") ORDER BY p.tang, p.so_phong";
        List<Phong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setTimestamp(1, Timestamp.valueOf(checkOut));
            statement.setTimestamp(2, Timestamp.valueOf(checkIn));
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    private List<Phong> executeList(String sql) throws SQLException {
        List<Phong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(mapRow(resultSet));
            }
        }
        return result;
    }

    private void bind(PreparedStatement statement, Phong phong, boolean includeId) throws SQLException {
        statement.setString(1, phong.getSoPhong());
        statement.setInt(2, phong.getLoaiPhongId());
        statement.setInt(3, phong.getTang());
        statement.setString(4, phong.getTrangThai().name());
        statement.setString(5, phong.getGhiChu());
        statement.setBoolean(6, phong.isDangHoatDong());
        if (includeId) {
            statement.setInt(7, phong.getId());
        }
    }

    private void rollbackQuietly(Connection connection, Exception originalException) {
        if (connection == null) {
            return;
        }
        try {
            connection.rollback();
        } catch (SQLException rollbackException) {
            originalException.addSuppressed(rollbackException);
        }
    }

    private void closeTransactionalConnection(Connection connection) {
        if (connection == null) {
            return;
        }
        try {
            connection.setAutoCommit(true);
        } catch (SQLException ignored) {
        }
        try {
            connection.close();
        } catch (SQLException ignored) {
        }
    }

    private Phong mapRow(ResultSet resultSet) throws SQLException {
        Phong phong = new Phong();
        phong.setId(resultSet.getInt("id"));
        phong.setSoPhong(resultSet.getString("so_phong"));
        phong.setLoaiPhongId(resultSet.getInt("loai_phong_id"));
        phong.setTang(resultSet.getInt("tang"));
        phong.setTrangThai(TrangThaiPhong.valueOf(resultSet.getString("trang_thai")));
        phong.setGhiChu(resultSet.getString("ghi_chu"));
        phong.setDangHoatDong(resultSet.getBoolean("dang_hoat_dong"));
        phong.setNgayTao(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_tao"));
        phong.setNgayCapNhat(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_cap_nhat"));
        return phong;
    }
}
