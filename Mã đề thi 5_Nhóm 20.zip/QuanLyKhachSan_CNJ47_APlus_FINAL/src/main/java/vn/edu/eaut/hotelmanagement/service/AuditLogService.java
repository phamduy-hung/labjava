package vn.edu.eaut.hotelmanagement.service;

import vn.edu.eaut.hotelmanagement.dao.NhatKyHeThongDAO;
import vn.edu.eaut.hotelmanagement.model.NhatKyHeThong;
import vn.edu.eaut.hotelmanagement.session.LoginSession;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Tầng ghi nhật ký nghiệp vụ dùng chung.
 * Nhật ký không được phép làm gián đoạn nghiệp vụ chính nếu CSDL log gặp lỗi.
 */
public final class AuditLogService {

    private static final Logger LOGGER = Logger.getLogger(AuditLogService.class.getName());
    private final NhatKyHeThongDAO nhatKyHeThongDAO;

    public AuditLogService() {
        this(new NhatKyHeThongDAO());
    }

    public AuditLogService(NhatKyHeThongDAO nhatKyHeThongDAO) {
        this.nhatKyHeThongDAO = nhatKyHeThongDAO;
    }

    public void log(LoginSession session, String action, String objectType, String objectId, String content) {
        Integer accountId = session == null || session.getTaiKhoan() == null
                ? null : session.getTaiKhoan().getId();
        log(accountId, action, objectType, objectId, content);
    }

    public void log(Integer accountId, String action, String objectType, String objectId, String content) {
        NhatKyHeThong log = new NhatKyHeThong();
        log.setTaiKhoanId(accountId);
        log.setHanhDong(action);
        log.setDoiTuong(objectType);
        log.setDoiTuongId(objectId);
        log.setNoiDung(content);
        log.setThoiGian(LocalDateTime.now());

        try {
            nhatKyHeThongDAO.insert(log);
        } catch (SQLException exception) {
            LOGGER.log(Level.WARNING, "Không thể ghi nhật ký hệ thống: " + action, exception);
        }
    }
}
