package vn.edu.eaut.hotelmanagement.model;

import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiPhong;

import java.time.LocalDateTime;

public class Phong {
    private Integer id;
    private String soPhong;
    private Integer loaiPhongId;
    private int tang;
    private TrangThaiPhong trangThai;
    private String ghiChu;
    private boolean dangHoatDong;
    private LocalDateTime ngayTao;
    private LocalDateTime ngayCapNhat;

    public Phong() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSoPhong() {
        return soPhong;
    }

    public void setSoPhong(String soPhong) {
        this.soPhong = soPhong;
    }

    public Integer getLoaiPhongId() {
        return loaiPhongId;
    }

    public void setLoaiPhongId(Integer loaiPhongId) {
        this.loaiPhongId = loaiPhongId;
    }

    public int getTang() {
        return tang;
    }

    public void setTang(int tang) {
        this.tang = tang;
    }

    public TrangThaiPhong getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(TrangThaiPhong trangThai) {
        this.trangThai = trangThai;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public boolean isDangHoatDong() {
        return dangHoatDong;
    }

    public void setDangHoatDong(boolean dangHoatDong) {
        this.dangHoatDong = dangHoatDong;
    }

    public LocalDateTime getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(LocalDateTime ngayTao) {
        this.ngayTao = ngayTao;
    }

    public LocalDateTime getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(LocalDateTime ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    }

    @Override
    public String toString() {
        return soPhong;
    }
}
