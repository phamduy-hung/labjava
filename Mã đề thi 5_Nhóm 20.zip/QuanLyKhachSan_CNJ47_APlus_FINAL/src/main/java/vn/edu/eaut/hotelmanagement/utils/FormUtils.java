package vn.edu.eaut.hotelmanagement.utils;


import javax.swing.*;
import java.awt.*;
import java.util.List;



public final class FormUtils {


    private FormUtils(){

    }



    /**
     * Focus vào component đầu tiên
     */
    public static void focusFirst(
            JComponent component){


        SwingUtilities.invokeLater(() -> {

            component.requestFocus();

        });

    }





    /**
     * Xóa toàn bộ JTextField
     */
    public static void clearFields(
            JTextField... fields){


        for(JTextField field: fields){


            field.setText("");

        }


    }





    /**
     * Xóa nhiều component
     */
    public static void clearAll(
            Container container){


        for(Component component :
                container.getComponents()){


            if(component instanceof JTextField){


                ((JTextField)component)
                        .setText("");

            }


            if(component instanceof Container){


                clearAll(
                        (Container)component
                );

            }


        }


    }





    /**
     * Enter chuyển sang ô tiếp theo
     */
    public static void addEnterNavigation(
            JTextField... fields){



        for(int i=0;i<fields.length-1;i++){


            JTextField current =
                    fields[i];


            JTextField next =
                    fields[i+1];



            current.addActionListener(e ->
                    next.requestFocus()
            );


        }


    }





    /**
     * Placeholder đơn giản
     */
    public static void addPlaceholder(
            JTextField field,
            String text){



        field.setForeground(Color.GRAY);


        field.setText(text);



        field.addFocusListener(
                new java.awt.event.FocusAdapter(){


                    @Override
                    public void focusGained(
                            java.awt.event.FocusEvent e){


                        if(field.getText()
                                .equals(text)){


                            field.setText("");

                            field.setForeground(
                                    Color.BLACK
                            );

                        }

                    }



                    @Override
                    public void focusLost(
                            java.awt.event.FocusEvent e){



                        if(field.getText()
                                .isEmpty()){


                            field.setText(text);

                            field.setForeground(
                                    Color.GRAY
                            );


                        }


                    }



                }
        );


    }



}