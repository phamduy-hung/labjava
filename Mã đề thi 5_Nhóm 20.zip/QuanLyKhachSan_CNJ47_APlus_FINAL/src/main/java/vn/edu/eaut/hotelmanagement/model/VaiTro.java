package vn.edu.eaut.hotelmanagement.model;

import java.time.LocalDateTime;

public class VaiTro {
    private Integer id;
    private String maVaiTro;
    private String tenVaiTro;
    private String moTa;
    private boolean dangHoatDong;
    private LocalDateTime ngayTao;

    public VaiTro() {
    }

    public VaiTro(Integer id, String maVaiTro, String tenVaiTro, String moTa,
                  boolean dangHoatDong, LocalDateTime ngayTao) {
        this.id = id;
        this.maVaiTro = maVaiTro;
        this.tenVaiTro = tenVaiTro;
        this.moTa = moTa;
        this.dangHoatDong = dangHoatDong;
        this.ngayTao = ngayTao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMaVaiTro() {
        return maVaiTro;
    }

    public void setMaVaiTro(String maVaiTro) {
        this.maVaiTro = maVaiTro;
    }

    public String getTenVaiTro() {
        return tenVaiTro;
    }

    public void setTenVaiTro(String tenVaiTro) {
        this.tenVaiTro = tenVaiTro;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public boolean isDangHoatDong() {
        return dangHoatDong;
    }

    public void setDangHoatDong(boolean dangHoatDong) {
        this.dangHoatDong = dangHoatDong;
    }

    public LocalDateTime getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(LocalDateTime ngayTao) {
        this.ngayTao = ngayTao;
    }

    @Override
    public String toString() {
        return tenVaiTro;
    }
}
