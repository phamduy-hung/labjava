package vn.edu.eaut.hotelmanagement.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class LoaiPhong {
    private Integer id;
    private String maLoaiPhong;
    private String tenLoaiPhong;
    private int sucChuaTieuChuan;
    private int sucChuaToiDa;
    private BigDecimal giaCoBan;
    private String moTa;
    private boolean dangHoatDong;
    private LocalDateTime ngayTao;
    private LocalDateTime ngayCapNhat;

    public LoaiPhong() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMaLoaiPhong() {
        return maLoaiPhong;
    }

    public void setMaLoaiPhong(String maLoaiPhong) {
        this.maLoaiPhong = maLoaiPhong;
    }

    public String getTenLoaiPhong() {
        return tenLoaiPhong;
    }

    public void setTenLoaiPhong(String tenLoaiPhong) {
        this.tenLoaiPhong = tenLoaiPhong;
    }

    public int getSucChuaTieuChuan() {
        return sucChuaTieuChuan;
    }

    public void setSucChuaTieuChuan(int sucChuaTieuChuan) {
        this.sucChuaTieuChuan = sucChuaTieuChuan;
    }

    public int getSucChuaToiDa() {
        return sucChuaToiDa;
    }

    public void setSucChuaToiDa(int sucChuaToiDa) {
        this.sucChuaToiDa = sucChuaToiDa;
    }

    public BigDecimal getGiaCoBan() {
        return giaCoBan;
    }

    public void setGiaCoBan(BigDecimal giaCoBan) {
        this.giaCoBan = giaCoBan;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public boolean isDangHoatDong() {
        return dangHoatDong;
    }

    public void setDangHoatDong(boolean dangHoatDong) {
        this.dangHoatDong = dangHoatDong;
    }

    public LocalDateTime getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(LocalDateTime ngayTao) {
        this.ngayTao = ngayTao;
    }

    public LocalDateTime getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(LocalDateTime ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    }

    @Override
    public String toString() {
        return maLoaiPhong + " - " + tenLoaiPhong;
    }
}
