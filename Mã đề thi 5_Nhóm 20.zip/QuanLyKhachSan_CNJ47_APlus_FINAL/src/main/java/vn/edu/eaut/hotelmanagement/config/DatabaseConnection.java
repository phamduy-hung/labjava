package vn.edu.eaut.hotelmanagement.config;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Quản lý việc tạo kết nối JDBC tới MySQL.
 *
 * Nguyên tắc:
 * - Không giữ một Connection dùng chung trong toàn ứng dụng.
 * - Mỗi DAO lấy Connection mới bằng getConnection().
 * - DAO phải đóng Connection bằng try-with-resources.
 * - Thông tin kết nối được tách ra file database.properties.
 */
public final class DatabaseConnection {

    private static final Logger LOGGER =
            Logger.getLogger(DatabaseConnection.class.getName());

    private static final String CONFIG_FILE = "/database.properties";

    private static final String JDBC_URL;
    private static final String USERNAME;
    private static final String PASSWORD;
    private static final String DRIVER_CLASS;

    static {
        Properties properties = new Properties();

        try (InputStream inputStream =
                     DatabaseConnection.class.getResourceAsStream(CONFIG_FILE)) {

            if (inputStream == null) {
                throw new IllegalStateException(
                        "Không tìm thấy file cấu hình " + CONFIG_FILE
                );
            }

            properties.load(inputStream);

            JDBC_URL = resolveSetting(properties, "db.url", "HOTEL_DB_URL");
            USERNAME = resolveSetting(properties, "db.username", "HOTEL_DB_USERNAME");
            PASSWORD = resolveSetting(properties, "db.password", "HOTEL_DB_PASSWORD");
            DRIVER_CLASS = resolveSetting(properties, "db.driver", "HOTEL_DB_DRIVER");

            Class.forName(DRIVER_CLASS);

        } catch (IOException exception) {
            throw new ExceptionInInitializerError(
                    "Không thể đọc cấu hình CSDL: " + exception.getMessage()
            );
        } catch (ClassNotFoundException exception) {
            throw new ExceptionInInitializerError(
                    "Không tìm thấy MySQL JDBC Driver: " + exception.getMessage()
            );
        }
    }

    private DatabaseConnection() {
        // Utility class: không cho phép tạo object.
    }

    /**
     * Tạo và trả về một Connection mới.
     *
     * @return Connection đang mở tới hotel_management_db
     * @throws SQLException nếu không thể kết nối CSDL
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
    }

    /**
     * Kiểm tra nhanh kết nối CSDL.
     *
     * @return true nếu kết nối hợp lệ, ngược lại false
     */
    public static boolean testConnection() {
        try (Connection connection = getConnection()) {
            boolean valid = connection != null
                    && !connection.isClosed()
                    && connection.isValid(3);

            if (valid) {
                LOGGER.info("Kết nối MySQL thành công.");
            }

            return valid;

        } catch (SQLException exception) {
            LOGGER.log(
                    Level.SEVERE,
                    "Kết nối MySQL thất bại: " + exception.getMessage(),
                    exception
            );
            return false;
        }
    }


    private static String resolveSetting(Properties properties, String key, String environmentVariable) {
        String systemValue = System.getProperty(key);
        if (systemValue != null && !systemValue.isBlank()) {
            return systemValue.trim();
        }

        String environmentValue = System.getenv(environmentVariable);
        if (environmentValue != null && !environmentValue.isBlank()) {
            return environmentValue.trim();
        }

        return requireProperty(properties, key);
    }

    private static String requireProperty(
            Properties properties,
            String key
    ) {
        String value = properties.getProperty(key);

        if (value == null || value.isBlank()) {
            throw new IllegalStateException(
                    "Thiếu cấu hình bắt buộc: " + key
            );
        }

        return value.trim();
    }
}
