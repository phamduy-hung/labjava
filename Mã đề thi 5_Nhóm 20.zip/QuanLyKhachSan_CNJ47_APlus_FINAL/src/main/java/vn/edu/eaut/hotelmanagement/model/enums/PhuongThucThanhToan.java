package vn.edu.eaut.hotelmanagement.model.enums;

public enum PhuongThucThanhToan {
    TIEN_MAT("Tiền mặt"),
    THE("Thẻ"),
    CHUYEN_KHOAN("Chuyển khoản"),
    VI_DIEN_TU("Ví điện tử");

    private final String hienThi;

    PhuongThucThanhToan(String hienThi) {
        this.hienThi = hienThi;
    }

    @Override
    public String toString() {
        return hienThi;
    }
}
