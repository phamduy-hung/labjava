package vn.edu.eaut.hotelmanagement.model.enums;

public enum MucDoUuTien {
    THAP("Thấp"),
    BINH_THUONG("Bình thường"),
    CAO("Cao");

    private final String hienThi;

    MucDoUuTien(String hienThi) {
        this.hienThi = hienThi;
    }

    @Override
    public String toString() {
        return hienThi;
    }
}
