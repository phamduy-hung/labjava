package vn.edu.eaut.hotelmanagement.utils;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

/**
 * Tiện ích dùng chung cho JTable.
 *
 * Mục tiêu:
 * - Header có độ tương phản cao, chữ trắng dễ đọc.
 * - Chiều cao hàng và header đồng nhất.
 * - Không để Look & Feel của Swing tự đổi màu header.
 * - Hỗ trợ căn trái / giữa / phải.
 * - Hỗ trợ tô màu trạng thái phòng.
 */
public final class TableUtils {

    private static final int MIN_COLUMN_WIDTH = 70;
    private static final int MAX_COLUMN_WIDTH = 300;
    private static final int COLUMN_PADDING = 18;

    private static final Color HEADER_BACKGROUND =
            new Color(31, 73, 125);

    private static final Color HEADER_FOREGROUND =
            Color.WHITE;

    private static final Color HEADER_BORDER =
            new Color(185, 199, 216);

    private static final Font HEADER_FONT =
            new Font(
                    UITheme.FONT_NAME,
                    Font.BOLD,
                    13
            );

    private TableUtils() {
        // Không cho phép tạo đối tượng.
    }

    /**
     * Thiết lập giao diện và hành vi chung cho bảng.
     */
    public static void setupTable(JTable table) {

        if (table == null) {
            return;
        }

        table.setRowHeight(30);

        table.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        table.setFillsViewportHeight(true);

        table.setAutoCreateRowSorter(true);

        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);

        table.setGridColor(
                UITheme.BORDER
        );

        table.setSelectionBackground(
                new Color(210, 228, 250)
        );

        table.setSelectionForeground(
                UITheme.TEXT_PRIMARY
        );

        /*
         * Quan trọng:
         * Không chỉ set màu trực tiếp trên JTableHeader,
         * vì một số Look & Feel có thể ghi đè.
         * Dùng renderer riêng để header luôn rõ chữ.
         */
        JTableHeader header = table.getTableHeader();

        header.setFont(HEADER_FONT);
        header.setReorderingAllowed(false);
        header.setOpaque(true);
        header.setBackground(HEADER_BACKGROUND);
        header.setForeground(HEADER_FOREGROUND);
        header.setBorder(
                javax.swing.BorderFactory.createMatteBorder(
                        0, 0, 1, 1, HEADER_BORDER
                )
        );
        header.setDefaultRenderer(
                new HeaderRenderer()
        );

        // Header cao hơn để tiếng Việt không bị sát mép.
        header.setPreferredSize(
                new java.awt.Dimension(
                        header.getPreferredSize().width,
                        38
                )
        );

        autoResizeColumns(table);
    }

    /**
     * Căn giữa một cột.
     */
    public static void centerColumn(
            JTable table,
            int columnIndex) {

        if (!isValidColumn(
                table,
                columnIndex)) {

            return;
        }

        DefaultTableCellRenderer renderer =
                new DefaultTableCellRenderer();

        renderer.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        table.getColumnModel()
                .getColumn(columnIndex)
                .setCellRenderer(renderer);
    }

    /**
     * Căn phải một cột.
     */
    public static void rightAlignColumn(
            JTable table,
            int columnIndex) {

        if (!isValidColumn(
                table,
                columnIndex)) {

            return;
        }

        DefaultTableCellRenderer renderer =
                new DefaultTableCellRenderer();

        renderer.setHorizontalAlignment(
                SwingConstants.RIGHT
        );

        table.getColumnModel()
                .getColumn(columnIndex)
                .setCellRenderer(renderer);
    }

    /**
     * Căn trái một cột.
     */
    public static void leftAlignColumn(
            JTable table,
            int columnIndex) {

        if (!isValidColumn(
                table,
                columnIndex)) {

            return;
        }

        DefaultTableCellRenderer renderer =
                new DefaultTableCellRenderer();

        renderer.setHorizontalAlignment(
                SwingConstants.LEFT
        );

        table.getColumnModel()
                .getColumn(columnIndex)
                .setCellRenderer(renderer);
    }

    /**
     * Tự tính chiều rộng cột nhưng vẫn giới hạn
     * để một bảng không chiếm quá nhiều chiều ngang.
     */
    public static void autoResizeColumns(
            JTable table) {

        if (table == null) {
            return;
        }

        for (int columnIndex = 0;
             columnIndex < table.getColumnCount();
             columnIndex++) {

            TableColumn column =
                    table.getColumnModel()
                            .getColumn(columnIndex);

            int preferredWidth =
                    calculatePreferredColumnWidth(
                            table,
                            columnIndex
                    );

            preferredWidth =
                    Math.max(
                            MIN_COLUMN_WIDTH,
                            preferredWidth
                    );

            preferredWidth =
                    Math.min(
                            MAX_COLUMN_WIDTH,
                            preferredWidth
                    );

            column.setPreferredWidth(
                    preferredWidth
            );
        }
    }

    private static int calculatePreferredColumnWidth(
            JTable table,
            int columnIndex) {

        int width = MIN_COLUMN_WIDTH;

        TableCellRenderer headerRenderer =
                table.getTableHeader()
                        .getDefaultRenderer();

        Component headerComponent =
                headerRenderer
                        .getTableCellRendererComponent(
                                table,
                                table.getColumnName(
                                        columnIndex
                                ),
                                false,
                                false,
                                -1,
                                columnIndex
                        );

        width = Math.max(
                width,
                headerComponent
                        .getPreferredSize()
                        .width
                        + COLUMN_PADDING
        );

        int rowLimit =
                Math.min(
                        table.getRowCount(),
                        100
                );

        for (int rowIndex = 0;
             rowIndex < rowLimit;
             rowIndex++) {

            TableCellRenderer cellRenderer =
                    table.getCellRenderer(
                            rowIndex,
                            columnIndex
                    );

            Component cellComponent =
                    table.prepareRenderer(
                            cellRenderer,
                            rowIndex,
                            columnIndex
                    );

            width = Math.max(
                    width,
                    cellComponent
                            .getPreferredSize()
                            .width
                            + COLUMN_PADDING
            );
        }

        return width;
    }

    /**
     * Tô màu riêng cho cột trạng thái phòng.
     */
    public static void applyRoomStatusColor(
            JTable table,
            int statusColumnIndex) {

        if (table == null) {
            return;
        }

        if (!isValidColumn(
                table,
                statusColumnIndex)) {

            return;
        }

        table.setDefaultRenderer(
                Object.class,
                new RoomStatusRenderer(
                        statusColumnIndex
                )
        );
    }

    /**
     * Renderer header dùng chung cho toàn hệ thống.
     */
    private static final class HeaderRenderer
            extends DefaultTableCellRenderer {

        private HeaderRenderer() {
            setOpaque(true);
            setHorizontalAlignment(
                    SwingConstants.LEFT
            );
            setVerticalAlignment(
                    SwingConstants.CENTER
            );
            setBackground(HEADER_BACKGROUND);
            setForeground(HEADER_FOREGROUND);
            setFont(HEADER_FONT);
            setBorder(
                    javax.swing.BorderFactory.createMatteBorder(
                            0,
                            0,
                            1,
                            1,
                            HEADER_BORDER
                    )
            );
        }

        @Override
        public Component getTableCellRendererComponent(
                JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row,
                int column) {

            super.getTableCellRendererComponent(
                    table,
                    value,
                    isSelected,
                    hasFocus,
                    row,
                    column
            );

            setOpaque(true);
            setBackground(HEADER_BACKGROUND);
            setForeground(HEADER_FOREGROUND);
            setFont(HEADER_FONT);
            setHorizontalAlignment(SwingConstants.LEFT);
            setVerticalAlignment(SwingConstants.CENTER);
            setBorder(
                    javax.swing.BorderFactory.createMatteBorder(
                            0, 0, 1, 1, HEADER_BORDER
                    )
            );

            return this;
        }
    }

    /**
     * Renderer màu trạng thái phòng.
     */
    private static final class RoomStatusRenderer
            extends DefaultTableCellRenderer {

        private final int statusColumnIndex;

        private RoomStatusRenderer(
                int statusColumnIndex) {

            this.statusColumnIndex =
                    statusColumnIndex;

            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(
                JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row,
                int column) {

            Component component =
                    super.getTableCellRendererComponent(
                            table,
                            value,
                            isSelected,
                            hasFocus,
                            row,
                            column
                    );

            if (isSelected) {

                component.setBackground(
                        table.getSelectionBackground()
                );

                component.setForeground(
                        table.getSelectionForeground()
                );

                return component;
            }

            int modelRow =
                    table.convertRowIndexToModel(
                            row
                    );

            int modelStatusColumn =
                    table.convertColumnIndexToModel(
                            statusColumnIndex
                    );

            Object statusValue =
                    table.getModel()
                            .getValueAt(
                                    modelRow,
                                    modelStatusColumn
                            );

            String status =
                    statusValue == null
                            ? ""
                            : statusValue
                                    .toString()
                                    .trim();

            applyStatusStyle(
                    component,
                    status
            );

            return component;
        }

        private void applyStatusStyle(
                Component component,
                String status) {

            switch (status) {

                case "Trống" -> {
                    component.setBackground(
                            UITheme.ROOM_EMPTY
                    );

                    component.setForeground(
                            UITheme.ROOM_EMPTY_TEXT
                    );
                }

                case "Có khách" -> {
                    component.setBackground(
                            UITheme.ROOM_OCCUPIED
                    );

                    component.setForeground(
                            UITheme.ROOM_OCCUPIED_TEXT
                    );
                }

                case "Đang dọn dẹp",
                     "Đang dọn" -> {

                    component.setBackground(
                            UITheme.ROOM_CLEANING
                    );

                    component.setForeground(
                            UITheme.ROOM_CLEANING_TEXT
                    );
                }

                case "Đã đặt" -> {
                    component.setBackground(
                            UITheme.ROOM_BOOKED
                    );

                    component.setForeground(
                            UITheme.ROOM_BOOKED_TEXT
                    );
                }

                case "Bảo trì" -> {
                    component.setBackground(
                            UITheme.ROOM_MAINTENANCE
                    );

                    component.setForeground(
                            UITheme.ROOM_MAINTENANCE_TEXT
                    );
                }

                default -> {
                    component.setBackground(
                            Color.WHITE
                    );

                    component.setForeground(
                            UITheme.TEXT_PRIMARY
                    );
                }
            }
        }
    }

    private static boolean isValidColumn(
            JTable table,
            int columnIndex) {

        return table != null
                && columnIndex >= 0
                && columnIndex
                < table.getColumnCount();
    }
}
