package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.NhatKyHeThong;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * DAO nhật ký hệ thống.
 *
 * Nguyên tắc:
 * - Nhật ký chỉ thêm và đọc, không cập nhật/xóa.
 * - Danh sách hiển thị theo phân trang để không tải toàn bộ lịch sử vào bộ nhớ.
 * - Tìm kiếm/lọc được thực hiện tại CSDL bằng PreparedStatement.
 */
public class NhatKyHeThongDAO {

    private static final String SELECT_COLUMNS =
            "nk.id, nk.tai_khoan_id, tk.ten_dang_nhap, "
                    + "nk.hanh_dong, nk.doi_tuong, nk.doi_tuong_id, "
                    + "nk.noi_dung, nk.thoi_gian";

    public long insert(NhatKyHeThong log) throws SQLException {
        String sql =
                "INSERT INTO nhat_ky_he_thong "
                        + "(tai_khoan_id, hanh_dong, doi_tuong, doi_tuong_id, noi_dung, thoi_gian) "
                        + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     sql,
                     Statement.RETURN_GENERATED_KEYS)) {

            JdbcDataAccessSupport.setNullableInteger(
                    statement,
                    1,
                    log.getTaiKhoanId()
            );
            statement.setString(2, log.getHanhDong());
            statement.setString(3, log.getDoiTuong());
            statement.setString(4, log.getDoiTuongId());
            statement.setString(5, log.getNoiDung());

            LocalDateTime time =
                    log.getThoiGian() == null
                            ? LocalDateTime.now()
                            : log.getThoiGian();

            statement.setTimestamp(
                    6,
                    Timestamp.valueOf(time)
            );

            statement.executeUpdate();

            try (ResultSet generatedKeys =
                         statement.getGeneratedKeys()) {

                if (generatedKeys.next()) {
                    long id = generatedKeys.getLong(1);
                    log.setId(id);
                    return id;
                }
            }
        }

        throw new SQLException(
                "Không lấy được khóa chính của nhật ký vừa thêm."
        );
    }

    public Optional<NhatKyHeThong> findById(long id)
            throws SQLException {

        String sql =
                "SELECT id, tai_khoan_id, hanh_dong, doi_tuong, "
                        + "doi_tuong_id, noi_dung, thoi_gian "
                        + "FROM nhat_ky_he_thong "
                        + "WHERE id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setLong(1, id);

            try (ResultSet resultSet =
                         statement.executeQuery()) {

                return resultSet.next()
                        ? Optional.of(mapRowWithoutAccount(resultSet))
                        : Optional.empty();
            }
        }
    }

    public List<NhatKyHeThong> findAll() throws SQLException {
        String sql =
                "SELECT id, tai_khoan_id, hanh_dong, doi_tuong, "
                        + "doi_tuong_id, noi_dung, thoi_gian "
                        + "FROM nhat_ky_he_thong "
                        + "ORDER BY thoi_gian DESC, id DESC";

        return executeList(sql);
    }

    public List<NhatKyHeThong> findByAccountId(int accountId)
            throws SQLException {

        String sql =
                "SELECT id, tai_khoan_id, hanh_dong, doi_tuong, "
                        + "doi_tuong_id, noi_dung, thoi_gian "
                        + "FROM nhat_ky_he_thong "
                        + "WHERE tai_khoan_id = ? "
                        + "ORDER BY thoi_gian DESC, id DESC";

        List<NhatKyHeThong> result = new ArrayList<>();

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, accountId);

            try (ResultSet resultSet =
                         statement.executeQuery()) {

                while (resultSet.next()) {
                    result.add(mapRowWithoutAccount(resultSet));
                }
            }
        }

        return result;
    }

    public List<NhatKyHeThong> search(String keyword)
            throws SQLException {

        String sql =
                "SELECT id, tai_khoan_id, hanh_dong, doi_tuong, "
                        + "doi_tuong_id, noi_dung, thoi_gian "
                        + "FROM nhat_ky_he_thong "
                        + "WHERE hanh_dong LIKE ? "
                        + "OR doi_tuong LIKE ? "
                        + "OR doi_tuong_id LIKE ? "
                        + "OR noi_dung LIKE ? "
                        + "ORDER BY thoi_gian DESC, id DESC";

        String searchValue =
                "%" + (keyword == null ? "" : keyword.trim()) + "%";

        List<NhatKyHeThong> result = new ArrayList<>();

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            for (int i = 1; i <= 4; i++) {
                statement.setString(i, searchValue);
            }

            try (ResultSet resultSet =
                         statement.executeQuery()) {

                while (resultSet.next()) {
                    result.add(mapRowWithoutAccount(resultSet));
                }
            }
        }

        return result;
    }

    /**
     * Tải một trang nhật ký.
     *
     * @param keyword từ khóa tìm trong tài khoản, hành động,
     *                đối tượng, mã đối tượng và nội dung
     * @param action mã hành động, null = tất cả
     * @param accountId mã tài khoản, null = tất cả
     * @param page trang bắt đầu từ 1
     * @param pageSize số bản ghi mỗi trang
     */
    public PageResult findPage(
            String keyword,
            String action,
            Integer accountId,
            int page,
            int pageSize) throws SQLException {

        int safePage = Math.max(1, page);
        int safePageSize =
                Math.min(100, Math.max(5, pageSize));

        FilterSql filter = buildFilter(
                keyword,
                action,
                accountId
        );

        String countSql =
                "SELECT COUNT(*) "
                        + "FROM nhat_ky_he_thong nk "
                        + "LEFT JOIN tai_khoan tk "
                        + "ON tk.id = nk.tai_khoan_id "
                        + filter.whereClause();

        String dataSql =
                "SELECT " + SELECT_COLUMNS + " "
                        + "FROM nhat_ky_he_thong nk "
                        + "LEFT JOIN tai_khoan tk "
                        + "ON tk.id = nk.tai_khoan_id "
                        + filter.whereClause()
                        + " ORDER BY nk.thoi_gian DESC, nk.id DESC "
                        + "LIMIT ? OFFSET ?";

        try (Connection connection =
                     DatabaseConnection.getConnection()) {

            long totalRecords;

            try (PreparedStatement countStatement =
                         connection.prepareStatement(countSql)) {

                filter.bind(countStatement);

                try (ResultSet resultSet =
                             countStatement.executeQuery()) {

                    resultSet.next();
                    totalRecords = resultSet.getLong(1);
                }
            }

            int offset =
                    (safePage - 1) * safePageSize;

            List<NhatKyHeThongRow> rows =
                    new ArrayList<>();

            try (PreparedStatement dataStatement =
                         connection.prepareStatement(dataSql)) {

                filter.bind(dataStatement);

                int parameterIndex =
                        filter.parameterCount() + 1;

                dataStatement.setInt(
                        parameterIndex,
                        safePageSize
                );

                dataStatement.setInt(
                        parameterIndex + 1,
                        offset
                );

                try (ResultSet resultSet =
                             dataStatement.executeQuery()) {

                    while (resultSet.next()) {
                        rows.add(mapJoinedRow(resultSet));
                    }
                }
            }

            int totalPages =
                    (int) Math.max(
                            1,
                            Math.ceil(
                                    totalRecords
                                            / (double) safePageSize
                            )
                    );

            int actualPage =
                    Math.min(safePage, totalPages);

            return new PageResult(
                    rows,
                    totalRecords,
                    totalPages,
                    actualPage,
                    safePageSize
            );
        }
    }

    /**
     * Lấy danh sách tài khoản để đưa vào bộ lọc.
     */
    public List<AccountOption> findAccountOptions()
            throws SQLException {

        String sql =
                "SELECT id, ten_dang_nhap, ho_ten "
                        + "FROM tai_khoan "
                        + "WHERE dang_hoat_dong = TRUE "
                        + "ORDER BY ho_ten, ten_dang_nhap";

        List<AccountOption> result =
                new ArrayList<>();

        try (Connection connection =
                     DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql);
             ResultSet resultSet =
                     statement.executeQuery()) {

            while (resultSet.next()) {
                result.add(
                        new AccountOption(
                                resultSet.getInt("id"),
                                resultSet.getString("ten_dang_nhap"),
                                resultSet.getString("ho_ten")
                        )
                );
            }
        }

        return result;
    }

    private FilterSql buildFilter(
            String keyword,
            String action,
            Integer accountId) {

        StringBuilder where =
                new StringBuilder(" WHERE 1 = 1 ");

        List<Object> parameters =
                new ArrayList<>();

        String normalizedKeyword =
                keyword == null
                        ? ""
                        : keyword.trim();

        if (!normalizedKeyword.isBlank()) {

            String value =
                    "%" + normalizedKeyword + "%";

            where.append(
                    " AND ("
                            + "tk.ten_dang_nhap LIKE ? "
                            + "OR tk.ho_ten LIKE ? "
                            + "OR nk.hanh_dong LIKE ? "
                            + "OR nk.doi_tuong LIKE ? "
                            + "OR nk.doi_tuong_id LIKE ? "
                            + "OR nk.noi_dung LIKE ?"
                            + ")"
            );

            for (int i = 0; i < 6; i++) {
                parameters.add(value);
            }
        }

        if (action != null
                && !action.isBlank()) {

            where.append(
                    " AND nk.hanh_dong = ?"
            );

            parameters.add(action);
        }

        if (accountId != null) {

            where.append(
                    " AND nk.tai_khoan_id = ?"
            );

            parameters.add(accountId);
        }

        return new FilterSql(
                where.toString(),
                parameters
        );
    }

    private List<NhatKyHeThong> executeList(
            String sql) throws SQLException {

        List<NhatKyHeThong> result =
                new ArrayList<>();

        try (Connection connection =
                     DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql);
             ResultSet resultSet =
                     statement.executeQuery()) {

            while (resultSet.next()) {
                result.add(
                        mapRowWithoutAccount(resultSet)
                );
            }
        }

        return result;
    }

    private NhatKyHeThong mapRowWithoutAccount(
            ResultSet resultSet) throws SQLException {

        NhatKyHeThong log =
                new NhatKyHeThong();

        log.setId(
                resultSet.getLong("id")
        );

        int accountId =
                resultSet.getInt("tai_khoan_id");

        log.setTaiKhoanId(
                resultSet.wasNull()
                        ? null
                        : accountId
        );

        log.setHanhDong(
                resultSet.getString("hanh_dong")
        );

        log.setDoiTuong(
                resultSet.getString("doi_tuong")
        );

        log.setDoiTuongId(
                resultSet.getString("doi_tuong_id")
        );

        log.setNoiDung(
                resultSet.getString("noi_dung")
        );

        log.setThoiGian(
                JdbcDataAccessSupport.getNullableLocalDateTime(
                        resultSet,
                        "thoi_gian"
                )
        );

        return log;
    }

    private NhatKyHeThongRow mapJoinedRow(
            ResultSet resultSet) throws SQLException {

        NhatKyHeThong log =
                new NhatKyHeThong();

        log.setId(
                resultSet.getLong("id")
        );

        int accountId =
                resultSet.getInt("tai_khoan_id");

        log.setTaiKhoanId(
                resultSet.wasNull()
                        ? null
                        : accountId
        );

        log.setHanhDong(
                resultSet.getString("hanh_dong")
        );

        log.setDoiTuong(
                resultSet.getString("doi_tuong")
        );

        log.setDoiTuongId(
                resultSet.getString("doi_tuong_id")
        );

        log.setNoiDung(
                resultSet.getString("noi_dung")
        );

        log.setThoiGian(
                JdbcDataAccessSupport.getNullableLocalDateTime(
                        resultSet,
                        "thoi_gian"
                )
        );

        return new NhatKyHeThongRow(
                log,
                resultSet.getString("ten_dang_nhap")
        );
    }

    public static final class PageResult {

        private final List<NhatKyHeThongRow> rows;
        private final long totalRecords;
        private final int totalPages;
        private final int page;
        private final int pageSize;

        public PageResult(
                List<NhatKyHeThongRow> rows,
                long totalRecords,
                int totalPages,
                int page,
                int pageSize) {

            this.rows = rows;
            this.totalRecords = totalRecords;
            this.totalPages = totalPages;
            this.page = page;
            this.pageSize = pageSize;
        }

        public List<NhatKyHeThongRow> getRows() {
            return rows;
        }

        public long getTotalRecords() {
            return totalRecords;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public int getPage() {
            return page;
        }

        public int getPageSize() {
            return pageSize;
        }
    }

    public static final class NhatKyHeThongRow {

        private final NhatKyHeThong log;
        private final String tenDangNhap;

        public NhatKyHeThongRow(
                NhatKyHeThong log,
                String tenDangNhap) {

            this.log = log;
            this.tenDangNhap = tenDangNhap;
        }

        public NhatKyHeThong getLog() {
            return log;
        }

        public String getTenDangNhap() {
            return tenDangNhap;
        }
    }

    public static final class AccountOption {

        private final Integer id;
        private final String tenDangNhap;
        private final String hoTen;

        public AccountOption(
                Integer id,
                String tenDangNhap,
                String hoTen) {

            this.id = id;
            this.tenDangNhap = tenDangNhap;
            this.hoTen = hoTen;
        }

        public Integer getId() {
            return id;
        }

        public String getTenDangNhap() {
            return tenDangNhap;
        }

        public String getHoTen() {
            return hoTen;
        }

        @Override
        public String toString() {
            return tenDangNhap
                    + " - "
                    + hoTen;
        }
    }

    private static final class FilterSql {

        private final String whereClause;
        private final List<Object> parameters;

        private FilterSql(
                String whereClause,
                List<Object> parameters) {

            this.whereClause = whereClause;
            this.parameters = parameters;
        }

        private void bind(
                PreparedStatement statement)
                throws SQLException {

            for (int i = 0;
                 i < parameters.size();
                 i++) {

                Object parameter =
                        parameters.get(i);

                if (parameter instanceof Integer) {
                    statement.setInt(
                            i + 1,
                            (Integer) parameter
                    );
                } else {
                    statement.setString(
                            i + 1,
                            String.valueOf(parameter)
                    );
                }
            }
        }

        private String whereClause() {
            return whereClause;
        }

        private int parameterCount() {
            return parameters.size();
        }
    }
}
