package vn.edu.eaut.hotelmanagement.session;

import vn.edu.eaut.hotelmanagement.model.TaiKhoan;
import vn.edu.eaut.hotelmanagement.model.VaiTro;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Thông tin phiên làm việc sau khi đăng nhập thành công.
 * Lớp này không chứa mật khẩu hoặc mật khẩu băm.
 */
public final class LoginSession {

    private final TaiKhoan taiKhoan;
    private final VaiTro vaiTro;
    private final LocalDateTime thoiGianDangNhap;

    public LoginSession(TaiKhoan taiKhoan, VaiTro vaiTro, LocalDateTime thoiGianDangNhap) {
        this.taiKhoan = Objects.requireNonNull(taiKhoan, "taiKhoan");
        this.vaiTro = Objects.requireNonNull(vaiTro, "vaiTro");
        this.thoiGianDangNhap = Objects.requireNonNull(thoiGianDangNhap, "thoiGianDangNhap");
    }

    public TaiKhoan getTaiKhoan() {
        return taiKhoan;
    }

    public VaiTro getVaiTro() {
        return vaiTro;
    }

    public LocalDateTime getThoiGianDangNhap() {
        return thoiGianDangNhap;
    }

    public boolean hasRole(String maVaiTro) {
        return maVaiTro != null && maVaiTro.equalsIgnoreCase(vaiTro.getMaVaiTro());
    }
}
