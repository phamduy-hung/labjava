package vn.edu.eaut.hotelmanagement.utils;

import javax.swing.JButton;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Insets;

/**
 * Tiện ích dùng chung để tạo và định dạng các nút
 * trong hệ thống quản lý khách sạn.
 *
 * Mục tiêu:
 * - Giao diện nút đồng nhất.
 * - Loại bỏ kiểu JButton 3D mặc định của Swing.
 * - Không xuất hiện viền/focus mặc định.
 * - Giữ đúng màu riêng của từng loại nút.
 * - Khi disable/enable không làm mất màu gốc.
 * - Tương thích với các View hiện tại.
 */
public final class ButtonUtils {

    // =========================================================
    // MÀU CHUNG
    // =========================================================

    private static final Color PRIMARY =
            new Color(37, 111, 190);

    private static final Color SUCCESS =
            new Color(39, 174, 96);

    private static final Color DANGER =
            new Color(220, 75, 75);

    private static final Color WARNING =
            new Color(230, 151, 45);

    private static final Color NEUTRAL =
            new Color(239, 243, 248);

    private static final Color TEXT_DARK =
            new Color(38, 50, 65);

    private static final Color DISABLED_FOREGROUND =
            new Color(175, 181, 188);

    private static final Color DISABLED_BACKGROUND =
            new Color(225, 230, 236);

    private ButtonUtils() {
        // Không cho phép tạo đối tượng.
    }

    // =========================================================
    // STYLE CƠ BẢN
    // =========================================================

    public static void primary(JButton button) {
        style(
                button,
                PRIMARY,
                Color.WHITE
        );
    }

    public static void success(JButton button) {
        style(
                button,
                SUCCESS,
                Color.WHITE
        );
    }

    public static void danger(JButton button) {
        style(
                button,
                DANGER,
                Color.WHITE
        );
    }

    public static void warning(JButton button) {
        style(
                button,
                WARNING,
                Color.WHITE
        );
    }

    public static void neutral(JButton button) {
        style(
                button,
                NEUTRAL,
                TEXT_DARK
        );
    }

    // =========================================================
    // TẠO NÚT
    // =========================================================

    /**
     * Tạo nút chức năng chính.
     */
    public static JButton createPrimaryButton(String text) {
        JButton button = new JButton(text);
        primary(button);
        return button;
    }

    /**
     * Tạo nút Đăng xuất.
     */
    public static JButton createLogoutButton() {
        JButton button = new JButton("Đăng xuất");
        danger(button);
        return button;
    }

    /**
     * Tạo nút Thoát.
     */
    public static JButton createExitButton() {
        JButton button = new JButton("Thoát");
        neutral(button);
        return button;
    }

    /**
     * Tạo nút quay lại Tổng quan.
     */
    public static JButton createBackButton() {
        JButton button = new JButton("← Tổng quan");
        neutral(button);
        return button;
    }

    /**
     * Tạo nút phụ.
     */
    public static JButton createSecondaryButton(String text) {
        JButton button = new JButton(text);
        neutral(button);
        return button;
    }

    /**
     * Tạo nút nguy hiểm.
     */
    public static JButton createDangerButton(String text) {
        JButton button = new JButton(text);
        danger(button);
        return button;
    }

    /**
     * Tạo nút thành công.
     */
    public static JButton createSuccessButton(String text) {
        JButton button = new JButton(text);
        success(button);
        return button;
    }

    /**
     * Tạo nút cảnh báo.
     */
    public static JButton createWarningButton(String text) {
        JButton button = new JButton(text);
        warning(button);
        return button;
    }

    // =========================================================
    // STYLE TRUNG TÂM
    // =========================================================

    private static void style(
            JButton button,
            Color background,
            Color foreground) {

        if (button == null) {
            return;
        }

        /*
         * Dùng BasicButtonUI để tránh kiểu JButton
         * 3D mặc định của Look & Feel.
         */
        button.setUI(new BasicButtonUI());

        // -----------------------------------------------------
        // MÀU GỐC
        // -----------------------------------------------------

        button.setBackground(background);
        button.setForeground(foreground);

        /*
         * Lưu màu gốc của từng nút.
         * Khi enable lại sẽ phục hồi đúng màu.
         */
        button.putClientProperty(
                "originalBackground",
                background
        );

        button.putClientProperty(
                "originalForeground",
                foreground
        );

        // -----------------------------------------------------
        // FONT
        // -----------------------------------------------------

        button.setFont(
                new Font(
                        Font.SANS_SERIF,
                        Font.BOLD,
                        12
                )
        );

        // -----------------------------------------------------
        // LOẠI BỎ STYLE MẶC ĐỊNH
        // -----------------------------------------------------

        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(true);
        button.setOpaque(true);
        button.setRolloverEnabled(false);
        button.setFocusable(false);

        // -----------------------------------------------------
        // KHÔNG HIỂN THỊ VIỀN
        // -----------------------------------------------------

        /*
         * EmptyBorder chỉ tạo khoảng cách bên trong,
         * không tạo đường viền nhìn thấy.
         */
        button.setBorder(
                new EmptyBorder(
                        9,
                        15,
                        9,
                        15
                )
        );

        // -----------------------------------------------------
        // MARGIN
        // -----------------------------------------------------

        button.setMargin(
                new Insets(
                        0,
                        0,
                        0,
                        0
                )
        );

        // -----------------------------------------------------
        // CON TRỎ
        // -----------------------------------------------------

        button.setCursor(
                Cursor.getPredefinedCursor(
                        Cursor.HAND_CURSOR
                )
        );
    }

    // =========================================================
    // ENABLE / DISABLE
    // =========================================================

    /**
     * Bật/tắt nút nhưng không làm mất màu gốc.
     *
     * Khi disabled:
     * - Giữ màu nền chức năng.
     * - Làm chữ nhạt đi.
     *
     * Khi enabled:
     * - Khôi phục chính xác màu ban đầu.
     */
    public static void applyEnabledState(
            JButton button,
            boolean enabled) {

        if (button == null) {
            return;
        }

        if (enabled) {

            button.setEnabled(true);

            Object originalBackground =
                    button.getClientProperty(
                            "originalBackground"
                    );

            Object originalForeground =
                    button.getClientProperty(
                            "originalForeground"
                    );

            if (originalBackground instanceof Color) {
                button.setBackground(
                        (Color) originalBackground
                );
            }

            if (originalForeground instanceof Color) {
                button.setForeground(
                        (Color) originalForeground
                );
            }

        } else {

            button.setEnabled(false);

            /*
             * Giữ nguyên màu nền gốc.
             */
            Object originalBackground =
                    button.getClientProperty(
                            "originalBackground"
                    );

            if (originalBackground instanceof Color) {

                button.setBackground(
                        (Color) originalBackground
                );

            } else {

                button.setBackground(
                        DISABLED_BACKGROUND
                );
            }

            /*
             * Chỉ làm chữ nhạt hơn.
             */
            button.setForeground(
                    DISABLED_FOREGROUND
            );
        }

        /*
         * Luôn đảm bảo nút không xuất hiện
         * viền/focus mặc định.
         */
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setContentAreaFilled(true);
        button.setOpaque(true);
    }

    /**
     * Hàm tương thích với các View cũ.
     */
    public static void setEnabled(
            JButton button,
            boolean enabled) {

        applyEnabledState(
                button,
                enabled
        );
    }

    // =========================================================
    // GHI NHỚ MÀU
    // =========================================================

    /**
     * Ghi nhớ cả màu nền và màu chữ hiện tại.
     */
    public static void rememberColors(
            JButton button) {

        if (button == null) {
            return;
        }

        button.putClientProperty(
                "originalBackground",
                button.getBackground()
        );

        button.putClientProperty(
                "originalForeground",
                button.getForeground()
        );
    }

    /**
     * Tương thích với MainView.java hiện tại.
     *
     * MainView đang gọi:
     *
     * ButtonUtils.rememberForeground(button);
     */
    public static void rememberForeground(
            JButton button) {

        if (button == null) {
            return;
        }

        button.putClientProperty(
                "originalForeground",
                button.getForeground()
        );
    }
}