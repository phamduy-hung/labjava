package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.security.CustomerDataCrypto;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO chuyên trách các truy vấn thống kê doanh thu và báo cáo.
 *
 * Nguyên tắc tính doanh thu:
 * - Chỉ tính hóa đơn có trạng thái DA_THANH_TOAN.
 * - Doanh thu lấy từ hoa_don.tong_thanh_toan để bảo đảm thống nhất với hóa đơn đã chốt.
 * - Số lượt phòng thuê là số dòng chi_tiet_dat_phong thuộc các hóa đơn đã thanh toán.
 * - Các truy vấn tổng hợp dùng SUM, COUNT và GROUP BY; mọi tham số đều truyền bằng PreparedStatement.
 *
 * Lưu ý với bộ lọc loại phòng:
 * - Một hóa đơn có thể chứa nhiều phòng. Doanh thu được tính một lần cho mỗi hóa đơn có sử dụng loại phòng được chọn,
 *   còn soLuotPhong chỉ đếm các phòng thuộc đúng loại phòng đó.
 */
public class ThongKeDAO {

    private static final String PAID_STATUS = "DA_THANH_TOAN";

    private static final String INVOICE_LIST_SELECT =
            "SELECT hd.id, hd.ma_hoa_don, hd.thoi_gian_lap, "
                    + "dp.ma_dat_phong, kh.ma_khach_hang, kh.ho_ten, "
                    + "GROUP_CONCAT(DISTINCT p.so_phong ORDER BY p.so_phong SEPARATOR ', ') AS danh_sach_phong, "
                    + "GROUP_CONCAT(DISTINCT lp.ten_loai_phong ORDER BY lp.ten_loai_phong SEPARATOR ', ') AS danh_sach_loai_phong, "
                    + "COUNT(ct.id) AS so_luot_phong, "
                    + "hd.tong_tien_phong, hd.tong_tien_dich_vu, hd.phu_thu, hd.giam_gia, "
                    + "hd.tong_thanh_toan, hd.trang_thai ";

    private static final String INVOICE_LIST_FROM =
            "FROM hoa_don hd "
                    + "JOIN dat_phong dp ON dp.id = hd.dat_phong_id "
                    + "JOIN khach_hang kh ON kh.id = dp.khach_hang_id "
                    + "JOIN chi_tiet_dat_phong ct ON ct.dat_phong_id = dp.id "
                    + "JOIN phong p ON p.id = ct.phong_id "
                    + "JOIN loai_phong lp ON lp.id = p.loai_phong_id ";

    private static final String INVOICE_LIST_GROUP_BY =
            "GROUP BY hd.id, hd.ma_hoa_don, hd.thoi_gian_lap, dp.ma_dat_phong, "
                    + "kh.ma_khach_hang, kh.ho_ten, hd.tong_tien_phong, hd.tong_tien_dich_vu, "
                    + "hd.phu_thu, hd.giam_gia, hd.tong_thanh_toan, hd.trang_thai ";

    public ThongKeTongHop thongKeTheoThang(int nam, int thang) throws SQLException {
        validateYear(nam);
        validateMonth(thang);
        YearMonth yearMonth = YearMonth.of(nam, thang);
        return querySummaryByRange(
                yearMonth.atDay(1).atStartOfDay(),
                yearMonth.plusMonths(1).atDay(1).atStartOfDay()
        );
    }

    public ThongKeTongHop thongKeTheoNam(int nam) throws SQLException {
        validateYear(nam);
        return querySummaryByRange(
                LocalDateTime.of(nam, 1, 1, 0, 0),
                LocalDateTime.of(nam + 1, 1, 1, 0, 0)
        );
    }

    public ThongKeTongHop thongKeTheoLoaiPhong(int loaiPhongId) throws SQLException {
        validateRoomTypeId(loaiPhongId);

        String sql =
                "SELECT COUNT(*) AS so_hoa_don, "
                        + "COALESCE(SUM(x.tong_thanh_toan), 0) AS tong_doanh_thu, "
                        + "COALESCE(SUM(x.so_luot_phong), 0) AS so_luot_phong "
                        + "FROM ( "
                        + "    SELECT hd.id, hd.tong_thanh_toan, COUNT(ct.id) AS so_luot_phong "
                        + "    FROM hoa_don hd "
                        + "    JOIN chi_tiet_dat_phong ct ON ct.dat_phong_id = hd.dat_phong_id "
                        + "    JOIN phong p ON p.id = ct.phong_id "
                        + "    WHERE hd.trang_thai = ? AND p.loai_phong_id = ? "
                        + "    GROUP BY hd.id, hd.tong_thanh_toan "
                        + ") x";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, PAID_STATUS);
            statement.setInt(2, loaiPhongId);

            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? mapSummary(resultSet) : ThongKeTongHop.empty();
            }
        }
    }

    public List<HoaDonThongKe> danhSachHoaDonTheoThang(int nam, int thang) throws SQLException {
        validateYear(nam);
        validateMonth(thang);
        YearMonth yearMonth = YearMonth.of(nam, thang);
        return queryInvoicesByRange(
                yearMonth.atDay(1).atStartOfDay(),
                yearMonth.plusMonths(1).atDay(1).atStartOfDay()
        );
    }

    public List<HoaDonThongKe> danhSachHoaDonTheoNam(int nam) throws SQLException {
        validateYear(nam);
        return queryInvoicesByRange(
                LocalDateTime.of(nam, 1, 1, 0, 0),
                LocalDateTime.of(nam + 1, 1, 1, 0, 0)
        );
    }

    public List<HoaDonThongKe> danhSachHoaDonTheoLoaiPhong(int loaiPhongId) throws SQLException {
        validateRoomTypeId(loaiPhongId);

        String sql = INVOICE_LIST_SELECT
                + INVOICE_LIST_FROM
                + "WHERE hd.trang_thai = ? AND lp.id = ? "
                + INVOICE_LIST_GROUP_BY
                + "ORDER BY hd.thoi_gian_lap DESC, hd.id DESC";

        List<HoaDonThongKe> result = new ArrayList<>();

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, PAID_STATUS);
            statement.setInt(2, loaiPhongId);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapInvoice(resultSet));
                }
            }
        }

        return result;
    }

    /**
     * Báo cáo nhóm cho chế độ "Theo tháng": GROUP BY loại phòng trong tháng được chọn.
     */
    public List<NhomThongKe> nhomTheoLoaiPhongTrongThang(int nam, int thang) throws SQLException {
        validateYear(nam);
        validateMonth(thang);
        YearMonth yearMonth = YearMonth.of(nam, thang);

        String sql =
                "SELECT x.ma_loai_phong, x.ten_loai_phong, "
                        + "COUNT(DISTINCT x.hoa_don_id) AS so_hoa_don, "
                        + "SUM(x.so_luot_phong) AS so_luot_phong, "
                        + "SUM(x.doanh_thu_hoa_don) AS tong_doanh_thu "
                        + "FROM ( "
                        + "    SELECT hd.id AS hoa_don_id, lp.id AS loai_phong_id, lp.ma_loai_phong, lp.ten_loai_phong, "
                        + "           COUNT(ct.id) AS so_luot_phong, hd.tong_thanh_toan AS doanh_thu_hoa_don "
                        + "    FROM hoa_don hd "
                        + "    JOIN chi_tiet_dat_phong ct ON ct.dat_phong_id = hd.dat_phong_id "
                        + "    JOIN phong p ON p.id = ct.phong_id "
                        + "    JOIN loai_phong lp ON lp.id = p.loai_phong_id "
                        + "    WHERE hd.trang_thai = ? AND hd.thoi_gian_lap >= ? AND hd.thoi_gian_lap < ? "
                        + "    GROUP BY hd.id, hd.tong_thanh_toan, lp.id, lp.ma_loai_phong, lp.ten_loai_phong "
                        + ") x "
                        + "GROUP BY x.loai_phong_id, x.ma_loai_phong, x.ten_loai_phong "
                        + "ORDER BY tong_doanh_thu DESC, x.ten_loai_phong";

        LocalDateTime from = yearMonth.atDay(1).atStartOfDay();
        LocalDateTime to = yearMonth.plusMonths(1).atDay(1).atStartOfDay();

        List<NhomThongKe> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, PAID_STATUS);
            statement.setTimestamp(2, Timestamp.valueOf(from));
            statement.setTimestamp(3, Timestamp.valueOf(to));

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String label = resultSet.getString("ma_loai_phong")
                            + " - " + resultSet.getString("ten_loai_phong");
                    result.add(mapGroup(resultSet, label));
                }
            }
        }
        return result;
    }

    /**
     * Báo cáo nhóm cho chế độ "Theo năm": GROUP BY từng tháng trong năm.
     */
    public List<NhomThongKe> nhomTheoThangTrongNam(int nam) throws SQLException {
        validateYear(nam);

        String sql =
                "SELECT YEAR(x.thoi_gian_lap) AS nam, MONTH(x.thoi_gian_lap) AS thang, "
                        + "COUNT(*) AS so_hoa_don, SUM(x.so_luot_phong) AS so_luot_phong, "
                        + "SUM(x.tong_thanh_toan) AS tong_doanh_thu "
                        + "FROM ( "
                        + "    SELECT hd.id, hd.thoi_gian_lap, hd.tong_thanh_toan, COUNT(ct.id) AS so_luot_phong "
                        + "    FROM hoa_don hd "
                        + "    JOIN chi_tiet_dat_phong ct ON ct.dat_phong_id = hd.dat_phong_id "
                        + "    WHERE hd.trang_thai = ? AND hd.thoi_gian_lap >= ? AND hd.thoi_gian_lap < ? "
                        + "    GROUP BY hd.id, hd.thoi_gian_lap, hd.tong_thanh_toan "
                        + ") x "
                        + "GROUP BY YEAR(x.thoi_gian_lap), MONTH(x.thoi_gian_lap) "
                        + "ORDER BY nam, thang";

        LocalDateTime from = LocalDateTime.of(nam, 1, 1, 0, 0);
        LocalDateTime to = LocalDateTime.of(nam + 1, 1, 1, 0, 0);

        List<NhomThongKe> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, PAID_STATUS);
            statement.setTimestamp(2, Timestamp.valueOf(from));
            statement.setTimestamp(3, Timestamp.valueOf(to));

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String label = String.format("Tháng %02d/%04d",
                            resultSet.getInt("thang"), resultSet.getInt("nam"));
                    result.add(mapGroup(resultSet, label));
                }
            }
        }
        return result;
    }

    /**
     * Báo cáo nhóm cho chế độ "Theo loại phòng": GROUP BY từng năm/tháng có phát sinh loại phòng đó.
     */
    public List<NhomThongKe> nhomTheoThoiGianCuaLoaiPhong(int loaiPhongId) throws SQLException {
        validateRoomTypeId(loaiPhongId);

        String sql =
                "SELECT YEAR(x.thoi_gian_lap) AS nam, MONTH(x.thoi_gian_lap) AS thang, "
                        + "COUNT(*) AS so_hoa_don, SUM(x.so_luot_phong) AS so_luot_phong, "
                        + "SUM(x.tong_thanh_toan) AS tong_doanh_thu "
                        + "FROM ( "
                        + "    SELECT hd.id, hd.thoi_gian_lap, hd.tong_thanh_toan, COUNT(ct.id) AS so_luot_phong "
                        + "    FROM hoa_don hd "
                        + "    JOIN chi_tiet_dat_phong ct ON ct.dat_phong_id = hd.dat_phong_id "
                        + "    JOIN phong p ON p.id = ct.phong_id "
                        + "    WHERE hd.trang_thai = ? AND p.loai_phong_id = ? "
                        + "    GROUP BY hd.id, hd.thoi_gian_lap, hd.tong_thanh_toan "
                        + ") x "
                        + "GROUP BY YEAR(x.thoi_gian_lap), MONTH(x.thoi_gian_lap) "
                        + "ORDER BY nam, thang";

        List<NhomThongKe> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, PAID_STATUS);
            statement.setInt(2, loaiPhongId);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String label = String.format("Tháng %02d/%04d",
                            resultSet.getInt("thang"), resultSet.getInt("nam"));
                    result.add(mapGroup(resultSet, label));
                }
            }
        }
        return result;
    }

    private ThongKeTongHop querySummaryByRange(LocalDateTime from, LocalDateTime to) throws SQLException {
        String sql =
                "SELECT COUNT(*) AS so_hoa_don, "
                        + "COALESCE(SUM(x.tong_thanh_toan), 0) AS tong_doanh_thu, "
                        + "COALESCE(SUM(x.so_luot_phong), 0) AS so_luot_phong "
                        + "FROM ( "
                        + "    SELECT hd.id, hd.tong_thanh_toan, COUNT(ct.id) AS so_luot_phong "
                        + "    FROM hoa_don hd "
                        + "    JOIN chi_tiet_dat_phong ct ON ct.dat_phong_id = hd.dat_phong_id "
                        + "    WHERE hd.trang_thai = ? AND hd.thoi_gian_lap >= ? AND hd.thoi_gian_lap < ? "
                        + "    GROUP BY hd.id, hd.tong_thanh_toan "
                        + ") x";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, PAID_STATUS);
            statement.setTimestamp(2, Timestamp.valueOf(from));
            statement.setTimestamp(3, Timestamp.valueOf(to));

            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? mapSummary(resultSet) : ThongKeTongHop.empty();
            }
        }
    }

    private List<HoaDonThongKe> queryInvoicesByRange(LocalDateTime from, LocalDateTime to) throws SQLException {
        String sql = INVOICE_LIST_SELECT
                + INVOICE_LIST_FROM
                + "WHERE hd.trang_thai = ? AND hd.thoi_gian_lap >= ? AND hd.thoi_gian_lap < ? "
                + INVOICE_LIST_GROUP_BY
                + "ORDER BY hd.thoi_gian_lap DESC, hd.id DESC";

        List<HoaDonThongKe> result = new ArrayList<>();

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, PAID_STATUS);
            statement.setTimestamp(2, Timestamp.valueOf(from));
            statement.setTimestamp(3, Timestamp.valueOf(to));

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapInvoice(resultSet));
                }
            }
        }

        return result;
    }

    private ThongKeTongHop mapSummary(ResultSet resultSet) throws SQLException {
        return new ThongKeTongHop(
                resultSet.getBigDecimal("tong_doanh_thu"),
                resultSet.getInt("so_hoa_don"),
                resultSet.getInt("so_luot_phong")
        );
    }

    private HoaDonThongKe mapInvoice(ResultSet resultSet) throws SQLException {
        Timestamp invoiceTime = resultSet.getTimestamp("thoi_gian_lap");
        return new HoaDonThongKe(
                resultSet.getInt("id"),
                resultSet.getString("ma_hoa_don"),
                invoiceTime == null ? null : invoiceTime.toLocalDateTime(),
                resultSet.getString("ma_dat_phong"),
                resultSet.getString("ma_khach_hang"),
                CustomerDataCrypto.decrypt(resultSet.getString("ho_ten")),
                resultSet.getString("danh_sach_phong"),
                resultSet.getString("danh_sach_loai_phong"),
                resultSet.getInt("so_luot_phong"),
                resultSet.getBigDecimal("tong_tien_phong"),
                resultSet.getBigDecimal("tong_tien_dich_vu"),
                resultSet.getBigDecimal("phu_thu"),
                resultSet.getBigDecimal("giam_gia"),
                resultSet.getBigDecimal("tong_thanh_toan"),
                resultSet.getString("trang_thai")
        );
    }

    private NhomThongKe mapGroup(ResultSet resultSet, String label) throws SQLException {
        return new NhomThongKe(
                label,
                resultSet.getInt("so_hoa_don"),
                resultSet.getInt("so_luot_phong"),
                resultSet.getBigDecimal("tong_doanh_thu")
        );
    }

    private void validateYear(int year) {
        if (year < 2000 || year > 2200) {
            throw new IllegalArgumentException("Năm thống kê phải nằm trong khoảng 2000 đến 2200.");
        }
    }

    private void validateMonth(int month) {
        if (month < 1 || month > 12) {
            throw new IllegalArgumentException("Tháng thống kê phải nằm trong khoảng 1 đến 12.");
        }
    }

    private void validateRoomTypeId(int roomTypeId) {
        if (roomTypeId <= 0) {
            throw new IllegalArgumentException("Loại phòng thống kê không hợp lệ.");
        }
    }

    public static final class ThongKeTongHop {
        private final BigDecimal tongDoanhThu;
        private final int soHoaDon;
        private final int soLuotPhong;

        public ThongKeTongHop(BigDecimal tongDoanhThu, int soHoaDon, int soLuotPhong) {
            this.tongDoanhThu = tongDoanhThu == null ? BigDecimal.ZERO : tongDoanhThu;
            this.soHoaDon = soHoaDon;
            this.soLuotPhong = soLuotPhong;
        }

        public static ThongKeTongHop empty() {
            return new ThongKeTongHop(BigDecimal.ZERO, 0, 0);
        }

        public BigDecimal getTongDoanhThu() {
            return tongDoanhThu;
        }

        public int getSoHoaDon() {
            return soHoaDon;
        }

        public int getSoLuotPhong() {
            return soLuotPhong;
        }

        public BigDecimal getDoanhThuTrungBinhMoiHoaDon() {
            if (soHoaDon <= 0) {
                return BigDecimal.ZERO;
            }
            return tongDoanhThu.divide(BigDecimal.valueOf(soHoaDon), 2, java.math.RoundingMode.HALF_UP);
        }
    }

    public static final class HoaDonThongKe {
        private final int id;
        private final String maHoaDon;
        private final LocalDateTime thoiGianLap;
        private final String maDatPhong;
        private final String maKhachHang;
        private final String hoTenKhachHang;
        private final String danhSachPhong;
        private final String danhSachLoaiPhong;
        private final int soLuotPhong;
        private final BigDecimal tongTienPhong;
        private final BigDecimal tongTienDichVu;
        private final BigDecimal phuThu;
        private final BigDecimal giamGia;
        private final BigDecimal tongThanhToan;
        private final String trangThai;

        public HoaDonThongKe(
                int id,
                String maHoaDon,
                LocalDateTime thoiGianLap,
                String maDatPhong,
                String maKhachHang,
                String hoTenKhachHang,
                String danhSachPhong,
                String danhSachLoaiPhong,
                int soLuotPhong,
                BigDecimal tongTienPhong,
                BigDecimal tongTienDichVu,
                BigDecimal phuThu,
                BigDecimal giamGia,
                BigDecimal tongThanhToan,
                String trangThai) {
            this.id = id;
            this.maHoaDon = maHoaDon;
            this.thoiGianLap = thoiGianLap;
            this.maDatPhong = maDatPhong;
            this.maKhachHang = maKhachHang;
            this.hoTenKhachHang = hoTenKhachHang;
            this.danhSachPhong = danhSachPhong;
            this.danhSachLoaiPhong = danhSachLoaiPhong;
            this.soLuotPhong = soLuotPhong;
            this.tongTienPhong = safeMoney(tongTienPhong);
            this.tongTienDichVu = safeMoney(tongTienDichVu);
            this.phuThu = safeMoney(phuThu);
            this.giamGia = safeMoney(giamGia);
            this.tongThanhToan = safeMoney(tongThanhToan);
            this.trangThai = trangThai;
        }

        private static BigDecimal safeMoney(BigDecimal value) {
            return value == null ? BigDecimal.ZERO : value;
        }

        public int getId() { return id; }
        public String getMaHoaDon() { return maHoaDon; }
        public LocalDateTime getThoiGianLap() { return thoiGianLap; }
        public String getMaDatPhong() { return maDatPhong; }
        public String getMaKhachHang() { return maKhachHang; }
        public String getHoTenKhachHang() { return hoTenKhachHang; }
        public String getDanhSachPhong() { return danhSachPhong; }
        public String getDanhSachLoaiPhong() { return danhSachLoaiPhong; }
        public int getSoLuotPhong() { return soLuotPhong; }
        public BigDecimal getTongTienPhong() { return tongTienPhong; }
        public BigDecimal getTongTienDichVu() { return tongTienDichVu; }
        public BigDecimal getPhuThu() { return phuThu; }
        public BigDecimal getGiamGia() { return giamGia; }
        public BigDecimal getTongThanhToan() { return tongThanhToan; }
        public String getTrangThai() { return trangThai; }
    }

    public static final class NhomThongKe {
        private final String nhom;
        private final int soHoaDon;
        private final int soLuotPhong;
        private final BigDecimal tongDoanhThu;

        public NhomThongKe(String nhom, int soHoaDon, int soLuotPhong, BigDecimal tongDoanhThu) {
            this.nhom = nhom;
            this.soHoaDon = soHoaDon;
            this.soLuotPhong = soLuotPhong;
            this.tongDoanhThu = tongDoanhThu == null ? BigDecimal.ZERO : tongDoanhThu;
        }

        public String getNhom() { return nhom; }
        public int getSoHoaDon() { return soHoaDon; }
        public int getSoLuotPhong() { return soLuotPhong; }
        public BigDecimal getTongDoanhThu() { return tongDoanhThu; }
    }
}
