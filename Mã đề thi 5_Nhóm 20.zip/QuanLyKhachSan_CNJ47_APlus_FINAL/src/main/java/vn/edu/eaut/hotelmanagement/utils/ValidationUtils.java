package vn.edu.eaut.hotelmanagement.utils;


import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;



public final class ValidationUtils {


    private ValidationUtils(){

    }




    public static boolean required(
            JTextField field,
            String message){


        if(field.getText()
                .trim()
                .isEmpty()){


            showError(message);

            field.requestFocus();

            return false;

        }


        return true;


    }





    public static boolean phone(
            String phone){


        if(!phone.matches(
                "0[0-9]{9}"
        )){


            showError(
                    "Số điện thoại phải gồm 10 chữ số"
            );


            return false;

        }


        return true;


    }





    public static boolean email(
            String email){


        if(!email.matches(
                "^[A-Za-z0-9+_.-]+@(.+)$"
        )){


            showError(
                    "Email không hợp lệ"
            );


            return false;

        }


        return true;


    }






    public static boolean cccd(
            String cccd){


        if(!cccd.matches(
                "[0-9]{12}"
        )){


            showError(
                    "CCCD phải gồm 12 chữ số"
            );


            return false;

        }


        return true;


    }





    public static boolean positiveNumber(
            String value){



        try{


            double number =
                    Double.parseDouble(value);



            if(number<=0){


                throw new Exception();

            }



            return true;


        }
        catch(Exception e){


            showError(
                    "Giá trị phải là số dương"
            );


            return false;


        }


    }





    public static boolean date(
            String value){


        try{


            LocalDate.parse(value);


            return true;


        }
        catch(DateTimeParseException e){


            showError(
                    "Ngày không đúng định dạng yyyy-MM-dd"
            );


            return false;


        }


    }





    private static void showError(
            String message){


        JOptionPane.showMessageDialog(
                null,
                message,
                "Thông báo lỗi",
                JOptionPane.ERROR_MESSAGE
        );


    }



}