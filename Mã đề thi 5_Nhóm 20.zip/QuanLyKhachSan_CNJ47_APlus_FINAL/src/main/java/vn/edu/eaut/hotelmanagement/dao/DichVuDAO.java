package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.DichVu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DichVuDAO {

    private static final String SELECT_COLUMNS =
            "id, ma_dich_vu, ten_dich_vu, don_vi_tinh, don_gia, dang_hoat_dong, ghi_chu, ngay_tao, ngay_cap_nhat";

    public int insert(DichVu dichVu) throws SQLException {
        String sql = "INSERT INTO dich_vu(ma_dich_vu, ten_dich_vu, don_vi_tinh, don_gia, dang_hoat_dong, ghi_chu) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, dichVu, false);
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    dichVu.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của dịch vụ vừa thêm.");
    }

    public boolean update(DichVu dichVu) throws SQLException {
        String sql = "UPDATE dich_vu SET ma_dich_vu = ?, ten_dich_vu = ?, don_vi_tinh = ?, don_gia = ?, dang_hoat_dong = ?, ghi_chu = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            bind(statement, dichVu, true);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteById(int id) throws SQLException {
        // Dịch vụ đã phát sinh giao dịch phải được giữ lại để bảo toàn giá lịch sử.
        String checkSql = "SELECT EXISTS (SELECT 1 FROM su_dung_dich_vu WHERE dich_vu_id = ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement check = connection.prepareStatement(checkSql)) {
            check.setInt(1, id);
            try (ResultSet rs = check.executeQuery()) {
                if (rs.next() && rs.getBoolean(1)) {
                    throw new SQLException(
                            "Không thể xóa dịch vụ vì dịch vụ đã phát sinh giao dịch. "
                                    + "Hãy chuyển dịch vụ sang ngừng hoạt động thay vì xóa."
                    );
                }
            }
        }

        String sql = "DELETE FROM dich_vu WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    public Optional<DichVu> findById(int id) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM dich_vu WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<DichVu> findAll() throws SQLException {
        return findList(false);
    }

    public List<DichVu> findActive() throws SQLException {
        return findList(true);
    }

    public List<DichVu> search(String keyword) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM dich_vu WHERE ma_dich_vu LIKE ? OR ten_dich_vu LIKE ? OR don_vi_tinh LIKE ? ORDER BY ten_dich_vu";
        String searchValue = "%" + (keyword == null ? "" : keyword.trim()) + "%";
        List<DichVu> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, searchValue);
            statement.setString(2, searchValue);
            statement.setString(3, searchValue);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    private List<DichVu> findList(boolean onlyActive) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM dich_vu" + (onlyActive ? " WHERE dang_hoat_dong = TRUE" : "") + " ORDER BY ten_dich_vu";
        List<DichVu> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(mapRow(resultSet));
            }
        }
        return result;
    }

    private void bind(PreparedStatement statement, DichVu dichVu, boolean includeId) throws SQLException {
        statement.setString(1, dichVu.getMaDichVu());
        statement.setString(2, dichVu.getTenDichVu());
        statement.setString(3, dichVu.getDonViTinh());
        statement.setBigDecimal(4, dichVu.getDonGia());
        statement.setBoolean(5, dichVu.isDangHoatDong());
        statement.setString(6, dichVu.getGhiChu());
        if (includeId) {
            statement.setInt(7, dichVu.getId());
        }
    }

    private DichVu mapRow(ResultSet resultSet) throws SQLException {
        DichVu dichVu = new DichVu();
        dichVu.setId(resultSet.getInt("id"));
        dichVu.setMaDichVu(resultSet.getString("ma_dich_vu"));
        dichVu.setTenDichVu(resultSet.getString("ten_dich_vu"));
        dichVu.setDonViTinh(resultSet.getString("don_vi_tinh"));
        dichVu.setDonGia(resultSet.getBigDecimal("don_gia"));
        dichVu.setDangHoatDong(resultSet.getBoolean("dang_hoat_dong"));
        dichVu.setGhiChu(resultSet.getString("ghi_chu"));
        dichVu.setNgayTao(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_tao"));
        dichVu.setNgayCapNhat(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_cap_nhat"));
        return dichVu;
    }
}
