package vn.edu.eaut.hotelmanagement.model.enums;

public enum TrangThaiNhiemVu {
    CHO_XU_LY("Chờ xử lý"),
    DANG_XU_LY("Đang xử lý"),
    HOAN_THANH("Hoàn thành"),
    DA_HUY("Đã hủy");

    private final String hienThi;

    TrangThaiNhiemVu(String hienThi) {
        this.hienThi = hienThi;
    }

    public boolean canTransitionTo(TrangThaiNhiemVu target) {
        if (target == null) {
            return false;
        }
        if (this == target) {
            return true;
        }
        return switch (this) {
            case CHO_XU_LY -> target == DANG_XU_LY || target == DA_HUY;
            case DANG_XU_LY -> target == HOAN_THANH || target == DA_HUY;
            case HOAN_THANH, DA_HUY -> false;
        };
    }

    @Override
    public String toString() {
        return hienThi;
    }
}
