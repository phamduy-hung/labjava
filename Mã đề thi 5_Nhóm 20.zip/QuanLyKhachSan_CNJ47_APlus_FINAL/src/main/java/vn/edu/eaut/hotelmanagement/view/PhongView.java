package vn.edu.eaut.hotelmanagement.view;

import vn.edu.eaut.hotelmanagement.dao.LoaiPhongDAO;
import vn.edu.eaut.hotelmanagement.dao.PhongDAO;
import vn.edu.eaut.hotelmanagement.model.LoaiPhong;
import vn.edu.eaut.hotelmanagement.model.Phong;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiPhong;
import vn.edu.eaut.hotelmanagement.session.LoginSession;
import vn.edu.eaut.hotelmanagement.utils.ButtonUtils;
import vn.edu.eaut.hotelmanagement.utils.TableUtils;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

/**
 * Màn hình quản lý phòng và hỗ trợ nghiệp vụ buồng phòng.
 *
 * Giá phòng trong thiết kế CSDL thuộc bảng loai_phong (gia_co_ban), không nằm
 * trực tiếp trong bảng phong. Vì vậy ô giá trên form được tự động lấy theo loại
 * phòng để tránh tạo dữ liệu giá trùng lặp hoặc sai lệch giữa các phòng cùng loại.
 *
 * Màn hình kết nối trực tiếp với PhongDAO theo yêu cầu của bài hiện tại. Các thao
 * tác CSDL được chạy bằng SwingWorker để không chặn Event Dispatch Thread.
 */
public class PhongView extends JPanel {

    private static final Color PRIMARY_COLOR = new Color(26, 83, 155);
    private static final Color PRIMARY_DARK_COLOR = new Color(17, 55, 105);
    private static final Color ACCENT_COLOR = new Color(40, 133, 220);
    private static final Color BACKGROUND_COLOR = new Color(244, 247, 251);
    private static final Color CARD_COLOR = Color.WHITE;
    private static final Color BORDER_COLOR = new Color(221, 228, 236);
    private static final Color TEXT_COLOR = new Color(38, 49, 64);
    private static final Color SECONDARY_TEXT_COLOR = new Color(105, 117, 133);
    private static final Color SUCCESS_COLOR = new Color(37, 137, 88);
    private static final Color WARNING_COLOR = new Color(193, 124, 31);
    private static final Color DANGER_COLOR = new Color(184, 55, 55);

    private static final int MAX_ROOM_NUMBER_LENGTH = 10;
    private static final int MAX_NOTE_LENGTH = 500;

    private final PhongDAO phongDAO;
    private final LoaiPhongDAO loaiPhongDAO;
    private final LoginSession loginSession;

    private final JTextField txtSoPhong = new JTextField(18);
    private final JComboBox<LoaiPhong> cboLoaiPhong = new JComboBox<>();
    private final JTextField txtGiaPhong = new JTextField(18);
    private final JTextField txtTang = new JTextField(18);
    private final JComboBox<TrangThaiPhong> cboTrangThai = new JComboBox<>(TrangThaiPhong.values());
    private final JTextArea txtGhiChu = new JTextArea(4, 18);
    private final JCheckBox chkDangHoatDong = new JCheckBox("Phòng đang hoạt động", true);

    private final JTextField txtTimKiem = new JTextField(24);
    private final JComboBox<Object> cboLocTrangThai = new JComboBox<>();

    private final JButton btnThem = new JButton("Thêm");
    private final JButton btnSua = new JButton("Sửa");
    private final JButton btnXoa = new JButton("Xóa");
    private final JButton btnCapNhatDonDep = new JButton("Cập nhật trạng thái dọn dẹp");
    private final JButton btnLamMoiForm = new JButton("Làm mới form");
    private final JButton btnTimKiem = new JButton("Tìm kiếm");
    private final JButton btnTaiLai = new JButton("Tải lại");

    private final JLabel lblThongBao = new JLabel("Sẵn sàng");
    private final JLabel lblTongSoPhong = new JLabel("Tổng số phòng: 0");

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{
                    "Số phòng",
                    "Loại phòng",
                    "Giá phòng",
                    "Tầng",
                    "Trạng thái",
                    "Ghi chú",
                    "Hoạt động"
            },
            0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tblPhong = new JTable(tableModel);

    private final List<Phong> danhSachPhongDangHienThi = new ArrayList<>();
    private final Map<Integer, LoaiPhong> loaiPhongTheoId = new HashMap<>();

    private Integer phongDangChonId;
    private boolean dangXuLy;

    /**
     * Constructor dùng khi chạy thử độc lập. Không có phiên đăng nhập thì cho
     * phép đầy đủ chức năng để thuận tiện kiểm thử giao diện.
     */
    public PhongView() {
        this(null, new PhongDAO(), new LoaiPhongDAO());
    }

    /**
     * Constructor dùng khi nhúng vào MainView. Quyền nút bấm được thiết lập theo
     * LoginSession.
     */
    public PhongView(LoginSession loginSession) {
        this(loginSession, new PhongDAO(), new LoaiPhongDAO());
    }

    /**
     * Constructor phục vụ kiểm thử hoặc thay DAO khi cần.
     */
    public PhongView(
            LoginSession loginSession,
            PhongDAO phongDAO,
            LoaiPhongDAO loaiPhongDAO) {

        this.loginSession = loginSession;
        this.phongDAO = phongDAO;
        this.loaiPhongDAO = loaiPhongDAO;

        initializeLayout();
        initializeComponents();
        registerEvents();
        applyRolePermissions();
        loadInitialData();
    }

    private void initializeLayout() {
        setLayout(new BorderLayout(0, 16));
        setBackground(BACKGROUND_COLOR);
        setBorder(new EmptyBorder(20, 20, 20, 20));
    }

    private void initializeComponents() {
        add(createHeaderPanel(), BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                createFormPanel(),
                createTableArea()
        );
        splitPane.setBorder(null);
        splitPane.setDividerLocation(390);
        splitPane.setResizeWeight(0.0);
        splitPane.setContinuousLayout(true);

        add(splitPane, BorderLayout.CENTER);
        add(createStatusPanel(), BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel panel = createCardPanel(new BorderLayout(12, 6));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(16, 18, 16, 18)
        ));

        JLabel lblTitle = new JLabel("QUẢN LÝ PHÒNG & BUỒNG PHÒNG");
        lblTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 21));
        lblTitle.setForeground(TEXT_COLOR);

        JLabel lblDescription = new JLabel(
                "Quản lý phòng, loại phòng, giá cơ bản và trạng thái dọn dẹp."
        );
        lblDescription.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        lblDescription.setForeground(SECONDARY_TEXT_COLOR);

        JPanel titlePanel = new JPanel(new GridBagLayout());
        titlePanel.setOpaque(false);
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.anchor = GridBagConstraints.WEST;
        constraints.weightx = 1.0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        titlePanel.add(lblTitle, constraints);

        constraints.gridy = 1;
        constraints.insets = new Insets(4, 0, 0, 0);
        titlePanel.add(lblDescription, constraints);

        JPanel badgePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        badgePanel.setOpaque(false);

        JLabel lblBadge = new JLabel("PHÒNG", SwingConstants.CENTER);
        lblBadge.setOpaque(true);
        lblBadge.setBackground(new Color(234, 242, 252));
        lblBadge.setForeground(PRIMARY_COLOR);
        lblBadge.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 11));
        lblBadge.setPreferredSize(new Dimension(88, 30));
        lblBadge.setBorder(BorderFactory.createLineBorder(new Color(198, 217, 241)));
        badgePanel.add(lblBadge);

        panel.add(titlePanel, BorderLayout.CENTER);
        panel.add(badgePanel, BorderLayout.EAST);
        return panel;
    }

    private JPanel createFormPanel() {
        JPanel outerPanel = new JPanel(new BorderLayout());
        outerPanel.setOpaque(false);
        outerPanel.setMinimumSize(new Dimension(360, 500));

        JPanel card = createCardPanel(new BorderLayout(0, 14));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(18, 18, 18, 18)
        ));

        JLabel lblFormTitle = new JLabel("THÔNG TIN PHÒNG");
        lblFormTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
        lblFormTitle.setForeground(PRIMARY_DARK_COLOR);
        card.add(lblFormTitle, BorderLayout.NORTH);

        JPanel fieldsPanel = new JPanel(new GridBagLayout());
        fieldsPanel.setOpaque(false);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.weightx = 0.0;
        constraints.anchor = GridBagConstraints.WEST;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(5, 0, 5, 10);

        addFormRow(fieldsPanel, constraints, "Số phòng (*)", txtSoPhong);
        addFormRow(fieldsPanel, constraints, "Loại phòng (*)", cboLoaiPhong);
        addFormRow(fieldsPanel, constraints, "Giá phòng (VNĐ)", txtGiaPhong);
        addFormRow(fieldsPanel, constraints, "Tầng (*)", txtTang);
        addFormRow(fieldsPanel, constraints, "Trạng thái (*)", cboTrangThai);

        JScrollPane noteScrollPane = new JScrollPane(txtGhiChu);
        noteScrollPane.setPreferredSize(new Dimension(210, 88));
        txtGhiChu.setLineWrap(true);
        txtGhiChu.setWrapStyleWord(true);
        txtGhiChu.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        addFormRow(fieldsPanel, constraints, "Ghi chú", noteScrollPane);

        constraints.gridx = 1;
        constraints.gridy++;
        constraints.weightx = 1.0;
        constraints.insets = new Insets(7, 0, 7, 0);
        chkDangHoatDong.setOpaque(false);
        chkDangHoatDong.setForeground(TEXT_COLOR);
        fieldsPanel.add(chkDangHoatDong, constraints);

        txtGiaPhong.setEditable(false);
        txtGiaPhong.setBackground(new Color(246, 248, 251));
        txtGiaPhong.setToolTipText(
                "Giá được lấy từ loại phòng. Bảng phong không lưu giá riêng."
        );

        card.add(fieldsPanel, BorderLayout.CENTER);
        card.add(createActionButtonPanel(), BorderLayout.SOUTH);

        outerPanel.add(card, BorderLayout.CENTER);
        return outerPanel;
    }

    private JPanel createActionButtonPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.weightx = 1.0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(4, 0, 4, 6);

        ButtonUtils.success(btnThem);
        ButtonUtils.primary(btnSua);
        ButtonUtils.danger(btnXoa);
        ButtonUtils.success(btnCapNhatDonDep);
        ButtonUtils.neutral(btnLamMoiForm);

        panel.add(btnThem, constraints);

        constraints.gridx = 1;
        constraints.insets = new Insets(4, 6, 4, 0);
        panel.add(btnSua, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.insets = new Insets(4, 0, 4, 6);
        panel.add(btnXoa, constraints);

        constraints.gridx = 1;
        constraints.insets = new Insets(4, 6, 4, 0);
        panel.add(btnLamMoiForm, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        constraints.insets = new Insets(8, 0, 0, 0);
        panel.add(btnCapNhatDonDep, constraints);

        return panel;
    }

    private JPanel createTableArea() {
        JPanel panel = createCardPanel(new BorderLayout(0, 12));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(14, 14, 14, 14)
        ));

        panel.add(createSearchPanel(), BorderLayout.NORTH);

        configureTable();
        JScrollPane scrollPane = new JScrollPane(tblPhong);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        scrollPane.getViewport().setBackground(Color.WHITE);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        footer.setOpaque(false);
        lblTongSoPhong.setForeground(SECONDARY_TEXT_COLOR);
        lblTongSoPhong.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        footer.add(lblTongSoPhong);
        panel.add(footer, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);

        cboLocTrangThai.addItem("Tất cả trạng thái");
        for (TrangThaiPhong trangThaiPhong : TrangThaiPhong.values()) {
            cboLocTrangThai.addItem(trangThaiPhong);
        }

        JLabel lblSearch = new JLabel("Tìm kiếm:");
        lblSearch.setForeground(TEXT_COLOR);
        lblSearch.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));

        JLabel lblStatusFilter = new JLabel("Trạng thái:");
        lblStatusFilter.setForeground(TEXT_COLOR);
        lblStatusFilter.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));

        ButtonUtils.primary(btnTimKiem);
        ButtonUtils.neutral(btnTaiLai);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(0, 0, 0, 8);
        constraints.anchor = GridBagConstraints.WEST;
        panel.add(lblSearch, constraints);

        constraints.gridx = 1;
        constraints.weightx = 1.0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        panel.add(txtTimKiem, constraints);

        constraints.gridx = 2;
        constraints.weightx = 0.0;
        constraints.fill = GridBagConstraints.NONE;
        constraints.insets = new Insets(0, 14, 0, 8);
        panel.add(lblStatusFilter, constraints);

        constraints.gridx = 3;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(0, 0, 0, 8);
        cboLocTrangThai.setPreferredSize(new Dimension(150, 30));
        panel.add(cboLocTrangThai, constraints);

        constraints.gridx = 4;
        constraints.fill = GridBagConstraints.NONE;
        panel.add(btnTimKiem, constraints);

        constraints.gridx = 5;
        constraints.insets = new Insets(0, 6, 0, 0);
        panel.add(btnTaiLai, constraints);

        return panel;
    }

    private JPanel createStatusPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        lblThongBao.setForeground(SECONDARY_TEXT_COLOR);
        lblThongBao.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));

        panel.add(lblThongBao, BorderLayout.WEST);
        return panel;
    }

    private void addFormRow(
            JPanel panel,
            GridBagConstraints constraints,
            String labelText,
            Component component) {

        JLabel label = new JLabel(labelText);
        label.setForeground(TEXT_COLOR);
        label.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));

        constraints.gridx = 0;
        constraints.weightx = 0.0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(5, 0, 5, 10);
        panel.add(label, constraints);

        constraints.gridx = 1;
        constraints.weightx = 1.0;
        constraints.insets = new Insets(5, 0, 5, 0);
        panel.add(component, constraints);

        constraints.gridy++;
    }

    private void configureTable() {
        TableUtils.setupTable(tblPhong);

        // Giữ renderer trạng thái phòng riêng để hiển thị màu theo nghiệp vụ.
        tblPhong.getColumnModel().getColumn(4)
                .setCellRenderer(new RoomStatusCellRenderer());

        // Căn giữa các cột ngắn; giá phòng căn phải.
        TableUtils.centerColumn(tblPhong, 0);
        TableUtils.rightAlignColumn(tblPhong, 2);
        TableUtils.centerColumn(tblPhong, 3);
        TableUtils.centerColumn(tblPhong, 6);

        // Ghi chú cần rộng hơn để hạn chế xuống dòng/thu hẹp quá mức.
        tblPhong.getColumnModel().getColumn(5).setPreferredWidth(220);
    }

    private void registerEvents() {
        cboLoaiPhong.addActionListener(event -> updateRoomPriceField());

        tblPhong.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                fillFormFromSelectedTableRow();
            }
        });

        btnThem.addActionListener(event -> handleAddRoom());
        btnSua.addActionListener(event -> handleUpdateRoom());
        btnXoa.addActionListener(event -> handleDeleteRoom());
        btnCapNhatDonDep.addActionListener(event -> handleUpdateCleaningStatus());
        btnLamMoiForm.addActionListener(event -> clearForm());
        btnTimKiem.addActionListener(event -> performSearch());
        btnTaiLai.addActionListener(event -> {
            txtTimKiem.setText("");
            cboLocTrangThai.setSelectedIndex(0);
            loadRoomsAsync();
        });

        txtTimKiem.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent event) {
                if (event.getKeyCode() == KeyEvent.VK_ENTER) {
                    performSearch();
                }
            }
        });
    }

    private void applyRolePermissions() {
        boolean canManageRoom = true;
        boolean canUpdateCleaning = true;

        if (loginSession != null) {
            canManageRoom = loginSession.hasRole("ADMIN") || loginSession.hasRole("LE_TAN");
            canUpdateCleaning = canManageRoom || loginSession.hasRole("BUONG_PHONG");
        }

        ButtonUtils.applyEnabledState(btnThem, canManageRoom);
        ButtonUtils.applyEnabledState(btnSua, canManageRoom);
        ButtonUtils.applyEnabledState(btnXoa, canManageRoom);
        ButtonUtils.applyEnabledState(btnCapNhatDonDep, canUpdateCleaning);

        txtSoPhong.setEditable(canManageRoom);
        cboLoaiPhong.setEnabled(canManageRoom);
        txtTang.setEditable(canManageRoom);
        cboTrangThai.setEnabled(canManageRoom);
        txtGhiChu.setEditable(canManageRoom);
        chkDangHoatDong.setEnabled(canManageRoom);

        if (!canManageRoom && canUpdateCleaning) {
            lblThongBao.setText(
                    "Vai trò buồng phòng: được xem danh sách và cập nhật trạng thái dọn dẹp."
            );
        }
    }

    private void loadInitialData() {
        setBusy(true, "Đang tải dữ liệu phòng...");

        SwingWorker<InitialData, Void> worker = new SwingWorker<>() {
            @Override
            protected InitialData doInBackground() throws Exception {
                List<LoaiPhong> roomTypes = loaiPhongDAO.findActive();
                List<Phong> rooms = phongDAO.findAll();
                return new InitialData(roomTypes, rooms);
            }

            @Override
            protected void done() {
                try {
                    InitialData data = get();
                    setRoomTypes(data.roomTypes());
                    showRoomList(data.rooms());
                    clearForm();
                    setBusy(false, "Tải dữ liệu phòng thành công.");
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Quá trình tải dữ liệu bị gián đoạn.");
                    showError("Không thể tải dữ liệu phòng vì tác vụ đã bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tải dữ liệu phòng.");
                    showDatabaseError("Tải dữ liệu phòng", exception.getCause());
                }
            }
        };

        worker.execute();
    }

    private void loadRoomsAsync() {
        setBusy(true, "Đang tải lại danh sách phòng...");

        SwingWorker<List<Phong>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Phong> doInBackground() throws Exception {
                return phongDAO.findAll();
            }

            @Override
            protected void done() {
                try {
                    showRoomList(get());
                    clearForm();
                    setBusy(false, "Danh sách phòng đã được cập nhật.");
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Quá trình tải dữ liệu bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tải danh sách phòng.");
                    showDatabaseError("Tải danh sách phòng", exception.getCause());
                }
            }
        };

        worker.execute();
    }

    private void performSearch() {
        String keyword = txtTimKiem.getText() == null ? "" : txtTimKiem.getText().trim();
        Object statusFilter = cboLocTrangThai.getSelectedItem();

        setBusy(true, "Đang tìm kiếm phòng...");

        SwingWorker<List<Phong>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Phong> doInBackground() throws Exception {
                List<Phong> source;

                if (statusFilter instanceof TrangThaiPhong selectedStatus) {
                    source = phongDAO.findByStatus(selectedStatus);
                } else if (!keyword.isBlank()) {
                    source = phongDAO.search(keyword);
                } else {
                    source = phongDAO.findAll();
                }

                if (keyword.isBlank() || !(statusFilter instanceof TrangThaiPhong)) {
                    return source;
                }

                String normalizedKeyword = keyword.toLowerCase(Locale.ROOT);
                List<Phong> filtered = new ArrayList<>();

                for (Phong room : source) {
                    LoaiPhong roomType = loaiPhongTheoId.get(room.getLoaiPhongId());
                    String roomTypeCode = roomType == null ? "" : roomType.getMaLoaiPhong();
                    String roomTypeName = roomType == null ? "" : roomType.getTenLoaiPhong();

                    if (containsIgnoreCase(room.getSoPhong(), normalizedKeyword)
                            || containsIgnoreCase(String.valueOf(room.getTang()), normalizedKeyword)
                            || containsIgnoreCase(roomTypeCode, normalizedKeyword)
                            || containsIgnoreCase(roomTypeName, normalizedKeyword)
                            || containsIgnoreCase(displayStatus(room.getTrangThai()), normalizedKeyword)) {

                        filtered.add(room);
                    }
                }

                return filtered;
            }

            @Override
            protected void done() {
                try {
                    List<Phong> result = get();
                    showRoomList(result);
                    clearForm();
                    setBusy(false, "Tìm thấy " + result.size() + " phòng phù hợp.");
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Tìm kiếm bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tìm kiếm phòng.");
                    showDatabaseError("Tìm kiếm phòng", exception.getCause());
                }
            }
        };

        worker.execute();
    }

    private boolean containsIgnoreCase(String value, String normalizedKeyword) {
        return value != null && value.toLowerCase(Locale.ROOT).contains(normalizedKeyword);
    }

    private void handleAddRoom() {
        if (!validateRoomForm(false)) {
            return;
        }

        Phong room = createRoomFromForm();

        setBusy(true, "Đang thêm phòng " + room.getSoPhong() + "...");

        SwingWorker<Integer, Void> worker = new SwingWorker<>() {
            @Override
            protected Integer doInBackground() throws Exception {
                Optional<Phong> existingRoom = phongDAO.findByRoomNumber(room.getSoPhong());
                if (existingRoom.isPresent()) {
                    throw new IllegalArgumentException(
                            "Số phòng " + room.getSoPhong() + " đã tồn tại."
                    );
                }
                return phongDAO.insert(room);
            }

            @Override
            protected void done() {
                try {
                    int newRoomId = get();
                    setBusy(false, "Đã thêm phòng " + room.getSoPhong() + ".");
                    JOptionPane.showMessageDialog(
                            PhongView.this,
                            "Thêm phòng thành công.\nMã nội bộ: " + newRoomId,
                            "Thành công",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    loadRoomsAsync();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Thêm phòng bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể thêm phòng.");
                    handleDataOperationFailure("Thêm phòng", exception.getCause());
                }
            }
        };

        worker.execute();
    }

    private void handleUpdateRoom() {
        if (phongDangChonId == null) {
            showWarning("Vui lòng chọn một phòng trong bảng trước khi sửa.");
            return;
        }

        if (!validateRoomForm(true)) {
            return;
        }

        Phong room = createRoomFromForm();
        room.setId(phongDangChonId);

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc chắn muốn cập nhật thông tin phòng "
                        + room.getSoPhong() + "?",
                "Xác nhận sửa phòng",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        setBusy(true, "Đang cập nhật phòng " + room.getSoPhong() + "...");

        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                Optional<Phong> roomWithSameNumber = phongDAO.findByRoomNumber(room.getSoPhong());
                if (roomWithSameNumber.isPresent()
                        && !roomWithSameNumber.get().getId().equals(room.getId())) {

                    throw new IllegalArgumentException(
                            "Số phòng " + room.getSoPhong() + " đã được sử dụng bởi phòng khác."
                    );
                }

                return phongDAO.update(room);
            }

            @Override
            protected void done() {
                try {
                    boolean updated = get();
                    if (!updated) {
                        setBusy(false, "Không tìm thấy phòng cần cập nhật.");
                        showWarning("Phòng đã không còn tồn tại hoặc đã bị thay đổi bởi thao tác khác.");
                        loadRoomsAsync();
                        return;
                    }

                    setBusy(false, "Cập nhật phòng thành công.");
                    JOptionPane.showMessageDialog(
                            PhongView.this,
                            "Cập nhật thông tin phòng thành công.",
                            "Thành công",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    loadRoomsAsync();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Cập nhật phòng bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể cập nhật phòng.");
                    handleDataOperationFailure("Cập nhật phòng", exception.getCause());
                }
            }
        };

        worker.execute();
    }

    private void handleDeleteRoom() {
        Phong selectedRoom = getSelectedRoom();
        if (selectedRoom == null) {
            showWarning("Vui lòng chọn phòng cần xóa trong bảng.");
            return;
        }

        if (selectedRoom.getTrangThai() == TrangThaiPhong.DANG_O) {
            showWarning("Không thể xóa phòng đang có khách lưu trú.");
            return;
        }

        if (selectedRoom.getTrangThai() == TrangThaiPhong.DA_DAT) {
            showWarning("Không thể xóa phòng đang có trạng thái Đã đặt.");
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc chắn muốn xóa phòng " + selectedRoom.getSoPhong() + "?\n\n"
                        + "Lưu ý: nếu phòng đã có lịch sử đặt phòng, CSDL sẽ từ chối xóa để bảo toàn dữ liệu.",
                "Xác nhận xóa phòng",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        setBusy(true, "Đang xóa phòng " + selectedRoom.getSoPhong() + "...");

        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                return phongDAO.deleteById(selectedRoom.getId());
            }

            @Override
            protected void done() {
                try {
                    boolean deleted = get();
                    if (!deleted) {
                        setBusy(false, "Không tìm thấy phòng cần xóa.");
                        showWarning("Phòng đã không còn tồn tại.");
                        loadRoomsAsync();
                        return;
                    }

                    setBusy(false, "Xóa phòng thành công.");
                    JOptionPane.showMessageDialog(
                            PhongView.this,
                            "Đã xóa phòng " + selectedRoom.getSoPhong() + ".",
                            "Thành công",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    loadRoomsAsync();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Xóa phòng bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể xóa phòng.");
                    Throwable cause = exception.getCause();
                    if (cause instanceof SQLException sqlException
                            && "23000".equals(sqlException.getSQLState())) {

                        showWarning(
                                "Không thể xóa phòng vì phòng đã phát sinh dữ liệu đặt phòng hoặc dữ liệu liên quan.\n"
                                        + "Hãy bỏ chọn 'Phòng đang hoạt động' và dùng nút Sửa nếu muốn ngừng khai thác phòng."
                        );
                    } else {
                        showDatabaseError("Xóa phòng", cause);
                    }
                }
            }
        };

        worker.execute();
    }

    private void handleUpdateCleaningStatus() {
        Phong selectedRoom = getSelectedRoom();
        if (selectedRoom == null) {
            showWarning("Vui lòng chọn một phòng trong bảng để cập nhật trạng thái dọn dẹp.");
            return;
        }

        TrangThaiPhong currentStatus = selectedRoom.getTrangThai();
        TrangThaiPhong targetStatus;
        String confirmationMessage;

        if (currentStatus == TrangThaiPhong.DANG_DON) {
            targetStatus = TrangThaiPhong.TRONG;
            confirmationMessage = "Xác nhận phòng " + selectedRoom.getSoPhong()
                    + " đã dọn dẹp xong và chuyển về trạng thái Trống?";
        } else if (currentStatus == TrangThaiPhong.TRONG) {
            targetStatus = TrangThaiPhong.DANG_DON;
            confirmationMessage = "Bắt đầu dọn dẹp phòng " + selectedRoom.getSoPhong()
                    + " và chuyển sang trạng thái Đang dọn dẹp?";
        } else if (currentStatus == TrangThaiPhong.DANG_O) {
            showWarning(
                    "Phòng " + selectedRoom.getSoPhong()
                            + " đang có khách. Hãy thực hiện Trả phòng trước khi chuyển sang trạng thái dọn dẹp."
            );
            return;
        } else if (currentStatus == TrangThaiPhong.DA_DAT) {
            showWarning(
                    "Phòng " + selectedRoom.getSoPhong()
                            + " đang được giữ cho khách đã đặt. Không thể chuyển trạng thái dọn dẹp tại đây."
            );
            return;
        } else {
            showWarning(
                    "Phòng " + selectedRoom.getSoPhong()
                            + " đang bảo trì. Hãy cập nhật trạng thái bảo trì bằng chức năng Sửa trước."
            );
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                this,
                confirmationMessage,
                "Cập nhật trạng thái dọn dẹp",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        setBusy(true, "Đang cập nhật trạng thái dọn dẹp...");

        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                selectedRoom.setTrangThai(targetStatus);
                return phongDAO.update(selectedRoom);
            }

            @Override
            protected void done() {
                try {
                    boolean updated = get();
                    if (!updated) {
                        setBusy(false, "Không tìm thấy phòng cần cập nhật.");
                        showWarning("Phòng đã không còn tồn tại.");
                        loadRoomsAsync();
                        return;
                    }

                    setBusy(false, "Đã cập nhật trạng thái dọn dẹp.");
                    JOptionPane.showMessageDialog(
                            PhongView.this,
                            "Phòng " + selectedRoom.getSoPhong()
                                    + " đã chuyển sang trạng thái: " + displayStatus(targetStatus) + ".",
                            "Cập nhật thành công",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    loadRoomsAsync();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Cập nhật trạng thái bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể cập nhật trạng thái dọn dẹp.");
                    showDatabaseError("Cập nhật trạng thái dọn dẹp", exception.getCause());
                }
            }
        };

        worker.execute();
    }

    private boolean validateRoomForm(boolean editing) {
        String roomNumber = txtSoPhong.getText() == null ? "" : txtSoPhong.getText().trim();
        if (roomNumber.isBlank()) {
            showValidationError("Số phòng không được để trống.", txtSoPhong);
            return false;
        }

        if (roomNumber.length() > MAX_ROOM_NUMBER_LENGTH) {
            showValidationError(
                    "Số phòng không được vượt quá " + MAX_ROOM_NUMBER_LENGTH + " ký tự.",
                    txtSoPhong
            );
            return false;
        }

        if (!roomNumber.matches("[A-Za-z0-9-]+")) {
            showValidationError(
                    "Số phòng chỉ được chứa chữ cái không dấu, chữ số hoặc dấu gạch ngang.",
                    txtSoPhong
            );
            return false;
        }

        LoaiPhong selectedRoomType = (LoaiPhong) cboLoaiPhong.getSelectedItem();
        if (selectedRoomType == null || selectedRoomType.getId() == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn loại phòng hợp lệ.",
                    "Dữ liệu chưa hợp lệ",
                    JOptionPane.WARNING_MESSAGE
            );
            cboLoaiPhong.requestFocusInWindow();
            return false;
        }

        BigDecimal roomPrice = selectedRoomType.getGiaCoBan();
        if (roomPrice == null || roomPrice.compareTo(BigDecimal.ZERO) <= 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Giá phòng của loại đã chọn không phải là số tiền hợp lệ lớn hơn 0.\n"
                            + "Vui lòng kiểm tra lại dữ liệu loại phòng.",
                    "Giá phòng không hợp lệ",
                    JOptionPane.WARNING_MESSAGE
            );
            cboLoaiPhong.requestFocusInWindow();
            return false;
        }

        String floorText = txtTang.getText() == null ? "" : txtTang.getText().trim();
        if (floorText.isBlank()) {
            showValidationError("Tầng không được để trống.", txtTang);
            return false;
        }

        int floor;
        try {
            floor = Integer.parseInt(floorText);
        } catch (NumberFormatException exception) {
            showValidationError("Tầng phải là một số nguyên hợp lệ.", txtTang);
            return false;
        }

        if (floor < 0) {
            showValidationError("Tầng phải lớn hơn hoặc bằng 0.", txtTang);
            return false;
        }

        if (floor > 200) {
            showValidationError("Tầng nhập vào quá lớn. Vui lòng kiểm tra lại.", txtTang);
            return false;
        }

        if (cboTrangThai.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn trạng thái phòng.",
                    "Dữ liệu chưa hợp lệ",
                    JOptionPane.WARNING_MESSAGE
            );
            cboTrangThai.requestFocusInWindow();
            return false;
        }

        String note = txtGhiChu.getText() == null ? "" : txtGhiChu.getText().trim();
        if (note.length() > MAX_NOTE_LENGTH) {
            JOptionPane.showMessageDialog(
                    this,
                    "Ghi chú không được vượt quá " + MAX_NOTE_LENGTH + " ký tự.",
                    "Dữ liệu chưa hợp lệ",
                    JOptionPane.WARNING_MESSAGE
            );
            txtGhiChu.requestFocusInWindow();
            return false;
        }

        if (editing && phongDangChonId == null) {
            showWarning("Không xác định được phòng đang sửa. Vui lòng chọn lại phòng trong bảng.");
            return false;
        }

        return true;
    }

    private Phong createRoomFromForm() {
        Phong room = new Phong();
        room.setId(phongDangChonId);
        room.setSoPhong(txtSoPhong.getText().trim().toUpperCase(Locale.ROOT));

        LoaiPhong selectedRoomType = (LoaiPhong) cboLoaiPhong.getSelectedItem();
        room.setLoaiPhongId(selectedRoomType.getId());
        room.setTang(Integer.parseInt(txtTang.getText().trim()));
        room.setTrangThai((TrangThaiPhong) cboTrangThai.getSelectedItem());

        String note = txtGhiChu.getText() == null ? "" : txtGhiChu.getText().trim();
        room.setGhiChu(note.isBlank() ? null : note);
        room.setDangHoatDong(chkDangHoatDong.isSelected());
        return room;
    }

    private void fillFormFromSelectedTableRow() {
        Phong selectedRoom = getSelectedRoom();
        if (selectedRoom == null) {
            return;
        }

        phongDangChonId = selectedRoom.getId();
        txtSoPhong.setText(selectedRoom.getSoPhong());
        txtTang.setText(String.valueOf(selectedRoom.getTang()));
        cboTrangThai.setSelectedItem(selectedRoom.getTrangThai());
        txtGhiChu.setText(selectedRoom.getGhiChu() == null ? "" : selectedRoom.getGhiChu());
        chkDangHoatDong.setSelected(selectedRoom.isDangHoatDong());

        selectRoomTypeById(selectedRoom.getLoaiPhongId());
        updateRoomPriceField();
        lblThongBao.setText("Đã chọn phòng " + selectedRoom.getSoPhong() + ".");
    }

    private Phong getSelectedRoom() {
        int viewRow = tblPhong.getSelectedRow();
        if (viewRow < 0) {
            return null;
        }

        int modelRow = tblPhong.convertRowIndexToModel(viewRow);
        if (modelRow < 0 || modelRow >= danhSachPhongDangHienThi.size()) {
            return null;
        }

        return danhSachPhongDangHienThi.get(modelRow);
    }

    private void selectRoomTypeById(Integer roomTypeId) {
        if (roomTypeId == null) {
            cboLoaiPhong.setSelectedIndex(-1);
            return;
        }

        for (int index = 0; index < cboLoaiPhong.getItemCount(); index++) {
            LoaiPhong roomType = cboLoaiPhong.getItemAt(index);
            if (roomType != null && roomTypeId.equals(roomType.getId())) {
                cboLoaiPhong.setSelectedIndex(index);
                return;
            }
        }

        cboLoaiPhong.setSelectedIndex(-1);
    }

    private void clearForm() {
        phongDangChonId = null;
        txtSoPhong.setText("");
        txtTang.setText("");
        txtGhiChu.setText("");
        chkDangHoatDong.setSelected(true);
        cboTrangThai.setSelectedItem(TrangThaiPhong.TRONG);

        if (cboLoaiPhong.getItemCount() > 0) {
            cboLoaiPhong.setSelectedIndex(0);
        } else {
            cboLoaiPhong.setSelectedIndex(-1);
        }

        updateRoomPriceField();
        tblPhong.clearSelection();
        txtSoPhong.requestFocusInWindow();
    }

    private void updateRoomPriceField() {
        LoaiPhong selectedRoomType = (LoaiPhong) cboLoaiPhong.getSelectedItem();
        if (selectedRoomType == null || selectedRoomType.getGiaCoBan() == null) {
            txtGiaPhong.setText("");
            return;
        }

        NumberFormat numberFormat = NumberFormat.getNumberInstance(new Locale("vi", "VN"));
        numberFormat.setMaximumFractionDigits(0);
        txtGiaPhong.setText(numberFormat.format(selectedRoomType.getGiaCoBan()));
    }

    private void setRoomTypes(List<LoaiPhong> roomTypes) {
        loaiPhongTheoId.clear();
        DefaultComboBoxModel<LoaiPhong> comboBoxModel = new DefaultComboBoxModel<>();

        for (LoaiPhong roomType : roomTypes) {
            if (roomType.getId() != null) {
                loaiPhongTheoId.put(roomType.getId(), roomType);
            }
            comboBoxModel.addElement(roomType);
        }

        cboLoaiPhong.setModel(comboBoxModel);
        if (comboBoxModel.getSize() > 0) {
            cboLoaiPhong.setSelectedIndex(0);
        }
        updateRoomPriceField();
    }

    private void showRoomList(List<Phong> rooms) {
        danhSachPhongDangHienThi.clear();
        danhSachPhongDangHienThi.addAll(rooms);
        tableModel.setRowCount(0);

        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));
        currencyFormat.setMaximumFractionDigits(0);

        for (Phong room : rooms) {
            LoaiPhong roomType = loaiPhongTheoId.get(room.getLoaiPhongId());
            String roomTypeName = roomType == null
                    ? "Không xác định"
                    : roomType.getTenLoaiPhong();

            String priceText = roomType == null || roomType.getGiaCoBan() == null
                    ? "-"
                    : currencyFormat.format(roomType.getGiaCoBan());

            tableModel.addRow(new Object[]{
                    room.getSoPhong(),
                    roomTypeName,
                    priceText,
                    room.getTang(),
                    displayStatus(room.getTrangThai()),
                    room.getGhiChu() == null ? "" : room.getGhiChu(),
                    room.isDangHoatDong() ? "Có" : "Ngừng"
            });
        }

        lblTongSoPhong.setText("Tổng số phòng: " + rooms.size());
    }

    private String displayStatus(TrangThaiPhong status) {
        if (status == null) {
            return "Không xác định";
        }

        return switch (status) {
            case TRONG -> "Trống";
            case DA_DAT -> "Đã đặt";
            case DANG_O -> "Có khách";
            case DANG_DON -> "Đang dọn dẹp";
            case BAO_TRI -> "Bảo trì";
        };
    }

    private void setBusy(boolean busy, String message) {
        dangXuLy = busy;
        setCursor(busy
                ? Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR)
                : Cursor.getDefaultCursor());

        boolean canManageRoom = loginSession == null
                || loginSession.hasRole("ADMIN")
                || loginSession.hasRole("LE_TAN");

        boolean canUpdateCleaning = loginSession == null
                || canManageRoom
                || loginSession.hasRole("BUONG_PHONG");

        ButtonUtils.applyEnabledState(btnThem, !busy && canManageRoom);
        ButtonUtils.applyEnabledState(btnSua, !busy && canManageRoom);
        ButtonUtils.applyEnabledState(btnXoa, !busy && canManageRoom);
        ButtonUtils.applyEnabledState(btnCapNhatDonDep, !busy && canUpdateCleaning);
        ButtonUtils.applyEnabledState(btnLamMoiForm, !busy);
        ButtonUtils.applyEnabledState(btnTimKiem, !busy);
        ButtonUtils.applyEnabledState(btnTaiLai, !busy);
        txtTimKiem.setEnabled(!busy);
        cboLocTrangThai.setEnabled(!busy);
        tblPhong.setEnabled(!busy);

        lblThongBao.setText(message == null || message.isBlank() ? "Sẵn sàng" : message);
    }

    private void showValidationError(String message, JTextField field) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Dữ liệu chưa hợp lệ",
                JOptionPane.WARNING_MESSAGE
        );
        field.requestFocusInWindow();
        field.selectAll();
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Cảnh báo",
                JOptionPane.WARNING_MESSAGE
        );
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Lỗi",
                JOptionPane.ERROR_MESSAGE
        );
    }

    private void handleDataOperationFailure(String operation, Throwable cause) {
        if (cause instanceof IllegalArgumentException illegalArgumentException) {
            showWarning(illegalArgumentException.getMessage());
            return;
        }

        if (cause instanceof SQLException sqlException) {
            if ("23000".equals(sqlException.getSQLState())) {
                showWarning(
                        "Không thể thực hiện " + operation.toLowerCase(Locale.ROOT)
                                + " vì dữ liệu bị trùng hoặc đang được bảng khác tham chiếu.\n"
                                + "Chi tiết: " + safeMessage(sqlException)
                );
            } else {
                showDatabaseError(operation, sqlException);
            }
            return;
        }

        showError(
                operation + " thất bại.\nChi tiết: " + safeMessage(cause)
        );
    }

    private void showDatabaseError(String operation, Throwable cause) {
        String detail = safeMessage(cause);
        JOptionPane.showMessageDialog(
                this,
                operation + " không thành công.\n\n"
                        + "Vui lòng kiểm tra kết nối MySQL và dữ liệu đầu vào.\n"
                        + "Chi tiết kỹ thuật: " + detail,
                "Lỗi cơ sở dữ liệu",
                JOptionPane.ERROR_MESSAGE
        );
    }

    private String safeMessage(Throwable throwable) {
        if (throwable == null) {
            return "Không xác định";
        }
        String message = throwable.getMessage();
        return message == null || message.isBlank()
                ? throwable.getClass().getSimpleName()
                : message;
    }

    private JPanel createCardPanel(BorderLayout layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(CARD_COLOR);
        return panel;
    }


    private final class RoomStatusCellRenderer extends DefaultTableCellRenderer {
        private RoomStatusCellRenderer() {
            setHorizontalAlignment(SwingConstants.CENTER);
        }

        @Override
        public Component getTableCellRendererComponent(
                JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row,
                int column) {

            Component component = super.getTableCellRendererComponent(
                    table,
                    value,
                    isSelected,
                    hasFocus,
                    row,
                    column
            );

            if (isSelected) {
                return component;
            }

            String text = value == null ? "" : value.toString();
            component.setForeground(TEXT_COLOR);

            if ("Trống".equals(text)) {
                component.setBackground(new Color(229, 247, 238));
                component.setForeground(SUCCESS_COLOR);
            } else if ("Có khách".equals(text)) {
                component.setBackground(new Color(252, 235, 235));
                component.setForeground(DANGER_COLOR);
            } else if ("Đang dọn dẹp".equals(text)) {
                component.setBackground(new Color(255, 244, 222));
                component.setForeground(WARNING_COLOR);
            } else if ("Đã đặt".equals(text)) {
                component.setBackground(new Color(231, 241, 253));
                component.setForeground(PRIMARY_COLOR);
            } else if ("Bảo trì".equals(text)) {
                component.setBackground(new Color(238, 238, 238));
                component.setForeground(new Color(90, 90, 90));
            } else {
                component.setBackground(Color.WHITE);
            }

            return component;
        }
    }

    private record InitialData(List<LoaiPhong> roomTypes, List<Phong> rooms) {
    }

    /**
     * Hàm main chỉ để kiểm thử PhongView độc lập trong IDE. Khi chạy ứng dụng
     * chính thức, PhongView được nhúng vào MainView sau khi đăng nhập.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Kiểm thử - Quản lý Phòng & Buồng phòng");
            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            frame.setMinimumSize(new Dimension(1180, 700));
            frame.setSize(1320, 780);
            frame.setLocationRelativeTo(null);
            frame.setContentPane(new PhongView());
            frame.setVisible(true);
        });
    }
}
