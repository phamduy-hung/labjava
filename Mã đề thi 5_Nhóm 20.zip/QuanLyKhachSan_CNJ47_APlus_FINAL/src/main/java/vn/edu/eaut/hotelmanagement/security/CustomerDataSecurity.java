package vn.edu.eaut.hotelmanagement.security;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Khởi tạo lớp bảo vệ dữ liệu khách hàng và tự động chuyển dữ liệu plaintext
 * của các bộ seed cũ sang AES-256-GCM ở lần chạy đầu tiên.
 */
public final class CustomerDataSecurity {

    private static final String[] ENCRYPTED_COLUMNS = {
            "ho_ten", "so_giay_to", "so_dien_thoai", "email", "dia_chi"
    };

    private CustomerDataSecurity() {
    }

    /**
     * Phải chạy sau khi kết nối CSDL sẵn sàng và trước khi mở màn hình đăng nhập.
     */
    public static MigrationResult initialize() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            connection.setAutoCommit(false);
            try {
                ensureColumnCapacity(connection);
                int migratedRows = migratePlaintextRows(connection);
                connection.commit();
                return new MigrationResult(migratedRows, ENCRYPTED_COLUMNS.length);
            } catch (SQLException | RuntimeException exception) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackException) {
                    exception.addSuppressed(rollbackException);
                }
                throw exception;
            } finally {
                try {
                    connection.setAutoCommit(true);
                } catch (SQLException ignored) {
                }
            }
        }
    }

    private static void ensureColumnCapacity(Connection connection) throws SQLException {
        // Ciphertext Base64 dài hơn plaintext. Chỉ ALTER khi schema hiện tại thực sự
        // nhỏ hơn yêu cầu; không sửa lại cột ở mọi lần khởi động.
        ensureVarcharCapacity(connection, "ho_ten", 512);
        ensureVarcharCapacity(connection, "so_giay_to", 256);
        ensureVarcharCapacity(connection, "so_dien_thoai", 128);
        ensureVarcharCapacity(connection, "email", 256);
        ensureVarcharCapacity(connection, "dia_chi", 512);
    }

    private static void ensureVarcharCapacity(Connection connection, String columnName, int requiredLength) throws SQLException {
        String metadataSql = "SELECT DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE "
                + "FROM information_schema.columns "
                + "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'khach_hang' AND COLUMN_NAME = ?";

        try (PreparedStatement metadata = connection.prepareStatement(metadataSql)) {
            metadata.setString(1, columnName);
            try (ResultSet rs = metadata.executeQuery()) {
                if (!rs.next()) {
                    throw new SQLException("Không tìm thấy cột khach_hang." + columnName + " để thiết lập mã hóa.");
                }

                String dataType = rs.getString("DATA_TYPE");
                long length = rs.getLong("CHARACTER_MAXIMUM_LENGTH");
                boolean lengthWasNull = rs.wasNull();

                if ("text".equalsIgnoreCase(dataType)
                        || "mediumtext".equalsIgnoreCase(dataType)
                        || "longtext".equalsIgnoreCase(dataType)
                        || (!lengthWasNull && length >= requiredLength)) {
                    return;
                }

                String nullable = "YES".equalsIgnoreCase(rs.getString("IS_NULLABLE"))
                        ? " NULL" : " NOT NULL";
                String sql = "ALTER TABLE khach_hang MODIFY COLUMN " + columnName
                        + " VARCHAR(" + requiredLength + ")" + nullable;
                try (Statement statement = connection.createStatement()) {
                    statement.executeUpdate(sql);
                }
            }
        }
    }

    private static int migratePlaintextRows(Connection connection) throws SQLException {
        String selectSql = "SELECT id, ho_ten, so_giay_to, so_dien_thoai, email, dia_chi FROM khach_hang FOR UPDATE";
        String updateSql = "UPDATE khach_hang SET ho_ten=?, so_giay_to=?, so_dien_thoai=?, email=?, dia_chi=? WHERE id=?";
        int migratedRows = 0;

        try (PreparedStatement select = connection.prepareStatement(selectSql);
             ResultSet rs = select.executeQuery();
             PreparedStatement update = connection.prepareStatement(updateSql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String hoTen = rs.getString("ho_ten");
                String soGiayTo = rs.getString("so_giay_to");
                String soDienThoai = rs.getString("so_dien_thoai");
                String email = rs.getString("email");
                String diaChi = rs.getString("dia_chi");

                boolean changed = false;
                String encryptedHoTen = encryptIfNeeded(hoTen);
                String encryptedSoGiayTo = encryptIfNeeded(soGiayTo);
                String encryptedSoDienThoai = encryptIfNeeded(soDienThoai);
                String encryptedEmail = encryptIfNeeded(email);
                String encryptedDiaChi = encryptIfNeeded(diaChi);

                changed |= !same(hoTen, encryptedHoTen);
                changed |= !same(soGiayTo, encryptedSoGiayTo);
                changed |= !same(soDienThoai, encryptedSoDienThoai);
                changed |= !same(email, encryptedEmail);
                changed |= !same(diaChi, encryptedDiaChi);

                if (changed) {
                    update.setString(1, encryptedHoTen);
                    update.setString(2, encryptedSoGiayTo);
                    update.setString(3, encryptedSoDienThoai);
                    update.setString(4, encryptedEmail);
                    update.setString(5, encryptedDiaChi);
                    update.setInt(6, id);
                    update.addBatch();
                    migratedRows++;
                }
            }
            if (migratedRows > 0) {
                update.executeBatch();
            }
        }
        return migratedRows;
    }

    private static String encryptIfNeeded(String value) {
        return value == null || value.isBlank() || CustomerDataCrypto.isEncrypted(value)
                ? value
                : CustomerDataCrypto.encrypt(value);
    }

    private static boolean same(String left, String right) {
        return left == null ? right == null : left.equals(right);
    }

    public record MigrationResult(int migratedRows, int protectedFieldsPerCustomer) {
    }
}
