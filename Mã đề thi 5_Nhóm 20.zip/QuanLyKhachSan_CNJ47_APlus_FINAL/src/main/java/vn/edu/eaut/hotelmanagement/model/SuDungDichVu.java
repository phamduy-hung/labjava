package vn.edu.eaut.hotelmanagement.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class SuDungDichVu {
    private Integer id;
    private Integer chiTietDatPhongId;
    private Integer dichVuId;
    private LocalDateTime thoiGianSuDung;
    private BigDecimal soLuong;
    private BigDecimal donGia;
    private BigDecimal thanhTien;
    private Integer nhanVienGhiNhanId;
    private String ghiChu;

    public SuDungDichVu() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChiTietDatPhongId() {
        return chiTietDatPhongId;
    }

    public void setChiTietDatPhongId(Integer chiTietDatPhongId) {
        this.chiTietDatPhongId = chiTietDatPhongId;
    }

    public Integer getDichVuId() {
        return dichVuId;
    }

    public void setDichVuId(Integer dichVuId) {
        this.dichVuId = dichVuId;
    }

    public LocalDateTime getThoiGianSuDung() {
        return thoiGianSuDung;
    }

    public void setThoiGianSuDung(LocalDateTime thoiGianSuDung) {
        this.thoiGianSuDung = thoiGianSuDung;
    }

    public BigDecimal getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(BigDecimal soLuong) {
        this.soLuong = soLuong;
    }

    public BigDecimal getDonGia() {
        return donGia;
    }

    public void setDonGia(BigDecimal donGia) {
        this.donGia = donGia;
    }

    public BigDecimal getThanhTien() {
        return thanhTien;
    }

    /**
     * Trường này được MySQL GENERATED ALWAYS tính tự động.
     * DAO chỉ dùng setter này khi đọc dữ liệu từ ResultSet, không dùng khi INSERT/UPDATE.
     */
    public void setThanhTien(BigDecimal thanhTien) {
        this.thanhTien = thanhTien;
    }

    public Integer getNhanVienGhiNhanId() {
        return nhanVienGhiNhanId;
    }

    public void setNhanVienGhiNhanId(Integer nhanVienGhiNhanId) {
        this.nhanVienGhiNhanId = nhanVienGhiNhanId;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }
}
