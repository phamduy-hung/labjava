package vn.edu.eaut.hotelmanagement.view;

import vn.edu.eaut.hotelmanagement.dao.KhachHangDAO;
import vn.edu.eaut.hotelmanagement.model.KhachHang;
import vn.edu.eaut.hotelmanagement.model.enums.GioiTinh;
import vn.edu.eaut.hotelmanagement.model.enums.LoaiGiayTo;
import vn.edu.eaut.hotelmanagement.security.CustomerDataCrypto;
import vn.edu.eaut.hotelmanagement.session.LoginSession;
import vn.edu.eaut.hotelmanagement.utils.ButtonUtils;
import vn.edu.eaut.hotelmanagement.utils.TableUtils;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.regex.Pattern;

/**
 * Màn hình Quản lý Khách hàng.
 *
 * Chức năng:
 * - Hiển thị danh sách khách hàng bằng JTable.
 * - Thêm, sửa, xóa khách hàng.
 * - Tìm kiếm theo tên hoặc số giấy tờ (CCCD/CMND/Hộ chiếu).
 * - Kiểm tra dữ liệu bắt buộc, ngày tháng, số điện thoại, email và giấy tờ.
 * - Kiểm tra trùng mã khách hàng và trùng giấy tờ trước khi lưu.
 * - Thao tác CSDL qua KhachHangDAO bằng SwingWorker để không khóa EDT.
 */
public class KhachHangView extends JPanel {

    private static final Color PRIMARY_COLOR = new Color(26, 83, 155);
    private static final Color PRIMARY_DARK_COLOR = new Color(17, 55, 105);
    private static final Color BACKGROUND_COLOR = new Color(244, 247, 251);
    private static final Color CARD_COLOR = Color.WHITE;
    private static final Color BORDER_COLOR = new Color(221, 228, 236);
    private static final Color TEXT_COLOR = new Color(38, 49, 64);
    private static final Color SECONDARY_TEXT_COLOR = new Color(105, 117, 133);
    private static final Color SUCCESS_COLOR = new Color(37, 137, 88);
    private static final Color DANGER_COLOR = new Color(184, 55, 55);

    private static final int MAX_CUSTOMER_CODE_LENGTH = 20;
    private static final int MAX_FULL_NAME_LENGTH = 100;
    private static final int MAX_IDENTITY_NUMBER_LENGTH = 30;
    private static final int MAX_PHONE_LENGTH = 15;
    private static final int MAX_EMAIL_LENGTH = 100;
    private static final int MAX_NATIONALITY_LENGTH = 60;
    private static final int MAX_ADDRESS_LENGTH = 255;
    private static final int MAX_NOTE_LENGTH = 500;

    private static final DateTimeFormatter DATE_FORMATTER =
            DateTimeFormatter.ofPattern("dd/MM/uuuu")
                    .withResolverStyle(ResolverStyle.STRICT);

    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@"
                    + "[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?"
                    + "(?:\\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$"
    );

    private final KhachHangDAO khachHangDAO;
    private final LoginSession loginSession;

    private final JTextField txtMaKhachHang = new JTextField(20);
    private final JTextField txtHoTen = new JTextField(20);
    private final JComboBox<Object> cboGioiTinh = new JComboBox<>();
    private final JTextField txtNgaySinh = new JTextField(20);
    private final JComboBox<LoaiGiayTo> cboLoaiGiayTo = new JComboBox<>(LoaiGiayTo.values());
    private final JTextField txtSoGiayTo = new JTextField(20);
    private final JTextField txtSoDienThoai = new JTextField(20);
    private final JTextField txtEmail = new JTextField(20);
    private final JTextField txtQuocTich = new JTextField(20);
    private final JTextField txtDiaChi = new JTextField(20);
    private final JTextArea txtGhiChu = new JTextArea(4, 20);

    private final JTextField txtTimKiem = new JTextField(26);

    private final JButton btnThem = new JButton("Thêm");
    private final JButton btnSua = new JButton("Sửa");
    private final JButton btnXoa = new JButton("Xóa");
    private final JButton btnLamMoiForm = new JButton("Làm mới form");
    private final JButton btnTimKiem = new JButton("Tìm kiếm");
    private final JButton btnTaiLai = new JButton("Tải lại");

    private final JLabel lblThongBao = new JLabel("Sẵn sàng");
    private final JLabel lblTongSoKhachHang = new JLabel("Tổng số khách hàng: 0");

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{
                    "Mã KH",
                    "Họ tên",
                    "CCCD / Passport",
                    "Số điện thoại",
                    "Giới tính"
            },
            0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tblKhachHang = new JTable(tableModel);
    private final List<KhachHang> danhSachKhachHangDangHienThi = new ArrayList<>();

    private Integer khachHangDangChonId;
    private boolean dangXuLy;
    private boolean coQuyenQuanLyKhachHang = true;

    /**
     * Constructor dùng để chạy thử độc lập.
     */
    public KhachHangView() {
        this(null, new KhachHangDAO());
    }

    /**
     * Constructor dùng khi nhúng vào MainView.
     */
    public KhachHangView(LoginSession loginSession) {
        this(loginSession, new KhachHangDAO());
    }

    /**
     * Constructor hỗ trợ kiểm thử với DAO được truyền từ ngoài vào.
     */
    public KhachHangView(LoginSession loginSession, KhachHangDAO khachHangDAO) {
        this.loginSession = loginSession;
        this.khachHangDAO = khachHangDAO;

        initializeLayout();
        initializeComponents();
        registerEvents();
        applyRolePermissions();
        loadCustomersAsync();
    }

    private void initializeLayout() {
        setLayout(new BorderLayout(0, 16));
        setBackground(BACKGROUND_COLOR);
        setBorder(new EmptyBorder(20, 20, 20, 20));
    }

    private void initializeComponents() {
        initializeGenderComboBox();
        txtQuocTich.setText("Việt Nam");
        txtNgaySinh.setToolTipText("Định dạng ngày sinh: dd/MM/yyyy. Có thể để trống nếu chưa có thông tin.");
        txtGhiChu.setLineWrap(true);
        txtGhiChu.setWrapStyleWord(true);
        txtGhiChu.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));

        add(createHeaderPanel(), BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                createFormPanel(),
                createTableArea()
        );
        splitPane.setBorder(null);
        splitPane.setDividerLocation(505);
        splitPane.setResizeWeight(0.0);
        splitPane.setContinuousLayout(true);

        add(splitPane, BorderLayout.CENTER);
        add(createStatusPanel(), BorderLayout.SOUTH);
    }

    private void initializeGenderComboBox() {
        cboGioiTinh.removeAllItems();
        cboGioiTinh.addItem("Chưa chọn");
        for (GioiTinh gioiTinh : GioiTinh.values()) {
            cboGioiTinh.addItem(gioiTinh);
        }
    }

    private JPanel createHeaderPanel() {
        JPanel panel = createCardPanel(new BorderLayout(12, 6));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(16, 18, 16, 18)
        ));

        JLabel lblTitle = new JLabel("QUẢN LÝ KHÁCH HÀNG");
        lblTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 21));
        lblTitle.setForeground(TEXT_COLOR);

        JLabel lblDescription = new JLabel(
                "Quản lý hồ sơ khách lưu trú. Dữ liệu định danh và liên hệ được mã hóa AES-256-GCM tại CSDL."
        );
        lblDescription.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        lblDescription.setForeground(SECONDARY_TEXT_COLOR);

        JPanel titlePanel = new JPanel(new GridBagLayout());
        titlePanel.setOpaque(false);
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.anchor = GridBagConstraints.WEST;
        constraints.weightx = 1.0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        titlePanel.add(lblTitle, constraints);

        constraints.gridy = 1;
        constraints.insets = new Insets(4, 0, 0, 0);
        titlePanel.add(lblDescription, constraints);

        JPanel badgePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        badgePanel.setOpaque(false);

        JLabel lblBadge = new JLabel("BẢO MẬT AES-256-GCM", SwingConstants.CENTER);
        lblBadge.setOpaque(true);
        lblBadge.setBackground(new Color(234, 242, 252));
        lblBadge.setForeground(PRIMARY_COLOR);
        lblBadge.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 11));
        lblBadge.setPreferredSize(new Dimension(112, 30));
        lblBadge.setBorder(BorderFactory.createLineBorder(new Color(198, 217, 241)));
        badgePanel.add(lblBadge);

        panel.add(titlePanel, BorderLayout.CENTER);
        panel.add(badgePanel, BorderLayout.EAST);
        return panel;
    }

    private JPanel createFormPanel() {
        JPanel outerPanel = new JPanel(new BorderLayout());
        outerPanel.setOpaque(false);
        outerPanel.setMinimumSize(new Dimension(500, 590));

        JPanel card = createCardPanel(new BorderLayout(0, 12));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(16, 16, 14, 16)
        ));

        JLabel lblFormTitle = new JLabel("THÔNG TIN KHÁCH HÀNG");
        lblFormTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
        lblFormTitle.setForeground(PRIMARY_DARK_COLOR);
        card.add(lblFormTitle, BorderLayout.NORTH);

        JPanel fieldsPanel = new JPanel(new GridBagLayout());
        fieldsPanel.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;

        addFormPair(fieldsPanel, c, 0, "Mã khách hàng (*)", txtMaKhachHang, "Họ tên (*)", txtHoTen);
        addFormPair(fieldsPanel, c, 1, "Giới tính", cboGioiTinh, "Ngày sinh", txtNgaySinh);
        addFormPair(fieldsPanel, c, 2, "Loại giấy tờ (*)", cboLoaiGiayTo, "Số CCCD/Passport (*)", txtSoGiayTo);
        addFormPair(fieldsPanel, c, 3, "Số điện thoại", txtSoDienThoai, "Email", txtEmail);
        addFormPair(fieldsPanel, c, 4, "Quốc tịch (*)", txtQuocTich, "Địa chỉ", txtDiaChi);

        JLabel lblNote = new JLabel("Ghi chú");
        lblNote.setForeground(TEXT_COLOR);
        lblNote.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 11));
        c.gridy = 5;
        c.gridx = 0;
        c.gridwidth = 1;
        c.weightx = 0;
        c.insets = new Insets(4, 0, 4, 8);
        fieldsPanel.add(lblNote, c);

        JScrollPane noteScrollPane = new JScrollPane(txtGhiChu);
        noteScrollPane.setPreferredSize(new Dimension(0, 62));
        c.gridx = 1;
        c.gridwidth = 3;
        c.weightx = 1;
        c.insets = new Insets(4, 0, 4, 0);
        fieldsPanel.add(noteScrollPane, c);

        card.add(fieldsPanel, BorderLayout.CENTER);
        card.add(createActionButtonPanel(), BorderLayout.SOUTH);
        outerPanel.add(card, BorderLayout.CENTER);
        return outerPanel;
    }

    private void addFormPair(
            JPanel panel,
            GridBagConstraints constraints,
            int row,
            String leftLabelText,
            Component leftComponent,
            String rightLabelText,
            Component rightComponent) {

        JLabel leftLabel = new JLabel(leftLabelText);
        leftLabel.setForeground(TEXT_COLOR);
        leftLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 11));
        constraints.gridy = row;
        constraints.gridx = 0;
        constraints.gridwidth = 1;
        constraints.weightx = 0;
        constraints.insets = new Insets(4, 0, 4, 8);
        panel.add(leftLabel, constraints);

        constraints.gridx = 1;
        constraints.weightx = 1;
        constraints.insets = new Insets(4, 0, 4, 12);
        panel.add(leftComponent, constraints);

        JLabel rightLabel = new JLabel(rightLabelText);
        rightLabel.setForeground(TEXT_COLOR);
        rightLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 11));
        constraints.gridx = 2;
        constraints.weightx = 0;
        constraints.insets = new Insets(4, 0, 4, 8);
        panel.add(rightLabel, constraints);

        constraints.gridx = 3;
        constraints.weightx = 1;
        constraints.insets = new Insets(4, 0, 4, 0);
        panel.add(rightComponent, constraints);
    }

    private JPanel createActionButtonPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);

        ButtonUtils.success(btnThem);
        ButtonUtils.primary(btnSua);
        ButtonUtils.danger(btnXoa);
        ButtonUtils.neutral(btnLamMoiForm);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.weightx = 1.0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(4, 0, 4, 6);
        panel.add(btnThem, constraints);

        constraints.gridx = 1;
        constraints.insets = new Insets(4, 6, 4, 0);
        panel.add(btnSua, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.insets = new Insets(4, 0, 4, 6);
        panel.add(btnXoa, constraints);

        constraints.gridx = 1;
        constraints.insets = new Insets(4, 6, 4, 0);
        panel.add(btnLamMoiForm, constraints);

        return panel;
    }

    private JPanel createTableArea() {
        JPanel panel = createCardPanel(new BorderLayout(0, 12));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(14, 14, 14, 14)
        ));

        panel.add(createSearchPanel(), BorderLayout.NORTH);

        configureTable();
        JScrollPane scrollPane = new JScrollPane(tblKhachHang);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        scrollPane.getViewport().setBackground(Color.WHITE);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        footer.setOpaque(false);
        lblTongSoKhachHang.setForeground(SECONDARY_TEXT_COLOR);
        lblTongSoKhachHang.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        footer.add(lblTongSoKhachHang);
        panel.add(footer, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);

        JLabel lblSearch = new JLabel("Tên / CCCD / Passport:");
        lblSearch.setForeground(TEXT_COLOR);
        lblSearch.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));

        ButtonUtils.primary(btnTimKiem);
        ButtonUtils.neutral(btnTaiLai);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(0, 0, 0, 8);
        constraints.anchor = GridBagConstraints.WEST;
        panel.add(lblSearch, constraints);

        constraints.gridx = 1;
        constraints.weightx = 1.0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        panel.add(txtTimKiem, constraints);

        constraints.gridx = 2;
        constraints.weightx = 0.0;
        constraints.fill = GridBagConstraints.NONE;
        constraints.insets = new Insets(0, 8, 0, 0);
        panel.add(btnTimKiem, constraints);

        constraints.gridx = 3;
        constraints.insets = new Insets(0, 6, 0, 0);
        panel.add(btnTaiLai, constraints);

        return panel;
    }

    private JPanel createStatusPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        lblThongBao.setForeground(SECONDARY_TEXT_COLOR);
        lblThongBao.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        panel.add(lblThongBao, BorderLayout.WEST);

        return panel;
    }

    private void addFormRow(
            JPanel panel,
            GridBagConstraints constraints,
            String labelText,
            Component component) {

        JLabel label = new JLabel(labelText);
        label.setForeground(TEXT_COLOR);
        label.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));

        constraints.gridx = 0;
        constraints.weightx = 0.0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(4, 0, 4, 10);
        panel.add(label, constraints);

        constraints.gridx = 1;
        constraints.weightx = 1.0;
        constraints.insets = new Insets(4, 0, 4, 0);
        panel.add(component, constraints);

        constraints.gridy++;
    }

    private void configureTable() {
        TableUtils.setupTable(tblKhachHang);

        // Các cột mã KH, số điện thoại và giới tính được căn giữa.
        TableUtils.centerColumn(tblKhachHang, 0);
        TableUtils.centerColumn(tblKhachHang, 3);
        TableUtils.centerColumn(tblKhachHang, 4);
    }

    private void registerEvents() {
        tblKhachHang.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                fillFormFromSelectedTableRow();
            }
        });

        btnThem.addActionListener(event -> handleAddCustomer());
        btnSua.addActionListener(event -> handleUpdateCustomer());
        btnXoa.addActionListener(event -> handleDeleteCustomer());
        btnLamMoiForm.addActionListener(event -> clearForm());
        btnTimKiem.addActionListener(event -> performSearch());
        btnTaiLai.addActionListener(event -> {
            txtTimKiem.setText("");
            loadCustomersAsync();
        });

        txtTimKiem.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent event) {
                if (event.getKeyCode() == KeyEvent.VK_ENTER) {
                    performSearch();
                }
            }
        });
    }

    private void applyRolePermissions() {
        coQuyenQuanLyKhachHang = true;

        if (loginSession != null) {
            coQuyenQuanLyKhachHang = loginSession.hasRole("ADMIN")
                    || loginSession.hasRole("LE_TAN");
        }

        applyEditableState();

        if (!coQuyenQuanLyKhachHang && loginSession != null) {
            lblThongBao.setText("Tài khoản hiện tại chỉ được xem dữ liệu khách hàng.");
        }
    }

    private void applyEditableState() {
        boolean enabled = coQuyenQuanLyKhachHang && !dangXuLy;

        ButtonUtils.applyEnabledState(btnThem, enabled);
        ButtonUtils.applyEnabledState(btnSua, enabled);
        ButtonUtils.applyEnabledState(btnXoa, enabled);
        ButtonUtils.applyEnabledState(btnLamMoiForm, !dangXuLy);
        ButtonUtils.applyEnabledState(btnTimKiem, !dangXuLy);
        ButtonUtils.applyEnabledState(btnTaiLai, !dangXuLy);
        txtTimKiem.setEnabled(!dangXuLy);

        txtMaKhachHang.setEditable(enabled);
        txtHoTen.setEditable(enabled);
        cboGioiTinh.setEnabled(enabled);
        txtNgaySinh.setEditable(enabled);
        cboLoaiGiayTo.setEnabled(enabled);
        txtSoGiayTo.setEditable(enabled);
        txtSoDienThoai.setEditable(enabled);
        txtEmail.setEditable(enabled);
        txtQuocTich.setEditable(enabled);
        txtDiaChi.setEditable(enabled);
        txtGhiChu.setEditable(enabled);
    }

    private void loadCustomersAsync() {
        setBusy(true, "Đang tải danh sách khách hàng...");

        SwingWorker<List<KhachHang>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<KhachHang> doInBackground() throws Exception {
                return khachHangDAO.findAll();
            }

            @Override
            protected void done() {
                try {
                    List<KhachHang> customers = get();
                    showCustomerList(customers);
                    clearForm();
                    setBusy(false, "Tải danh sách khách hàng thành công.");
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Quá trình tải dữ liệu bị gián đoạn.");
                    showError("Không thể tải danh sách khách hàng vì tác vụ đã bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tải danh sách khách hàng.");
                    showDatabaseError("Tải danh sách khách hàng", exception.getCause());
                }
            }
        };

        worker.execute();
    }

    private void performSearch() {
        String keyword = txtTimKiem.getText() == null ? "" : txtTimKiem.getText().trim();

        if (keyword.length() > 100) {
            showValidationError("Từ khóa tìm kiếm không được vượt quá 100 ký tự.", txtTimKiem);
            return;
        }

        setBusy(true, keyword.isBlank()
                ? "Đang tải toàn bộ khách hàng..."
                : "Đang tìm kiếm khách hàng...");

        SwingWorker<List<KhachHang>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<KhachHang> doInBackground() throws Exception {
                if (keyword.isBlank()) {
                    return khachHangDAO.findAll();
                }
                return khachHangDAO.search(keyword);
            }

            @Override
            protected void done() {
                try {
                    List<KhachHang> result = get();
                    showCustomerList(result);
                    clearForm();
                    setBusy(false, "Tìm thấy " + result.size() + " khách hàng phù hợp.");

                    if (result.isEmpty() && !keyword.isBlank()) {
                        JOptionPane.showMessageDialog(
                                KhachHangView.this,
                                "Không tìm thấy khách hàng có tên hoặc số giấy tờ phù hợp với từ khóa:\n"
                                        + keyword,
                                "Không có kết quả",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                    }
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Tìm kiếm bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tìm kiếm khách hàng.");
                    showDatabaseError("Tìm kiếm khách hàng", exception.getCause());
                }
            }
        };

        worker.execute();
    }

    private void handleAddCustomer() {
        if (!coQuyenQuanLyKhachHang) {
            showWarning("Tài khoản hiện tại không có quyền thêm khách hàng.");
            return;
        }

        ValidationResult validationResult = validateCustomerForm();
        if (!validationResult.valid()) {
            return;
        }

        KhachHang customer = createCustomerFromForm(validationResult.birthDate());

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Xác nhận thêm khách hàng mới?\n\n"
                        + "Mã khách hàng: " + customer.getMaKhachHang() + "\n"
                        + "Họ tên: " + customer.getHoTen() + "\n"
                        + "Giấy tờ: " + customer.getLoaiGiayTo() + " - " + customer.getSoGiayTo(),
                "Xác nhận thêm khách hàng",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        setBusy(true, "Đang thêm khách hàng " + customer.getMaKhachHang() + "...");

        SwingWorker<Integer, Void> worker = new SwingWorker<>() {
            @Override
            protected Integer doInBackground() throws Exception {
                ensureCustomerIsUnique(customer, null);
                return khachHangDAO.insert(customer);
            }

            @Override
            protected void done() {
                try {
                    int generatedId = get();
                    setBusy(false, "Thêm khách hàng thành công.");
                    JOptionPane.showMessageDialog(
                            KhachHangView.this,
                            "Đã thêm khách hàng " + customer.getHoTen()
                                    + " thành công.\nID: " + generatedId,
                            "Thành công",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    loadCustomersAsync();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Thêm khách hàng bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể thêm khách hàng.");
                    handleDataOperationFailure("Thêm khách hàng", exception.getCause());
                }
            }
        };

        worker.execute();
    }

    private void handleUpdateCustomer() {
        if (!coQuyenQuanLyKhachHang) {
            showWarning("Tài khoản hiện tại không có quyền sửa khách hàng.");
            return;
        }

        if (khachHangDangChonId == null) {
            showWarning("Vui lòng chọn một khách hàng trong bảng trước khi sửa.");
            return;
        }

        ValidationResult validationResult = validateCustomerForm();
        if (!validationResult.valid()) {
            return;
        }

        KhachHang customer = createCustomerFromForm(validationResult.birthDate());
        customer.setId(khachHangDangChonId);

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc chắn muốn cập nhật thông tin khách hàng:\n"
                        + customer.getMaKhachHang() + " - " + customer.getHoTen() + "?",
                "Xác nhận sửa khách hàng",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        setBusy(true, "Đang cập nhật khách hàng " + customer.getMaKhachHang() + "...");

        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                ensureCustomerIsUnique(customer, customer.getId());
                return khachHangDAO.update(customer);
            }

            @Override
            protected void done() {
                try {
                    boolean updated = get();

                    if (!updated) {
                        setBusy(false, "Không tìm thấy khách hàng cần cập nhật.");
                        showWarning("Khách hàng đã không còn tồn tại hoặc đã bị thay đổi bởi thao tác khác.");
                        loadCustomersAsync();
                        return;
                    }

                    setBusy(false, "Cập nhật khách hàng thành công.");
                    JOptionPane.showMessageDialog(
                            KhachHangView.this,
                            "Cập nhật thông tin khách hàng thành công.",
                            "Thành công",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    loadCustomersAsync();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Cập nhật khách hàng bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể cập nhật khách hàng.");
                    handleDataOperationFailure("Cập nhật khách hàng", exception.getCause());
                }
            }
        };

        worker.execute();
    }

    private void handleDeleteCustomer() {
        if (!coQuyenQuanLyKhachHang) {
            showWarning("Tài khoản hiện tại không có quyền xóa khách hàng.");
            return;
        }

        KhachHang selectedCustomer = getSelectedCustomer();
        if (selectedCustomer == null) {
            showWarning("Vui lòng chọn khách hàng cần xóa trong bảng.");
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc chắn muốn xóa khách hàng sau?\n\n"
                        + "Mã khách hàng: " + selectedCustomer.getMaKhachHang() + "\n"
                        + "Họ tên: " + selectedCustomer.getHoTen() + "\n"
                        + "Giấy tờ: " + selectedCustomer.getLoaiGiayTo() + " - "
                        + selectedCustomer.getSoGiayTo() + "\n\n"
                        + "Nếu khách hàng đã có lịch sử đặt phòng, CSDL sẽ từ chối xóa để bảo toàn dữ liệu.",
                "Xác nhận xóa khách hàng",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        setBusy(true, "Đang xóa khách hàng " + selectedCustomer.getMaKhachHang() + "...");

        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                return khachHangDAO.deleteById(selectedCustomer.getId());
            }

            @Override
            protected void done() {
                try {
                    boolean deleted = get();

                    if (!deleted) {
                        setBusy(false, "Không tìm thấy khách hàng cần xóa.");
                        showWarning("Khách hàng đã không còn tồn tại.");
                        loadCustomersAsync();
                        return;
                    }

                    setBusy(false, "Xóa khách hàng thành công.");
                    JOptionPane.showMessageDialog(
                            KhachHangView.this,
                            "Đã xóa khách hàng " + selectedCustomer.getHoTen() + ".",
                            "Thành công",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    loadCustomersAsync();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Xóa khách hàng bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể xóa khách hàng.");
                    Throwable cause = exception.getCause();
                    SQLException sqlException = findSQLException(cause);

                    if (sqlException != null && "23000".equals(sqlException.getSQLState())) {
                        showWarning(
                                "Không thể xóa khách hàng vì khách hàng đã phát sinh đặt phòng, hóa đơn hoặc dữ liệu liên quan.\n"
                                        + "Hệ thống giữ lại hồ sơ này để bảo toàn lịch sử nghiệp vụ."
                        );
                    } else {
                        showDatabaseError("Xóa khách hàng", cause);
                    }
                }
            }
        };

        worker.execute();
    }

    private ValidationResult validateCustomerForm() {
        String customerCode = safeTrim(txtMaKhachHang.getText());
        String fullName = safeTrim(txtHoTen.getText());
        String identityNumber = normalizeIdentityNumber(
                (LoaiGiayTo) cboLoaiGiayTo.getSelectedItem(),
                txtSoGiayTo.getText()
        );
        String phoneNumber = safeTrim(txtSoDienThoai.getText());
        String email = safeTrim(txtEmail.getText());
        String nationality = safeTrim(txtQuocTich.getText());
        String address = safeTrim(txtDiaChi.getText());
        String note = safeTrim(txtGhiChu.getText());

        if (customerCode.isBlank()) {
            showValidationError("Mã khách hàng không được để trống.", txtMaKhachHang);
            return ValidationResult.invalid();
        }

        if (customerCode.length() > MAX_CUSTOMER_CODE_LENGTH) {
            showValidationError(
                    "Mã khách hàng không được vượt quá " + MAX_CUSTOMER_CODE_LENGTH + " ký tự.",
                    txtMaKhachHang
            );
            return ValidationResult.invalid();
        }

        if (!customerCode.matches("[A-Za-z0-9_-]+")) {
            showValidationError(
                    "Mã khách hàng chỉ được chứa chữ cái không dấu, chữ số, gạch ngang hoặc gạch dưới.",
                    txtMaKhachHang
            );
            return ValidationResult.invalid();
        }

        if (fullName.isBlank()) {
            showValidationError("Họ tên khách hàng không được để trống.", txtHoTen);
            return ValidationResult.invalid();
        }

        if (fullName.length() > MAX_FULL_NAME_LENGTH) {
            showValidationError(
                    "Họ tên khách hàng không được vượt quá " + MAX_FULL_NAME_LENGTH + " ký tự.",
                    txtHoTen
            );
            return ValidationResult.invalid();
        }

        LoaiGiayTo identityType = (LoaiGiayTo) cboLoaiGiayTo.getSelectedItem();
        if (identityType == null) {
            showValidationError("Vui lòng chọn loại giấy tờ.", cboLoaiGiayTo);
            return ValidationResult.invalid();
        }

        if (identityNumber.isBlank()) {
            showValidationError("Số CCCD/Passport không được để trống.", txtSoGiayTo);
            return ValidationResult.invalid();
        }

        if (identityNumber.length() > MAX_IDENTITY_NUMBER_LENGTH) {
            showValidationError(
                    "Số giấy tờ không được vượt quá " + MAX_IDENTITY_NUMBER_LENGTH + " ký tự.",
                    txtSoGiayTo
            );
            return ValidationResult.invalid();
        }

        if (!isIdentityNumberValid(identityType, identityNumber)) {
            showIdentityValidationMessage(identityType);
            return ValidationResult.invalid();
        }

        if (!phoneNumber.isBlank()) {
            if (phoneNumber.length() > MAX_PHONE_LENGTH) {
                showValidationError(
                        "Số điện thoại không được vượt quá " + MAX_PHONE_LENGTH + " ký tự.",
                        txtSoDienThoai
                );
                return ValidationResult.invalid();
            }

            if (!phoneNumber.matches("\\+?\\d{9,14}")) {
                showValidationError(
                        "Số điện thoại phải gồm 9 đến 14 chữ số và có thể bắt đầu bằng dấu +.\n"
                                + "Ví dụ: 0912345678 hoặc +84912345678.",
                        txtSoDienThoai
                );
                return ValidationResult.invalid();
            }
        }

        if (!email.isBlank()) {
            if (email.length() > MAX_EMAIL_LENGTH) {
                showValidationError(
                        "Email không được vượt quá " + MAX_EMAIL_LENGTH + " ký tự.",
                        txtEmail
                );
                return ValidationResult.invalid();
            }

            if (!EMAIL_PATTERN.matcher(email).matches()) {
                showValidationError("Email không đúng định dạng.", txtEmail);
                return ValidationResult.invalid();
            }
        }

        if (nationality.isBlank()) {
            showValidationError("Quốc tịch không được để trống.", txtQuocTich);
            return ValidationResult.invalid();
        }

        if (nationality.length() > MAX_NATIONALITY_LENGTH) {
            showValidationError(
                    "Quốc tịch không được vượt quá " + MAX_NATIONALITY_LENGTH + " ký tự.",
                    txtQuocTich
            );
            return ValidationResult.invalid();
        }

        if (address.length() > MAX_ADDRESS_LENGTH) {
            showValidationError(
                    "Địa chỉ không được vượt quá " + MAX_ADDRESS_LENGTH + " ký tự.",
                    txtDiaChi
            );
            return ValidationResult.invalid();
        }

        if (note.length() > MAX_NOTE_LENGTH) {
            showValidationError(
                    "Ghi chú không được vượt quá " + MAX_NOTE_LENGTH + " ký tự.",
                    txtGhiChu
            );
            return ValidationResult.invalid();
        }

        LocalDate birthDate = null;
        String birthDateText = safeTrim(txtNgaySinh.getText());
        if (!birthDateText.isBlank()) {
            try {
                birthDate = LocalDate.parse(birthDateText, DATE_FORMATTER);
            } catch (DateTimeParseException exception) {
                showValidationError(
                        "Ngày sinh không hợp lệ. Vui lòng nhập đúng định dạng dd/MM/yyyy.\nVí dụ: 20/05/1988.",
                        txtNgaySinh
                );
                return ValidationResult.invalid();
            }

            if (birthDate.isAfter(LocalDate.now())) {
                showValidationError("Ngày sinh không được lớn hơn ngày hiện tại.", txtNgaySinh);
                return ValidationResult.invalid();
            }

            if (birthDate.isBefore(LocalDate.of(1900, 1, 1))) {
                showValidationError("Ngày sinh phải từ 01/01/1900 trở đi.", txtNgaySinh);
                return ValidationResult.invalid();
            }
        }

        return ValidationResult.valid(birthDate);
    }

    private void showIdentityValidationMessage(LoaiGiayTo identityType) {
        String message = switch (identityType) {
            case CCCD -> "CCCD phải gồm đúng 12 chữ số.";
            case CMND -> "CMND phải gồm 9 hoặc 12 chữ số.";
            case HO_CHIEU -> "Số hộ chiếu phải gồm 6 đến 20 ký tự chữ và số, không có khoảng trắng.";
            case KHAC -> "Số giấy tờ phải có từ 3 đến 30 ký tự chữ, số, dấu gạch ngang hoặc dấu /.";
        };

        showValidationError(message, txtSoGiayTo);
    }

    private boolean isIdentityNumberValid(LoaiGiayTo identityType, String identityNumber) {
        if (identityType == null) {
            return false;
        }

        return switch (identityType) {
            case CCCD -> identityNumber.matches("\\d{12}");
            case CMND -> identityNumber.matches("(?:\\d{9}|\\d{12})");
            case HO_CHIEU -> identityNumber.matches("[A-Za-z0-9]{6,20}");
            case KHAC -> identityNumber.matches("[A-Za-z0-9/-]{3,30}");
        };
    }

    private KhachHang createCustomerFromForm(LocalDate birthDate) {
        KhachHang customer = new KhachHang();

        customer.setMaKhachHang(safeTrim(txtMaKhachHang.getText()).toUpperCase(Locale.ROOT));
        customer.setHoTen(safeTrim(txtHoTen.getText()));
        customer.setGioiTinh(getSelectedGender());
        customer.setNgaySinh(birthDate);

        LoaiGiayTo identityType = (LoaiGiayTo) cboLoaiGiayTo.getSelectedItem();
        customer.setLoaiGiayTo(identityType);
        customer.setSoGiayTo(normalizeIdentityNumber(identityType, txtSoGiayTo.getText()));

        customer.setSoDienThoai(emptyToNull(safeTrim(txtSoDienThoai.getText())));
        customer.setEmail(emptyToNull(safeTrim(txtEmail.getText()).toLowerCase(Locale.ROOT)));
        customer.setQuocTich(safeTrim(txtQuocTich.getText()));
        customer.setDiaChi(emptyToNull(safeTrim(txtDiaChi.getText())));
        customer.setGhiChu(emptyToNull(safeTrim(txtGhiChu.getText())));

        return customer;
    }

    private void ensureCustomerIsUnique(KhachHang customer, Integer currentCustomerId) throws SQLException {
        Optional<KhachHang> sameCode = khachHangDAO.findByCode(customer.getMaKhachHang());
        if (sameCode.isPresent() && !sameId(sameCode.get().getId(), currentCustomerId)) {
            throw new IllegalArgumentException(
                    "Mã khách hàng " + customer.getMaKhachHang() + " đã tồn tại."
            );
        }

        Optional<KhachHang> sameIdentity = khachHangDAO.findByIdentityDocument(
                customer.getLoaiGiayTo(),
                customer.getSoGiayTo()
        );

        if (sameIdentity.isPresent() && !sameId(sameIdentity.get().getId(), currentCustomerId)) {
            throw new IllegalArgumentException(
                    "Giấy tờ " + customer.getLoaiGiayTo() + " - " + customer.getSoGiayTo()
                            + " đã được sử dụng cho khách hàng "
                            + sameIdentity.get().getMaKhachHang() + " - "
                            + sameIdentity.get().getHoTen() + "."
            );
        }
    }

    private boolean sameId(Integer left, Integer right) {
        if (left == null || right == null) {
            return false;
        }
        return left.equals(right);
    }

    private void showCustomerList(List<KhachHang> customers) {
        danhSachKhachHangDangHienThi.clear();
        danhSachKhachHangDangHienThi.addAll(customers);

        tableModel.setRowCount(0);

        for (KhachHang customer : customers) {
            tableModel.addRow(new Object[]{
                    customer.getMaKhachHang(),
                    customer.getHoTen(),
                    displayIdentityDocument(customer),
                    CustomerDataCrypto.maskIdentifier(displayNullable(customer.getSoDienThoai())),
                    customer.getGioiTinh() == null ? "Chưa cập nhật" : customer.getGioiTinh().toString()
            });
        }

        lblTongSoKhachHang.setText("Tổng số khách hàng: " + customers.size());
    }

    private String displayIdentityDocument(KhachHang customer) {
        String type = customer.getLoaiGiayTo() == null
                ? "Giấy tờ"
                : customer.getLoaiGiayTo().toString();
        String number = CustomerDataCrypto.maskIdentifier(displayNullable(customer.getSoGiayTo()));
        return type + " - " + number;
    }

    private void fillFormFromSelectedTableRow() {
        KhachHang selectedCustomer = getSelectedCustomer();
        if (selectedCustomer == null) {
            return;
        }

        khachHangDangChonId = selectedCustomer.getId();

        txtMaKhachHang.setText(selectedCustomer.getMaKhachHang());
        txtHoTen.setText(selectedCustomer.getHoTen());
        setSelectedGender(selectedCustomer.getGioiTinh());
        txtNgaySinh.setText(selectedCustomer.getNgaySinh() == null
                ? ""
                : selectedCustomer.getNgaySinh().format(DATE_FORMATTER));

        if (selectedCustomer.getLoaiGiayTo() != null) {
            cboLoaiGiayTo.setSelectedItem(selectedCustomer.getLoaiGiayTo());
        }

        txtSoGiayTo.setText(displayEditable(selectedCustomer.getSoGiayTo()));
        txtSoDienThoai.setText(displayEditable(selectedCustomer.getSoDienThoai()));
        txtEmail.setText(displayEditable(selectedCustomer.getEmail()));
        txtQuocTich.setText(displayEditable(selectedCustomer.getQuocTich()));
        txtDiaChi.setText(displayEditable(selectedCustomer.getDiaChi()));
        txtGhiChu.setText(displayEditable(selectedCustomer.getGhiChu()));

        lblThongBao.setText(
                "Đang chọn khách hàng: " + selectedCustomer.getMaKhachHang()
                        + " - " + selectedCustomer.getHoTen()
        );
    }

    private KhachHang getSelectedCustomer() {
        int selectedViewRow = tblKhachHang.getSelectedRow();
        if (selectedViewRow < 0) {
            return null;
        }

        int selectedModelRow = tblKhachHang.convertRowIndexToModel(selectedViewRow);
        if (selectedModelRow < 0 || selectedModelRow >= danhSachKhachHangDangHienThi.size()) {
            return null;
        }

        return danhSachKhachHangDangHienThi.get(selectedModelRow);
    }

    private void clearForm() {
        khachHangDangChonId = null;

        txtMaKhachHang.setText("");
        txtHoTen.setText("");
        cboGioiTinh.setSelectedIndex(0);
        txtNgaySinh.setText("");
        cboLoaiGiayTo.setSelectedItem(LoaiGiayTo.CCCD);
        txtSoGiayTo.setText("");
        txtSoDienThoai.setText("");
        txtEmail.setText("");
        txtQuocTich.setText("Việt Nam");
        txtDiaChi.setText("");
        txtGhiChu.setText("");

        tblKhachHang.clearSelection();
        txtMaKhachHang.requestFocusInWindow();
    }

    private GioiTinh getSelectedGender() {
        Object selectedItem = cboGioiTinh.getSelectedItem();
        return selectedItem instanceof GioiTinh gioiTinh ? gioiTinh : null;
    }

    private void setSelectedGender(GioiTinh gender) {
        if (gender == null) {
            cboGioiTinh.setSelectedIndex(0);
        } else {
            cboGioiTinh.setSelectedItem(gender);
        }
    }

    private String normalizeIdentityNumber(LoaiGiayTo identityType, String rawValue) {
        String value = safeTrim(rawValue);
        if (identityType == LoaiGiayTo.HO_CHIEU || identityType == LoaiGiayTo.KHAC) {
            return value.toUpperCase(Locale.ROOT);
        }
        return value;
    }

    private void setBusy(boolean busy, String message) {
        dangXuLy = busy;
        setCursor(busy
                ? Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR)
                : Cursor.getDefaultCursor());

        applyEditableState();
        tblKhachHang.setEnabled(!busy);
        lblThongBao.setText(message == null || message.isBlank() ? "Sẵn sàng" : message);
    }

    private void handleDataOperationFailure(String operationName, Throwable cause) {
        if (cause instanceof IllegalArgumentException illegalArgumentException) {
            showWarning(illegalArgumentException.getMessage());
            return;
        }

        SQLException sqlException = findSQLException(cause);
        if (sqlException != null && "23000".equals(sqlException.getSQLState())) {
            String databaseMessage = sqlException.getMessage() == null
                    ? ""
                    : sqlException.getMessage().toLowerCase(Locale.ROOT);

            if (databaseMessage.contains("ma_khach_hang")) {
                showWarning("Mã khách hàng đã tồn tại. Vui lòng sử dụng mã khác.");
            } else if (databaseMessage.contains("uq_khach_hang_giay_to")
                    || databaseMessage.contains("loai_giay_to")
                    || databaseMessage.contains("so_giay_to")) {
                showWarning("Số giấy tờ đã tồn tại cho loại giấy tờ đang chọn.");
            } else {
                showWarning(
                        "Dữ liệu vi phạm ràng buộc toàn vẹn của CSDL.\n"
                                + "Vui lòng kiểm tra mã khách hàng và giấy tờ định danh."
                );
            }
            return;
        }

        showDatabaseError(operationName, cause);
    }

    private SQLException findSQLException(Throwable throwable) {
        Throwable current = throwable;
        while (current != null) {
            if (current instanceof SQLException sqlException) {
                return sqlException;
            }
            current = current.getCause();
        }
        return null;
    }

    private void showDatabaseError(String operationName, Throwable cause) {
        SQLException sqlException = findSQLException(cause);
        String detail;

        if (sqlException != null) {
            detail = sqlException.getMessage();
        } else if (cause != null && cause.getMessage() != null) {
            detail = cause.getMessage();
        } else {
            detail = "Không xác định được nguyên nhân lỗi.";
        }

        JOptionPane.showMessageDialog(
                this,
                operationName + " thất bại.\n\nChi tiết kỹ thuật: " + detail,
                "Lỗi dữ liệu",
                JOptionPane.ERROR_MESSAGE
        );
    }

    private void showValidationError(String message, Component component) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Dữ liệu chưa hợp lệ",
                JOptionPane.WARNING_MESSAGE
        );

        if (component != null) {
            component.requestFocusInWindow();
        }
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Thông báo",
                JOptionPane.WARNING_MESSAGE
        );
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Lỗi",
                JOptionPane.ERROR_MESSAGE
        );
    }

    private JPanel createCardPanel(BorderLayout layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(CARD_COLOR);
        return panel;
    }


    private String displayNullable(String value) {
        return value == null || value.isBlank() ? "—" : value;
    }

    private String displayEditable(String value) {
        return value == null ? "" : value;
    }

    private String safeTrim(String value) {
        return value == null ? "" : value.trim();
    }

    private String emptyToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }

    /**
     * Chạy thử độc lập màn hình Khách hàng.
     * Khi chạy trong ứng dụng thật, MainView sẽ tạo KhachHangView(LoginSession).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Hotel Management - Quản lý Khách hàng");
            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            frame.setMinimumSize(new Dimension(1180, 720));
            frame.setSize(1320, 800);
            frame.setLocationRelativeTo(null);
            frame.setContentPane(new KhachHangView());
            frame.setVisible(true);
        });
    }

    private record ValidationResult(boolean valid, LocalDate birthDate) {
        private static ValidationResult valid(LocalDate birthDate) {
            return new ValidationResult(true, birthDate);
        }

        private static ValidationResult invalid() {
            return new ValidationResult(false, null);
        }
    }
}
