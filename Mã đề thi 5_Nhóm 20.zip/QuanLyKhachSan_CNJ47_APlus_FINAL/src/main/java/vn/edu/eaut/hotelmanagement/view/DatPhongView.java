package vn.edu.eaut.hotelmanagement.view;

import vn.edu.eaut.hotelmanagement.dao.ChiTietDatPhongDAO;
import vn.edu.eaut.hotelmanagement.dao.DatPhongDAO;
import vn.edu.eaut.hotelmanagement.dao.KhachHangDAO;
import vn.edu.eaut.hotelmanagement.dao.LoaiPhongDAO;
import vn.edu.eaut.hotelmanagement.dao.PhongDAO;
import vn.edu.eaut.hotelmanagement.model.ChiTietDatPhong;
import vn.edu.eaut.hotelmanagement.model.DatPhong;
import vn.edu.eaut.hotelmanagement.model.KhachHang;
import vn.edu.eaut.hotelmanagement.security.CustomerDataCrypto;
import vn.edu.eaut.hotelmanagement.model.LoaiPhong;
import vn.edu.eaut.hotelmanagement.model.Phong;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiDatPhong;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiPhong;
import vn.edu.eaut.hotelmanagement.session.LoginSession;
import vn.edu.eaut.hotelmanagement.utils.ButtonUtils;
import vn.edu.eaut.hotelmanagement.utils.TableUtils;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

/**
 * Màn hình nghiệp vụ Lễ tân & Đặt phòng.
 *
 * Chức năng hoàn chỉnh trong màn hình này:
 * - Tạo booking trước cho khách hàng và phòng còn trống theo khoảng thời gian.
 * - Tìm khách theo mã khách hàng.
 * - Tìm phòng khả dụng từ MySQL bằng PhongDAO.
 * - Check-in booking đã xác nhận.
 * - Khi check-in thành công, DatPhongDAO cập nhật booking và toàn bộ phòng sang DANG_O
 *   trong cùng một transaction để bảo toàn dữ liệu.
 * - Đổi phòng cho khách đang lưu trú. Phòng cũ chuyển DANG_DON, phòng mới chuyển DANG_O.
 * - Tìm kiếm/lọc booking và hiển thị bằng JTable.
 * - Toàn bộ truy vấn CSDL chạy trong SwingWorker để không làm treo EDT.
 */
public class DatPhongView extends JPanel {

    private static final Color PRIMARY_COLOR = new Color(26, 83, 155);
    private static final Color PRIMARY_DARK_COLOR = new Color(17, 55, 105);
    private static final Color BACKGROUND_COLOR = new Color(244, 247, 251);
    private static final Color CARD_COLOR = Color.WHITE;
    private static final Color BORDER_COLOR = new Color(221, 228, 236);
    private static final Color TEXT_COLOR = new Color(38, 49, 64);
    private static final Color SECONDARY_TEXT_COLOR = new Color(105, 117, 133);
    private static final Color SUCCESS_COLOR = new Color(37, 137, 88);
    private static final Color WARNING_COLOR = new Color(193, 124, 31);
    private static final Color DANGER_COLOR = new Color(184, 55, 55);

    private static final int MAX_BOOKING_CODE_LENGTH = 20;
    private static final int MAX_NOTE_LENGTH = 500;

    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("dd/MM/uuuu HH:mm")
                    .withResolverStyle(ResolverStyle.STRICT);

    private static final NumberFormat MONEY_FORMAT =
            NumberFormat.getNumberInstance(new Locale("vi", "VN"));

    private final LoginSession loginSession;
    private final DatPhongDAO datPhongDAO;
    private final ChiTietDatPhongDAO chiTietDatPhongDAO;
    private final KhachHangDAO khachHangDAO;
    private final PhongDAO phongDAO;
    private final LoaiPhongDAO loaiPhongDAO;

    private final JTextField txtMaDatPhong = new JTextField(20);
    private final JComboBox<KhachHang> cboKhachHang = new JComboBox<>();
    private final JTextField txtMaKhachHang = new JTextField(14);
    private final JButton btnChonKhachTheoMa = new JButton("Chọn theo mã");

    private final JComboBox<Phong> cboPhongTrong = new JComboBox<>();
    private final JButton btnTimPhongTrong = new JButton("Tìm phòng trống");
    private final JTextField txtGiaPhong = new JTextField(20);

    private final JTextField txtNgayDat = new JTextField(20);
    private final JTextField txtNgayDuKienNhan = new JTextField(20);
    private final JTextField txtNgayDuKienTra = new JTextField(20);
    private final JTextField txtSoNguoiLon = new JTextField(20);
    private final JTextField txtSoTreEm = new JTextField(20);
    private final JTextField txtTienCoc = new JTextField(20);
    private final JTextArea txtGhiChu = new JTextArea(4, 20);

    private final JButton btnDatPhong = new JButton("Đặt phòng");
    private final JButton btnLamMoiForm = new JButton("Làm mới form");

    private final JTextField txtTimKiem = new JTextField(20);
    private final JComboBox<Object> cboLocTrangThai = new JComboBox<>();
    private final JButton btnTimKiem = new JButton("Tìm kiếm");
    private final JButton btnTaiLai = new JButton("Tải lại");
    private final JButton btnNhanPhong = new JButton("Nhận phòng (Check-in)");
    private final JButton btnDoiPhong = new JButton("Đổi phòng");

    private final JLabel lblThongBao = new JLabel("Sẵn sàng");
    private final JLabel lblTongSoBooking = new JLabel("Tổng số booking: 0");
    private final JLabel lblBookingDangChon = new JLabel("Chưa chọn booking");

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{
                    "Mã đặt phòng",
                    "Khách hàng",
                    "Phòng",
                    "Ngày dự kiến nhận",
                    "Ngày dự kiến trả",
                    "Tiền cọc",
                    "Trạng thái"
            },
            0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tblDatPhong = new JTable(tableModel);

    private final List<BookingDisplayRow> bookingRows = new ArrayList<>();
    private final Map<Integer, KhachHang> khachHangTheoId = new HashMap<>();
    private final Map<Integer, Phong> phongTheoId = new HashMap<>();
    private final Map<Integer, LoaiPhong> loaiPhongTheoId = new HashMap<>();

    private BookingDisplayRow bookingDangChon;
    private boolean dangXuLy;
    private boolean coQuyenLeTan = true;

    public DatPhongView() {
        this(
                null,
                new DatPhongDAO(),
                new ChiTietDatPhongDAO(),
                new KhachHangDAO(),
                new PhongDAO(),
                new LoaiPhongDAO()
        );
    }

    public DatPhongView(LoginSession loginSession) {
        this(
                loginSession,
                new DatPhongDAO(),
                new ChiTietDatPhongDAO(),
                new KhachHangDAO(),
                new PhongDAO(),
                new LoaiPhongDAO()
        );
    }

    public DatPhongView(
            LoginSession loginSession,
            DatPhongDAO datPhongDAO,
            ChiTietDatPhongDAO chiTietDatPhongDAO,
            KhachHangDAO khachHangDAO,
            PhongDAO phongDAO,
            LoaiPhongDAO loaiPhongDAO) {

        this.loginSession = loginSession;
        this.datPhongDAO = datPhongDAO;
        this.chiTietDatPhongDAO = chiTietDatPhongDAO;
        this.khachHangDAO = khachHangDAO;
        this.phongDAO = phongDAO;
        this.loaiPhongDAO = loaiPhongDAO;

        initializeLayout();
        initializeComponents();
        registerEvents();
        applyRolePermissions();
        resetBookingForm();
        loadInitialData();
    }

    private void initializeLayout() {
        setLayout(new BorderLayout(0, 16));
        setBackground(BACKGROUND_COLOR);
        setBorder(new EmptyBorder(14, 14, 14, 14));
    }

    private void initializeComponents() {
        txtMaDatPhong.setEditable(false);
        txtNgayDat.setEditable(false);
        txtGiaPhong.setEditable(false);

        txtMaDatPhong.setBackground(new Color(246, 248, 251));
        txtNgayDat.setBackground(new Color(246, 248, 251));
        txtGiaPhong.setBackground(new Color(246, 248, 251));

        txtNgayDuKienNhan.setToolTipText("Định dạng: dd/MM/yyyy HH:mm");
        txtNgayDuKienTra.setToolTipText("Định dạng: dd/MM/yyyy HH:mm");
        txtTienCoc.setToolTipText("Nhập số tiền, ví dụ 500000 hoặc 500.000");

        txtGhiChu.setLineWrap(true);
        txtGhiChu.setWrapStyleWord(true);
        txtGhiChu.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));

        initializeStatusFilter();
        initializeComboRenderers();

        add(createHeaderPanel(), BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                createBookingFormPanel(),
                createBookingTableArea()
        );
        splitPane.setBorder(null);
        splitPane.setDividerLocation(505);
        splitPane.setResizeWeight(0.0);
        splitPane.setContinuousLayout(true);

        add(splitPane, BorderLayout.CENTER);
        add(createStatusPanel(), BorderLayout.SOUTH);
    }

    private void initializeStatusFilter() {
        cboLocTrangThai.removeAllItems();
        cboLocTrangThai.addItem("Tất cả trạng thái");
        for (TrangThaiDatPhong status : TrangThaiDatPhong.values()) {
            cboLocTrangThai.addItem(status);
        }
    }

    private void initializeComboRenderers() {
        cboKhachHang.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list,
                    Object value,
                    int index,
                    boolean isSelected,
                    boolean cellHasFocus) {

                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof KhachHang customer) {
                    setText(customer.getMaKhachHang() + " - " + customer.getHoTen()
                            + " - " + CustomerDataCrypto.maskIdentifier(customer.getSoGiayTo()));
                } else if (value == null) {
                    setText("-- Chọn khách hàng --");
                }
                return this;
            }
        });

        cboPhongTrong.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list,
                    Object value,
                    int index,
                    boolean isSelected,
                    boolean cellHasFocus) {

                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Phong room) {
                    LoaiPhong roomType = loaiPhongTheoId.get(room.getLoaiPhongId());
                    String typeName = roomType == null ? "Không rõ loại" : roomType.getTenLoaiPhong();
                    String price = roomType == null || roomType.getGiaCoBan() == null
                            ? "0"
                            : MONEY_FORMAT.format(roomType.getGiaCoBan());
                    setText("Phòng " + room.getSoPhong() + " - " + typeName + " - " + price + " VNĐ");
                } else if (value == null) {
                    setText("-- Chưa có phòng khả dụng --");
                }
                return this;
            }
        });
    }

    private JPanel createHeaderPanel() {
        JPanel panel = createCardPanel(new BorderLayout(12, 6));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(16, 18, 16, 18)
        ));

        JLabel lblTitle = new JLabel("QUẢN LÝ ĐẶT PHÒNG & LỄ TÂN");
        lblTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 21));
        lblTitle.setForeground(TEXT_COLOR);

        JLabel lblDescription = new JLabel(
                "Booking trước, tìm phòng khả dụng, check-in và đổi phòng cho khách đang lưu trú."
        );
        lblDescription.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        lblDescription.setForeground(SECONDARY_TEXT_COLOR);

        JPanel titlePanel = new JPanel(new GridBagLayout());
        titlePanel.setOpaque(false);
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.anchor = GridBagConstraints.WEST;
        constraints.weightx = 1.0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        titlePanel.add(lblTitle, constraints);

        constraints.gridy = 1;
        constraints.insets = new Insets(4, 0, 0, 0);
        titlePanel.add(lblDescription, constraints);

        JLabel lblBadge = new JLabel("LỄ TÂN", SwingConstants.CENTER);
        lblBadge.setOpaque(true);
        lblBadge.setBackground(new Color(234, 242, 252));
        lblBadge.setForeground(PRIMARY_COLOR);
        lblBadge.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 11));
        lblBadge.setPreferredSize(new Dimension(96, 30));
        lblBadge.setBorder(BorderFactory.createLineBorder(new Color(198, 217, 241)));

        panel.add(titlePanel, BorderLayout.CENTER);
        panel.add(lblBadge, BorderLayout.EAST);
        return panel;
    }

    private JPanel createBookingFormPanel() {
        JPanel outerPanel = new JPanel(new BorderLayout());
        outerPanel.setOpaque(false);
        outerPanel.setMinimumSize(new Dimension(500, 560));

        JPanel card = createCardPanel(new BorderLayout(0, 12));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(16, 16, 14, 16)
        ));

        JLabel lblTitle = new JLabel("TẠO BOOKING");
        lblTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
        lblTitle.setForeground(PRIMARY_DARK_COLOR);
        card.add(lblTitle, BorderLayout.NORTH);

        JPanel fields = new JPanel(new GridBagLayout());
        fields.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 4, 4, 8);
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;

        addFormPair(fields, c, 0, "Mã đặt phòng *", txtMaDatPhong, "Ngày đặt", txtNgayDat);
        addFormPair(fields, c, 1, "Khách hàng *", cboKhachHang, "Mã KH", createCustomerCodePanel());
        addFormPair(fields, c, 2, "Ngày dự kiến nhận *", txtNgayDuKienNhan, "Ngày dự kiến trả *", txtNgayDuKienTra);
        addFormPair(fields, c, 3, "Phòng còn trống *", createAvailableRoomPanel(), "Giá phòng", txtGiaPhong);
        addFormPair(fields, c, 4, "Số người lớn *", txtSoNguoiLon, "Số trẻ em", txtSoTreEm);
        addFormPair(fields, c, 5, "Tiền cọc (VNĐ)", txtTienCoc, "", new JPanel());

        JLabel lblNote = new JLabel("Ghi chú");
        lblNote.setForeground(TEXT_COLOR);
        lblNote.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        c.gridy = 6;
        c.gridx = 0;
        c.weightx = 0;
        c.gridwidth = 1;
        fields.add(lblNote, c);

        JScrollPane noteScrollPane = new JScrollPane(txtGhiChu);
        noteScrollPane.setPreferredSize(new Dimension(0, 62));
        c.gridx = 1;
        c.weightx = 1;
        c.gridwidth = 3;
        c.insets = new Insets(4, 4, 4, 4);
        fields.add(noteScrollPane, c);

        JLabel lblRequired = new JLabel("(*) Bắt buộc • Định dạng ngày giờ: dd/MM/yyyy HH:mm");
        lblRequired.setForeground(SECONDARY_TEXT_COLOR);
        lblRequired.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 10));
        c.gridy = 7;
        c.gridx = 0;
        c.gridwidth = 4;
        c.weightx = 1;
        fields.add(lblRequired, c);

        JPanel buttons = new JPanel(new GridLayout(1, 2, 8, 0));
        buttons.setOpaque(false);
        styleActionButton(btnDatPhong, SUCCESS_COLOR, Color.WHITE);
        styleOutlineButton(btnLamMoiForm, PRIMARY_COLOR);
        buttons.add(btnDatPhong);
        buttons.add(btnLamMoiForm);

        card.add(fields, BorderLayout.CENTER);
        card.add(buttons, BorderLayout.SOUTH);
        outerPanel.add(card, BorderLayout.CENTER);
        return outerPanel;
    }

    private void addFormPair(
            JPanel panel,
            GridBagConstraints constraints,
            int row,
            String leftLabelText,
            Component leftComponent,
            String rightLabelText,
            Component rightComponent) {

        JLabel leftLabel = new JLabel(leftLabelText);
        leftLabel.setForeground(TEXT_COLOR);
        leftLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
        constraints.gridy = row;
        constraints.gridx = 0;
        constraints.gridwidth = 1;
        constraints.weightx = 0;
        constraints.insets = new Insets(4, 4, 4, 6);
        constraints.fill = GridBagConstraints.HORIZONTAL;
        panel.add(leftLabel, constraints);

        constraints.gridx = 1;
        constraints.weightx = 1;
        constraints.insets = new Insets(4, 0, 4, 10);
        panel.add(leftComponent, constraints);

        JLabel rightLabel = new JLabel(rightLabelText);
        rightLabel.setForeground(TEXT_COLOR);
        rightLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
        constraints.gridx = 2;
        constraints.weightx = 0;
        constraints.insets = new Insets(4, 0, 4, 6);
        panel.add(rightLabel, constraints);

        constraints.gridx = 3;
        constraints.weightx = 1;
        constraints.insets = new Insets(4, 0, 4, 4);
        panel.add(rightComponent, constraints);
    }

    private JPanel createCustomerCodePanel() {
        JPanel panel = new JPanel(new BorderLayout(6, 0));
        panel.setOpaque(false);
        panel.add(txtMaKhachHang, BorderLayout.CENTER);
        styleSmallButton(btnChonKhachTheoMa);
        panel.add(btnChonKhachTheoMa, BorderLayout.EAST);
        return panel;
    }

    private JPanel createAvailableRoomPanel() {
        JPanel panel = new JPanel(new BorderLayout(6, 0));
        panel.setOpaque(false);
        panel.add(cboPhongTrong, BorderLayout.CENTER);
        styleSmallButton(btnTimPhongTrong);
        panel.add(btnTimPhongTrong, BorderLayout.EAST);
        return panel;
    }

    private JPanel createBookingTableArea() {
        JPanel outer = new JPanel(new BorderLayout(0, 10));
        outer.setOpaque(false);

        JPanel searchCard = createCardPanel(new BorderLayout(10, 8));
        searchCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(12, 14, 12, 14)
        ));

        JPanel searchFields = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        searchFields.setOpaque(false);
        searchFields.add(new JLabel("Tìm booking / khách:"));
        searchFields.add(txtTimKiem);
        searchFields.add(new JLabel("Trạng thái:"));
        searchFields.add(cboLocTrangThai);

        styleSmallButton(btnTimKiem);
        styleSmallButton(btnTaiLai);
        JPanel searchButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchButtons.setOpaque(false);
        searchButtons.add(btnTimKiem);
        searchButtons.add(btnTaiLai);

        searchCard.add(searchFields, BorderLayout.CENTER);
        searchCard.add(searchButtons, BorderLayout.EAST);

        JPanel tableCard = createCardPanel(new BorderLayout(0, 10));
        tableCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(12, 12, 12, 12)
        ));

        configureBookingTable();
        JScrollPane tableScrollPane = new JScrollPane(tblDatPhong);
        tableScrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        tableScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        tableScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        JPanel actionPanel = new JPanel(new BorderLayout(10, 0));
        actionPanel.setOpaque(false);
        actionPanel.setBorder(new EmptyBorder(4, 0, 2, 0));
        actionPanel.setPreferredSize(new Dimension(0, 48));
        lblBookingDangChon.setForeground(SECONDARY_TEXT_COLOR);
        lblBookingDangChon.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));

        JPanel businessButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        businessButtons.setOpaque(false);
        styleActionButton(btnNhanPhong, SUCCESS_COLOR, Color.WHITE);
        styleActionButton(btnDoiPhong, WARNING_COLOR, Color.WHITE);
        businessButtons.add(btnNhanPhong);
        businessButtons.add(btnDoiPhong);

        actionPanel.add(lblBookingDangChon, BorderLayout.CENTER);
        actionPanel.add(businessButtons, BorderLayout.EAST);

        tableCard.add(tableScrollPane, BorderLayout.CENTER);
        tableCard.add(actionPanel, BorderLayout.SOUTH);

        outer.add(searchCard, BorderLayout.NORTH);
        outer.add(tableCard, BorderLayout.CENTER);
        return outer;
    }

    private void configureBookingTable() {
        // Dùng TableUtils để header luôn dùng renderer chung của toàn ứng dụng.
        TableUtils.setupTable(tblDatPhong);

        // Giữ bố cục bảng hiện tại của màn hình Lễ tân.
        tblDatPhong.setRowHeight(30);
        tblDatPhong.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        tblDatPhong.setSelectionBackground(new Color(210, 228, 250));
        tblDatPhong.setSelectionForeground(TEXT_COLOR);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        tblDatPhong.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tblDatPhong.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        tblDatPhong.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
        tblDatPhong.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
        tblDatPhong.getColumnModel().getColumn(6).setCellRenderer(centerRenderer);

        tblDatPhong.getColumnModel().getColumn(0).setPreferredWidth(110);
        tblDatPhong.getColumnModel().getColumn(1).setPreferredWidth(155);
        tblDatPhong.getColumnModel().getColumn(2).setPreferredWidth(100);
        tblDatPhong.getColumnModel().getColumn(3).setPreferredWidth(125);
        tblDatPhong.getColumnModel().getColumn(4).setPreferredWidth(125);
        tblDatPhong.getColumnModel().getColumn(5).setPreferredWidth(95);
        tblDatPhong.getColumnModel().getColumn(6).setPreferredWidth(115);
    }

    private JPanel createStatusPanel() {
        JPanel panel = createCardPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(8, 12, 8, 12)
        ));

        lblThongBao.setForeground(SECONDARY_TEXT_COLOR);
        lblTongSoBooking.setForeground(SECONDARY_TEXT_COLOR);
        lblTongSoBooking.setHorizontalAlignment(SwingConstants.RIGHT);

        panel.add(lblThongBao, BorderLayout.CENTER);
        panel.add(lblTongSoBooking, BorderLayout.EAST);
        return panel;
    }

    private void addFormRow(
            JPanel panel,
            GridBagConstraints constraints,
            int row,
            String labelText,
            Component component) {

        JLabel label = new JLabel(labelText);
        label.setForeground(TEXT_COLOR);
        label.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));

        constraints.gridx = 0;
        constraints.gridy = row;
        constraints.gridwidth = 1;
        constraints.weightx = 0.0;
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.WEST;
        panel.add(label, constraints);

        constraints.gridx = 1;
        constraints.weightx = 1.0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        panel.add(component, constraints);
    }

    private void registerEvents() {
        btnChonKhachTheoMa.addActionListener(event -> selectCustomerByCode());
        btnTimPhongTrong.addActionListener(event -> loadAvailableRoomsFromForm());
        btnDatPhong.addActionListener(event -> createBooking());
        btnLamMoiForm.addActionListener(event -> resetBookingForm());
        btnTimKiem.addActionListener(event -> searchBookingsAsync());
        btnTaiLai.addActionListener(event -> loadBookingsAsync());
        btnNhanPhong.addActionListener(event -> checkInSelectedBooking());
        btnDoiPhong.addActionListener(event -> openChangeRoomDialog());

        cboPhongTrong.addActionListener(event -> updateSelectedRoomPrice());
        cboKhachHang.addActionListener(event -> syncCustomerCodeField());
        cboLocTrangThai.addActionListener(event -> {
            if (!dangXuLy) {
                searchBookingsAsync();
            }
        });

        tblDatPhong.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                handleBookingSelection();
            }
        });

        KeyAdapter enterSearchListener = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent event) {
                if (event.getKeyCode() == KeyEvent.VK_ENTER) {
                    searchBookingsAsync();
                }
            }
        };
        txtTimKiem.addKeyListener(enterSearchListener);

        txtMaKhachHang.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent event) {
                if (event.getKeyCode() == KeyEvent.VK_ENTER) {
                    selectCustomerByCode();
                }
            }
        });
    }

    private void applyRolePermissions() {
        if (loginSession == null) {
            coQuyenLeTan = true;
        } else {
            coQuyenLeTan = loginSession.hasRole("ADMIN") || loginSession.hasRole("LE_TAN");
        }

        ButtonUtils.setEnabled(btnDatPhong, coQuyenLeTan);
        ButtonUtils.setEnabled(btnNhanPhong, false);
        ButtonUtils.setEnabled(btnDoiPhong, false);

        if (!coQuyenLeTan) {
            lblThongBao.setText("Tài khoản hiện tại chỉ có quyền xem dữ liệu đặt phòng.");
        }
    }

    private void loadInitialData() {
        setBusy(true, "Đang tải khách hàng, loại phòng và booking...");

        SwingWorker<InitialData, Void> worker = new SwingWorker<>() {
            @Override
            protected InitialData doInBackground() throws Exception {
                InitialData data = new InitialData();
                data.customers = khachHangDAO.findAll();
                data.roomTypes = loaiPhongDAO.findAll();
                data.rooms = phongDAO.findAll();
                data.bookings = datPhongDAO.findAll();
                data.bookingDetails = chiTietDatPhongDAO.findAll();
                return data;
            }

            @Override
            protected void done() {
                try {
                    InitialData data = get();
                    applyReferenceData(data.customers, data.roomTypes, data.rooms);
                    applyBookingData(data.bookings, data.bookingDetails);
                    setBusy(false, "Dữ liệu lễ tân đã được tải thành công.");
                    loadAvailableRoomsFromForm();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Tải dữ liệu bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tải dữ liệu lễ tân.");
                    showDatabaseError("Không thể tải dữ liệu ban đầu", exception.getCause());
                }
            }
        };
        worker.execute();
    }

    private void applyReferenceData(
            List<KhachHang> customers,
            List<LoaiPhong> roomTypes,
            List<Phong> rooms) {

        khachHangTheoId.clear();
        for (KhachHang customer : customers) {
            khachHangTheoId.put(customer.getId(), customer);
        }

        loaiPhongTheoId.clear();
        for (LoaiPhong roomType : roomTypes) {
            loaiPhongTheoId.put(roomType.getId(), roomType);
        }

        phongTheoId.clear();
        for (Phong room : rooms) {
            phongTheoId.put(room.getId(), room);
        }

        DefaultComboBoxModel<KhachHang> customerModel = new DefaultComboBoxModel<>();
        for (KhachHang customer : customers) {
            customerModel.addElement(customer);
        }
        cboKhachHang.setModel(customerModel);
        if (customerModel.getSize() > 0) {
            cboKhachHang.setSelectedIndex(0);
        }
        syncCustomerCodeField();
    }

    private void loadBookingsAsync() {
        loadBookingsAsync(null, null);
    }

    private void searchBookingsAsync() {
        String keyword = txtTimKiem.getText().trim();
        TrangThaiDatPhong selectedStatus = getSelectedStatusFilter();
        loadBookingsAsync(keyword, selectedStatus);
    }

    private void loadBookingsAsync(String keyword, TrangThaiDatPhong status) {
        setBusy(true, "Đang tải danh sách booking...");

        SwingWorker<BookingData, Void> worker = new SwingWorker<>() {
            @Override
            protected BookingData doInBackground() throws Exception {
                BookingData data = new BookingData();

                if (keyword != null && !keyword.isBlank()) {
                    data.bookings = datPhongDAO.search(keyword);
                    if (status != null) {
                        data.bookings.removeIf(booking -> booking.getTrangThai() != status);
                    }
                } else if (status != null) {
                    data.bookings = datPhongDAO.findByStatus(status);
                } else {
                    data.bookings = datPhongDAO.findAll();
                }

                data.customers = khachHangDAO.findAll();
                data.rooms = phongDAO.findAll();
                data.details = chiTietDatPhongDAO.findAll();
                return data;
            }

            @Override
            protected void done() {
                try {
                    BookingData data = get();

                    khachHangTheoId.clear();
                    for (KhachHang customer : data.customers) {
                        khachHangTheoId.put(customer.getId(), customer);
                    }

                    phongTheoId.clear();
                    for (Phong room : data.rooms) {
                        phongTheoId.put(room.getId(), room);
                    }

                    applyBookingData(data.bookings, data.details);
                    setBusy(false, "Đã tải " + bookingRows.size() + " booking.");
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Tải booking bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tải booking.");
                    showDatabaseError("Lỗi tải danh sách booking", exception.getCause());
                }
            }
        };
        worker.execute();
    }

    private void applyBookingData(List<DatPhong> bookings, List<ChiTietDatPhong> details) {
        Map<Integer, List<ChiTietDatPhong>> detailsByBooking = new HashMap<>();
        for (ChiTietDatPhong detail : details) {
            detailsByBooking
                    .computeIfAbsent(detail.getDatPhongId(), ignored -> new ArrayList<>())
                    .add(detail);
        }

        bookingRows.clear();
        tableModel.setRowCount(0);

        for (DatPhong booking : bookings) {
            KhachHang customer = khachHangTheoId.get(booking.getKhachHangId());
            List<ChiTietDatPhong> bookingDetails =
                    detailsByBooking.getOrDefault(booking.getId(), new ArrayList<>());

            String roomNumbers = buildRoomNumbers(bookingDetails);
            BookingDisplayRow row = new BookingDisplayRow(booking, customer, bookingDetails, roomNumbers);
            bookingRows.add(row);

            tableModel.addRow(new Object[]{
                    booking.getMaDatPhong(),
                    customer == null ? "Không rõ khách" : customer.getMaKhachHang() + " - " + customer.getHoTen(),
                    roomNumbers,
                    formatDateTime(booking.getNgayDuKienNhan()),
                    formatDateTime(booking.getNgayDuKienTra()),
                    formatMoney(booking.getTienCoc()),
                    booking.getTrangThai()
            });
        }

        lblTongSoBooking.setText("Tổng số booking: " + bookingRows.size());
        clearBookingSelection();
    }

    private String buildRoomNumbers(List<ChiTietDatPhong> details) {
        if (details == null || details.isEmpty()) {
            return "Chưa có phòng";
        }
        List<String> numbers = new ArrayList<>();
        for (ChiTietDatPhong detail : details) {
            Phong room = phongTheoId.get(detail.getPhongId());
            numbers.add(room == null ? "#" + detail.getPhongId() : room.getSoPhong());
        }
        return String.join(", ", numbers);
    }

    private void loadAvailableRoomsFromForm() {
        LocalDateTime checkIn;
        LocalDateTime checkOut;
        try {
            checkIn = parseRequiredDateTime(txtNgayDuKienNhan, "Ngày dự kiến nhận");
            checkOut = parseRequiredDateTime(txtNgayDuKienTra, "Ngày dự kiến trả");
            if (!checkOut.isAfter(checkIn)) {
                showValidationWarning("Ngày dự kiến trả phải sau ngày dự kiến nhận.", txtNgayDuKienTra);
                return;
            }
        } catch (IllegalArgumentException exception) {
            showValidationWarning(exception.getMessage(), txtNgayDuKienNhan);
            return;
        }

        setBusy(true, "Đang tìm phòng còn trống...");
        SwingWorker<List<Phong>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Phong> doInBackground() throws Exception {
                return phongDAO.findAvailable(checkIn, checkOut);
            }

            @Override
            protected void done() {
                try {
                    List<Phong> availableRooms = get();
                    applyAvailableRooms(availableRooms);
                    setBusy(false, availableRooms.isEmpty()
                            ? "Không có phòng phù hợp trong khoảng thời gian đã chọn."
                            : "Tìm thấy " + availableRooms.size() + " phòng khả dụng.");
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Tìm phòng bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tìm phòng trống.");
                    showDatabaseError("Lỗi tìm phòng trống", exception.getCause());
                }
            }
        };
        worker.execute();
    }

    private void applyAvailableRooms(List<Phong> rooms) {
        DefaultComboBoxModel<Phong> model = new DefaultComboBoxModel<>();
        for (Phong room : rooms) {
            if (room.isDangHoatDong() && room.getTrangThai() != TrangThaiPhong.BAO_TRI) {
                model.addElement(room);
            }
        }
        cboPhongTrong.setModel(model);
        if (model.getSize() > 0) {
            cboPhongTrong.setSelectedIndex(0);
        }
        updateSelectedRoomPrice();
    }

    private void updateSelectedRoomPrice() {
        Phong room = (Phong) cboPhongTrong.getSelectedItem();
        if (room == null) {
            txtGiaPhong.setText("");
            return;
        }

        LoaiPhong roomType = loaiPhongTheoId.get(room.getLoaiPhongId());
        if (roomType == null || roomType.getGiaCoBan() == null) {
            txtGiaPhong.setText("Không xác định");
            return;
        }
        txtGiaPhong.setText(MONEY_FORMAT.format(roomType.getGiaCoBan()) + " VNĐ");
    }

    private void syncCustomerCodeField() {
        KhachHang customer = (KhachHang) cboKhachHang.getSelectedItem();
        txtMaKhachHang.setText(customer == null ? "" : customer.getMaKhachHang());
    }

    private void selectCustomerByCode() {
        String customerCode = txtMaKhachHang.getText().trim();
        if (customerCode.isBlank()) {
            showValidationWarning("Vui lòng nhập mã khách hàng cần tìm.", txtMaKhachHang);
            return;
        }

        for (int index = 0; index < cboKhachHang.getItemCount(); index++) {
            KhachHang customer = cboKhachHang.getItemAt(index);
            if (customerCode.equalsIgnoreCase(customer.getMaKhachHang())) {
                cboKhachHang.setSelectedIndex(index);
                lblThongBao.setText("Đã chọn khách hàng: " + customer.getHoTen());
                return;
            }
        }

        setBusy(true, "Đang tìm khách hàng...");
        SwingWorker<Optional<KhachHang>, Void> worker = new SwingWorker<>() {
            @Override
            protected Optional<KhachHang> doInBackground() throws Exception {
                return khachHangDAO.findByCode(customerCode);
            }

            @Override
            protected void done() {
                try {
                    Optional<KhachHang> customerOptional = get();
                    setBusy(false, "Đã hoàn tất tìm khách hàng.");
                    if (customerOptional.isEmpty()) {
                        JOptionPane.showMessageDialog(
                                DatPhongView.this,
                                "Không tìm thấy khách hàng có mã " + customerCode + ".\n"
                                        + "Hãy tạo khách hàng ở màn hình Quản lý khách hàng trước khi đặt phòng.",
                                "Không tìm thấy khách hàng",
                                JOptionPane.WARNING_MESSAGE
                        );
                        return;
                    }

                    KhachHang customer = customerOptional.get();
                    DefaultComboBoxModel<KhachHang> model = (DefaultComboBoxModel<KhachHang>) cboKhachHang.getModel();
                    boolean exists = false;
                    for (int index = 0; index < model.getSize(); index++) {
                        if (model.getElementAt(index).getId().equals(customer.getId())) {
                            exists = true;
                            cboKhachHang.setSelectedIndex(index);
                            break;
                        }
                    }
                    if (!exists) {
                        model.addElement(customer);
                        cboKhachHang.setSelectedItem(customer);
                    }
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Tìm khách hàng bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tìm khách hàng.");
                    showDatabaseError("Lỗi tìm khách hàng", exception.getCause());
                }
            }
        };
        worker.execute();
    }

    private void createBooking() {
        if (!coQuyenLeTan) {
            showPermissionWarning();
            return;
        }

        BookingFormData formData;
        try {
            formData = readAndValidateBookingForm();
        } catch (IllegalArgumentException exception) {
            JOptionPane.showMessageDialog(
                    this,
                    exception.getMessage(),
                    "Dữ liệu chưa hợp lệ",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Xác nhận tạo booking " + formData.booking.getMaDatPhong() + "?\n"
                        + "Khách: " + formData.customer.getHoTen() + "\n"
                        + "Phòng: " + formData.room.getSoPhong() + "\n"
                        + "Nhận: " + formatDateTime(formData.booking.getNgayDuKienNhan()) + "\n"
                        + "Trả: " + formatDateTime(formData.booking.getNgayDuKienTra()),
                "Xác nhận đặt phòng",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        setBusy(true, "Đang tạo booking...");
        SwingWorker<Integer, Void> worker = new SwingWorker<>() {
            @Override
            protected Integer doInBackground() throws Exception {
                Optional<DatPhong> duplicate = datPhongDAO.findByCode(formData.booking.getMaDatPhong());
                if (duplicate.isPresent()) {
                    throw new SQLException("Mã booking vừa tạo đã tồn tại. Vui lòng thử lại.");
                }
                return datPhongDAO.insertWithDetails(
                        formData.booking,
                        List.of(formData.detail)
                );
            }

            @Override
            protected void done() {
                try {
                    int bookingId = get();
                    setBusy(false, "Đặt phòng thành công.");
                    JOptionPane.showMessageDialog(
                            DatPhongView.this,
                            "Đặt phòng thành công.\n"
                                    + "Mã booking: " + formData.booking.getMaDatPhong() + "\n"
                                    + "ID: " + bookingId + "\n\n"
                                    + "Phòng vẫn ở trạng thái vận hành hiện tại và sẽ chuyển sang 'Có khách' "
                                    + "khi Check-in thành công.",
                            "Đặt phòng thành công",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    resetBookingForm();
                    loadBookingsAsync();
                    loadAvailableRoomsFromForm();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Tạo booking bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tạo booking.");
                    showDatabaseError("Đặt phòng thất bại", exception.getCause());
                }
            }
        };
        worker.execute();
    }

    private BookingFormData readAndValidateBookingForm() {
        KhachHang customer = (KhachHang) cboKhachHang.getSelectedItem();
        if (customer == null || customer.getId() == null) {
            throw new IllegalArgumentException("Vui lòng chọn khách hàng.");
        }

        Phong room = (Phong) cboPhongTrong.getSelectedItem();
        if (room == null || room.getId() == null) {
            throw new IllegalArgumentException(
                    "Chưa có phòng được chọn. Hãy nhập ngày nhận/ngày trả và bấm 'Tìm phòng trống'."
            );
        }

        String bookingCode = txtMaDatPhong.getText().trim();
        if (bookingCode.isBlank() || bookingCode.length() > MAX_BOOKING_CODE_LENGTH) {
            throw new IllegalArgumentException("Mã đặt phòng không hợp lệ.");
        }

        LocalDateTime checkIn = parseRequiredDateTime(txtNgayDuKienNhan, "Ngày dự kiến nhận");
        LocalDateTime checkOut = parseRequiredDateTime(txtNgayDuKienTra, "Ngày dự kiến trả");
        if (!checkOut.isAfter(checkIn)) {
            throw new IllegalArgumentException("Ngày dự kiến trả phải sau ngày dự kiến nhận.");
        }
        if (checkIn.isBefore(LocalDateTime.now().minusMinutes(5))) {
            throw new IllegalArgumentException("Ngày dự kiến nhận không được nằm trong quá khứ.");
        }

        int adults = parsePositiveInteger(txtSoNguoiLon, "Số người lớn", true);
        int children = parsePositiveInteger(txtSoTreEm, "Số trẻ em", false);
        BigDecimal deposit = parseNonNegativeMoney(txtTienCoc, "Tiền cọc");

        String note = txtGhiChu.getText().trim();
        if (note.length() > MAX_NOTE_LENGTH) {
            throw new IllegalArgumentException("Ghi chú không được vượt quá " + MAX_NOTE_LENGTH + " ký tự.");
        }

        LoaiPhong roomType = loaiPhongTheoId.get(room.getLoaiPhongId());
        if (roomType == null || roomType.getGiaCoBan() == null
                || roomType.getGiaCoBan().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Không xác định được giá hợp lệ của phòng đã chọn.");
        }

        int totalGuests = adults + children;
        if (roomType.getSucChuaToiDa() > 0 && totalGuests > roomType.getSucChuaToiDa()) {
            throw new IllegalArgumentException(
                    "Số khách (" + totalGuests + ") vượt sức chứa tối đa của loại phòng "
                            + roomType.getTenLoaiPhong() + " (" + roomType.getSucChuaToiDa() + " người)."
            );
        }

        DatPhong booking = new DatPhong();
        booking.setMaDatPhong(bookingCode);
        booking.setKhachHangId(customer.getId());
        booking.setThoiGianDat(LocalDateTime.now());
        booking.setNgayDuKienNhan(checkIn);
        booking.setNgayDuKienTra(checkOut);
        booking.setSoNguoiLon(adults);
        booking.setSoTreEm(children);
        booking.setTienCoc(deposit);
        booking.setTrangThai(TrangThaiDatPhong.DA_XAC_NHAN);
        booking.setNhanVienTaoId(getCurrentEmployeeId());
        booking.setGhiChu(note.isBlank() ? null : note);

        ChiTietDatPhong detail = new ChiTietDatPhong();
        detail.setPhongId(room.getId());
        detail.setGiaPhongThucTe(roomType.getGiaCoBan());
        detail.setSoNguoiLon(adults);
        detail.setSoTreEm(children);
        detail.setGhiChu(null);

        return new BookingFormData(booking, detail, customer, room);
    }

    private void checkInSelectedBooking() {
        if (!coQuyenLeTan) {
            showPermissionWarning();
            return;
        }
        if (bookingDangChon == null) {
            showWarning("Vui lòng chọn một booking trên bảng trước khi Check-in.");
            return;
        }

        DatPhong booking = bookingDangChon.booking;
        if (booking.getTrangThai() != TrangThaiDatPhong.DA_XAC_NHAN
                && booking.getTrangThai() != TrangThaiDatPhong.CHO_XAC_NHAN) {
            showWarning("Booking " + booking.getMaDatPhong()
                    + " không ở trạng thái cho phép nhận phòng.\nTrạng thái hiện tại: "
                    + booking.getTrangThai());
            return;
        }

        LocalDateTime now = LocalDateTime.now();
        if (booking.getNgayDuKienNhan() != null
                && now.isBefore(booking.getNgayDuKienNhan().minusHours(3))) {
            int earlyConfirm = JOptionPane.showConfirmDialog(
                    this,
                    "Khách đang Check-in sớm hơn thời gian dự kiến trên 3 giờ.\n"
                            + "Bạn vẫn muốn tiếp tục?",
                    "Xác nhận Check-in sớm",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );
            if (earlyConfirm != JOptionPane.YES_OPTION) {
                return;
            }
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Xác nhận Check-in booking " + booking.getMaDatPhong() + "?\n"
                        + "Khách: " + getCustomerDisplayName(bookingDangChon.customer) + "\n"
                        + "Phòng: " + bookingDangChon.roomNumbers + "\n\n"
                        + "Sau khi thành công, trạng thái phòng sẽ chuyển sang 'Có khách'.",
                "Xác nhận nhận phòng",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        setBusy(true, "Đang thực hiện Check-in...");
        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                return datPhongDAO.checkIn(booking.getId(), getCurrentEmployeeId());
            }

            @Override
            protected void done() {
                try {
                    boolean success = get();
                    if (!success) {
                        throw new SQLException("Không cập nhật được dữ liệu Check-in.");
                    }
                    setBusy(false, "Check-in thành công.");
                    JOptionPane.showMessageDialog(
                            DatPhongView.this,
                            "Check-in thành công cho booking " + booking.getMaDatPhong() + ".\n"
                                    + "Phòng " + bookingDangChon.roomNumbers + " đã chuyển sang trạng thái Có khách.",
                            "Nhận phòng thành công",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    loadBookingsAsync();
                    loadAvailableRoomsFromForm();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Check-in bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Check-in thất bại.");
                    showDatabaseError("Không thể nhận phòng", exception.getCause());
                } catch (SQLException exception) {
                    setBusy(false, "Check-in thất bại.");
                    showDatabaseError("Không thể nhận phòng", exception);
                }
            }
        };
        worker.execute();
    }

    private void openChangeRoomDialog() {
        if (!coQuyenLeTan) {
            showPermissionWarning();
            return;
        }
        if (bookingDangChon == null) {
            showWarning("Vui lòng chọn booking cần đổi phòng.");
            return;
        }
        if (bookingDangChon.booking.getTrangThai() != TrangThaiDatPhong.DA_NHAN_PHONG) {
            showWarning("Chỉ có thể đổi phòng cho khách đã Check-in.");
            return;
        }

        DatPhong selectedBooking = bookingDangChon.booking;
        setBusy(true, "Đang tải dữ liệu đổi phòng...");

        SwingWorker<ChangeRoomData, Void> worker = new SwingWorker<>() {
            @Override
            protected ChangeRoomData doInBackground() throws Exception {
                ChangeRoomData data = new ChangeRoomData();
                data.details = chiTietDatPhongDAO.findByBookingId(selectedBooking.getId());
                data.rooms = phongDAO.findAll();
                data.roomTypes = loaiPhongDAO.findAll();

                LocalDateTime from = LocalDateTime.now();
                LocalDateTime to = selectedBooking.getNgayDuKienTra();
                if (to == null || !to.isAfter(from)) {
                    to = from.plusDays(1);
                }
                data.availableRooms = phongDAO.findAvailable(from, to);
                return data;
            }

            @Override
            protected void done() {
                try {
                    ChangeRoomData data = get();
                    setBusy(false, "Đã tải dữ liệu đổi phòng.");
                    showChangeRoomDialog(selectedBooking, data);
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Tải dữ liệu đổi phòng bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tải dữ liệu đổi phòng.");
                    showDatabaseError("Lỗi tải dữ liệu đổi phòng", exception.getCause());
                }
            }
        };
        worker.execute();
    }

    private void showChangeRoomDialog(DatPhong booking, ChangeRoomData data) {
        if (data.details == null || data.details.isEmpty()) {
            showWarning("Booking không có chi tiết phòng để đổi.");
            return;
        }

        Map<Integer, Phong> roomMap = new HashMap<>();
        for (Phong room : data.rooms) {
            roomMap.put(room.getId(), room);
        }
        Map<Integer, LoaiPhong> roomTypeMap = new HashMap<>();
        for (LoaiPhong roomType : data.roomTypes) {
            roomTypeMap.put(roomType.getId(), roomType);
        }

        List<RoomDetailItem> currentRoomItems = new ArrayList<>();
        for (ChiTietDatPhong detail : data.details) {
            Phong room = roomMap.get(detail.getPhongId());
            if (room != null) {
                currentRoomItems.add(new RoomDetailItem(detail, room));
            }
        }

        List<Phong> newRooms = new ArrayList<>();
        for (Phong room : data.availableRooms) {
            if (room.getTrangThai() == TrangThaiPhong.TRONG && room.isDangHoatDong()) {
                boolean alreadyInBooking = false;
                for (ChiTietDatPhong detail : data.details) {
                    if (detail.getPhongId().equals(room.getId())) {
                        alreadyInBooking = true;
                        break;
                    }
                }
                if (!alreadyInBooking) {
                    newRooms.add(room);
                }
            }
        }

        if (newRooms.isEmpty()) {
            showWarning("Hiện không có phòng Trống phù hợp để đổi trong thời gian lưu trú còn lại.");
            return;
        }

        JDialog dialog = new JDialog();
        dialog.setTitle("Đổi phòng - " + booking.getMaDatPhong());
        dialog.setModalityType(JDialog.ModalityType.APPLICATION_MODAL);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setLayout(new BorderLayout(0, 12));

        JPanel content = new JPanel(new GridBagLayout());
        content.setBorder(new EmptyBorder(18, 18, 8, 18));
        content.setBackground(CARD_COLOR);

        JComboBox<RoomDetailItem> cboCurrentRoom = new JComboBox<>(
                currentRoomItems.toArray(new RoomDetailItem[0])
        );
        JComboBox<Phong> cboNewRoom = new JComboBox<>(newRooms.toArray(new Phong[0]));
        JTextField txtNewPrice = new JTextField(20);
        txtNewPrice.setEditable(false);
        txtNewPrice.setBackground(new Color(246, 248, 251));

        cboNewRoom.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list,
                    Object value,
                    int index,
                    boolean isSelected,
                    boolean cellHasFocus) {

                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Phong room) {
                    LoaiPhong roomType = roomTypeMap.get(room.getLoaiPhongId());
                    String roomTypeName = roomType == null ? "Không rõ loại" : roomType.getTenLoaiPhong();
                    String price = roomType == null || roomType.getGiaCoBan() == null
                            ? "0"
                            : MONEY_FORMAT.format(roomType.getGiaCoBan());
                    setText("Phòng " + room.getSoPhong() + " - " + roomTypeName + " - " + price + " VNĐ");
                }
                return this;
            }
        });

        Runnable updatePrice = () -> {
            Phong selectedNewRoom = (Phong) cboNewRoom.getSelectedItem();
            LoaiPhong type = selectedNewRoom == null ? null : roomTypeMap.get(selectedNewRoom.getLoaiPhongId());
            txtNewPrice.setText(type == null || type.getGiaCoBan() == null
                    ? "Không xác định"
                    : MONEY_FORMAT.format(type.getGiaCoBan()) + " VNĐ");
        };
        cboNewRoom.addActionListener(event -> updatePrice.run());
        updatePrice.run();

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(7, 7, 7, 7);
        constraints.anchor = GridBagConstraints.WEST;
        constraints.fill = GridBagConstraints.HORIZONTAL;

        addDialogRow(content, constraints, 0, "Booking", new JLabel(booking.getMaDatPhong()));
        addDialogRow(content, constraints, 1, "Phòng hiện tại *", cboCurrentRoom);
        addDialogRow(content, constraints, 2, "Phòng mới *", cboNewRoom);
        addDialogRow(content, constraints, 3, "Giá phòng mới", txtNewPrice);

        JLabel lblExplanation = new JLabel(
                "Phòng cũ sẽ chuyển sang 'Đang dọn'; phòng mới chuyển sang 'Có khách'."
        );
        lblExplanation.setForeground(SECONDARY_TEXT_COLOR);
        lblExplanation.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 11));
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.gridwidth = 2;
        constraints.weightx = 1.0;
        content.add(lblExplanation, constraints);

        JButton btnConfirm = new JButton("Xác nhận đổi phòng");
        JButton btnCancel = new JButton("Hủy");
        styleActionButton(btnConfirm, WARNING_COLOR, Color.WHITE);
        styleOutlineButton(btnCancel, PRIMARY_COLOR);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        buttonPanel.setBackground(CARD_COLOR);
        buttonPanel.setBorder(new EmptyBorder(0, 10, 10, 10));
        buttonPanel.add(btnCancel);
        buttonPanel.add(btnConfirm);

        btnCancel.addActionListener(event -> dialog.dispose());
        btnConfirm.addActionListener(event -> {
            RoomDetailItem currentItem = (RoomDetailItem) cboCurrentRoom.getSelectedItem();
            Phong newRoom = (Phong) cboNewRoom.getSelectedItem();
            if (currentItem == null || newRoom == null) {
                JOptionPane.showMessageDialog(
                        dialog,
                        "Vui lòng chọn phòng hiện tại và phòng mới.",
                        "Dữ liệu chưa hợp lệ",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            LoaiPhong newRoomType = roomTypeMap.get(newRoom.getLoaiPhongId());
            if (newRoomType == null || newRoomType.getGiaCoBan() == null
                    || newRoomType.getGiaCoBan().compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(
                        dialog,
                        "Không xác định được giá hợp lệ của phòng mới.",
                        "Giá phòng không hợp lệ",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(
                    dialog,
                    "Đổi từ phòng " + currentItem.room.getSoPhong()
                            + " sang phòng " + newRoom.getSoPhong() + "?\n\n"
                            + "Phòng cũ sẽ chuyển sang Đang dọn dẹp.",
                    "Xác nhận đổi phòng",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            btnConfirm.setEnabled(false);
            btnCancel.setEnabled(false);
            dialog.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

            SwingWorker<Boolean, Void> changeWorker = new SwingWorker<>() {
                @Override
                protected Boolean doInBackground() throws Exception {
                    return datPhongDAO.changeRoom(
                            booking.getId(),
                            currentItem.detail.getId(),
                            newRoom.getId(),
                            newRoomType.getGiaCoBan()
                    );
                }

                @Override
                protected void done() {
                    try {
                        boolean success = get();
                        if (!success) {
                            throw new SQLException("Không cập nhật được dữ liệu đổi phòng.");
                        }
                        dialog.dispose();
                        JOptionPane.showMessageDialog(
                                DatPhongView.this,
                                "Đổi phòng thành công.\n"
                                        + "Phòng cũ " + currentItem.room.getSoPhong() + " -> Đang dọn dẹp.\n"
                                        + "Phòng mới " + newRoom.getSoPhong() + " -> Có khách.",
                                "Đổi phòng thành công",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                        loadBookingsAsync();
                        loadAvailableRoomsFromForm();
                    } catch (InterruptedException exception) {
                        Thread.currentThread().interrupt();
                        btnConfirm.setEnabled(true);
                        btnCancel.setEnabled(true);
                        dialog.setCursor(Cursor.getDefaultCursor());
                    } catch (ExecutionException exception) {
                        btnConfirm.setEnabled(true);
                        btnCancel.setEnabled(true);
                        dialog.setCursor(Cursor.getDefaultCursor());
                        showDatabaseError("Đổi phòng thất bại", exception.getCause());
                    } catch (SQLException exception) {
                        btnConfirm.setEnabled(true);
                        btnCancel.setEnabled(true);
                        dialog.setCursor(Cursor.getDefaultCursor());
                        showDatabaseError("Đổi phòng thất bại", exception);
                    }
                }
            };
            changeWorker.execute();
        });

        dialog.add(content, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setMinimumSize(new Dimension(520, 300));
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void addDialogRow(
            JPanel panel,
            GridBagConstraints constraints,
            int row,
            String labelText,
            Component component) {

        constraints.gridx = 0;
        constraints.gridy = row;
        constraints.gridwidth = 1;
        constraints.weightx = 0.0;
        panel.add(new JLabel(labelText), constraints);

        constraints.gridx = 1;
        constraints.weightx = 1.0;
        panel.add(component, constraints);
    }

    private void handleBookingSelection() {
        int selectedViewRow = tblDatPhong.getSelectedRow();
        if (selectedViewRow < 0) {
            clearBookingSelection();
            return;
        }

        int selectedModelRow = tblDatPhong.convertRowIndexToModel(selectedViewRow);
        if (selectedModelRow < 0 || selectedModelRow >= bookingRows.size()) {
            clearBookingSelection();
            return;
        }

        bookingDangChon = bookingRows.get(selectedModelRow);
        DatPhong booking = bookingDangChon.booking;

        lblBookingDangChon.setText(
                "Đang chọn: " + booking.getMaDatPhong()
                        + " | " + getCustomerDisplayName(bookingDangChon.customer)
                        + " | Phòng: " + bookingDangChon.roomNumbers
        );

        ButtonUtils.setEnabled(btnNhanPhong, 
                coQuyenLeTan
                        && (booking.getTrangThai() == TrangThaiDatPhong.DA_XAC_NHAN
                        || booking.getTrangThai() == TrangThaiDatPhong.CHO_XAC_NHAN)
        );
        ButtonUtils.setEnabled(btnDoiPhong, coQuyenLeTan && booking.getTrangThai() == TrangThaiDatPhong.DA_NHAN_PHONG);
    }

    private void clearBookingSelection() {
        bookingDangChon = null;
        tblDatPhong.clearSelection();
        lblBookingDangChon.setText("Chưa chọn booking");
        ButtonUtils.setEnabled(btnNhanPhong, false);
        ButtonUtils.setEnabled(btnDoiPhong, false);
    }

    private void resetBookingForm() {
        LocalDateTime now = LocalDateTime.now().withSecond(0).withNano(0);
        LocalDateTime defaultCheckIn = now.plusHours(1);
        LocalDateTime defaultCheckOut = defaultCheckIn.plusDays(1);

        txtMaDatPhong.setText(generateBookingCode());
        txtNgayDat.setText(formatDateTime(now));
        txtNgayDuKienNhan.setText(formatDateTime(defaultCheckIn));
        txtNgayDuKienTra.setText(formatDateTime(defaultCheckOut));
        txtSoNguoiLon.setText("1");
        txtSoTreEm.setText("0");
        txtTienCoc.setText("0");
        txtGhiChu.setText("");
        txtGiaPhong.setText("");

        if (cboKhachHang.getItemCount() > 0) {
            cboKhachHang.setSelectedIndex(0);
        }
        syncCustomerCodeField();

        cboPhongTrong.setModel(new DefaultComboBoxModel<>());
        bookingDangChon = null;
        lblBookingDangChon.setText("Chưa chọn booking");
        ButtonUtils.setEnabled(btnNhanPhong, false);
        ButtonUtils.setEnabled(btnDoiPhong, false);

        if (isShowing()) {
            loadAvailableRoomsFromForm();
        }
    }

    private String generateBookingCode() {
        return "DP" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmssSSS"));
    }

    private TrangThaiDatPhong getSelectedStatusFilter() {
        Object selected = cboLocTrangThai.getSelectedItem();
        return selected instanceof TrangThaiDatPhong ? (TrangThaiDatPhong) selected : null;
    }

    private LocalDateTime parseRequiredDateTime(JTextField field, String fieldName) {
        String value = field.getText().trim();
        if (value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " không được để trống.");
        }
        try {
            return LocalDateTime.parse(value, DATE_TIME_FORMATTER);
        } catch (DateTimeParseException exception) {
            throw new IllegalArgumentException(
                    fieldName + " không đúng định dạng dd/MM/yyyy HH:mm hoặc ngày giờ không tồn tại."
            );
        }
    }

    private int parsePositiveInteger(JTextField field, String fieldName, boolean mustBeGreaterThanZero) {
        String value = field.getText().trim();
        if (value.isBlank()) {
            if (mustBeGreaterThanZero) {
                throw new IllegalArgumentException(fieldName + " không được để trống.");
            }
            return 0;
        }
        try {
            int number = Integer.parseInt(value);
            if (mustBeGreaterThanZero && number <= 0) {
                throw new IllegalArgumentException(fieldName + " phải lớn hơn 0.");
            }
            if (!mustBeGreaterThanZero && number < 0) {
                throw new IllegalArgumentException(fieldName + " không được âm.");
            }
            return number;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(fieldName + " phải là số nguyên hợp lệ.");
        }
    }

    private BigDecimal parseNonNegativeMoney(JTextField field, String fieldName) {
        String raw = field.getText().trim();
        if (raw.isBlank()) {
            return BigDecimal.ZERO;
        }
        String normalized = raw.replace(".", "").replace(",", "").replace(" ", "");
        if (!normalized.matches("\\d+")) {
            throw new IllegalArgumentException(fieldName + " phải là số tiền hợp lệ, ví dụ 500000.");
        }
        try {
            BigDecimal value = new BigDecimal(normalized);
            if (value.compareTo(BigDecimal.ZERO) < 0) {
                throw new IllegalArgumentException(fieldName + " không được âm.");
            }
            return value;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(fieldName + " phải là số tiền hợp lệ.");
        }
    }

    private Integer getCurrentEmployeeId() {
        if (loginSession == null || loginSession.getTaiKhoan() == null) {
            return null;
        }
        return loginSession.getTaiKhoan().getId();
    }

    private String getCustomerDisplayName(KhachHang customer) {
        if (customer == null) {
            return "Không rõ khách hàng";
        }
        return customer.getMaKhachHang() + " - " + customer.getHoTen();
    }

    private String formatDateTime(LocalDateTime value) {
        return value == null ? "" : value.format(DATE_TIME_FORMATTER);
    }

    private String formatMoney(BigDecimal value) {
        return value == null ? "0 VNĐ" : MONEY_FORMAT.format(value) + " VNĐ";
    }

    private void setBusy(boolean busy, String message) {
        dangXuLy = busy;
        setCursor(busy ? Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR) : Cursor.getDefaultCursor());

        ButtonUtils.setEnabled(btnChonKhachTheoMa, !busy && coQuyenLeTan);
        ButtonUtils.setEnabled(btnTimPhongTrong, !busy && coQuyenLeTan);
        ButtonUtils.setEnabled(btnDatPhong, !busy && coQuyenLeTan);
        ButtonUtils.setEnabled(btnLamMoiForm, !busy && coQuyenLeTan);
        ButtonUtils.setEnabled(btnTimKiem, !busy);
        ButtonUtils.setEnabled(btnTaiLai, !busy);

        if (busy) {
            ButtonUtils.setEnabled(btnNhanPhong, false);
            ButtonUtils.setEnabled(btnDoiPhong, false);
        } else if (bookingDangChon != null) {
            DatPhong booking = bookingDangChon.booking;
            ButtonUtils.setEnabled(btnNhanPhong, 
                    coQuyenLeTan
                            && (booking.getTrangThai() == TrangThaiDatPhong.DA_XAC_NHAN
                            || booking.getTrangThai() == TrangThaiDatPhong.CHO_XAC_NHAN)
            );
            ButtonUtils.setEnabled(btnDoiPhong, coQuyenLeTan && booking.getTrangThai() == TrangThaiDatPhong.DA_NHAN_PHONG);
        }

        lblThongBao.setText(message == null ? "" : message);
    }

    private void showValidationWarning(String message, Component focusComponent) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Dữ liệu chưa hợp lệ",
                JOptionPane.WARNING_MESSAGE
        );
        if (focusComponent != null) {
            focusComponent.requestFocusInWindow();
        }
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Thông báo",
                JOptionPane.WARNING_MESSAGE
        );
    }

    private void showPermissionWarning() {
        JOptionPane.showMessageDialog(
                this,
                "Tài khoản hiện tại không có quyền thực hiện nghiệp vụ lễ tân.",
                "Không đủ quyền",
                JOptionPane.WARNING_MESSAGE
        );
    }

    private void showDatabaseError(String title, Throwable throwable) {
        Throwable rootCause = unwrapCause(throwable);
        String message = rootCause == null || rootCause.getMessage() == null
                ? "Lỗi không xác định."
                : rootCause.getMessage();

        JOptionPane.showMessageDialog(
                this,
                title + ".\n\nChi tiết: " + message,
                "Lỗi xử lý dữ liệu",
                JOptionPane.ERROR_MESSAGE
        );
    }

    private Throwable unwrapCause(Throwable throwable) {
        Throwable current = throwable;
        while (current != null && current.getCause() != null && current.getCause() != current) {
            current = current.getCause();
        }
        return current;
    }

    private JPanel createCardPanel(BorderLayout layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(CARD_COLOR);
        return panel;
    }

    /**
     * Cầu nối tương thích với code nghiệp vụ hiện tại.
     * Toàn bộ nút của màn hình dùng ButtonUtils để tránh style cục bộ ghi đè.
     */
    private void styleActionButton(JButton button, Color background, Color foreground) {
        if (SUCCESS_COLOR.equals(background)) {
            ButtonUtils.success(button);
        } else if (WARNING_COLOR.equals(background)) {
            ButtonUtils.warning(button);
        } else if (DANGER_COLOR.equals(background)) {
            ButtonUtils.danger(button);
        } else {
            ButtonUtils.primary(button);
        }
    }

    private void styleOutlineButton(JButton button, Color foreground) {
        ButtonUtils.neutral(button);
    }

    private void styleSmallButton(JButton button) {
        ButtonUtils.neutral(button);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (Exception ignored) {
            }

            JFrame frame = new JFrame("Kiểm thử - Quản lý Đặt phòng & Lễ tân");
            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            frame.setContentPane(new DatPhongView());
            frame.setSize(1450, 820);
            frame.setMinimumSize(new Dimension(1180, 700));
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

    private static final class BookingDisplayRow {
        private final DatPhong booking;
        private final KhachHang customer;
        private final List<ChiTietDatPhong> details;
        private final String roomNumbers;

        private BookingDisplayRow(
                DatPhong booking,
                KhachHang customer,
                List<ChiTietDatPhong> details,
                String roomNumbers) {
            this.booking = booking;
            this.customer = customer;
            this.details = details;
            this.roomNumbers = roomNumbers;
        }
    }

    private static final class BookingFormData {
        private final DatPhong booking;
        private final ChiTietDatPhong detail;
        private final KhachHang customer;
        private final Phong room;

        private BookingFormData(
                DatPhong booking,
                ChiTietDatPhong detail,
                KhachHang customer,
                Phong room) {
            this.booking = booking;
            this.detail = detail;
            this.customer = customer;
            this.room = room;
        }
    }

    private static final class InitialData {
        private List<KhachHang> customers;
        private List<LoaiPhong> roomTypes;
        private List<Phong> rooms;
        private List<DatPhong> bookings;
        private List<ChiTietDatPhong> bookingDetails;
    }

    private static final class BookingData {
        private List<DatPhong> bookings;
        private List<KhachHang> customers;
        private List<Phong> rooms;
        private List<ChiTietDatPhong> details;
    }

    private static final class ChangeRoomData {
        private List<ChiTietDatPhong> details;
        private List<Phong> rooms;
        private List<LoaiPhong> roomTypes;
        private List<Phong> availableRooms;
    }

    private static final class RoomDetailItem {
        private final ChiTietDatPhong detail;
        private final Phong room;

        private RoomDetailItem(ChiTietDatPhong detail, Phong room) {
            this.detail = detail;
            this.room = room;
        }

        @Override
        public String toString() {
            return "Phòng " + room.getSoPhong();
        }
    }
}
