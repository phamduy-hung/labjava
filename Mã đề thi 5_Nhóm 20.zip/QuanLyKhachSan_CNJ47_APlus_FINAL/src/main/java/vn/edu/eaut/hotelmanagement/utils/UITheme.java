package vn.edu.eaut.hotelmanagement.utils;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.FontUIResource;
import java.awt.Color;
import java.awt.Font;
import java.util.Enumeration;

public final class UITheme {

    private UITheme() {
    }

    /*
     * =========================
     * COLOR PALETTE
     * =========================
     */

    public static final Color PRIMARY =
            new Color(24, 63, 120);

    public static final Color PRIMARY_DARK =
            new Color(18, 48, 92);

    public static final Color PRIMARY_LIGHT =
            new Color(230, 240, 255);

    public static final Color BACKGROUND =
            new Color(245, 247, 250);

    public static final Color PANEL_BACKGROUND =
            Color.WHITE;

    public static final Color TEXT_PRIMARY =
            new Color(36, 47, 62);

    public static final Color TEXT_SECONDARY =
            new Color(110, 123, 142);

    public static final Color BORDER =
            new Color(215, 222, 232);

    /*
     * BUTTON COLORS
     */

    public static final Color BUTTON_ADD =
            new Color(46, 125, 50);

    public static final Color BUTTON_EDIT =
            new Color(30, 90, 180);

    public static final Color BUTTON_DELETE =
            new Color(198, 40, 40);

    public static final Color BUTTON_SEARCH =
            new Color(0, 121, 107);

    public static final Color BUTTON_WARNING =
            new Color(230, 126, 34);

    /*
     * ROOM STATUS COLORS
     */

    public static final Color ROOM_EMPTY =
            new Color(220, 245, 225);

    public static final Color ROOM_OCCUPIED =
            new Color(255, 225, 225);

    public static final Color ROOM_CLEANING =
            new Color(255, 245, 190);

    public static final Color ROOM_BOOKED =
            new Color(225, 238, 255);

    public static final Color ROOM_MAINTENANCE =
            new Color(232, 232, 232);

    /*
     * ROOM STATUS TEXT COLORS
     */

    public static final Color ROOM_EMPTY_TEXT =
            new Color(25, 118, 72);

    public static final Color ROOM_OCCUPIED_TEXT =
            new Color(198, 40, 40);

    public static final Color ROOM_CLEANING_TEXT =
            new Color(183, 110, 0);

    public static final Color ROOM_BOOKED_TEXT =
            new Color(30, 90, 180);

    public static final Color ROOM_MAINTENANCE_TEXT =
            new Color(90, 90, 90);

    /*
     * FONT
     */

    public static final String FONT_NAME =
            "Segoe UI";

    public static final int FONT_SIZE =
            14;

    public static final int FONT_SIZE_SMALL =
            12;

    public static final int FONT_SIZE_TITLE =
            22;

    public static void setupUI() {
        configureLookAndFeel();
        configureGlobalFont();
        configureCommonUIProperties();
    }

    private static void configureLookAndFeel() {
        boolean nimbusApplied = false;

        for (UIManager.LookAndFeelInfo info
                : UIManager.getInstalledLookAndFeels()) {

            if ("Nimbus".equalsIgnoreCase(info.getName())) {

                try {
                    UIManager.setLookAndFeel(
                            info.getClassName()
                    );

                    nimbusApplied = true;
                    break;

                } catch (ClassNotFoundException
                         | InstantiationException
                         | IllegalAccessException
                         | UnsupportedLookAndFeelException exception) {

                    nimbusApplied = false;
                }
            }
        }

        if (!nimbusApplied) {
            try {
                UIManager.setLookAndFeel(
                        UIManager.getSystemLookAndFeelClassName()
                );
            } catch (ClassNotFoundException
                     | InstantiationException
                     | IllegalAccessException
                     | UnsupportedLookAndFeelException exception) {

                System.err.println(
                        "Không thể thiết lập Look and Feel: "
                                + exception.getMessage()
                );
            }
        }
    }

    private static void configureGlobalFont() {
        FontUIResource defaultFont =
                new FontUIResource(
                        FONT_NAME,
                        Font.PLAIN,
                        FONT_SIZE
                );

        Enumeration<Object> keys =
                UIManager.getDefaults().keys();

        while (keys.hasMoreElements()) {

            Object key = keys.nextElement();

            Object value =
                    UIManager.get(key);

            if (value instanceof FontUIResource) {
                UIManager.put(
                        key,
                        defaultFont
                );
            }
        }

        UIManager.put(
                "Button.font",
                new FontUIResource(
                        FONT_NAME,
                        Font.BOLD,
                        FONT_SIZE
                )
        );

        UIManager.put(
                "TableHeader.font",
                new FontUIResource(
                        FONT_NAME,
                        Font.BOLD,
                        FONT_SIZE
                )
        );

        UIManager.put(
                "TitledBorder.font",
                new FontUIResource(
                        FONT_NAME,
                        Font.BOLD,
                        FONT_SIZE
                )
        );
    }

    private static void configureCommonUIProperties() {

        UIManager.put(
                "Table.rowHeight",
                30
        );

        UIManager.put(
                "Table.showHorizontalLines",
                true
        );

        UIManager.put(
                "Table.showVerticalLines",
                false
        );

        UIManager.put(
                "Table.gridColor",
                BORDER
        );

        UIManager.put(
                "Table.selectionBackground",
                new Color(210, 228, 250)
        );

        UIManager.put(
                "Table.selectionForeground",
                TEXT_PRIMARY
        );

        UIManager.put(
                "Panel.background",
                BACKGROUND
        );

        UIManager.put(
                "OptionPane.messageFont",
                new FontUIResource(
                        FONT_NAME,
                        Font.PLAIN,
                        FONT_SIZE
                )
        );
    }
}