package vn.edu.eaut.hotelmanagement.model;

import java.math.BigDecimal;

public class ChiTietDatPhong {
    private Integer id;
    private Integer datPhongId;
    private Integer phongId;
    private BigDecimal giaPhongThucTe;
    private int soNguoiLon;
    private int soTreEm;
    private String ghiChu;

    public ChiTietDatPhong() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDatPhongId() {
        return datPhongId;
    }

    public void setDatPhongId(Integer datPhongId) {
        this.datPhongId = datPhongId;
    }

    public Integer getPhongId() {
        return phongId;
    }

    public void setPhongId(Integer phongId) {
        this.phongId = phongId;
    }

    public BigDecimal getGiaPhongThucTe() {
        return giaPhongThucTe;
    }

    public void setGiaPhongThucTe(BigDecimal giaPhongThucTe) {
        this.giaPhongThucTe = giaPhongThucTe;
    }

    public int getSoNguoiLon() {
        return soNguoiLon;
    }

    public void setSoNguoiLon(int soNguoiLon) {
        this.soNguoiLon = soNguoiLon;
    }

    public int getSoTreEm() {
        return soTreEm;
    }

    public void setSoTreEm(int soTreEm) {
        this.soTreEm = soTreEm;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }
}
