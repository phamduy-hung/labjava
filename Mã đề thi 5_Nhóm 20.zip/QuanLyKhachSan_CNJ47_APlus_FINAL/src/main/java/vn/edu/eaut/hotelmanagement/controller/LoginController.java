package vn.edu.eaut.hotelmanagement.controller;

import vn.edu.eaut.hotelmanagement.service.AuthenticationException;
import vn.edu.eaut.hotelmanagement.service.AuthenticationService;
import vn.edu.eaut.hotelmanagement.session.LoginSession;

import java.sql.SQLException;

/**
 * Controller của màn hình đăng nhập.
 */
public class LoginController {

    private final AuthenticationService authenticationService;

    public LoginController() {
        this(new AuthenticationService());
    }

    public LoginController(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    public LoginSession login(String tenDangNhap, char[] matKhau)
            throws SQLException, AuthenticationException {
        return authenticationService.authenticate(tenDangNhap, matKhau);
    }
}
