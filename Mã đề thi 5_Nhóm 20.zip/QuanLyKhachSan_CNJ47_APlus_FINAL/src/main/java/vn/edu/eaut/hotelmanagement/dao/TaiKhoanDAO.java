package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.TaiKhoan;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TaiKhoanDAO {

    private static final String SELECT_COLUMNS =
            "id, ten_dang_nhap, mat_khau_hash, ho_ten, so_dien_thoai, email, vai_tro_id, "
                    + "dang_hoat_dong, lan_dang_nhap_cuoi, ngay_tao, ngay_cap_nhat";

    public int insert(TaiKhoan taiKhoan) throws SQLException {
        String sql = "INSERT INTO tai_khoan(ten_dang_nhap, mat_khau_hash, ho_ten, so_dien_thoai, email, vai_tro_id, dang_hoat_dong) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, taiKhoan.getTenDangNhap());
            statement.setString(2, taiKhoan.getMatKhauHash());
            statement.setString(3, taiKhoan.getHoTen());
            statement.setString(4, taiKhoan.getSoDienThoai());
            statement.setString(5, taiKhoan.getEmail());
            statement.setInt(6, taiKhoan.getVaiTroId());
            statement.setBoolean(7, taiKhoan.isDangHoatDong());
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    taiKhoan.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của tài khoản vừa thêm.");
    }

    /** Cập nhật thông tin tài khoản nhưng không tự ý thay đổi mật khẩu. */
    public boolean update(TaiKhoan taiKhoan) throws SQLException {
        String sql = "UPDATE tai_khoan SET ten_dang_nhap = ?, ho_ten = ?, so_dien_thoai = ?, email = ?, "
                + "vai_tro_id = ?, dang_hoat_dong = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, taiKhoan.getTenDangNhap());
            statement.setString(2, taiKhoan.getHoTen());
            statement.setString(3, taiKhoan.getSoDienThoai());
            statement.setString(4, taiKhoan.getEmail());
            statement.setInt(5, taiKhoan.getVaiTroId());
            statement.setBoolean(6, taiKhoan.isDangHoatDong());
            statement.setInt(7, taiKhoan.getId());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean updatePasswordHash(int id, String newPasswordHash) throws SQLException {
        String sql = "UPDATE tai_khoan SET mat_khau_hash = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, newPasswordHash);
            statement.setInt(2, id);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean updateLastLogin(int id, LocalDateTime loginTime) throws SQLException {
        String sql = "UPDATE tai_khoan SET lan_dang_nhap_cuoi = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setTimestamp(1, Timestamp.valueOf(loginTime));
            statement.setInt(2, id);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteById(int id) throws SQLException {
        String sql = "DELETE FROM tai_khoan WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    public Optional<TaiKhoan> findById(int id) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM tai_khoan WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public Optional<TaiKhoan> findByUsername(String username) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM tai_khoan WHERE ten_dang_nhap = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<TaiKhoan> findAll() throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM tai_khoan ORDER BY ho_ten";
        return executeListQuery(sql);
    }

    public List<TaiKhoan> search(String keyword) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM tai_khoan "
                + "WHERE ten_dang_nhap LIKE ? OR ho_ten LIKE ? OR so_dien_thoai LIKE ? OR email LIKE ? ORDER BY ho_ten";
        String searchValue = "%" + (keyword == null ? "" : keyword.trim()) + "%";
        List<TaiKhoan> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            for (int i = 1; i <= 4; i++) {
                statement.setString(i, searchValue);
            }
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public List<TaiKhoan> findByRoleId(int roleId) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM tai_khoan WHERE vai_tro_id = ? ORDER BY ho_ten";
        List<TaiKhoan> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, roleId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    private List<TaiKhoan> executeListQuery(String sql) throws SQLException {
        List<TaiKhoan> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(mapRow(resultSet));
            }
        }
        return result;
    }

    TaiKhoan mapRow(ResultSet resultSet) throws SQLException {
        TaiKhoan taiKhoan = new TaiKhoan();
        taiKhoan.setId(resultSet.getInt("id"));
        taiKhoan.setTenDangNhap(resultSet.getString("ten_dang_nhap"));
        taiKhoan.setMatKhauHash(resultSet.getString("mat_khau_hash"));
        taiKhoan.setHoTen(resultSet.getString("ho_ten"));
        taiKhoan.setSoDienThoai(resultSet.getString("so_dien_thoai"));
        taiKhoan.setEmail(resultSet.getString("email"));
        taiKhoan.setVaiTroId(resultSet.getInt("vai_tro_id"));
        taiKhoan.setDangHoatDong(resultSet.getBoolean("dang_hoat_dong"));
        taiKhoan.setLanDangNhapCuoi(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "lan_dang_nhap_cuoi"));
        taiKhoan.setNgayTao(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_tao"));
        taiKhoan.setNgayCapNhat(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_cap_nhat"));
        return taiKhoan;
    }
}
