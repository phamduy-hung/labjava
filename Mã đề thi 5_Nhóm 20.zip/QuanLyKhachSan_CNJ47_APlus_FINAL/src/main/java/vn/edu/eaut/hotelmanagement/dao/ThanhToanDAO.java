package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.ThanhToan;
import vn.edu.eaut.hotelmanagement.model.enums.PhuongThucThanhToan;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ThanhToanDAO {

    private static final String SELECT_COLUMNS =
            "tt.id, tt.ma_thanh_toan, tt.hoa_don_id, tt.so_tien, tt.phuong_thuc, tt.ma_tham_chieu, "
                    + "tt.nhan_vien_thu_id, tt.thoi_gian_thanh_toan, tt.ghi_chu";

    public int insert(ThanhToan payment) throws SQLException {
        String sql = "INSERT INTO thanh_toan(ma_thanh_toan, hoa_don_id, so_tien, phuong_thuc, ma_tham_chieu, nhan_vien_thu_id, thoi_gian_thanh_toan, ghi_chu) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, payment, false);
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    payment.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của thanh toán vừa thêm.");
    }

    public boolean update(ThanhToan payment) throws SQLException {
        String sql = "UPDATE thanh_toan SET ma_thanh_toan = ?, hoa_don_id = ?, so_tien = ?, phuong_thuc = ?, ma_tham_chieu = ?, "
                + "nhan_vien_thu_id = ?, thoi_gian_thanh_toan = ?, ghi_chu = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            bind(statement, payment, true);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteById(int id) throws SQLException {
        String sql = "DELETE FROM thanh_toan WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    public Optional<ThanhToan> findById(int id) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM thanh_toan tt WHERE tt.id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<ThanhToan> findAll() throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM thanh_toan tt ORDER BY tt.thoi_gian_thanh_toan DESC, tt.id DESC";
        return executeList(sql);
    }

    public List<ThanhToan> findByInvoiceId(int invoiceId) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM thanh_toan tt WHERE tt.hoa_don_id = ? ORDER BY tt.thoi_gian_thanh_toan, tt.id";
        List<ThanhToan> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, invoiceId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public List<ThanhToan> search(String keyword) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM thanh_toan tt JOIN hoa_don hd ON hd.id = tt.hoa_don_id "
                + "WHERE tt.ma_thanh_toan LIKE ? OR hd.ma_hoa_don LIKE ? OR tt.ma_tham_chieu LIKE ? ORDER BY tt.thoi_gian_thanh_toan DESC";
        String searchValue = "%" + (keyword == null ? "" : keyword.trim()) + "%";
        List<ThanhToan> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, searchValue);
            statement.setString(2, searchValue);
            statement.setString(3, searchValue);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public BigDecimal sumByInvoiceId(int invoiceId) throws SQLException {
        String sql = "SELECT COALESCE(SUM(so_tien), 0) AS tong_da_thanh_toan FROM thanh_toan WHERE hoa_don_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, invoiceId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getBigDecimal("tong_da_thanh_toan") : BigDecimal.ZERO;
            }
        }
    }

    private List<ThanhToan> executeList(String sql) throws SQLException {
        List<ThanhToan> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(mapRow(resultSet));
            }
        }
        return result;
    }

    private void bind(PreparedStatement statement, ThanhToan payment, boolean includeId) throws SQLException {
        LocalDateTime paymentTime = payment.getThoiGianThanhToan() == null ? LocalDateTime.now() : payment.getThoiGianThanhToan();
        statement.setString(1, payment.getMaThanhToan());
        statement.setInt(2, payment.getHoaDonId());
        statement.setBigDecimal(3, payment.getSoTien());
        statement.setString(4, payment.getPhuongThuc().name());
        statement.setString(5, payment.getMaThamChieu());
        JdbcDataAccessSupport.setNullableInteger(statement, 6, payment.getNhanVienThuId());
        statement.setTimestamp(7, Timestamp.valueOf(paymentTime));
        statement.setString(8, payment.getGhiChu());
        if (includeId) {
            statement.setInt(9, payment.getId());
        }
    }

    private ThanhToan mapRow(ResultSet resultSet) throws SQLException {
        ThanhToan payment = new ThanhToan();
        payment.setId(resultSet.getInt("id"));
        payment.setMaThanhToan(resultSet.getString("ma_thanh_toan"));
        payment.setHoaDonId(resultSet.getInt("hoa_don_id"));
        payment.setSoTien(resultSet.getBigDecimal("so_tien"));
        payment.setPhuongThuc(PhuongThucThanhToan.valueOf(resultSet.getString("phuong_thuc")));
        payment.setMaThamChieu(resultSet.getString("ma_tham_chieu"));
        int employeeId = resultSet.getInt("nhan_vien_thu_id");
        payment.setNhanVienThuId(resultSet.wasNull() ? null : employeeId);
        payment.setThoiGianThanhToan(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "thoi_gian_thanh_toan"));
        payment.setGhiChu(resultSet.getString("ghi_chu"));
        return payment;
    }
}
