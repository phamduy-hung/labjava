package vn.edu.eaut.hotelmanagement.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Các hàm hỗ trợ dùng chung cho tầng DAO khi làm việc với JDBC.
 * Lớp này chỉ xử lý chuyển đổi kiểu dữ liệu JDBC, không chứa nghiệp vụ.
 */
final class JdbcDataAccessSupport {

    private JdbcDataAccessSupport() {
    }

    static void setNullableInteger(PreparedStatement statement, int parameterIndex, Integer value)
            throws SQLException {
        if (value == null) {
            statement.setNull(parameterIndex, Types.INTEGER);
        } else {
            statement.setInt(parameterIndex, value);
        }
    }

    static void setNullableLocalDate(PreparedStatement statement, int parameterIndex, LocalDate value)
            throws SQLException {
        if (value == null) {
            statement.setNull(parameterIndex, Types.DATE);
        } else {
            statement.setDate(parameterIndex, Date.valueOf(value));
        }
    }

    static void setNullableLocalDateTime(PreparedStatement statement, int parameterIndex, LocalDateTime value)
            throws SQLException {
        if (value == null) {
            statement.setNull(parameterIndex, Types.TIMESTAMP);
        } else {
            statement.setTimestamp(parameterIndex, Timestamp.valueOf(value));
        }
    }

    static LocalDate getNullableLocalDate(ResultSet resultSet, String columnName) throws SQLException {
        Date value = resultSet.getDate(columnName);
        return value == null ? null : value.toLocalDate();
    }

    static LocalDateTime getNullableLocalDateTime(ResultSet resultSet, String columnName) throws SQLException {
        Timestamp value = resultSet.getTimestamp(columnName);
        return value == null ? null : value.toLocalDateTime();
    }
}
