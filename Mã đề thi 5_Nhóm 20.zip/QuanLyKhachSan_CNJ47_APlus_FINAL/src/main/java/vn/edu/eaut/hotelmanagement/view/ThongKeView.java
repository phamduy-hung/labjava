package vn.edu.eaut.hotelmanagement.view;

import vn.edu.eaut.hotelmanagement.dao.LoaiPhongDAO;
import vn.edu.eaut.hotelmanagement.dao.ThongKeDAO;
import vn.edu.eaut.hotelmanagement.dao.ThongKeDAO.HoaDonThongKe;
import vn.edu.eaut.hotelmanagement.dao.ThongKeDAO.NhomThongKe;
import vn.edu.eaut.hotelmanagement.dao.ThongKeDAO.ThongKeTongHop;
import vn.edu.eaut.hotelmanagement.model.LoaiPhong;
import vn.edu.eaut.hotelmanagement.session.LoginSession;

import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.math.BigDecimal;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

/**
 * Màn hình Thống kê doanh thu và Báo cáo.
 *
 * Chức năng:
 * - Thống kê theo tháng, theo năm hoặc theo loại phòng.
 * - Hiển thị tổng doanh thu, số lượt phòng thuê, số hóa đơn và doanh thu trung bình/hóa đơn.
 * - Hiển thị danh sách hóa đơn đã thanh toán trong phạm vi lọc.
 * - Hiển thị bảng phân tích nhóm bằng các truy vấn SUM, COUNT, GROUP BY trong ThongKeDAO.
 * - Tất cả thao tác truy vấn CSDL chạy bằng SwingWorker để không làm treo EDT.
 */
public class ThongKeView extends JPanel {

    private static final Color PRIMARY_COLOR = new Color(26, 83, 155);
    private static final Color PRIMARY_DARK_COLOR = new Color(17, 55, 105);
    private static final Color BACKGROUND_COLOR = new Color(244, 247, 251);
    private static final Color CARD_COLOR = Color.WHITE;
    private static final Color BORDER_COLOR = new Color(221, 228, 236);
    private static final Color TEXT_COLOR = new Color(38, 49, 64);
    private static final Color SECONDARY_TEXT_COLOR = new Color(105, 117, 133);
    private static final Color SUCCESS_COLOR = new Color(37, 137, 88);
    private static final Color WARNING_COLOR = new Color(193, 124, 31);

    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private static final NumberFormat MONEY_FORMAT =
            NumberFormat.getNumberInstance(new Locale("vi", "VN"));

    private final LoginSession loginSession;
    private final ThongKeDAO thongKeDAO;
    private final LoaiPhongDAO loaiPhongDAO;

    private final JComboBox<LoaiThongKe> cboLoaiThongKe =
            new JComboBox<>(LoaiThongKe.values());

    private final JSpinner spnThang = new JSpinner(
            new SpinnerNumberModel(LocalDate.now().getMonthValue(), 1, 12, 1)
    );

    private final JSpinner spnNam = new JSpinner(
            new SpinnerNumberModel(LocalDate.now().getYear(), 2000, 2200, 1)
    );

    private final JComboBox<LoaiPhong> cboLoaiPhong = new JComboBox<>();

    private final JButton btnThongKe = new JButton("Thống kê");
    private final JButton btnLamMoi = new JButton("Làm mới");
    private final JButton btnXemBaoCao = new JButton("Xem báo cáo");
    private final JButton btnXuatCsv = new JButton("Xuất CSV");

    private final JLabel lblTongDoanhThu = new JLabel("0 VNĐ");
    private final JLabel lblSoLuotPhong = new JLabel("0");
    private final JLabel lblSoHoaDon = new JLabel("0");
    private final JLabel lblTrungBinhHoaDon = new JLabel("0 VNĐ");
    private final JLabel lblMoTaBoLoc = new JLabel(" ");
    private final JLabel lblTrangThai = new JLabel("Sẵn sàng");

    private final DefaultTableModel hoaDonTableModel = new DefaultTableModel(
            new Object[]{
                    "Mã hóa đơn",
                    "Thời gian lập",
                    "Mã booking",
                    "Khách hàng",
                    "Phòng",
                    "Loại phòng",
                    "Lượt phòng",
                    "Tiền phòng",
                    "Tiền dịch vụ",
                    "Phụ thu",
                    "Giảm giá",
                    "Tổng thanh toán"
            },
            0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tblHoaDon = new JTable(hoaDonTableModel);

    private final DefaultTableModel nhomTableModel = new DefaultTableModel(
            new Object[]{"Nhóm thống kê", "Số hóa đơn", "Lượt phòng", "Doanh thu"},
            0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tblNhomThongKe = new JTable(nhomTableModel);

    private ThongKeTongHop thongKeTongHopHienTai = ThongKeTongHop.empty();
    private List<HoaDonThongKe> danhSachHoaDonHienTai = new ArrayList<>();
    private List<NhomThongKe> danhSachNhomHienTai = new ArrayList<>();
    private String moTaBoLocHienTai = "Chưa thực hiện thống kê";
    private boolean dangXuLy;

    public ThongKeView(LoginSession loginSession) {
        this.loginSession = Objects.requireNonNull(
                loginSession,
                "Phiên đăng nhập không được để trống."
        );
        this.thongKeDAO = new ThongKeDAO();
        this.loaiPhongDAO = new LoaiPhongDAO();

        initializeLayout();
        configureTables();
        registerEvents();
        updateFilterControls();
        loadRoomTypesThenStatistics();
    }

    private void initializeLayout() {
        setLayout(new BorderLayout(0, 16));
        setBackground(BACKGROUND_COLOR);
        setBorder(new EmptyBorder(20, 20, 20, 20));

        add(createHeaderPanel(), BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout(0, 14));
        centerPanel.setOpaque(false);
        centerPanel.add(createFilterPanel(), BorderLayout.NORTH);

        JPanel reportPanel = new JPanel(new BorderLayout(0, 14));
        reportPanel.setOpaque(false);
        reportPanel.add(createSummaryPanel(), BorderLayout.NORTH);
        reportPanel.add(createAnalyticsPanel(), BorderLayout.CENTER);

        centerPanel.add(reportPanel, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);
        add(createStatusPanel(), BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(12, 4));
        panel.setOpaque(false);

        JLabel title = new JLabel("THỐNG KÊ DOANH THU VÀ BÁO CÁO");
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        title.setForeground(PRIMARY_DARK_COLOR);

        JLabel subtitle = new JLabel(
                "Phân tích hóa đơn đã thanh toán theo tháng, năm hoặc loại phòng."
        );
        subtitle.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        subtitle.setForeground(SECONDARY_TEXT_COLOR);

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 3));
        textPanel.setOpaque(false);
        textPanel.add(title);
        textPanel.add(subtitle);

        panel.add(textPanel, BorderLayout.WEST);
        return panel;
    }

    private JPanel createFilterPanel() {
        JPanel outer = createCardPanel(new BorderLayout(0, 10));

        JLabel title = new JLabel("BỘ LỌC THỐNG KÊ");
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        title.setForeground(TEXT_COLOR);
        outer.add(title, BorderLayout.NORTH);

        JPanel fields = new JPanel(new GridBagLayout());
        fields.setOpaque(false);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(5, 6, 5, 6);
        constraints.anchor = GridBagConstraints.WEST;
        constraints.fill = GridBagConstraints.HORIZONTAL;

        int column = 0;

        constraints.gridx = column++;
        constraints.gridy = 0;
        constraints.weightx = 0;
        fields.add(new JLabel("Kiểu thống kê:"), constraints);

        constraints.gridx = column++;
        constraints.weightx = 0.2;
        cboLoaiThongKe.setPreferredSize(new Dimension(175, 30));
        fields.add(cboLoaiThongKe, constraints);

        constraints.gridx = column++;
        constraints.weightx = 0;
        fields.add(new JLabel("Tháng:"), constraints);

        constraints.gridx = column++;
        constraints.weightx = 0.08;
        spnThang.setPreferredSize(new Dimension(80, 30));
        fields.add(spnThang, constraints);

        constraints.gridx = column++;
        constraints.weightx = 0;
        fields.add(new JLabel("Năm:"), constraints);

        constraints.gridx = column++;
        constraints.weightx = 0.1;
        spnNam.setPreferredSize(new Dimension(95, 30));
        fields.add(spnNam, constraints);

        constraints.gridx = column++;
        constraints.weightx = 0;
        fields.add(new JLabel("Loại phòng:"), constraints);

        constraints.gridx = column++;
        constraints.weightx = 0.35;
        cboLoaiPhong.setPreferredSize(new Dimension(230, 30));
        fields.add(cboLoaiPhong, constraints);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);

        stylePrimaryButton(btnThongKe);
        styleSecondaryButton(btnLamMoi);
        styleSecondaryButton(btnXemBaoCao);
        styleSecondaryButton(btnXuatCsv);

        buttons.add(btnThongKe);
        buttons.add(btnLamMoi);
        buttons.add(btnXemBaoCao);
        buttons.add(btnXuatCsv);

        constraints.gridx = column;
        constraints.weightx = 0;
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.EAST;
        fields.add(buttons, constraints);

        outer.add(fields, BorderLayout.CENTER);

        lblMoTaBoLoc.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 12));
        lblMoTaBoLoc.setForeground(SECONDARY_TEXT_COLOR);
        outer.add(lblMoTaBoLoc, BorderLayout.SOUTH);

        return outer;
    }

    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 4, 12, 0));
        panel.setOpaque(false);

        panel.add(createSummaryCard(
                "TỔNG DOANH THU",
                lblTongDoanhThu,
                "Tổng giá trị hóa đơn đã thanh toán",
                SUCCESS_COLOR
        ));

        panel.add(createSummaryCard(
                "LƯỢT PHÒNG ĐƯỢC THUÊ",
                lblSoLuotPhong,
                "Số phòng phát sinh trong các hóa đơn",
                PRIMARY_COLOR
        ));

        panel.add(createSummaryCard(
                "SỐ HÓA ĐƠN",
                lblSoHoaDon,
                "Hóa đơn đã thanh toán trong bộ lọc",
                WARNING_COLOR
        ));

        panel.add(createSummaryCard(
                "TRUNG BÌNH / HÓA ĐƠN",
                lblTrungBinhHoaDon,
                "Doanh thu trung bình mỗi hóa đơn",
                PRIMARY_DARK_COLOR
        ));

        return panel;
    }

    private JPanel createSummaryCard(
            String title,
            JLabel valueLabel,
            String description,
            Color accentColor) {

        JPanel card = createCardPanel(new BorderLayout(0, 7));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(4, 0, 0, 0, accentColor),
                new EmptyBorder(13, 15, 13, 15)
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        titleLabel.setForeground(SECONDARY_TEXT_COLOR);

        valueLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 23));
        valueLabel.setForeground(accentColor);

        JLabel descriptionLabel = new JLabel(description);
        descriptionLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
        descriptionLabel.setForeground(SECONDARY_TEXT_COLOR);

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(descriptionLabel, BorderLayout.SOUTH);
        return card;
    }

    private Component createTablesPanel() {
        JPanel invoicePanel = createCardPanel(new BorderLayout(0, 8));
        JLabel invoiceTitle = new JLabel("DANH SÁCH HÓA ĐƠN TRONG BỘ LỌC");
        invoiceTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        invoiceTitle.setForeground(TEXT_COLOR);
        invoicePanel.add(invoiceTitle, BorderLayout.NORTH);
        invoicePanel.add(new JScrollPane(tblHoaDon), BorderLayout.CENTER);

        JPanel groupPanel = createCardPanel(new BorderLayout(0, 8));
        JLabel groupTitle = new JLabel("PHÂN TÍCH TỔNG HỢP (SUM / COUNT / GROUP BY)");
        groupTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        groupTitle.setForeground(TEXT_COLOR);
        groupPanel.add(groupTitle, BorderLayout.NORTH);
        groupPanel.add(new JScrollPane(tblNhomThongKe), BorderLayout.CENTER);

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                invoicePanel,
                groupPanel
        );
        splitPane.setResizeWeight(0.72);
        splitPane.setDividerLocation(390);
        splitPane.setBorder(null);
        splitPane.setOpaque(false);
        return splitPane;
    }

    private Component createAnalyticsPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setOpaque(false);

        JPanel charts = new JPanel(new GridLayout(1, 2, 12, 0));
        charts.setOpaque(false);
        charts.add(createRevenueChartPanel());
        charts.add(createVolumeChartPanel());

        panel.add(charts, BorderLayout.NORTH);
        panel.add(createTablesPanel(), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createRevenueChartPanel() {
        JPanel card = createCardPanel(new BorderLayout(0, 6));
        JLabel title = new JLabel("DOANH THU THEO NHÓM");
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        title.setForeground(TEXT_COLOR);
        card.add(title, BorderLayout.NORTH);
        card.add(new RevenueChartPanel(), BorderLayout.CENTER);
        return card;
    }

    private JPanel createVolumeChartPanel() {
        JPanel card = createCardPanel(new BorderLayout(0, 6));
        JLabel title = new JLabel("SỐ HÓA ĐƠN VÀ LƯỢT PHÒNG");
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        title.setForeground(TEXT_COLOR);
        card.add(title, BorderLayout.NORTH);
        card.add(new VolumeChartPanel(), BorderLayout.CENTER);
        return card;
    }

    private JPanel createStatusPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        lblTrangThai.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        lblTrangThai.setForeground(SECONDARY_TEXT_COLOR);
        panel.add(lblTrangThai, BorderLayout.WEST);
        return panel;
    }

    private JPanel createCardPanel(BorderLayout layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(CARD_COLOR);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(12, 12, 12, 12)
        ));
        return panel;
    }

    private void configureTables() {
        configureTable(tblHoaDon);
        configureTable(tblNhomThongKe);

        tblHoaDon.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        int[] widths = {110, 135, 115, 200, 130, 180, 85, 125, 125, 105, 105, 145};
        for (int index = 0; index < widths.length; index++) {
            tblHoaDon.getColumnModel().getColumn(index).setPreferredWidth(widths[index]);
        }

        tblNhomThongKe.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        tblNhomThongKe.getColumnModel().getColumn(0).setPreferredWidth(260);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);

        int[] centerColumns = {0, 1, 2, 4, 6};
        for (int column : centerColumns) {
            tblHoaDon.getColumnModel().getColumn(column).setCellRenderer(centerRenderer);
        }

        int[] moneyColumns = {7, 8, 9, 10, 11};
        for (int column : moneyColumns) {
            tblHoaDon.getColumnModel().getColumn(column).setCellRenderer(rightRenderer);
        }

        tblNhomThongKe.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        tblNhomThongKe.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        tblNhomThongKe.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);
    }

    private void configureTable(JTable table) {
        table.setRowHeight(28);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setFillsViewportHeight(true);
        table.setGridColor(new Color(231, 235, 241));
        table.setShowVerticalLines(true);
        table.setShowHorizontalLines(true);
        table.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(header.getPreferredSize().width, 32));
    }

    private void registerEvents() {
        cboLoaiThongKe.addActionListener(event -> updateFilterControls());
        btnThongKe.addActionListener(event -> executeStatistics());
        btnLamMoi.addActionListener(event -> resetFilters());
        btnXemBaoCao.addActionListener(event -> showReportDialog());
        btnXuatCsv.addActionListener(event -> exportCsv());
    }

    private void updateFilterControls() {
        LoaiThongKe selected = (LoaiThongKe) cboLoaiThongKe.getSelectedItem();
        if (selected == null) {
            selected = LoaiThongKe.THEO_THANG;
        }

        boolean monthEnabled = selected == LoaiThongKe.THEO_THANG;
        boolean yearEnabled = selected == LoaiThongKe.THEO_THANG || selected == LoaiThongKe.THEO_NAM;
        boolean roomTypeEnabled = selected == LoaiThongKe.THEO_LOAI_PHONG;

        spnThang.setEnabled(monthEnabled && !dangXuLy);
        spnNam.setEnabled(yearEnabled && !dangXuLy);
        cboLoaiPhong.setEnabled(roomTypeEnabled && !dangXuLy);

        switch (selected) {
            case THEO_THANG -> lblMoTaBoLoc.setText(
                    "Theo tháng: chỉ tính hóa đơn DA_THANH_TOAN trong tháng/năm được chọn."
            );
            case THEO_NAM -> lblMoTaBoLoc.setText(
                    "Theo năm: tổng hợp cả năm và phân tích doanh thu theo từng tháng."
            );
            case THEO_LOAI_PHONG -> lblMoTaBoLoc.setText(
                    "Theo loại phòng: lọc các hóa đơn đã thanh toán có sử dụng loại phòng được chọn."
            );
        }
    }

    private void loadRoomTypesThenStatistics() {
        setBusy(true, "Đang tải danh mục loại phòng...");

        SwingWorker<List<LoaiPhong>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<LoaiPhong> doInBackground() throws Exception {
                return loaiPhongDAO.findAll();
            }

            @Override
            protected void done() {
                try {
                    List<LoaiPhong> roomTypes = get();
                    cboLoaiPhong.removeAllItems();
                    for (LoaiPhong roomType : roomTypes) {
                        cboLoaiPhong.addItem(roomType);
                    }
                    setBusy(false, "Đã tải danh mục loại phòng.");
                    executeStatistics();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Tải loại phòng bị gián đoạn.");
                    showError("Quá trình tải loại phòng đã bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không thể tải loại phòng.");
                    showDatabaseError(exception.getCause());
                }
            }
        };

        worker.execute();
    }

    private void executeStatistics() {
        if (dangXuLy) {
            return;
        }

        LoaiThongKe filterType = (LoaiThongKe) cboLoaiThongKe.getSelectedItem();
        if (filterType == null) {
            showWarning("Vui lòng chọn kiểu thống kê.");
            return;
        }

        int month = (Integer) spnThang.getValue();
        int year = (Integer) spnNam.getValue();
        LoaiPhong roomType = (LoaiPhong) cboLoaiPhong.getSelectedItem();

        if (filterType == LoaiThongKe.THEO_LOAI_PHONG && roomType == null) {
            showWarning("Vui lòng chọn loại phòng cần thống kê.");
            return;
        }

        String filterDescription = createFilterDescription(filterType, month, year, roomType);
        setBusy(true, "Đang truy vấn và tổng hợp dữ liệu...");

        SwingWorker<ReportData, Void> worker = new SwingWorker<>() {
            @Override
            protected ReportData doInBackground() throws Exception {
                return queryReportData(filterType, month, year, roomType);
            }

            @Override
            protected void done() {
                try {
                    ReportData data = get();
                    thongKeTongHopHienTai = data.summary;
                    danhSachHoaDonHienTai = data.invoices;
                    danhSachNhomHienTai = data.groups;
                    moTaBoLocHienTai = filterDescription;

                    updateSummary(data.summary);
                    fillInvoiceTable(data.invoices);
                    fillGroupTable(data.groups);
                    lblMoTaBoLoc.setText(filterDescription);
                    repaintCharts();

                    setBusy(
                            false,
                            "Hoàn thành: " + data.summary.getSoHoaDon()
                                    + " hóa đơn, " + data.summary.getSoLuotPhong()
                                    + " lượt phòng."
                    );
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Thống kê bị gián đoạn.");
                    showError("Quá trình thống kê đã bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Thống kê thất bại.");
                    Throwable cause = exception.getCause();
                    if (cause instanceof IllegalArgumentException) {
                        showWarning(cause.getMessage());
                    } else {
                        showDatabaseError(cause);
                    }
                }
            }
        };

        worker.execute();
    }

    private ReportData queryReportData(
            LoaiThongKe filterType,
            int month,
            int year,
            LoaiPhong roomType) throws SQLException {

        return switch (filterType) {
            case THEO_THANG -> new ReportData(
                    thongKeDAO.thongKeTheoThang(year, month),
                    thongKeDAO.danhSachHoaDonTheoThang(year, month),
                    thongKeDAO.nhomTheoLoaiPhongTrongThang(year, month)
            );

            case THEO_NAM -> new ReportData(
                    thongKeDAO.thongKeTheoNam(year),
                    thongKeDAO.danhSachHoaDonTheoNam(year),
                    thongKeDAO.nhomTheoThangTrongNam(year)
            );

            case THEO_LOAI_PHONG -> {
                if (roomType == null || roomType.getId() == null) {
                    throw new IllegalArgumentException("Loại phòng thống kê không hợp lệ.");
                }
                yield new ReportData(
                        thongKeDAO.thongKeTheoLoaiPhong(roomType.getId()),
                        thongKeDAO.danhSachHoaDonTheoLoaiPhong(roomType.getId()),
                        thongKeDAO.nhomTheoThoiGianCuaLoaiPhong(roomType.getId())
                );
            }
        };
    }

    private String createFilterDescription(
            LoaiThongKe filterType,
            int month,
            int year,
            LoaiPhong roomType) {

        return switch (filterType) {
            case THEO_THANG -> String.format(
                    "Bộ lọc hiện tại: Tháng %02d/%04d - chỉ tính hóa đơn đã thanh toán.",
                    month,
                    year
            );
            case THEO_NAM -> String.format(
                    "Bộ lọc hiện tại: Năm %04d - chỉ tính hóa đơn đã thanh toán.",
                    year
            );
            case THEO_LOAI_PHONG -> "Bộ lọc hiện tại: Loại phòng "
                    + (roomType == null ? "chưa chọn" : roomType.toString())
                    + " - toàn bộ thời gian, chỉ tính hóa đơn đã thanh toán.";
        };
    }

    private void updateSummary(ThongKeTongHop summary) {
        lblTongDoanhThu.setText(formatMoney(summary.getTongDoanhThu()));
        lblSoLuotPhong.setText(String.valueOf(summary.getSoLuotPhong()));
        lblSoHoaDon.setText(String.valueOf(summary.getSoHoaDon()));
        lblTrungBinhHoaDon.setText(formatMoney(summary.getDoanhThuTrungBinhMoiHoaDon()));
    }

    private void fillInvoiceTable(List<HoaDonThongKe> invoices) {
        hoaDonTableModel.setRowCount(0);

        for (HoaDonThongKe invoice : invoices) {
            String customer = invoice.getMaKhachHang() + " - " + invoice.getHoTenKhachHang();
            hoaDonTableModel.addRow(new Object[]{
                    invoice.getMaHoaDon(),
                    invoice.getThoiGianLap() == null
                            ? ""
                            : invoice.getThoiGianLap().format(DATE_TIME_FORMATTER),
                    invoice.getMaDatPhong(),
                    customer,
                    invoice.getDanhSachPhong(),
                    invoice.getDanhSachLoaiPhong(),
                    invoice.getSoLuotPhong(),
                    formatMoney(invoice.getTongTienPhong()),
                    formatMoney(invoice.getTongTienDichVu()),
                    formatMoney(invoice.getPhuThu()),
                    formatMoney(invoice.getGiamGia()),
                    formatMoney(invoice.getTongThanhToan())
            });
        }
    }

    private void fillGroupTable(List<NhomThongKe> groups) {
        nhomTableModel.setRowCount(0);

        for (NhomThongKe group : groups) {
            nhomTableModel.addRow(new Object[]{
                    group.getNhom(),
                    group.getSoHoaDon(),
                    group.getSoLuotPhong(),
                    formatMoney(group.getTongDoanhThu())
            });
        }
    }

    private void resetFilters() {
        cboLoaiThongKe.setSelectedItem(LoaiThongKe.THEO_THANG);
        spnThang.setValue(LocalDate.now().getMonthValue());
        spnNam.setValue(LocalDate.now().getYear());
        if (cboLoaiPhong.getItemCount() > 0) {
            cboLoaiPhong.setSelectedIndex(0);
        }
        updateFilterControls();
        executeStatistics();
    }

    private void showReportDialog() {
        JTextArea reportArea = new JTextArea(buildReportText(), 34, 88);
        reportArea.setEditable(false);
        reportArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        reportArea.setCaretPosition(0);
        reportArea.setLineWrap(false);

        JScrollPane scrollPane = new JScrollPane(reportArea);
        scrollPane.setPreferredSize(new Dimension(920, 620));

        JDialog dialog = new JDialog(
                (Frame) javax.swing.SwingUtilities.getWindowAncestor(this),
                "Báo cáo doanh thu",
                true
        );
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.getRootPane().setBorder(new EmptyBorder(12, 12, 12, 12));
        dialog.add(scrollPane, BorderLayout.CENTER);

        JButton closeButton = new JButton("Đóng");
        stylePrimaryButton(closeButton);
        closeButton.addActionListener(event -> dialog.dispose());

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.add(closeButton);
        dialog.add(bottom, BorderLayout.SOUTH);

        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private String buildReportText() {
        StringBuilder builder = new StringBuilder();
        builder.append("================================================================================\n");
        builder.append("                 BÁO CÁO THỐNG KÊ DOANH THU KHÁCH SẠN\n");
        builder.append("================================================================================\n");
        builder.append("Thời điểm xuất báo cáo : ")
                .append(LocalDateTime.now().format(DATE_TIME_FORMATTER))
                .append('\n');
        builder.append("Nhân viên              : ")
                .append(loginSession.getTaiKhoan().getHoTen())
                .append('\n');
        builder.append("Vai trò                : ")
                .append(loginSession.getVaiTro().getTenVaiTro())
                .append('\n');
        builder.append("Bộ lọc                 : ")
                .append(moTaBoLocHienTai)
                .append("\n\n");

        builder.append("TỔNG DOANH THU          : ")
                .append(formatMoney(thongKeTongHopHienTai.getTongDoanhThu()))
                .append('\n');
        builder.append("SỐ LƯỢT PHÒNG THUÊ      : ")
                .append(thongKeTongHopHienTai.getSoLuotPhong())
                .append('\n');
        builder.append("SỐ HÓA ĐƠN              : ")
                .append(thongKeTongHopHienTai.getSoHoaDon())
                .append('\n');
        builder.append("TRUNG BÌNH / HÓA ĐƠN    : ")
                .append(formatMoney(thongKeTongHopHienTai.getDoanhThuTrungBinhMoiHoaDon()))
                .append("\n\n");

        builder.append("--------------------------------------------------------------------------------\n");
        builder.append("PHÂN TÍCH TỔNG HỢP\n");
        builder.append("--------------------------------------------------------------------------------\n");
        if (danhSachNhomHienTai.isEmpty()) {
            builder.append("Không có dữ liệu.\n");
        } else {
            for (NhomThongKe group : danhSachNhomHienTai) {
                builder.append(String.format(
                        Locale.ROOT,
                        "%-32s | HĐ: %4d | Lượt phòng: %4d | %s%n",
                        group.getNhom(),
                        group.getSoHoaDon(),
                        group.getSoLuotPhong(),
                        formatMoney(group.getTongDoanhThu())
                ));
            }
        }

        builder.append("\n--------------------------------------------------------------------------------\n");
        builder.append("DANH SÁCH HÓA ĐƠN\n");
        builder.append("--------------------------------------------------------------------------------\n");
        if (danhSachHoaDonHienTai.isEmpty()) {
            builder.append("Không có hóa đơn trong bộ lọc.\n");
        } else {
            for (HoaDonThongKe invoice : danhSachHoaDonHienTai) {
                builder.append(invoice.getMaHoaDon())
                        .append(" | ")
                        .append(invoice.getThoiGianLap() == null
                                ? ""
                                : invoice.getThoiGianLap().format(DATE_TIME_FORMATTER))
                        .append(" | ")
                        .append(invoice.getHoTenKhachHang())
                        .append(" | Phòng: ")
                        .append(invoice.getDanhSachPhong())
                        .append(" | ")
                        .append(formatMoney(invoice.getTongThanhToan()))
                        .append('\n');
            }
        }

        builder.append("================================================================================\n");
        builder.append("Ghi chú: Doanh thu chỉ bao gồm hóa đơn ở trạng thái ĐÃ THANH TOÁN.\n");
        builder.append("================================================================================\n");
        return builder.toString();
    }

    private void repaintCharts() {
        getContentPaneDescendants(this).forEach(Component::repaint);
    }

    private List<Component> getContentPaneDescendants(Component root) {
        List<Component> result = new ArrayList<>();
        if (root instanceof java.awt.Container container) {
            for (Component child : container.getComponents()) {
                result.add(child);
                result.addAll(getContentPaneDescendants(child));
            }
        }
        return result;
    }

    private void exportCsv() {
        if (danhSachHoaDonHienTai.isEmpty()) {
            showWarning("Chưa có dữ liệu hóa đơn để xuất.");
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Xuất báo cáo doanh thu CSV");
        chooser.setSelectedFile(new java.io.File("bao_cao_doanh_thu.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        Path path = chooser.getSelectedFile().toPath();
        StringBuilder csv = new StringBuilder();
        csv.append("Mã hóa đơn,Mã booking,Thời gian lập,Khách hàng,Phòng,Loại phòng,Lượt phòng,Tiền phòng,Tiền dịch vụ,Phụ thu,Giảm giá,Tổng thanh toán\n");
        for (HoaDonThongKe invoice : danhSachHoaDonHienTai) {
            csv.append(csvCell(invoice.getMaHoaDon())).append(',')
                    .append(csvCell(invoice.getMaDatPhong())).append(',')
                    .append(csvCell(invoice.getThoiGianLap() == null ? "" : invoice.getThoiGianLap().format(DATE_TIME_FORMATTER))).append(',')
                    .append(csvCell(invoice.getHoTenKhachHang())).append(',')
                    .append(csvCell(invoice.getDanhSachPhong())).append(',')
                    .append(csvCell(invoice.getDanhSachLoaiPhong())).append(',')
                    .append(invoice.getSoLuotPhong()).append(',')
                    .append(invoice.getTongTienPhong().toPlainString()).append(',')
                    .append(invoice.getTongTienDichVu().toPlainString()).append(',')
                    .append(invoice.getPhuThu().toPlainString()).append(',')
                    .append(invoice.getGiamGia().toPlainString()).append(',')
                    .append(invoice.getTongThanhToan().toPlainString()).append('\n');
        }

        try {
            Files.writeString(path, "\uFEFF" + csv, StandardCharsets.UTF_8);
            lblTrangThai.setText("Đã xuất báo cáo CSV: " + path.getFileName());
            JOptionPane.showMessageDialog(this, "Đã xuất báo cáo thành công.", "Xuất báo cáo", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException exception) {
            showError("Không thể xuất báo cáo CSV.\n\nChi tiết: " + exception.getMessage());
        }
    }

    private String csvCell(String value) {
        String safe = value == null ? "" : value;
        return "\"" + safe.replace("\"", "\"\"") + "\"";
    }

    private void setBusy(boolean busy, String status) {
        dangXuLy = busy;
        setCursor(Cursor.getPredefinedCursor(
                busy ? Cursor.WAIT_CURSOR : Cursor.DEFAULT_CURSOR
        ));

        btnThongKe.setEnabled(!busy);
        btnLamMoi.setEnabled(!busy);
        btnXemBaoCao.setEnabled(!busy);
        btnXuatCsv.setEnabled(!busy && !danhSachHoaDonHienTai.isEmpty());
        cboLoaiThongKe.setEnabled(!busy);
        lblTrangThai.setText(status == null ? " " : status);

        updateFilterControls();
    }

    private String formatMoney(BigDecimal amount) {
        BigDecimal safeAmount = amount == null ? BigDecimal.ZERO : amount;
        return MONEY_FORMAT.format(safeAmount) + " VNĐ";
    }

    private void stylePrimaryButton(JButton button) {
        button.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        button.setBackground(PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(108, 32));
    }

    private void styleSecondaryButton(JButton button) {
        button.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        button.setBackground(Color.WHITE);
        button.setForeground(PRIMARY_DARK_COLOR);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(110, 32));
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Dữ liệu chưa hợp lệ",
                JOptionPane.WARNING_MESSAGE
        );
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Lỗi",
                JOptionPane.ERROR_MESSAGE
        );
    }

    private void showDatabaseError(Throwable throwable) {
        Throwable actual = throwable;
        while (actual instanceof ExecutionException && actual.getCause() != null) {
            actual = actual.getCause();
        }

        String message;
        if (actual instanceof SQLException sqlException) {
            message = "Không thể truy vấn dữ liệu thống kê từ MySQL.\n\n"
                    + "Chi tiết: " + sqlException.getMessage();
        } else {
            message = "Không thể thực hiện thống kê.\n\nChi tiết: "
                    + (actual == null || actual.getMessage() == null
                    ? "Lỗi không xác định."
                    : actual.getMessage());
        }

        showError(message);
    }

    private final class RevenueChartPanel extends JPanel {
        RevenueChartPanel() {
            setOpaque(false);
            setPreferredSize(new Dimension(460, 230));
        }

        @Override
        protected void paintComponent(java.awt.Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g = (Graphics2D) graphics.create();
            try {
                g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));
                int left = 58, right = 14, top = 16, bottom = 42;
                int width = getWidth() - left - right;
                int height = getHeight() - top - bottom;
                g.setColor(new Color(230, 235, 241));
                g.drawLine(left, top + height, left + width, top + height);
                g.drawLine(left, top, left, top + height);

                if (danhSachNhomHienTai.isEmpty()) {
                    g.setColor(SECONDARY_TEXT_COLOR);
                    g.drawString("Chưa có dữ liệu trong bộ lọc.", left + 20, top + height / 2);
                    return;
                }

                BigDecimal max = BigDecimal.ZERO;
                for (NhomThongKe group : danhSachNhomHienTai) {
                    if (group.getTongDoanhThu().compareTo(max) > 0) max = group.getTongDoanhThu();
                }
                if (max.signum() == 0) max = BigDecimal.ONE;

                int count = danhSachNhomHienTai.size();
                int slot = Math.max(1, width / count);
                int barWidth = Math.max(10, Math.min(42, slot - 10));
                for (int i = 0; i < count; i++) {
                    NhomThongKe group = danhSachNhomHienTai.get(i);
                    double ratio = group.getTongDoanhThu().doubleValue() / max.doubleValue();
                    int barHeight = (int) Math.round(height * ratio);
                    int x = left + i * slot + Math.max(2, (slot - barWidth) / 2);
                    int y = top + height - barHeight;
                    g.setColor(PRIMARY_COLOR);
                    g.fillRoundRect(x, y, barWidth, barHeight, 8, 8);
                    g.setColor(TEXT_COLOR);
                    String label = shortLabel(group.getNhom());
                    int labelWidth = g.getFontMetrics().stringWidth(label);
                    g.drawString(label, x + (barWidth - labelWidth) / 2, top + height + 15);
                    if (count <= 12) {
                        String value = compactMoney(group.getTongDoanhThu());
                        int valueWidth = g.getFontMetrics().stringWidth(value);
                        g.drawString(value, x + (barWidth - valueWidth) / 2, Math.max(top + 11, y - 4));
                    }
                }
            } finally {
                g.dispose();
            }
        }
    }

    private final class VolumeChartPanel extends JPanel {
        VolumeChartPanel() {
            setOpaque(false);
            setPreferredSize(new Dimension(460, 230));
        }

        @Override
        protected void paintComponent(java.awt.Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g = (Graphics2D) graphics.create();
            try {
                int left = 42, right = 18, top = 16, bottom = 42;
                int width = getWidth() - left - right;
                int height = getHeight() - top - bottom;
                g.setColor(new Color(230, 235, 241));
                g.drawLine(left, top + height, left + width, top + height);
                g.drawLine(left, top, left, top + height);

                if (danhSachNhomHienTai.isEmpty()) {
                    g.setColor(SECONDARY_TEXT_COLOR);
                    g.drawString("Chưa có dữ liệu trong bộ lọc.", left + 20, top + height / 2);
                    return;
                }

                int max = 1;
                for (NhomThongKe group : danhSachNhomHienTai) {
                    max = Math.max(max, Math.max(group.getSoHoaDon(), group.getSoLuotPhong()));
                }
                int count = danhSachNhomHienTai.size();
                int slot = Math.max(1, width / count);
                int barWidth = Math.max(6, Math.min(15, slot / 3));
                for (int i = 0; i < count; i++) {
                    NhomThongKe group = danhSachNhomHienTai.get(i);
                    int x = left + i * slot + slot / 2;
                    int hInvoice = (int) Math.round(height * group.getSoHoaDon() / (double) max);
                    int hRoom = (int) Math.round(height * group.getSoLuotPhong() / (double) max);
                    g.setColor(SUCCESS_COLOR);
                    g.fillRoundRect(x - barWidth - 2, top + height - hInvoice, barWidth, hInvoice, 6, 6);
                    g.setColor(WARNING_COLOR);
                    g.fillRoundRect(x + 2, top + height - hRoom, barWidth, hRoom, 6, 6);
                    if (count <= 12) {
                        g.setColor(TEXT_COLOR);
                        String label = shortLabel(group.getNhom());
                        int labelWidth = g.getFontMetrics().stringWidth(label);
                        g.drawString(label, x - labelWidth / 2, top + height + 15);
                    }
                }
                g.setColor(SUCCESS_COLOR);
                g.fillRect(left + 8, top + 4, 10, 10);
                g.setColor(TEXT_COLOR);
                g.drawString("Hóa đơn", left + 24, top + 14);
                g.setColor(WARNING_COLOR);
                g.fillRect(left + 92, top + 4, 10, 10);
                g.setColor(TEXT_COLOR);
                g.drawString("Lượt phòng", left + 108, top + 14);
            } finally {
                g.dispose();
            }
        }
    }

    private String shortLabel(String label) {
        if (label == null) return "";
        return label.length() <= 13 ? label : label.substring(0, 12) + "…";
    }

    private String compactMoney(BigDecimal value) {
        if (value == null) return "0";
        double number = value.doubleValue();
        if (number >= 1_000_000_000) return String.format(Locale.ROOT, "%.1fB", number / 1_000_000_000d);
        if (number >= 1_000_000) return String.format(Locale.ROOT, "%.1fM", number / 1_000_000d);
        if (number >= 1_000) return String.format(Locale.ROOT, "%.0fK", number / 1_000d);
        return String.format(Locale.ROOT, "%.0f", number);
    }

    private enum LoaiThongKe {
        THEO_THANG("Theo tháng"),
        THEO_NAM("Theo năm"),
        THEO_LOAI_PHONG("Theo loại phòng");

        private final String displayName;

        LoaiThongKe(String displayName) {
            this.displayName = displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }

    private static final class ReportData {
        private final ThongKeTongHop summary;
        private final List<HoaDonThongKe> invoices;
        private final List<NhomThongKe> groups;

        private ReportData(
                ThongKeTongHop summary,
                List<HoaDonThongKe> invoices,
                List<NhomThongKe> groups) {
            this.summary = summary;
            this.invoices = invoices;
            this.groups = groups;
        }
    }
}
