package vn.edu.eaut.hotelmanagement.model;

import vn.edu.eaut.hotelmanagement.model.enums.LoaiNhiemVuBuongPhong;
import vn.edu.eaut.hotelmanagement.model.enums.MucDoUuTien;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiNhiemVu;

import java.time.LocalDateTime;

public class NhiemVuBuongPhong {
    private Integer id;
    private String maNhiemVu;
    private Integer phongId;
    private LoaiNhiemVuBuongPhong loaiNhiemVu;
    private MucDoUuTien mucDoUuTien;
    private TrangThaiNhiemVu trangThai;
    private Integer nguoiTaoId;
    private Integer nhanVienPhuTrachId;
    private LocalDateTime thoiGianTao;
    private LocalDateTime thoiGianBatDau;
    private LocalDateTime thoiGianHoanThanh;
    private String ghiChu;

    public NhiemVuBuongPhong() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMaNhiemVu() {
        return maNhiemVu;
    }

    public void setMaNhiemVu(String maNhiemVu) {
        this.maNhiemVu = maNhiemVu;
    }

    public Integer getPhongId() {
        return phongId;
    }

    public void setPhongId(Integer phongId) {
        this.phongId = phongId;
    }

    public LoaiNhiemVuBuongPhong getLoaiNhiemVu() {
        return loaiNhiemVu;
    }

    public void setLoaiNhiemVu(LoaiNhiemVuBuongPhong loaiNhiemVu) {
        this.loaiNhiemVu = loaiNhiemVu;
    }

    public MucDoUuTien getMucDoUuTien() {
        return mucDoUuTien;
    }

    public void setMucDoUuTien(MucDoUuTien mucDoUuTien) {
        this.mucDoUuTien = mucDoUuTien;
    }

    public TrangThaiNhiemVu getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(TrangThaiNhiemVu trangThai) {
        this.trangThai = trangThai;
    }

    public Integer getNguoiTaoId() {
        return nguoiTaoId;
    }

    public void setNguoiTaoId(Integer nguoiTaoId) {
        this.nguoiTaoId = nguoiTaoId;
    }

    public Integer getNhanVienPhuTrachId() {
        return nhanVienPhuTrachId;
    }

    public void setNhanVienPhuTrachId(Integer nhanVienPhuTrachId) {
        this.nhanVienPhuTrachId = nhanVienPhuTrachId;
    }

    public LocalDateTime getThoiGianTao() {
        return thoiGianTao;
    }

    public void setThoiGianTao(LocalDateTime thoiGianTao) {
        this.thoiGianTao = thoiGianTao;
    }

    public LocalDateTime getThoiGianBatDau() {
        return thoiGianBatDau;
    }

    public void setThoiGianBatDau(LocalDateTime thoiGianBatDau) {
        this.thoiGianBatDau = thoiGianBatDau;
    }

    public LocalDateTime getThoiGianHoanThanh() {
        return thoiGianHoanThanh;
    }

    public void setThoiGianHoanThanh(LocalDateTime thoiGianHoanThanh) {
        this.thoiGianHoanThanh = thoiGianHoanThanh;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    @Override
    public String toString() {
        return maNhiemVu;
    }
}
