package vn.edu.eaut.hotelmanagement.model;

import vn.edu.eaut.hotelmanagement.model.enums.PhuongThucThanhToan;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class ThanhToan {
    private Integer id;
    private String maThanhToan;
    private Integer hoaDonId;
    private BigDecimal soTien;
    private PhuongThucThanhToan phuongThuc;
    private String maThamChieu;
    private Integer nhanVienThuId;
    private LocalDateTime thoiGianThanhToan;
    private String ghiChu;

    public ThanhToan() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMaThanhToan() {
        return maThanhToan;
    }

    public void setMaThanhToan(String maThanhToan) {
        this.maThanhToan = maThanhToan;
    }

    public Integer getHoaDonId() {
        return hoaDonId;
    }

    public void setHoaDonId(Integer hoaDonId) {
        this.hoaDonId = hoaDonId;
    }

    public BigDecimal getSoTien() {
        return soTien;
    }

    public void setSoTien(BigDecimal soTien) {
        this.soTien = soTien;
    }

    public PhuongThucThanhToan getPhuongThuc() {
        return phuongThuc;
    }

    public void setPhuongThuc(PhuongThucThanhToan phuongThuc) {
        this.phuongThuc = phuongThuc;
    }

    public String getMaThamChieu() {
        return maThamChieu;
    }

    public void setMaThamChieu(String maThamChieu) {
        this.maThamChieu = maThamChieu;
    }

    public Integer getNhanVienThuId() {
        return nhanVienThuId;
    }

    public void setNhanVienThuId(Integer nhanVienThuId) {
        this.nhanVienThuId = nhanVienThuId;
    }

    public LocalDateTime getThoiGianThanhToan() {
        return thoiGianThanhToan;
    }

    public void setThoiGianThanhToan(LocalDateTime thoiGianThanhToan) {
        this.thoiGianThanhToan = thoiGianThanhToan;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    @Override
    public String toString() {
        return maThanhToan;
    }
}
