package vn.edu.eaut.hotelmanagement.model.enums;

public enum LoaiNhiemVuBuongPhong {
    DON_PHONG("Dọn phòng"),
    KIEM_TRA("Kiểm tra"),
    BO_SUNG_VAT_DUNG("Bổ sung vật dụng"),
    BAO_TRI("Bảo trì");

    private final String hienThi;

    LoaiNhiemVuBuongPhong(String hienThi) {
        this.hienThi = hienThi;
    }

    @Override
    public String toString() {
        return hienThi;
    }
}
