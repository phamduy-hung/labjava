package vn.edu.eaut.hotelmanagement.model.enums;

public enum TrangThaiHoaDon {
    CHUA_THANH_TOAN("Chưa thanh toán"),
    THANH_TOAN_MOT_PHAN("Thanh toán một phần"),
    DA_THANH_TOAN("Đã thanh toán"),
    DA_HUY("Đã hủy");

    private final String hienThi;

    TrangThaiHoaDon(String hienThi) {
        this.hienThi = hienThi;
    }

    public boolean canTransitionTo(TrangThaiHoaDon target) {
        if (target == null) {
            return false;
        }
        if (this == target) {
            return true;
        }
        return switch (this) {
            case CHUA_THANH_TOAN -> target == THANH_TOAN_MOT_PHAN || target == DA_THANH_TOAN || target == DA_HUY;
            case THANH_TOAN_MOT_PHAN -> target == DA_THANH_TOAN || target == DA_HUY;
            case DA_THANH_TOAN, DA_HUY -> false;
        };
    }

    @Override
    public String toString() {
        return hienThi;
    }
}
