package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.ChiTietDatPhong;
import vn.edu.eaut.hotelmanagement.model.DatPhong;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiDatPhong;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiPhong;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class DatPhongDAO {

    private static final String SELECT_COLUMNS =
            "dp.id, dp.ma_dat_phong, dp.khach_hang_id, dp.thoi_gian_dat, dp.ngay_du_kien_nhan, dp.ngay_du_kien_tra, "
                    + "dp.ngay_nhan_thuc_te, dp.ngay_tra_thuc_te, dp.so_nguoi_lon, dp.so_tre_em, dp.tien_coc, "
                    + "dp.trang_thai, dp.nhan_vien_tao_id, dp.nhan_vien_nhan_phong_id, dp.nhan_vien_tra_phong_id, "
                    + "dp.ghi_chu, dp.ngay_tao, dp.ngay_cap_nhat";

    private final ChiTietDatPhongDAO chiTietDatPhongDAO = new ChiTietDatPhongDAO();

    public int insert(DatPhong datPhong) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            return insert(connection, datPhong);
        }
    }

    /**
     * Tạo booking và các phòng của booking trong cùng một transaction.
     * Trước khi ghi, mỗi phòng được khóa và kiểm tra trùng lịch để tránh hai lễ tân
     * cùng đặt một phòng trong cùng khoảng thời gian.
     */
    public int insertWithDetails(DatPhong datPhong, List<ChiTietDatPhong> details) throws SQLException {
        if (datPhong == null) {
            throw new IllegalArgumentException("Thông tin đặt phòng không được để trống.");
        }
        if (details == null || details.isEmpty()) {
            throw new IllegalArgumentException("Booking phải có ít nhất một phòng.");
        }
        if (datPhong.getNgayDuKienNhan() == null || datPhong.getNgayDuKienTra() == null
                || !datPhong.getNgayDuKienTra().isAfter(datPhong.getNgayDuKienNhan())) {
            throw new IllegalArgumentException("Ngày dự kiến trả phải sau ngày dự kiến nhận.");
        }

        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            validateBookingRooms(connection, datPhong, details);

            int bookingId = insert(connection, datPhong);
            for (ChiTietDatPhong detail : details) {
                detail.setDatPhongId(bookingId);
                chiTietDatPhongDAO.insert(connection, detail);
            }

            connection.commit();
            return bookingId;
        } catch (SQLException | RuntimeException exception) {
            rollbackQuietly(connection, exception);
            throw exception;
        } finally {
            closeTransactionalConnection(connection);
        }
    }

    /**
     * Check-in nguyên tử: cập nhật booking và toàn bộ phòng sang DANG_O trong cùng
     * một transaction. Nếu bất kỳ phòng nào không sẵn sàng thì toàn bộ thao tác bị rollback.
     */
    public boolean checkIn(int bookingId, Integer employeeId) throws SQLException {
        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            TrangThaiDatPhong bookingStatus = lockBookingStatus(connection, bookingId);
            if (bookingStatus != TrangThaiDatPhong.CHO_XAC_NHAN
                    && bookingStatus != TrangThaiDatPhong.DA_XAC_NHAN) {
                throw new SQLException("Booking không ở trạng thái cho phép nhận phòng: " + bookingStatus + ".");
            }

            List<Integer> roomIds = findRoomIdsByBookingForUpdate(connection, bookingId);
            if (roomIds.isEmpty()) {
                throw new SQLException("Booking chưa có phòng để thực hiện check-in.");
            }

            for (Integer roomId : roomIds) {
                RoomLockInfo roomInfo = lockRoom(connection, roomId);
                if (!roomInfo.active) {
                    throw new SQLException("Phòng " + roomInfo.roomNumber + " đã ngừng hoạt động.");
                }
                if (roomInfo.status != TrangThaiPhong.TRONG && roomInfo.status != TrangThaiPhong.DA_DAT) {
                    throw new SQLException(
                            "Phòng " + roomInfo.roomNumber + " chưa sẵn sàng để nhận khách. Trạng thái hiện tại: "
                                    + roomInfo.status + "."
                    );
                }
            }

            String updateBookingSql = "UPDATE dat_phong SET ngay_nhan_thuc_te = ?, nhan_vien_nhan_phong_id = ?, "
                    + "trang_thai = 'DA_NHAN_PHONG' WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(updateBookingSql)) {
                statement.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
                if (employeeId == null) {
                    statement.setNull(2, Types.INTEGER);
                } else {
                    statement.setInt(2, employeeId);
                }
                statement.setInt(3, bookingId);
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Không cập nhật được trạng thái nhận phòng của booking.");
                }
            }

            String updateRoomSql = "UPDATE phong SET trang_thai = 'DANG_O' WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(updateRoomSql)) {
                for (Integer roomId : roomIds) {
                    statement.setInt(1, roomId);
                    statement.addBatch();
                }
                int[] results = statement.executeBatch();
                for (int result : results) {
                    if (result == Statement.EXECUTE_FAILED) {
                        throw new SQLException("Không cập nhật được trạng thái phòng khi check-in.");
                    }
                }
            }

            connection.commit();
            return true;
        } catch (SQLException | RuntimeException exception) {
            rollbackQuietly(connection, exception);
            throw exception;
        } finally {
            closeTransactionalConnection(connection);
        }
    }

    /**
     * Đổi phòng cho khách đã check-in. Chi tiết booking, phòng cũ và phòng mới được
     * cập nhật trong một transaction: phòng cũ -> DANG_DON, phòng mới -> DANG_O.
     */
    public boolean changeRoom(
            int bookingId,
            int bookingDetailId,
            int newRoomId,
            BigDecimal newRoomPrice) throws SQLException {

        if (newRoomPrice == null || newRoomPrice.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Giá phòng mới phải lớn hơn 0.");
        }

        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            BookingLockInfo bookingInfo = lockBookingInfo(connection, bookingId);
            if (bookingInfo.status != TrangThaiDatPhong.DA_NHAN_PHONG) {
                throw new SQLException("Chỉ có thể đổi phòng cho booking đã nhận phòng.");
            }

            int oldRoomId = lockBookingDetailRoomId(connection, bookingId, bookingDetailId);
            if (oldRoomId == newRoomId) {
                throw new SQLException("Phòng mới phải khác phòng hiện tại.");
            }

            int firstRoomId = Math.min(oldRoomId, newRoomId);
            int secondRoomId = Math.max(oldRoomId, newRoomId);
            RoomLockInfo firstRoom = lockRoom(connection, firstRoomId);
            RoomLockInfo secondRoom = lockRoom(connection, secondRoomId);
            RoomLockInfo newRoom = firstRoom.id == newRoomId ? firstRoom : secondRoom;

            if (!newRoom.active) {
                throw new SQLException("Phòng " + newRoom.roomNumber + " đã ngừng hoạt động.");
            }
            if (newRoom.status != TrangThaiPhong.TRONG) {
                throw new SQLException("Phòng " + newRoom.roomNumber + " không ở trạng thái Trống.");
            }

            LocalDateTime conflictFrom = LocalDateTime.now();
            LocalDateTime conflictTo = bookingInfo.expectedCheckOut;
            if (conflictTo == null || !conflictTo.isAfter(conflictFrom)) {
                conflictTo = conflictFrom.plusDays(1);
            }

            if (hasScheduleConflict(connection, newRoomId, conflictFrom, conflictTo, bookingId)) {
                throw new SQLException("Phòng " + newRoom.roomNumber + " đã có lịch đặt trùng trong thời gian còn lại.");
            }

            String updateDetailSql = "UPDATE chi_tiet_dat_phong SET phong_id = ?, gia_phong_thuc_te = ? "
                    + "WHERE id = ? AND dat_phong_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(updateDetailSql)) {
                statement.setInt(1, newRoomId);
                statement.setBigDecimal(2, newRoomPrice);
                statement.setInt(3, bookingDetailId);
                statement.setInt(4, bookingId);
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Không cập nhật được chi tiết phòng trong booking.");
                }
            }

            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE phong SET trang_thai = ? WHERE id = ?")) {
                statement.setString(1, TrangThaiPhong.DANG_DON.name());
                statement.setInt(2, oldRoomId);
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Không cập nhật được trạng thái phòng cũ.");
                }

                statement.setString(1, TrangThaiPhong.DANG_O.name());
                statement.setInt(2, newRoomId);
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Không cập nhật được trạng thái phòng mới.");
                }
            }

            connection.commit();
            return true;
        } catch (SQLException | RuntimeException exception) {
            rollbackQuietly(connection, exception);
            throw exception;
        } finally {
            closeTransactionalConnection(connection);
        }
    }

    int insert(Connection connection, DatPhong datPhong) throws SQLException {
        String sql = "INSERT INTO dat_phong(ma_dat_phong, khach_hang_id, thoi_gian_dat, ngay_du_kien_nhan, ngay_du_kien_tra, "
                + "ngay_nhan_thuc_te, ngay_tra_thuc_te, so_nguoi_lon, so_tre_em, tien_coc, trang_thai, nhan_vien_tao_id, "
                + "nhan_vien_nhan_phong_id, nhan_vien_tra_phong_id, ghi_chu) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bindForWrite(statement, datPhong, false);
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    datPhong.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của đặt phòng vừa thêm.");
    }

    public boolean update(DatPhong datPhong) throws SQLException {
        if (datPhong == null || datPhong.getId() == null || datPhong.getId() <= 0) {
            throw new IllegalArgumentException("Thông tin booking không hợp lệ.");
        }

        /*
         * CRUD không được phép thay đổi trạng thái booking.
         * Check-in, check-out, hủy và không đến phải đi qua nghiệp vụ chuyên dụng.
         */
        String selectSql = "SELECT trang_thai FROM dat_phong WHERE id = ? FOR UPDATE";
        String updateSql = "UPDATE dat_phong SET ma_dat_phong = ?, khach_hang_id = ?, thoi_gian_dat = ?, "
                + "ngay_du_kien_nhan = ?, ngay_du_kien_tra = ?, ngay_nhan_thuc_te = ?, ngay_tra_thuc_te = ?, "
                + "so_nguoi_lon = ?, so_tre_em = ?, tien_coc = ?, nhan_vien_tao_id = ?, nhan_vien_nhan_phong_id = ?, "
                + "nhan_vien_tra_phong_id = ?, ghi_chu = ? WHERE id = ?";

        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            TrangThaiDatPhong currentStatus;
            try (PreparedStatement statement = connection.prepareStatement(selectSql)) {
                statement.setInt(1, datPhong.getId());
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (!resultSet.next()) {
                        throw new SQLException("Không tìm thấy booking cần cập nhật.");
                    }
                    currentStatus = TrangThaiDatPhong.valueOf(resultSet.getString("trang_thai"));
                }
            }

            if (datPhong.getTrangThai() != null && datPhong.getTrangThai() != currentStatus) {
                throw new SQLException(
                        "Không được thay đổi trạng thái booking bằng chức năng Sửa. "
                                + "Hãy dùng đúng nghiệp vụ Check-in, Hủy hoặc Trả phòng."
                );
            }

            try (PreparedStatement statement = connection.prepareStatement(updateSql)) {
                bindForCrudUpdate(statement, datPhong);
                boolean updated = statement.executeUpdate() == 1;
                connection.commit();
                datPhong.setTrangThai(currentStatus);
                return updated;
            }
        } catch (SQLException | RuntimeException exception) {
            rollbackQuietly(connection, exception);
            throw exception;
        } finally {
            closeTransactionalConnection(connection);
        }
    }

    /**
     * API trạng thái dùng cho các chuyển tiếp đơn giản như xác nhận/hủy.
     * Các chuyển tiếp check-in và check-out bị chặn tại đây để buộc đi qua
     * transaction chuyên dụng.
     */
    public boolean updateStatus(int bookingId, TrangThaiDatPhong targetStatus) throws SQLException {
        if (bookingId <= 0 || targetStatus == null) {
            throw new IllegalArgumentException("Booking hoặc trạng thái không hợp lệ.");
        }

        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            TrangThaiDatPhong currentStatus = lockBookingStatus(connection, bookingId);
            if (currentStatus == targetStatus) {
                connection.commit();
                return true;
            }
            if (!currentStatus.canTransitionTo(targetStatus)) {
                throw new SQLException(
                        "Không được chuyển booking từ " + currentStatus + " sang " + targetStatus + "."
                );
            }

            if (targetStatus == TrangThaiDatPhong.DA_NHAN_PHONG
                    || targetStatus == TrangThaiDatPhong.DA_TRA_PHONG) {
                throw new SQLException(
                        "Chuyển sang " + targetStatus
                                + " phải dùng nghiệp vụ transaction chuyên dụng."
                );
            }

            String sql = "UPDATE dat_phong SET trang_thai = ? WHERE id = ? AND trang_thai = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, targetStatus.name());
                statement.setInt(2, bookingId);
                statement.setString(3, currentStatus.name());
                boolean updated = statement.executeUpdate() == 1;
                if (!updated) {
                    throw new SQLException("Booking đã thay đổi bởi thao tác khác. Vui lòng tải lại dữ liệu.");
                }
                connection.commit();
                return true;
            }
        } catch (SQLException | RuntimeException exception) {
            rollbackQuietly(connection, exception);
            throw exception;
        } finally {
            closeTransactionalConnection(connection);
        }
    }

    public boolean cancel(int bookingId) throws SQLException {
        return updateStatus(bookingId, TrangThaiDatPhong.DA_HUY);
    }

    /**
     * Đánh dấu khách không đến. Chỉ booking đã xác nhận và đã đến thời điểm nhận phòng
     * mới được chuyển sang KHONG_DEN. Thao tác được khóa theo booking để tránh cập nhật đồng thời.
     */
    public boolean markNoShow(int bookingId) throws SQLException {
        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            String sql = "SELECT trang_thai, ngay_du_kien_nhan FROM dat_phong WHERE id = ? FOR UPDATE";
            TrangThaiDatPhong currentStatus;
            LocalDateTime expectedCheckIn;
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, bookingId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (!resultSet.next()) {
                        throw new SQLException("Không tìm thấy booking có ID " + bookingId + ".");
                    }
                    currentStatus = TrangThaiDatPhong.valueOf(resultSet.getString("trang_thai"));
                    Timestamp timestamp = resultSet.getTimestamp("ngay_du_kien_nhan");
                    expectedCheckIn = timestamp == null ? null : timestamp.toLocalDateTime();
                }
            }

            if (currentStatus != TrangThaiDatPhong.DA_XAC_NHAN) {
                throw new SQLException("Chỉ booking đã xác nhận mới có thể đánh dấu Không đến.");
            }
            if (expectedCheckIn == null || LocalDateTime.now().isBefore(expectedCheckIn)) {
                throw new SQLException("Chưa đến thời gian nhận phòng dự kiến, chưa thể đánh dấu Không đến.");
            }

            String updateSql = "UPDATE dat_phong SET trang_thai = 'KHONG_DEN' "
                    + "WHERE id = ? AND trang_thai = 'DA_XAC_NHAN'";
            try (PreparedStatement statement = connection.prepareStatement(updateSql)) {
                statement.setInt(1, bookingId);
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Booking đã thay đổi bởi thao tác khác. Vui lòng tải lại dữ liệu.");
                }
            }

            connection.commit();
            return true;
        } catch (SQLException | RuntimeException exception) {
            rollbackQuietly(connection, exception);
            throw exception;
        } finally {
            closeTransactionalConnection(connection);
        }
    }

    /**
     * Không cho xóa booking bằng CRUD. Booking là dữ liệu nghiệp vụ và phải giữ lịch sử.
     * Hủy hoặc Không đến phải dùng các nghiệp vụ chuyên dụng.
     */
    public boolean deleteById(int id) throws SQLException {
        throw new SQLException(
                "Không được xóa booking trực tiếp. Hãy dùng nghiệp vụ Hủy hoặc Không đến để bảo toàn lịch sử."
        );
    }

    public Optional<DatPhong> findById(int id) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM dat_phong dp WHERE dp.id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public Optional<DatPhong> findByCode(String bookingCode) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM dat_phong dp WHERE dp.ma_dat_phong = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bookingCode);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<DatPhong> findAll() throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM dat_phong dp ORDER BY dp.thoi_gian_dat DESC, dp.id DESC";
        return executeList(sql);
    }

    public List<DatPhong> findByStatus(TrangThaiDatPhong status) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM dat_phong dp WHERE dp.trang_thai = ? ORDER BY dp.ngay_du_kien_nhan, dp.id";
        List<DatPhong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, status.name());
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public List<DatPhong> findByDateRange(LocalDateTime from, LocalDateTime to) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM dat_phong dp "
                + "WHERE dp.ngay_du_kien_nhan < ? AND dp.ngay_du_kien_tra > ? ORDER BY dp.ngay_du_kien_nhan";
        List<DatPhong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setTimestamp(1, Timestamp.valueOf(to));
            statement.setTimestamp(2, Timestamp.valueOf(from));
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    public List<DatPhong> search(String keyword) throws SQLException {
        String candidate = keyword == null ? "" : keyword.trim();
        String searchValue = "%" + candidate + "%";

        // PII của khách hàng đã được mã hóa AES-256-GCM nên không thể LIKE
        // trực tiếp trong MySQL. KhachHangDAO tìm kiếm sau khi giải mã và
        // trả về các ID phù hợp; truy vấn booking vẫn thực hiện bằng SQL.
        List<Integer> customerIds = new KhachHangDAO().search(candidate).stream()
                .map(vn.edu.eaut.hotelmanagement.model.KhachHang::getId)
                .filter(java.util.Objects::nonNull)
                .toList();

        StringBuilder sql = new StringBuilder(
                "SELECT " + SELECT_COLUMNS + " FROM dat_phong dp WHERE dp.ma_dat_phong LIKE ?");
        if (!customerIds.isEmpty()) {
            sql.append(" OR dp.khach_hang_id IN (");
            sql.append("?,".repeat(customerIds.size()));
            sql.setLength(sql.length() - 1);
            sql.append(")");
        }
        sql.append(" ORDER BY dp.thoi_gian_dat DESC, dp.id DESC");

        List<DatPhong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {
            int index = 1;
            statement.setString(index++, searchValue);
            for (Integer customerId : customerIds) {
                statement.setInt(index++, customerId);
            }
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    private void validateBookingRooms(Connection connection, DatPhong datPhong, List<ChiTietDatPhong> details)
            throws SQLException {
        Set<Integer> uniqueRoomIds = new HashSet<>();
        for (ChiTietDatPhong detail : details) {
            if (detail == null || detail.getPhongId() == null) {
                throw new SQLException("Chi tiết đặt phòng chứa phòng không hợp lệ.");
            }
            if (!uniqueRoomIds.add(detail.getPhongId())) {
                throw new SQLException("Một phòng không được xuất hiện hai lần trong cùng booking.");
            }

            RoomLockInfo roomInfo = lockRoom(connection, detail.getPhongId());
            if (!roomInfo.active) {
                throw new SQLException("Phòng " + roomInfo.roomNumber + " đã ngừng hoạt động.");
            }
            if (roomInfo.status == TrangThaiPhong.BAO_TRI) {
                throw new SQLException("Phòng " + roomInfo.roomNumber + " đang bảo trì.");
            }
            if (hasScheduleConflict(
                    connection,
                    detail.getPhongId(),
                    datPhong.getNgayDuKienNhan(),
                    datPhong.getNgayDuKienTra(),
                    null)) {
                throw new SQLException("Phòng " + roomInfo.roomNumber + " đã có lịch đặt trùng thời gian.");
            }
        }
    }

    private boolean hasScheduleConflict(
            Connection connection,
            int roomId,
            LocalDateTime checkIn,
            LocalDateTime checkOut,
            Integer excludedBookingId) throws SQLException {

        String sql = "SELECT COUNT(*) FROM chi_tiet_dat_phong ct "
                + "JOIN dat_phong dp ON dp.id = ct.dat_phong_id "
                + "WHERE ct.phong_id = ? "
                + "AND dp.trang_thai IN ('CHO_XAC_NHAN','DA_XAC_NHAN','DA_NHAN_PHONG') "
                + "AND dp.ngay_du_kien_nhan < ? AND dp.ngay_du_kien_tra > ? "
                + (excludedBookingId == null ? "" : "AND dp.id <> ? ");

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, roomId);
            statement.setTimestamp(2, Timestamp.valueOf(checkOut));
            statement.setTimestamp(3, Timestamp.valueOf(checkIn));
            if (excludedBookingId != null) {
                statement.setInt(4, excludedBookingId);
            }
            try (ResultSet resultSet = statement.executeQuery()) {
                resultSet.next();
                return resultSet.getInt(1) > 0;
            }
        }
    }

    private TrangThaiDatPhong lockBookingStatus(Connection connection, int bookingId) throws SQLException {
        String sql = "SELECT trang_thai FROM dat_phong WHERE id = ? FOR UPDATE";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new SQLException("Không tìm thấy booking có ID " + bookingId + ".");
                }
                return TrangThaiDatPhong.valueOf(resultSet.getString("trang_thai"));
            }
        }
    }

    private BookingLockInfo lockBookingInfo(Connection connection, int bookingId) throws SQLException {
        String sql = "SELECT trang_thai, ngay_du_kien_nhan, ngay_du_kien_tra FROM dat_phong WHERE id = ? FOR UPDATE";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new SQLException("Không tìm thấy booking có ID " + bookingId + ".");
                }
                BookingLockInfo info = new BookingLockInfo();
                info.status = TrangThaiDatPhong.valueOf(resultSet.getString("trang_thai"));
                Timestamp expectedCheckIn = resultSet.getTimestamp("ngay_du_kien_nhan");
                Timestamp expectedCheckOut = resultSet.getTimestamp("ngay_du_kien_tra");
                info.expectedCheckIn = expectedCheckIn == null ? null : expectedCheckIn.toLocalDateTime();
                info.expectedCheckOut = expectedCheckOut == null ? null : expectedCheckOut.toLocalDateTime();
                return info;
            }
        }
    }

    private List<Integer> findRoomIdsByBookingForUpdate(Connection connection, int bookingId) throws SQLException {
        String sql = "SELECT phong_id FROM chi_tiet_dat_phong WHERE dat_phong_id = ? ORDER BY phong_id FOR UPDATE";
        List<Integer> roomIds = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    roomIds.add(resultSet.getInt("phong_id"));
                }
            }
        }
        return roomIds;
    }

    private int lockBookingDetailRoomId(Connection connection, int bookingId, int bookingDetailId) throws SQLException {
        String sql = "SELECT phong_id FROM chi_tiet_dat_phong WHERE id = ? AND dat_phong_id = ? FOR UPDATE";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookingDetailId);
            statement.setInt(2, bookingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new SQLException("Không tìm thấy phòng hiện tại trong booking.");
                }
                return resultSet.getInt("phong_id");
            }
        }
    }

    private RoomLockInfo lockRoom(Connection connection, int roomId) throws SQLException {
        String sql = "SELECT id, so_phong, trang_thai, dang_hoat_dong FROM phong WHERE id = ? FOR UPDATE";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, roomId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new SQLException("Không tìm thấy phòng có ID " + roomId + ".");
                }
                RoomLockInfo info = new RoomLockInfo();
                info.id = resultSet.getInt("id");
                info.roomNumber = resultSet.getString("so_phong");
                info.status = TrangThaiPhong.valueOf(resultSet.getString("trang_thai"));
                info.active = resultSet.getBoolean("dang_hoat_dong");
                return info;
            }
        }
    }

    private List<DatPhong> executeList(String sql) throws SQLException {
        List<DatPhong> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(mapRow(resultSet));
            }
        }
        return result;
    }

    private void bindForCrudUpdate(PreparedStatement statement, DatPhong datPhong) throws SQLException {
        LocalDateTime bookingTime = datPhong.getThoiGianDat() == null ? LocalDateTime.now() : datPhong.getThoiGianDat();
        BigDecimal deposit = datPhong.getTienCoc() == null ? BigDecimal.ZERO : datPhong.getTienCoc();

        statement.setString(1, datPhong.getMaDatPhong());
        statement.setInt(2, datPhong.getKhachHangId());
        statement.setTimestamp(3, Timestamp.valueOf(bookingTime));
        statement.setTimestamp(4, Timestamp.valueOf(datPhong.getNgayDuKienNhan()));
        statement.setTimestamp(5, Timestamp.valueOf(datPhong.getNgayDuKienTra()));
        JdbcDataAccessSupport.setNullableLocalDateTime(statement, 6, datPhong.getNgayNhanThucTe());
        JdbcDataAccessSupport.setNullableLocalDateTime(statement, 7, datPhong.getNgayTraThucTe());
        statement.setInt(8, datPhong.getSoNguoiLon());
        statement.setInt(9, datPhong.getSoTreEm());
        statement.setBigDecimal(10, deposit);
        JdbcDataAccessSupport.setNullableInteger(statement, 11, datPhong.getNhanVienTaoId());
        JdbcDataAccessSupport.setNullableInteger(statement, 12, datPhong.getNhanVienNhanPhongId());
        JdbcDataAccessSupport.setNullableInteger(statement, 13, datPhong.getNhanVienTraPhongId());
        statement.setString(14, datPhong.getGhiChu());
        statement.setInt(15, datPhong.getId());
    }

    private void bindForWrite(PreparedStatement statement, DatPhong datPhong, boolean includeId) throws SQLException {
        LocalDateTime bookingTime = datPhong.getThoiGianDat() == null ? LocalDateTime.now() : datPhong.getThoiGianDat();
        BigDecimal deposit = datPhong.getTienCoc() == null ? BigDecimal.ZERO : datPhong.getTienCoc();
        TrangThaiDatPhong status = datPhong.getTrangThai() == null ? TrangThaiDatPhong.CHO_XAC_NHAN : datPhong.getTrangThai();

        statement.setString(1, datPhong.getMaDatPhong());
        statement.setInt(2, datPhong.getKhachHangId());
        statement.setTimestamp(3, Timestamp.valueOf(bookingTime));
        statement.setTimestamp(4, Timestamp.valueOf(datPhong.getNgayDuKienNhan()));
        statement.setTimestamp(5, Timestamp.valueOf(datPhong.getNgayDuKienTra()));
        JdbcDataAccessSupport.setNullableLocalDateTime(statement, 6, datPhong.getNgayNhanThucTe());
        JdbcDataAccessSupport.setNullableLocalDateTime(statement, 7, datPhong.getNgayTraThucTe());
        statement.setInt(8, datPhong.getSoNguoiLon());
        statement.setInt(9, datPhong.getSoTreEm());
        statement.setBigDecimal(10, deposit);
        statement.setString(11, status.name());
        JdbcDataAccessSupport.setNullableInteger(statement, 12, datPhong.getNhanVienTaoId());
        JdbcDataAccessSupport.setNullableInteger(statement, 13, datPhong.getNhanVienNhanPhongId());
        JdbcDataAccessSupport.setNullableInteger(statement, 14, datPhong.getNhanVienTraPhongId());
        statement.setString(15, datPhong.getGhiChu());
        if (includeId) {
            statement.setInt(16, datPhong.getId());
        }
    }

    private DatPhong mapRow(ResultSet resultSet) throws SQLException {
        DatPhong datPhong = new DatPhong();
        datPhong.setId(resultSet.getInt("id"));
        datPhong.setMaDatPhong(resultSet.getString("ma_dat_phong"));
        datPhong.setKhachHangId(resultSet.getInt("khach_hang_id"));
        datPhong.setThoiGianDat(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "thoi_gian_dat"));
        datPhong.setNgayDuKienNhan(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_du_kien_nhan"));
        datPhong.setNgayDuKienTra(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_du_kien_tra"));
        datPhong.setNgayNhanThucTe(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_nhan_thuc_te"));
        datPhong.setNgayTraThucTe(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_tra_thuc_te"));
        datPhong.setSoNguoiLon(resultSet.getInt("so_nguoi_lon"));
        datPhong.setSoTreEm(resultSet.getInt("so_tre_em"));
        datPhong.setTienCoc(resultSet.getBigDecimal("tien_coc"));
        datPhong.setTrangThai(TrangThaiDatPhong.valueOf(resultSet.getString("trang_thai")));
        datPhong.setNhanVienTaoId(getNullableInteger(resultSet, "nhan_vien_tao_id"));
        datPhong.setNhanVienNhanPhongId(getNullableInteger(resultSet, "nhan_vien_nhan_phong_id"));
        datPhong.setNhanVienTraPhongId(getNullableInteger(resultSet, "nhan_vien_tra_phong_id"));
        datPhong.setGhiChu(resultSet.getString("ghi_chu"));
        datPhong.setNgayTao(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_tao"));
        datPhong.setNgayCapNhat(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_cap_nhat"));
        return datPhong;
    }

    private Integer getNullableInteger(ResultSet resultSet, String columnName) throws SQLException {
        int value = resultSet.getInt(columnName);
        return resultSet.wasNull() ? null : value;
    }

    private void rollbackQuietly(Connection connection, Exception originalException) {
        if (connection == null) {
            return;
        }
        try {
            connection.rollback();
        } catch (SQLException rollbackException) {
            originalException.addSuppressed(rollbackException);
        }
    }

    private void closeTransactionalConnection(Connection connection) {
        if (connection == null) {
            return;
        }
        try {
            connection.setAutoCommit(true);
        } catch (SQLException ignored) {
        }
        try {
            connection.close();
        } catch (SQLException ignored) {
        }
    }

    private static final class RoomLockInfo {
        private int id;
        private String roomNumber;
        private TrangThaiPhong status;
        private boolean active;
    }

    private static final class BookingLockInfo {
        private TrangThaiDatPhong status;
        private LocalDateTime expectedCheckIn;
        private LocalDateTime expectedCheckOut;
    }
}
