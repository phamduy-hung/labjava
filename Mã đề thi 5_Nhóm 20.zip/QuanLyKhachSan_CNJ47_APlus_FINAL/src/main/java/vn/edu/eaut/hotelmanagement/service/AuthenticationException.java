package vn.edu.eaut.hotelmanagement.service;

/**
 * Ngoại lệ nghiệp vụ dùng cho các lỗi xác thực có thể hiển thị cho người dùng.
 */
public class AuthenticationException extends Exception {

    public AuthenticationException(String message) {
        super(message);
    }
}
