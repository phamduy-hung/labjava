package vn.edu.eaut.hotelmanagement.model;

import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiDatPhong;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class DatPhong {
    private Integer id;
    private String maDatPhong;
    private Integer khachHangId;
    private LocalDateTime thoiGianDat;
    private LocalDateTime ngayDuKienNhan;
    private LocalDateTime ngayDuKienTra;
    private LocalDateTime ngayNhanThucTe;
    private LocalDateTime ngayTraThucTe;
    private int soNguoiLon;
    private int soTreEm;
    private BigDecimal tienCoc;
    private TrangThaiDatPhong trangThai;
    private Integer nhanVienTaoId;
    private Integer nhanVienNhanPhongId;
    private Integer nhanVienTraPhongId;
    private String ghiChu;
    private LocalDateTime ngayTao;
    private LocalDateTime ngayCapNhat;

    public DatPhong() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMaDatPhong() {
        return maDatPhong;
    }

    public void setMaDatPhong(String maDatPhong) {
        this.maDatPhong = maDatPhong;
    }

    public Integer getKhachHangId() {
        return khachHangId;
    }

    public void setKhachHangId(Integer khachHangId) {
        this.khachHangId = khachHangId;
    }

    public LocalDateTime getThoiGianDat() {
        return thoiGianDat;
    }

    public void setThoiGianDat(LocalDateTime thoiGianDat) {
        this.thoiGianDat = thoiGianDat;
    }

    public LocalDateTime getNgayDuKienNhan() {
        return ngayDuKienNhan;
    }

    public void setNgayDuKienNhan(LocalDateTime ngayDuKienNhan) {
        this.ngayDuKienNhan = ngayDuKienNhan;
    }

    public LocalDateTime getNgayDuKienTra() {
        return ngayDuKienTra;
    }

    public void setNgayDuKienTra(LocalDateTime ngayDuKienTra) {
        this.ngayDuKienTra = ngayDuKienTra;
    }

    public LocalDateTime getNgayNhanThucTe() {
        return ngayNhanThucTe;
    }

    public void setNgayNhanThucTe(LocalDateTime ngayNhanThucTe) {
        this.ngayNhanThucTe = ngayNhanThucTe;
    }

    public LocalDateTime getNgayTraThucTe() {
        return ngayTraThucTe;
    }

    public void setNgayTraThucTe(LocalDateTime ngayTraThucTe) {
        this.ngayTraThucTe = ngayTraThucTe;
    }

    public int getSoNguoiLon() {
        return soNguoiLon;
    }

    public void setSoNguoiLon(int soNguoiLon) {
        this.soNguoiLon = soNguoiLon;
    }

    public int getSoTreEm() {
        return soTreEm;
    }

    public void setSoTreEm(int soTreEm) {
        this.soTreEm = soTreEm;
    }

    public BigDecimal getTienCoc() {
        return tienCoc;
    }

    public void setTienCoc(BigDecimal tienCoc) {
        this.tienCoc = tienCoc;
    }

    public TrangThaiDatPhong getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(TrangThaiDatPhong trangThai) {
        this.trangThai = trangThai;
    }

    public Integer getNhanVienTaoId() {
        return nhanVienTaoId;
    }

    public void setNhanVienTaoId(Integer nhanVienTaoId) {
        this.nhanVienTaoId = nhanVienTaoId;
    }

    public Integer getNhanVienNhanPhongId() {
        return nhanVienNhanPhongId;
    }

    public void setNhanVienNhanPhongId(Integer nhanVienNhanPhongId) {
        this.nhanVienNhanPhongId = nhanVienNhanPhongId;
    }

    public Integer getNhanVienTraPhongId() {
        return nhanVienTraPhongId;
    }

    public void setNhanVienTraPhongId(Integer nhanVienTraPhongId) {
        this.nhanVienTraPhongId = nhanVienTraPhongId;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public LocalDateTime getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(LocalDateTime ngayTao) {
        this.ngayTao = ngayTao;
    }

    public LocalDateTime getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(LocalDateTime ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    }

    @Override
    public String toString() {
        return maDatPhong;
    }
}
