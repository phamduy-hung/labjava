package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.TaiKhoan;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * CSDL Phần 1 không có bảng nhan_vien riêng.
 * Nhân viên được biểu diễn bằng bảng tai_khoan và vai trò LE_TAN, BUONG_PHONG, KE_TOAN.
 * Lớp này cung cấp API theo khái niệm "nhân viên" nhưng không tạo thêm bảng/model trái với schema đã chốt.
 */
public class NhanVienDAO {

    private final TaiKhoanDAO taiKhoanDAO = new TaiKhoanDAO();

    private static final String STAFF_SELECT =
            "SELECT tk.id, tk.ten_dang_nhap, tk.mat_khau_hash, tk.ho_ten, tk.so_dien_thoai, tk.email, "
                    + "tk.vai_tro_id, tk.dang_hoat_dong, tk.lan_dang_nhap_cuoi, tk.ngay_tao, tk.ngay_cap_nhat "
                    + "FROM tai_khoan tk JOIN vai_tro vt ON vt.id = tk.vai_tro_id "
                    + "WHERE vt.ma_vai_tro IN ('LE_TAN', 'BUONG_PHONG', 'KE_TOAN')";

    public int insert(TaiKhoan nhanVien) throws SQLException {
        return taiKhoanDAO.insert(nhanVien);
    }

    public boolean update(TaiKhoan nhanVien) throws SQLException {
        return taiKhoanDAO.update(nhanVien);
    }

    public boolean deleteById(int id) throws SQLException {
        return taiKhoanDAO.deleteById(id);
    }

    public Optional<TaiKhoan> findById(int id) throws SQLException {
        String sql = STAFF_SELECT + " AND tk.id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(taiKhoanDAO.mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<TaiKhoan> findAll() throws SQLException {
        String sql = STAFF_SELECT + " ORDER BY tk.ho_ten";
        List<TaiKhoan> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(taiKhoanDAO.mapRow(resultSet));
            }
        }
        return result;
    }

    public List<TaiKhoan> search(String keyword) throws SQLException {
        String sql = STAFF_SELECT
                + " AND (tk.ten_dang_nhap LIKE ? OR tk.ho_ten LIKE ? OR tk.so_dien_thoai LIKE ? OR tk.email LIKE ?) "
                + "ORDER BY tk.ho_ten";
        String searchValue = "%" + (keyword == null ? "" : keyword.trim()) + "%";
        List<TaiKhoan> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            for (int i = 1; i <= 4; i++) {
                statement.setString(i, searchValue);
            }
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(taiKhoanDAO.mapRow(resultSet));
                }
            }
        }
        return result;
    }
}
