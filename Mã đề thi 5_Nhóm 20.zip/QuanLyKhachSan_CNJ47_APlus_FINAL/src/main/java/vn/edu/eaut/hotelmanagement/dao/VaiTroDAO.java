package vn.edu.eaut.hotelmanagement.dao;

import vn.edu.eaut.hotelmanagement.config.DatabaseConnection;
import vn.edu.eaut.hotelmanagement.model.VaiTro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class VaiTroDAO {

    private static final String SELECT_COLUMNS =
            "id, ma_vai_tro, ten_vai_tro, mo_ta, dang_hoat_dong, ngay_tao";

    public int insert(VaiTro vaiTro) throws SQLException {
        String sql = "INSERT INTO vai_tro(ma_vai_tro, ten_vai_tro, mo_ta, dang_hoat_dong) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, vaiTro.getMaVaiTro());
            statement.setString(2, vaiTro.getTenVaiTro());
            statement.setString(3, vaiTro.getMoTa());
            statement.setBoolean(4, vaiTro.isDangHoatDong());
            statement.executeUpdate();
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    vaiTro.setId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Không lấy được khóa chính của vai trò vừa thêm.");
    }

    public boolean update(VaiTro vaiTro) throws SQLException {
        String sql = "UPDATE vai_tro SET ma_vai_tro = ?, ten_vai_tro = ?, mo_ta = ?, dang_hoat_dong = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, vaiTro.getMaVaiTro());
            statement.setString(2, vaiTro.getTenVaiTro());
            statement.setString(3, vaiTro.getMoTa());
            statement.setBoolean(4, vaiTro.isDangHoatDong());
            statement.setInt(5, vaiTro.getId());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteById(int id) throws SQLException {
        String sql = "DELETE FROM vai_tro WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    public Optional<VaiTro> findById(int id) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM vai_tro WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public Optional<VaiTro> findByCode(String maVaiTro) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM vai_tro WHERE ma_vai_tro = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, maVaiTro);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapRow(resultSet)) : Optional.empty();
            }
        }
    }

    public List<VaiTro> findAll() throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM vai_tro ORDER BY ten_vai_tro";
        List<VaiTro> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                result.add(mapRow(resultSet));
            }
        }
        return result;
    }

    public List<VaiTro> search(String keyword) throws SQLException {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM vai_tro "
                + "WHERE ma_vai_tro LIKE ? OR ten_vai_tro LIKE ? OR mo_ta LIKE ? ORDER BY ten_vai_tro";
        String searchValue = "%" + (keyword == null ? "" : keyword.trim()) + "%";
        List<VaiTro> result = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, searchValue);
            statement.setString(2, searchValue);
            statement.setString(3, searchValue);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(mapRow(resultSet));
                }
            }
        }
        return result;
    }

    private VaiTro mapRow(ResultSet resultSet) throws SQLException {
        VaiTro vaiTro = new VaiTro();
        vaiTro.setId(resultSet.getInt("id"));
        vaiTro.setMaVaiTro(resultSet.getString("ma_vai_tro"));
        vaiTro.setTenVaiTro(resultSet.getString("ten_vai_tro"));
        vaiTro.setMoTa(resultSet.getString("mo_ta"));
        vaiTro.setDangHoatDong(resultSet.getBoolean("dang_hoat_dong"));
        vaiTro.setNgayTao(JdbcDataAccessSupport.getNullableLocalDateTime(resultSet, "ngay_tao"));
        return vaiTro;
    }
}
