package vn.edu.eaut.hotelmanagement.model;

import java.time.LocalDateTime;

public class NhatKyHeThong {
    private Long id;
    private Integer taiKhoanId;
    private String hanhDong;
    private String doiTuong;
    private String doiTuongId;
    private String noiDung;
    private LocalDateTime thoiGian;

    public NhatKyHeThong() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getTaiKhoanId() {
        return taiKhoanId;
    }

    public void setTaiKhoanId(Integer taiKhoanId) {
        this.taiKhoanId = taiKhoanId;
    }

    public String getHanhDong() {
        return hanhDong;
    }

    public void setHanhDong(String hanhDong) {
        this.hanhDong = hanhDong;
    }

    public String getDoiTuong() {
        return doiTuong;
    }

    public void setDoiTuong(String doiTuong) {
        this.doiTuong = doiTuong;
    }

    public String getDoiTuongId() {
        return doiTuongId;
    }

    public void setDoiTuongId(String doiTuongId) {
        this.doiTuongId = doiTuongId;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }

    public LocalDateTime getThoiGian() {
        return thoiGian;
    }

    public void setThoiGian(LocalDateTime thoiGian) {
        this.thoiGian = thoiGian;
    }
}
