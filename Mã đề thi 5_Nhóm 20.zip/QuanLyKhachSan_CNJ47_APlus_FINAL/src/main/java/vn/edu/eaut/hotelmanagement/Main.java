package vn.edu.eaut.hotelmanagement;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import vn.edu.eaut.hotelmanagement.security.CustomerDataSecurity;
import vn.edu.eaut.hotelmanagement.utils.UITheme;
import vn.edu.eaut.hotelmanagement.view.LoginView;

import java.util.Locale;


/**
 * Điểm khởi động chính của ứng dụng quản lý khách sạn.
 *
 * Luồng hoạt động:
 * Main
 *  -> Thiết lập môi trường
 *  -> Cấu hình giao diện chung
 *  -> Mở màn hình đăng nhập
 */
public final class Main {

    private static final String APPLICATION_NAME = "Hotel Management System";


    private Main() {
        // Không cho phép tạo đối tượng từ lớp Main.
    }


    public static void main(String[] args) {

        configureApplicationEnvironment();

        SwingUtilities.invokeLater(() -> {

            try {

                UITheme.setupUI();

                // Bảo vệ dữ liệu cá nhân khách hàng trước khi cho phép truy cập hệ thống.
                // Lần chạy đầu sẽ tự động chuyển dữ liệu seed plaintext sang AES-256-GCM.
                CustomerDataSecurity.MigrationResult migration = CustomerDataSecurity.initialize();
                if (migration.migratedRows() > 0) {
                    System.out.println("[SECURITY] Đã mã hóa dữ liệu cá nhân của "
                            + migration.migratedRows() + " khách hàng bằng AES-256-GCM.");
                }

                LoginView loginView = new LoginView();

                loginView.setVisible(true);

            } catch (Exception exception) {

                showStartupError(exception);

            }

        });

    }


    /**
     * Thiết lập môi trường chạy ứng dụng.
     */
    private static void configureApplicationEnvironment() {

        Locale.setDefault(new Locale("vi", "VN"));

        System.setProperty(
                "awt.useSystemAAFontSettings",
                "on"
        );

        System.setProperty(
                "swing.aatext",
                "true"
        );


        Thread.setDefaultUncaughtExceptionHandler(
                (thread, throwable) -> {

                    SwingUtilities.invokeLater(() -> {

                        JOptionPane.showMessageDialog(
                                null,
                                "Chương trình gặp lỗi không mong muốn.\n\n"
                                        + "Chi tiết: "
                                        + throwable.getMessage(),
                                APPLICATION_NAME + " - Lỗi",
                                JOptionPane.ERROR_MESSAGE
                        );

                    });

                }
        );

    }


    /**
     * Hiển thị lỗi khi chương trình không thể khởi động.
     */
    private static void showStartupError(Exception exception) {

        JOptionPane.showMessageDialog(
                null,
                "Không thể khởi động chương trình.\n\n"
                        + "Chi tiết: "
                        + exception.getMessage(),
                APPLICATION_NAME + " - Lỗi khởi động",
                JOptionPane.ERROR_MESSAGE
        );

    }

}