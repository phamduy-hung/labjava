package vn.edu.eaut.hotelmanagement.model;

import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiHoaDon;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class HoaDon {
    private Integer id;
    private String maHoaDon;
    private Integer datPhongId;
    private BigDecimal tongTienPhong;
    private BigDecimal tongTienDichVu;
    private BigDecimal phuThu;
    private BigDecimal giamGia;
    private BigDecimal tongThanhToan;
    private TrangThaiHoaDon trangThai;
    private Integer nhanVienLapId;
    private LocalDateTime thoiGianLap;
    private String ghiChu;

    public HoaDon() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public Integer getDatPhongId() {
        return datPhongId;
    }

    public void setDatPhongId(Integer datPhongId) {
        this.datPhongId = datPhongId;
    }

    public BigDecimal getTongTienPhong() {
        return tongTienPhong;
    }

    public void setTongTienPhong(BigDecimal tongTienPhong) {
        this.tongTienPhong = tongTienPhong;
    }

    public BigDecimal getTongTienDichVu() {
        return tongTienDichVu;
    }

    public void setTongTienDichVu(BigDecimal tongTienDichVu) {
        this.tongTienDichVu = tongTienDichVu;
    }

    public BigDecimal getPhuThu() {
        return phuThu;
    }

    public void setPhuThu(BigDecimal phuThu) {
        this.phuThu = phuThu;
    }

    public BigDecimal getGiamGia() {
        return giamGia;
    }

    public void setGiamGia(BigDecimal giamGia) {
        this.giamGia = giamGia;
    }

    public BigDecimal getTongThanhToan() {
        return tongThanhToan;
    }

    /**
     * Trường này được MySQL GENERATED ALWAYS tính tự động.
     * DAO chỉ dùng setter này khi đọc dữ liệu từ ResultSet, không dùng khi INSERT/UPDATE.
     */
    public void setTongThanhToan(BigDecimal tongThanhToan) {
        this.tongThanhToan = tongThanhToan;
    }

    public TrangThaiHoaDon getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(TrangThaiHoaDon trangThai) {
        this.trangThai = trangThai;
    }

    public Integer getNhanVienLapId() {
        return nhanVienLapId;
    }

    public void setNhanVienLapId(Integer nhanVienLapId) {
        this.nhanVienLapId = nhanVienLapId;
    }

    public LocalDateTime getThoiGianLap() {
        return thoiGianLap;
    }

    public void setThoiGianLap(LocalDateTime thoiGianLap) {
        this.thoiGianLap = thoiGianLap;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    @Override
    public String toString() {
        return maHoaDon;
    }
}
