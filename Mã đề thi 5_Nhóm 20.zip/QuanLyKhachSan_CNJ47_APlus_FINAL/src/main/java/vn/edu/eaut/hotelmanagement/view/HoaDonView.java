package vn.edu.eaut.hotelmanagement.view;

import vn.edu.eaut.hotelmanagement.dao.ChiTietDatPhongDAO;
import vn.edu.eaut.hotelmanagement.dao.DatPhongDAO;
import vn.edu.eaut.hotelmanagement.dao.DichVuDAO;
import vn.edu.eaut.hotelmanagement.dao.HoaDonDAO;
import vn.edu.eaut.hotelmanagement.dao.KhachHangDAO;
import vn.edu.eaut.hotelmanagement.dao.LoaiPhongDAO;
import vn.edu.eaut.hotelmanagement.dao.PhongDAO;
import vn.edu.eaut.hotelmanagement.dao.SuDungDichVuDAO;
import vn.edu.eaut.hotelmanagement.model.ChiTietDatPhong;
import vn.edu.eaut.hotelmanagement.model.DatPhong;
import vn.edu.eaut.hotelmanagement.model.DichVu;
import vn.edu.eaut.hotelmanagement.model.HoaDon;
import vn.edu.eaut.hotelmanagement.model.KhachHang;
import vn.edu.eaut.hotelmanagement.model.LoaiPhong;
import vn.edu.eaut.hotelmanagement.model.Phong;
import vn.edu.eaut.hotelmanagement.model.SuDungDichVu;
import vn.edu.eaut.hotelmanagement.model.enums.PhuongThucThanhToan;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiDatPhong;
import vn.edu.eaut.hotelmanagement.model.enums.TrangThaiPhong;
import vn.edu.eaut.hotelmanagement.session.LoginSession;
import vn.edu.eaut.hotelmanagement.utils.ButtonUtils;
import vn.edu.eaut.hotelmanagement.utils.TableUtils;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.print.PrinterException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

/**
 * Màn hình Trả phòng & Thanh toán.
 *
 * Chức năng:
 * - Hiển thị các phòng thuộc booking đang DA_NHAN_PHONG.
 * - Tính số ngày lưu trú, tiền phòng theo giá đã chốt trong chi_tiet_dat_phong,
 *   tiền dịch vụ, phụ thu, giảm giá và tổng hóa đơn.
 * - Xem/In hóa đơn bằng JDialog + JTextArea.
 * - Thanh toán và checkout bằng HoaDonDAO.checkoutAndPay(...).
 * - HoaDonDAO thực hiện transaction nguyên tử: hóa đơn + thanh toán + booking + trạng thái phòng.
 * - Sau checkout thành công, phòng chuyển DANG_DON (Đang dọn dẹp).
 * - Tất cả truy vấn CSDL chạy trong SwingWorker để không làm treo EDT.
 */
public class HoaDonView extends JPanel {

    private static final Color PRIMARY_COLOR = new Color(26, 83, 155);
    private static final Color PRIMARY_DARK_COLOR = new Color(17, 55, 105);
    private static final Color BACKGROUND_COLOR = new Color(244, 247, 251);
    private static final Color CARD_COLOR = Color.WHITE;
    private static final Color BORDER_COLOR = new Color(221, 228, 236);
    private static final Color TEXT_COLOR = new Color(38, 49, 64);
    private static final Color SECONDARY_TEXT_COLOR = new Color(105, 117, 133);
    private static final Color SUCCESS_COLOR = new Color(37, 137, 88);
    private static final Color WARNING_COLOR = new Color(193, 124, 31);
    private static final Color DANGER_COLOR = new Color(184, 55, 55);
    private static final Color INPUT_BACKGROUND = new Color(250, 252, 255);

    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private static final NumberFormat MONEY_FORMAT =
            NumberFormat.getNumberInstance(new Locale("vi", "VN"));

    private final LoginSession loginSession;
    private final HoaDonDAO hoaDonDAO;
    private final DatPhongDAO datPhongDAO;
    private final ChiTietDatPhongDAO chiTietDatPhongDAO;
    private final KhachHangDAO khachHangDAO;
    private final PhongDAO phongDAO;
    private final LoaiPhongDAO loaiPhongDAO;
    private final SuDungDichVuDAO suDungDichVuDAO;
    private final DichVuDAO dichVuDAO;

    private final JTextField txtTimKiem = new JTextField(24);
    private final JButton btnTimKiem = new JButton("Tìm kiếm");
    private final JButton btnTaiLai = new JButton("Tải lại");

    private final DefaultTableModel roomTableModel = new DefaultTableModel(
            new Object[]{
                    "Mã booking",
                    "Số phòng",
                    "Khách hàng",
                    "Check-in",
                    "Dự kiến trả",
                    "Giá phòng/ngày"
            },
            0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tblPhongDangO = new JTable(roomTableModel);

    private final JLabel lblMaBooking = createValueLabel("-");
    private final JLabel lblKhachHang = createValueLabel("-");
    private final JLabel lblSoPhong = createValueLabel("-");
    private final JLabel lblLoaiPhong = createValueLabel("-");
    private final JLabel lblThoiGianNhan = createValueLabel("-");
    private final JLabel lblThoiGianTra = createValueLabel("-");
    private final JLabel lblSoNgay = createValueLabel("0");
    private final JLabel lblTienCoc = createValueLabel("0 VNĐ");
    private final JLabel lblTienPhong = createMoneyValueLabel();
    private final JLabel lblTienDichVu = createMoneyValueLabel();
    private final JLabel lblTongThanhToan = createTotalValueLabel();
    private final JLabel lblHoaDonHienTai = createValueLabel("Chưa lập hóa đơn");
    private final JLabel lblDaThanhToan = createValueLabel("0 VNĐ");

    private final JTextField txtPhuThu = new JTextField("0", 14);
    private final JTextField txtGiamGia = new JTextField("0", 14);
    private final JComboBox<PhuongThucThanhToan> cboPhuongThucThanhToan =
            new JComboBox<>(PhuongThucThanhToan.values());
    private final JTextField txtMaThamChieu = new JTextField(18);
    private final JTextArea txtGhiChu = new JTextArea(3, 18);

    private final JButton btnTinhLai = new JButton("Tính lại");
    private final JButton btnInHoaDon = new JButton("In hóa đơn");
    private final JButton btnThanhToan = new JButton("Thanh toán & Check-out");

    private final DefaultTableModel serviceTableModel = new DefaultTableModel(
            new Object[]{"Dịch vụ", "Số lượng", "Đơn giá", "Thành tiền"},
            0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tblDichVu = new JTable(serviceTableModel);

    private final JLabel lblTrangThai = new JLabel("Sẵn sàng");
    private final JLabel lblTongPhongDangO = new JLabel("Phòng đang có khách: 0");

    private final List<OccupiedRoomRow> occupiedRows = new ArrayList<>();
    private final Map<Integer, KhachHang> customerCache = new HashMap<>();
    private final Map<Integer, Phong> roomCache = new HashMap<>();
    private final Map<Integer, LoaiPhong> roomTypeCache = new HashMap<>();
    private final Map<Integer, DichVu> serviceCache = new HashMap<>();

    private OccupiedRoomRow selectedRow;
    private CheckoutCalculation currentCalculation;
    private boolean busy;
    private boolean paymentPermission = true;
    private BigDecimal lastCalculatedSurcharge = BigDecimal.ZERO;
    private BigDecimal lastCalculatedDiscount = BigDecimal.ZERO;

    public HoaDonView() {
        this(
                null,
                new HoaDonDAO(),
                new DatPhongDAO(),
                new ChiTietDatPhongDAO(),
                new KhachHangDAO(),
                new PhongDAO(),
                new LoaiPhongDAO(),
                new SuDungDichVuDAO(),
                new DichVuDAO()
        );
    }

    public HoaDonView(LoginSession loginSession) {
        this(
                loginSession,
                new HoaDonDAO(),
                new DatPhongDAO(),
                new ChiTietDatPhongDAO(),
                new KhachHangDAO(),
                new PhongDAO(),
                new LoaiPhongDAO(),
                new SuDungDichVuDAO(),
                new DichVuDAO()
        );
    }

    public HoaDonView(
            LoginSession loginSession,
            HoaDonDAO hoaDonDAO,
            DatPhongDAO datPhongDAO,
            ChiTietDatPhongDAO chiTietDatPhongDAO,
            KhachHangDAO khachHangDAO,
            PhongDAO phongDAO,
            LoaiPhongDAO loaiPhongDAO,
            SuDungDichVuDAO suDungDichVuDAO,
            DichVuDAO dichVuDAO) {

        this.loginSession = loginSession;
        this.hoaDonDAO = hoaDonDAO;
        this.datPhongDAO = datPhongDAO;
        this.chiTietDatPhongDAO = chiTietDatPhongDAO;
        this.khachHangDAO = khachHangDAO;
        this.phongDAO = phongDAO;
        this.loaiPhongDAO = loaiPhongDAO;
        this.suDungDichVuDAO = suDungDichVuDAO;
        this.dichVuDAO = dichVuDAO;

        initializeLayout();
        initializeComponents();
        registerEvents();
        applyRolePermissions();
        clearSelectionDetails();
        loadOccupiedRooms("");
    }

    private void initializeLayout() {
        setLayout(new BorderLayout(0, 16));
        setBackground(BACKGROUND_COLOR);
        setBorder(new EmptyBorder(20, 20, 20, 20));
    }

    private void initializeComponents() {
        txtGhiChu.setLineWrap(true);
        txtGhiChu.setWrapStyleWord(true);
        txtGhiChu.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));

        txtPhuThu.setToolTipText("Nhập số tiền, ví dụ 100000 hoặc 100.000");
        txtGiamGia.setToolTipText("Nhập số tiền, ví dụ 50000 hoặc 50.000");
        txtMaThamChieu.setToolTipText("Mã giao dịch/tham chiếu. Bắt buộc với thanh toán không dùng tiền mặt.");
        styleMoneyInput(txtPhuThu);
        styleMoneyInput(txtGiamGia);
        txtGhiChu.setBackground(Color.WHITE);
        txtMaThamChieu.setBackground(INPUT_BACKGROUND);

        ButtonUtils.success(btnThanhToan);
        ButtonUtils.neutral(btnInHoaDon);
        ButtonUtils.neutral(btnTinhLai);
        ButtonUtils.primary(btnTimKiem);
        ButtonUtils.neutral(btnTaiLai);

        TableUtils.setupTable(tblPhongDangO);
        tblPhongDangO.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblPhongDangO.setRowHeight(30);
        tblPhongDangO.setSelectionBackground(new Color(218, 232, 250));
        tblPhongDangO.setSelectionForeground(TEXT_COLOR);
        configureMoneyColumn(tblPhongDangO, 5);

        TableUtils.setupTable(tblDichVu);
        tblDichVu.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblDichVu.setRowHeight(28);
        configureMoneyColumn(tblDichVu, 2);
        configureMoneyColumn(tblDichVu, 3);

        add(createHeaderPanel(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
        add(createStatusBar(), BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(16, 8));
        panel.setOpaque(false);

        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);

        JLabel title = new JLabel("TRẢ PHÒNG & THANH TOÁN");
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        title.setForeground(TEXT_COLOR);

        JLabel subtitle = new JLabel(
                "Tính tiền lưu trú, dịch vụ, lập hóa đơn và chuyển phòng sang trạng thái Đang dọn dẹp sau checkout."
        );
        subtitle.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        subtitle.setForeground(SECONDARY_TEXT_COLOR);

        titlePanel.add(title);
        titlePanel.add(subtitle);

        JPanel searchPanel = createCardPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        searchPanel.add(new JLabel("Tìm phòng/booking/khách:"));
        searchPanel.add(txtTimKiem);
        searchPanel.add(btnTimKiem);
        searchPanel.add(btnTaiLai);

        panel.add(titlePanel, BorderLayout.CENTER);
        panel.add(searchPanel, BorderLayout.EAST);
        return panel;
    }

    private Component createMainContent() {
        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                createOccupiedRoomsPanel(),
                createCheckoutPanel()
        );
        splitPane.setResizeWeight(0.48);
        splitPane.setDividerLocation(620);
        splitPane.setContinuousLayout(true);
        splitPane.setBorder(null);
        splitPane.setBackground(BACKGROUND_COLOR);
        return splitPane;
    }

    private JPanel createOccupiedRoomsPanel() {
        JPanel panel = createCardPanel(new BorderLayout(0, 10));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(14, 14, 14, 14)
        ));

        JPanel heading = new JPanel(new BorderLayout());
        heading.setOpaque(false);

        JLabel title = new JLabel("PHÒNG ĐANG CÓ KHÁCH");
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
        title.setForeground(PRIMARY_DARK_COLOR);

        lblTongPhongDangO.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        lblTongPhongDangO.setForeground(SECONDARY_TEXT_COLOR);

        heading.add(title, BorderLayout.WEST);
        heading.add(lblTongPhongDangO, BorderLayout.EAST);

        JScrollPane scrollPane = new JScrollPane(tblPhongDangO);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        scrollPane.getViewport().setBackground(Color.WHITE);

        JLabel hint = new JLabel(
                "Chọn một phòng để xem toàn bộ chi phí của booking. Nếu booking có nhiều phòng, checkout sẽ áp dụng cho toàn booking."
        );
        hint.setForeground(SECONDARY_TEXT_COLOR);
        hint.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 12));

        panel.add(heading, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(hint, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createCheckoutPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(0, 14, 0, 0));

        JPanel informationCard = createCardPanel(new BorderLayout(0, 10));
        informationCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(14, 16, 14, 16)
        ));

        JLabel informationTitle = new JLabel("THÔNG TIN CHECK-OUT");
        informationTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
        informationTitle.setForeground(PRIMARY_DARK_COLOR);

        JPanel informationGrid = new JPanel(new GridBagLayout());
        informationGrid.setOpaque(false);
        GridBagConstraints constraints = createGridConstraints();

        addInformationRow(informationGrid, constraints, 0, "Mã booking:", lblMaBooking);
        addInformationRow(informationGrid, constraints, 1, "Khách hàng:", lblKhachHang);
        addInformationRow(informationGrid, constraints, 2, "Phòng:", lblSoPhong);
        addInformationRow(informationGrid, constraints, 3, "Loại phòng:", lblLoaiPhong);
        addInformationRow(informationGrid, constraints, 4, "Check-in thực tế:", lblThoiGianNhan);
        addInformationRow(informationGrid, constraints, 5, "Thời điểm tính trả:", lblThoiGianTra);
        addInformationRow(informationGrid, constraints, 6, "Số ngày/đêm tính tiền:", lblSoNgay);
        addInformationRow(informationGrid, constraints, 7, "Tiền cọc booking:", lblTienCoc);
        addInformationRow(informationGrid, constraints, 8, "Hóa đơn hiện tại:", lblHoaDonHienTai);
        addInformationRow(informationGrid, constraints, 9, "Đã thanh toán trước:", lblDaThanhToan);

        informationCard.add(informationTitle, BorderLayout.NORTH);
        informationCard.add(informationGrid, BorderLayout.CENTER);

        JPanel serviceCard = createCardPanel(new BorderLayout(0, 8));
        serviceCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(12, 14, 12, 14)
        ));
        JLabel serviceTitle = new JLabel("DỊCH VỤ PHÁT SINH");
        serviceTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        serviceTitle.setForeground(PRIMARY_DARK_COLOR);
        JScrollPane serviceScrollPane = new JScrollPane(tblDichVu);
        serviceScrollPane.setPreferredSize(new Dimension(520, 145));
        serviceScrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        serviceCard.add(serviceTitle, BorderLayout.NORTH);
        serviceCard.add(serviceScrollPane, BorderLayout.CENTER);

        JPanel paymentCard = createCardPanel(new BorderLayout(0, 10));
        paymentCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(14, 16, 14, 16)
        ));

        JLabel paymentTitle = new JLabel("TỔNG HỢP & THANH TOÁN");
        paymentTitle.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
        paymentTitle.setForeground(PRIMARY_DARK_COLOR);

        JPanel paymentGrid = new JPanel(new GridBagLayout());
        paymentGrid.setOpaque(false);
        GridBagConstraints paymentConstraints = createGridConstraints();

        addInformationRow(paymentGrid, paymentConstraints, 0, "Tiền phòng:", lblTienPhong);
        addInformationRow(paymentGrid, paymentConstraints, 1, "Tiền dịch vụ:", lblTienDichVu);
        addInputRow(paymentGrid, paymentConstraints, 2, "Phụ thu (VNĐ):", txtPhuThu);
        addInputRow(paymentGrid, paymentConstraints, 3, "Giảm giá (VNĐ):", txtGiamGia);
        addInformationRow(paymentGrid, paymentConstraints, 4, "TỔNG THANH TOÁN:", lblTongThanhToan);
        addInputRow(paymentGrid, paymentConstraints, 5, "Phương thức:", cboPhuongThucThanhToan);
        addInputRow(paymentGrid, paymentConstraints, 6, "Mã tham chiếu:", txtMaThamChieu);

        paymentConstraints.gridx = 0;
        paymentConstraints.gridy = 7;
        paymentConstraints.weightx = 0;
        paymentConstraints.weighty = 0;
        paymentConstraints.fill = GridBagConstraints.NONE;
        paymentConstraints.anchor = GridBagConstraints.NORTHWEST;
        paymentGrid.add(createFieldLabel("Ghi chú:"), paymentConstraints);

        paymentConstraints.gridx = 1;
        paymentConstraints.weightx = 1;
        paymentConstraints.weighty = 0.4;
        paymentConstraints.fill = GridBagConstraints.BOTH;
        JScrollPane noteScroll = new JScrollPane(txtGhiChu);
        noteScroll.setPreferredSize(new Dimension(300, 65));
        paymentGrid.add(noteScroll, paymentConstraints);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(btnTinhLai);
        buttonPanel.add(btnInHoaDon);
        buttonPanel.add(btnThanhToan);

        paymentCard.add(paymentTitle, BorderLayout.NORTH);
        paymentCard.add(paymentGrid, BorderLayout.CENTER);
        paymentCard.add(buttonPanel, BorderLayout.SOUTH);

        JPanel rightContent = new JPanel();
        rightContent.setLayout(new javax.swing.BoxLayout(rightContent, javax.swing.BoxLayout.Y_AXIS));
        rightContent.setOpaque(false);
        informationCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        serviceCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        paymentCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightContent.add(informationCard);
        rightContent.add(javax.swing.Box.createVerticalStrut(10));
        rightContent.add(serviceCard);
        rightContent.add(javax.swing.Box.createVerticalStrut(10));
        rightContent.add(paymentCard);

        JScrollPane rightScrollPane = new JScrollPane(rightContent);
        rightScrollPane.setBorder(null);
        rightScrollPane.getViewport().setBackground(BACKGROUND_COLOR);
        rightScrollPane.getVerticalScrollBar().setUnitIncrement(16);
        panel.add(rightScrollPane, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createStatusBar() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(2, 4, 0, 4));

        lblTrangThai.setForeground(SECONDARY_TEXT_COLOR);
        lblTrangThai.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));

        JLabel guide = new JLabel("Thanh toán thành công → Booking: Đã trả phòng | Phòng: Đang dọn dẹp");
        guide.setForeground(SECONDARY_TEXT_COLOR);
        guide.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));

        panel.add(lblTrangThai, BorderLayout.WEST);
        panel.add(guide, BorderLayout.EAST);
        return panel;
    }

    private void registerEvents() {
        btnTaiLai.addActionListener(event -> {
            txtTimKiem.setText("");
            loadOccupiedRooms("");
        });

        btnTimKiem.addActionListener(event -> loadOccupiedRooms(txtTimKiem.getText().trim()));
        txtTimKiem.addActionListener(event -> loadOccupiedRooms(txtTimKiem.getText().trim()));

        tblPhongDangO.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                handleRoomSelection();
            }
        });

        btnTinhLai.addActionListener(event -> recalculateSelectedBooking(true));
        btnInHoaDon.addActionListener(event -> printInvoicePreview());
        btnThanhToan.addActionListener(event -> checkoutAndPay());

        cboPhuongThucThanhToan.addActionListener(event -> updateReferenceFieldState());
        updateReferenceFieldState();
    }

    private void applyRolePermissions() {
        if (loginSession == null) {
            paymentPermission = true;
            return;
        }

        paymentPermission = loginSession.hasRole("ADMIN")
                || loginSession.hasRole("LE_TAN")
                || loginSession.hasRole("KE_TOAN");

        ButtonUtils.applyEnabledState(btnThanhToan, paymentPermission);
        if (!paymentPermission) {
            btnThanhToan.setToolTipText("Tài khoản hiện tại không có quyền thanh toán/trả phòng.");
        }
    }

    private void loadOccupiedRooms(String keyword) {
        if (busy) {
            return;
        }

        setBusy(true, "Đang tải danh sách phòng có khách...");
        String normalizedKeyword = keyword == null ? "" : keyword.trim().toLowerCase(Locale.ROOT);

        SwingWorker<List<OccupiedRoomRow>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<OccupiedRoomRow> doInBackground() throws Exception {
                List<OccupiedRoomRow> rows = new ArrayList<>();
                List<DatPhong> bookings = datPhongDAO.findByStatus(TrangThaiDatPhong.DA_NHAN_PHONG);

                for (DatPhong booking : bookings) {
                    KhachHang customer = getCustomer(booking.getKhachHangId());
                    List<ChiTietDatPhong> details = chiTietDatPhongDAO.findByBookingId(booking.getId());

                    for (ChiTietDatPhong detail : details) {
                        Phong room = getRoom(detail.getPhongId());
                        if (room == null || room.getTrangThai() != TrangThaiPhong.DANG_O) {
                            continue;
                        }
                        LoaiPhong roomType = getRoomType(room.getLoaiPhongId());
                        OccupiedRoomRow row = new OccupiedRoomRow(booking, detail, room, roomType, customer);

                        if (matchesKeyword(row, normalizedKeyword)) {
                            rows.add(row);
                        }
                    }
                }
                return rows;
            }

            @Override
            protected void done() {
                try {
                    List<OccupiedRoomRow> rows = get();
                    occupiedRows.clear();
                    occupiedRows.addAll(rows);
                    refreshOccupiedRoomTable();
                    clearSelectionDetails();
                    setBusy(false, "Đã tải " + rows.size() + " phòng đang có khách.");
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Tải dữ liệu bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không tải được danh sách phòng.");
                    showDatabaseError("Không thể tải danh sách phòng đang có khách.", exception.getCause());
                }
            }
        };
        worker.execute();
    }

    private boolean matchesKeyword(OccupiedRoomRow row, String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return true;
        }
        String bookingCode = safe(row.booking.getMaDatPhong()).toLowerCase(Locale.ROOT);
        String roomNumber = safe(row.room.getSoPhong()).toLowerCase(Locale.ROOT);
        String customerName = row.customer == null ? "" : safe(row.customer.getHoTen()).toLowerCase(Locale.ROOT);
        String customerCode = row.customer == null ? "" : safe(row.customer.getMaKhachHang()).toLowerCase(Locale.ROOT);
        String identityNumber = row.customer == null ? "" : safe(row.customer.getSoGiayTo()).toLowerCase(Locale.ROOT);
        return bookingCode.contains(keyword)
                || roomNumber.contains(keyword)
                || customerName.contains(keyword)
                || customerCode.contains(keyword)
                || identityNumber.contains(keyword);
    }

    private void refreshOccupiedRoomTable() {
        roomTableModel.setRowCount(0);
        for (OccupiedRoomRow row : occupiedRows) {
            roomTableModel.addRow(new Object[]{
                    row.booking.getMaDatPhong(),
                    row.room.getSoPhong(),
                    row.customer == null ? "-" : row.customer.getHoTen(),
                    formatDateTime(row.booking.getNgayNhanThucTe()),
                    formatDateTime(row.booking.getNgayDuKienTra()),
                    formatMoney(row.detail.getGiaPhongThucTe())
            });
        }
        lblTongPhongDangO.setText("Phòng đang có khách: " + occupiedRows.size());
    }

    private void handleRoomSelection() {
        int viewRow = tblPhongDangO.getSelectedRow();
        if (viewRow < 0) {
            selectedRow = null;
            clearSelectionDetails();
            return;
        }

        int modelRow = tblPhongDangO.convertRowIndexToModel(viewRow);
        if (modelRow < 0 || modelRow >= occupiedRows.size()) {
            return;
        }

        selectedRow = occupiedRows.get(modelRow);
        txtPhuThu.setText("0");
        txtGiamGia.setText("0");
        txtMaThamChieu.setText("");
        txtGhiChu.setText("");
        recalculateSelectedBooking(false);
    }

    private void recalculateSelectedBooking(boolean showValidationMessage) {
        if (selectedRow == null) {
            if (showValidationMessage) {
                showWarning("Vui lòng chọn một phòng đang có khách trước khi tính tiền.");
            }
            return;
        }
        if (busy) {
            return;
        }

        BigDecimal surcharge;
        BigDecimal discount;
        try {
            surcharge = parseMoney(txtPhuThu, "Phụ thu");
            discount = parseMoney(txtGiamGia, "Giảm giá");
        } catch (IllegalArgumentException exception) {
            if (showValidationMessage) {
                showWarning(exception.getMessage());
            }
            return;
        }

        setBusy(true, "Đang tính chi phí checkout...");
        OccupiedRoomRow selectedSnapshot = selectedRow;

        SwingWorker<CheckoutCalculation, Void> worker = new SwingWorker<>() {
            @Override
            protected CheckoutCalculation doInBackground() throws Exception {
                return calculateCheckout(selectedSnapshot, surcharge, discount);
            }

            @Override
            protected void done() {
                try {
                    CheckoutCalculation calculation = get();
                    if (selectedRow == null
                            || selectedRow.booking.getId() == null
                            || !selectedRow.booking.getId().equals(calculation.booking.getId())) {
                        setBusy(false, "Booking đang chọn đã thay đổi.");
                        return;
                    }
                    currentCalculation = calculation;
                    lastCalculatedSurcharge = calculation.surcharge;
                    lastCalculatedDiscount = calculation.discount;

                    displayCalculation(calculation);

                    setBusy(
                            false,
                            "Đã tính chi phí. Vui lòng kiểm tra trước khi thanh toán."
                    );
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Tính tiền bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Không tính được chi phí.");
                    showDatabaseError("Không thể tính chi phí checkout.", exception.getCause());
                }
            }
        };
        worker.execute();
    }

    private CheckoutCalculation calculateCheckout(
            OccupiedRoomRow row,
            BigDecimal surcharge,
            BigDecimal discount) throws SQLException {

        DatPhong booking = datPhongDAO.findById(row.booking.getId())
                .orElseThrow(() -> new SQLException("Booking không còn tồn tại."));

        if (booking.getTrangThai() != TrangThaiDatPhong.DA_NHAN_PHONG) {
            throw new SQLException("Booking không còn ở trạng thái Đã nhận phòng.");
        }

        LocalDateTime checkIn = booking.getNgayNhanThucTe();
        if (checkIn == null) {
            throw new SQLException("Booking chưa có thời gian check-in thực tế.");
        }

        LocalDateTime checkoutTime = LocalDateTime.now();
        int billableDays = calculateBillableDays(checkIn, checkoutTime);

        List<ChiTietDatPhong> details = chiTietDatPhongDAO.findByBookingId(booking.getId());
        if (details.isEmpty()) {
            throw new SQLException("Booking không có chi tiết phòng.");
        }

        BigDecimal roomTotal = BigDecimal.ZERO;
        List<String> roomNumbers = new ArrayList<>();
        for (ChiTietDatPhong detail : details) {
            BigDecimal price = nonNull(detail.getGiaPhongThucTe());
            roomTotal = roomTotal.add(price.multiply(BigDecimal.valueOf(billableDays)));
            Phong room = getRoom(detail.getPhongId());
            roomNumbers.add(room == null ? "#" + detail.getPhongId() : room.getSoPhong());
        }

        List<SuDungDichVu> serviceUsages = suDungDichVuDAO.findByBookingId(booking.getId());
        List<ServiceDisplayRow> serviceRows = new ArrayList<>();
        BigDecimal serviceTotal = BigDecimal.ZERO;
        for (SuDungDichVu usage : serviceUsages) {
            DichVu service = getService(usage.getDichVuId());
            BigDecimal lineTotal = nonNull(usage.getThanhTien());
            serviceTotal = serviceTotal.add(lineTotal);
            serviceRows.add(new ServiceDisplayRow(
                    service == null ? "Dịch vụ #" + usage.getDichVuId() : service.getTenDichVu(),
                    usage.getSoLuong(),
                    usage.getDonGia(),
                    lineTotal
            ));
        }

        BigDecimal beforeDiscount = roomTotal.add(serviceTotal).add(surcharge);
        if (discount.compareTo(beforeDiscount) > 0) {
            throw new IllegalArgumentException("Giảm giá không được lớn hơn tổng tiền trước giảm giá.");
        }
        BigDecimal total = beforeDiscount.subtract(discount);
        if (total.compareTo(BigDecimal.ZERO) < 0) {
            total = BigDecimal.ZERO;
        }

        Optional<HoaDon> existingInvoice = hoaDonDAO.findByBookingId(booking.getId());
        BigDecimal paid = existingInvoice.isPresent()
                ? hoaDonDAO.getPaidAmount(existingInvoice.get().getId())
                : BigDecimal.ZERO;

        KhachHang customer = getCustomer(booking.getKhachHangId());
        return new CheckoutCalculation(
                booking,
                customer,
                roomNumbers,
                checkIn,
                checkoutTime,
                billableDays,
                roomTotal,
                serviceTotal,
                surcharge,
                discount,
                total,
                nonNull(booking.getTienCoc()),
                existingInvoice.orElse(null),
                paid,
                serviceRows
        );
    }

    private int calculateBillableDays(LocalDateTime checkIn, LocalDateTime checkout) {
        LocalDate checkInDate = checkIn.toLocalDate();
        LocalDate checkoutDate = checkout.toLocalDate();
        long days = ChronoUnit.DAYS.between(checkInDate, checkoutDate);
        return (int) Math.max(1L, days);
    }

    private void displayCalculation(CheckoutCalculation calculation) {
        lblMaBooking.setText(calculation.booking.getMaDatPhong());
        lblKhachHang.setText(calculation.customer == null
                ? "Khách hàng #" + calculation.booking.getKhachHangId()
                : calculation.customer.getMaKhachHang() + " - " + calculation.customer.getHoTen());
        lblSoPhong.setText(String.join(", ", calculation.roomNumbers));

        LoaiPhong selectedType = selectedRow == null ? null : selectedRow.roomType;
        lblLoaiPhong.setText(selectedType == null ? "-" : selectedType.getTenLoaiPhong());
        lblThoiGianNhan.setText(formatDateTime(calculation.checkIn));
        lblThoiGianTra.setText(formatDateTime(calculation.checkoutTime));
        lblSoNgay.setText(String.valueOf(calculation.billableDays));
        lblTienCoc.setText(formatMoney(calculation.deposit));
        lblTienPhong.setText(formatMoney(calculation.roomTotal));
        lblTienDichVu.setText(formatMoney(calculation.serviceTotal));
        lblTongThanhToan.setText(formatMoney(calculation.total));
        lblDaThanhToan.setText(formatMoney(calculation.paidAmount));

        if (calculation.existingInvoice == null) {
            lblHoaDonHienTai.setText("Chưa lập hóa đơn");
        } else {
            lblHoaDonHienTai.setText(
                    calculation.existingInvoice.getMaHoaDon()
                            + " - " + calculation.existingInvoice.getTrangThai()
            );
        }

        serviceTableModel.setRowCount(0);
        for (ServiceDisplayRow row : calculation.services) {
            serviceTableModel.addRow(new Object[]{
                    row.serviceName,
                    formatQuantity(row.quantity),
                    formatMoney(row.unitPrice),
                    formatMoney(row.lineTotal)
            });
        }

        ButtonUtils.applyEnabledState(btnInHoaDon, true);
        ButtonUtils.applyEnabledState(btnThanhToan, paymentPermission);
    }

    private void checkoutAndPay() {
        if (!paymentPermission) {
            showWarning("Tài khoản hiện tại không có quyền thanh toán và trả phòng.");
            return;
        }
        if (selectedRow == null) {
            showWarning("Vui lòng chọn một phòng đang có khách cần trả phòng.");
            return;
        }
        if (busy) {
            return;
        }

        BigDecimal surcharge;
        BigDecimal discount;
        try {
            surcharge = parseMoney(txtPhuThu, "Phụ thu");
            discount = parseMoney(txtGiamGia, "Giảm giá");
        } catch (IllegalArgumentException exception) {
            showWarning(exception.getMessage());
            return;
        }

        PhuongThucThanhToan paymentMethod =
                (PhuongThucThanhToan) cboPhuongThucThanhToan.getSelectedItem();
        if (paymentMethod == null) {
            showWarning("Vui lòng chọn phương thức thanh toán.");
            return;
        }

        String referenceCode = txtMaThamChieu.getText().trim();
        if (paymentMethod != PhuongThucThanhToan.TIEN_MAT && referenceCode.isBlank()) {
            showWarning("Vui lòng nhập mã tham chiếu/giao dịch cho phương thức thanh toán đã chọn.");
            txtMaThamChieu.requestFocusInWindow();
            return;
        }
        if (referenceCode.length() > 100) {
            showWarning("Mã tham chiếu không được dài quá 100 ký tự.");
            txtMaThamChieu.requestFocusInWindow();
            return;
        }

        String note = txtGhiChu.getText().trim();
        if (note.length() > 500) {
            showWarning("Ghi chú không được dài quá 500 ký tự.");
            txtGhiChu.requestFocusInWindow();
            return;
        }

        if (currentCalculation == null
                || currentCalculation.booking.getId() == null
                || !currentCalculation.booking.getId().equals(selectedRow.booking.getId())) {
            showWarning("Chi phí chưa được tính. Vui lòng bấm Tính lại trước khi thanh toán.");
            return;
        }

        if (!isCalculationStillCurrent(surcharge, discount)) {
            return;
        }

        BigDecimal beforeDiscount = currentCalculation.roomTotal
                .add(currentCalculation.serviceTotal)
                .add(surcharge);
        BigDecimal previewTotal = beforeDiscount.subtract(discount).max(BigDecimal.ZERO);
        String confirmMessage = "XÁC NHẬN THANH TOÁN & CHECK-OUT\n\n"
                + "Booking: " + selectedRow.booking.getMaDatPhong() + "\n"
                + "Phòng: " + String.join(", ", currentCalculation.roomNumbers) + "\n"
                + "Khách hàng: " + (currentCalculation.customer == null
                ? "-" : currentCalculation.customer.getHoTen()) + "\n"
                + "Số ngày/đêm: " + currentCalculation.billableDays + "\n"
                + "Tiền phòng: " + formatMoney(currentCalculation.roomTotal) + "\n"
                + "Tiền dịch vụ: " + formatMoney(currentCalculation.serviceTotal) + "\n"
                + "Phụ thu: " + formatMoney(surcharge) + "\n"
                + "Giảm giá: " + formatMoney(discount) + "\n"
                + "TỔNG: " + formatMoney(previewTotal) + "\n\n"
                + "Sau khi thành công, booking sẽ chuyển sang Đã trả phòng và phòng chuyển sang Đang dọn dẹp.\n"
                + "Bạn có chắc chắn muốn tiếp tục?";

        int answer = JOptionPane.showConfirmDialog(
                this,
                confirmMessage,
                "Xác nhận thanh toán",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (answer != JOptionPane.YES_OPTION) {
            return;
        }

        int bookingId = selectedRow.booking.getId();
        Integer employeeId = getCurrentEmployeeId();
        setBusy(true, "Đang lập hóa đơn, ghi thanh toán và trả phòng...");

        SwingWorker<HoaDonDAO.CheckoutResult, Void> worker = new SwingWorker<>() {
            @Override
            protected HoaDonDAO.CheckoutResult doInBackground() throws Exception {
                return hoaDonDAO.checkoutAndPay(
                        bookingId,
                        surcharge,
                        discount,
                        employeeId,
                        paymentMethod,
                        referenceCode,
                        note
                );
            }

            @Override
            protected void done() {
                try {
                    HoaDonDAO.CheckoutResult result = get();
                    setBusy(false, "Thanh toán và checkout thành công.");

                    JOptionPane.showMessageDialog(
                            HoaDonView.this,
                            "Thanh toán thành công!\n\n"
                                    + "Hóa đơn: " + result.getInvoice().getMaHoaDon() + "\n"
                                    + "Tổng tiền: " + formatMoney(result.getInvoiceTotal()) + "\n"
                                    + "Đã thu lần này: " + formatMoney(result.getPaidNow()) + "\n"
                                    + "Booking đã chuyển sang Đã trả phòng.\n"
                                    + "Phòng " + String.join(", ", result.getRoomNumbers())
                                    + " đã chuyển sang Đang dọn dẹp.",
                            "Hoàn tất trả phòng",
                            JOptionPane.INFORMATION_MESSAGE
                    );

                                        showInvoiceDialog(
                            buildInvoiceText(result, currentCalculation)
                    );

                    txtTimKiem.setText("");

                    clearSelectionDetails();

                    lastCalculatedSurcharge = BigDecimal.ZERO;
                    lastCalculatedDiscount = BigDecimal.ZERO;

                    loadOccupiedRooms("");

                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    setBusy(false, "Thanh toán bị gián đoạn.");
                } catch (ExecutionException exception) {
                    setBusy(false, "Thanh toán thất bại.");
                    showDatabaseError(
                            "Không thể hoàn tất thanh toán/trả phòng. Mọi thay đổi đã được rollback nếu transaction thất bại.",
                            exception.getCause()
                    );
                }
            }
        };
        worker.execute();
    }

    private boolean isCalculationStillCurrent(
            BigDecimal surcharge,
            BigDecimal discount) {

        if (currentCalculation == null || selectedRow == null
                || currentCalculation.booking.getId() == null
                || selectedRow.booking.getId() == null
                || !currentCalculation.booking.getId().equals(selectedRow.booking.getId())) {
            showWarning("Chi phí chưa được tính cho booking đang chọn. Vui lòng bấm Tính lại.");
            return false;
        }

        if (surcharge.compareTo(lastCalculatedSurcharge) != 0
                || discount.compareTo(lastCalculatedDiscount) != 0) {
            showWarning(
                    "Phụ thu hoặc giảm giá đã thay đổi sau lần tính tiền.\n"
                            + "Vui lòng bấm \"Tính lại\" trước khi tiếp tục."
            );
            return false;
        }

        BigDecimal beforeDiscount = currentCalculation.roomTotal
                .add(currentCalculation.serviceTotal)
                .add(surcharge);
        if (discount.compareTo(beforeDiscount) > 0) {
            showWarning("Giảm giá không được lớn hơn tổng tiền trước giảm giá.");
            return false;
        }

        return true;
    }

    private void printInvoicePreview() {
        if (selectedRow == null || currentCalculation == null) {
            showWarning("Vui lòng chọn phòng và tính chi phí trước khi in hóa đơn.");
            return;
        }

        BigDecimal surcharge;
        BigDecimal discount;
        try {
            surcharge = parseMoney(txtPhuThu, "Phụ thu");
            discount = parseMoney(txtGiamGia, "Giảm giá");
        } catch (IllegalArgumentException exception) {
            showWarning(exception.getMessage());
            return;
        }

        if (!isCalculationStillCurrent(surcharge, discount)) {
            return;
        }

        BigDecimal total = currentCalculation.roomTotal
                .add(currentCalculation.serviceTotal)
                .add(surcharge)
                .subtract(discount)
                .max(BigDecimal.ZERO);

        CheckoutCalculation preview = currentCalculation.withMoney(surcharge, discount, total);
        showInvoiceDialog(buildPreviewInvoiceText(preview));
    }

    private String buildPreviewInvoiceText(CheckoutCalculation calculation) {
        StringBuilder builder = new StringBuilder();
        appendInvoiceHeader(builder, "HÓA ĐƠN TẠM TÍNH");
        builder.append("Mã hóa đơn      : ")
                .append(calculation.existingInvoice == null
                        ? "CHƯA LƯU" : calculation.existingInvoice.getMaHoaDon())
                .append('\n');
        appendCommonInvoiceInformation(builder, calculation);
        appendMoneySummary(
                builder,
                calculation.roomTotal,
                calculation.serviceTotal,
                calculation.surcharge,
                calculation.discount,
                calculation.total
        );
        builder.append("\nTrạng thái       : TẠM TÍNH - CHƯA CHECK-OUT\n");
        builder.append("\nLưu ý: Số tiền được tính lại từ CSDL khi bấm Thanh toán & Check-out.\n");
        appendInvoiceFooter(builder);
        return builder.toString();
    }

    private String buildInvoiceText(
            HoaDonDAO.CheckoutResult result,
            CheckoutCalculation previousCalculation) {

        StringBuilder builder = new StringBuilder();
        appendInvoiceHeader(builder, "HÓA ĐƠN THANH TOÁN");
        builder.append("Mã hóa đơn      : ").append(result.getInvoice().getMaHoaDon()).append('\n');
        builder.append("Mã thanh toán   : ")
                .append(result.getPaymentCode() == null ? "Không phát sinh thêm" : result.getPaymentCode())
                .append('\n');
        builder.append("Mã booking      : ").append(result.getBookingCode()).append('\n');

        if (previousCalculation != null) {
            builder.append("Khách hàng      : ")
                    .append(previousCalculation.customer == null
                            ? "-"
                            : previousCalculation.customer.getMaKhachHang()
                            + " - " + previousCalculation.customer.getHoTen())
                    .append('\n');
            if (previousCalculation.customer != null) {
                builder.append("Giấy tờ         : ")
                        .append(previousCalculation.customer.getLoaiGiayTo())
                        .append(" - ")
                        .append(safe(previousCalculation.customer.getSoGiayTo()))
                        .append('\n');
                builder.append("Điện thoại      : ")
                        .append(safe(previousCalculation.customer.getSoDienThoai()))
                        .append('\n');
            }
            builder.append("Check-in        : ")
                    .append(formatDateTime(previousCalculation.checkIn)).append('\n');
        }

        builder.append("Check-out       : ").append(formatDateTime(result.getCheckoutTime())).append('\n');
        builder.append("Phòng           : ").append(String.join(", ", result.getRoomNumbers())).append('\n');
        builder.append("Số ngày/đêm     : ").append(result.getBillableDays()).append('\n');
        builder.append(SEPARATOR).append('\n');

        if (previousCalculation != null) {
            appendServiceDetails(builder, previousCalculation.services);
        }

        appendMoneySummary(
                builder,
                result.getRoomTotal(),
                result.getServiceTotal(),
                result.getSurcharge(),
                result.getDiscount(),
                result.getInvoiceTotal()
        );
        builder.append(String.format("%-19s %18s%n", "Đã thanh toán trước:", formatMoneyPlain(result.getPaidBefore())));
        builder.append(String.format("%-19s %18s%n", "Thu lần này:", formatMoneyPlain(result.getPaidNow())));
        builder.append("Phương thức      : ").append(cboPhuongThucThanhToan.getSelectedItem()).append('\n');
        if (!txtMaThamChieu.getText().trim().isBlank()) {
            builder.append("Mã tham chiếu    : ").append(txtMaThamChieu.getText().trim()).append('\n');
        }
        builder.append("Trạng thái       : ĐÃ THANH TOÁN - ĐÃ TRẢ PHÒNG\n");
        builder.append("Nhân viên        : ").append(getCurrentEmployeeName()).append('\n');
        appendInvoiceFooter(builder);
        return builder.toString();
    }

    private static final String SEPARATOR =
            "--------------------------------------------------------------------------";

    private void appendInvoiceHeader(StringBuilder builder, String title) {
        builder.append("                         HOTEL MANAGEMENT\n");
        builder.append("                 HỆ THỐNG QUẢN LÝ KHÁCH SẠN\n");
        builder.append(SEPARATOR).append('\n');
        builder.append("                         ").append(title).append('\n');
        builder.append(SEPARATOR).append('\n');
    }

    private void appendCommonInvoiceInformation(StringBuilder builder, CheckoutCalculation calculation) {
        builder.append("Mã booking      : ").append(calculation.booking.getMaDatPhong()).append('\n');
        builder.append("Khách hàng      : ")
                .append(calculation.customer == null
                        ? "-"
                        : calculation.customer.getMaKhachHang() + " - " + calculation.customer.getHoTen())
                .append('\n');
        if (calculation.customer != null) {
            builder.append("Giấy tờ         : ")
                    .append(calculation.customer.getLoaiGiayTo()).append(" - ")
                    .append(safe(calculation.customer.getSoGiayTo())).append('\n');
            builder.append("Điện thoại      : ")
                    .append(safe(calculation.customer.getSoDienThoai())).append('\n');
        }
        builder.append("Phòng           : ").append(String.join(", ", calculation.roomNumbers)).append('\n');
        builder.append("Check-in        : ").append(formatDateTime(calculation.checkIn)).append('\n');
        builder.append("Thời điểm tính  : ").append(formatDateTime(calculation.checkoutTime)).append('\n');
        builder.append("Số ngày/đêm     : ").append(calculation.billableDays).append('\n');
        builder.append("Tiền cọc booking: ").append(formatMoneyPlain(calculation.deposit)).append('\n');
        builder.append(SEPARATOR).append('\n');
        appendServiceDetails(builder, calculation.services);
    }

    private void appendServiceDetails(StringBuilder builder, List<ServiceDisplayRow> services) {
        builder.append("DỊCH VỤ PHÁT SINH\n");
        if (services == null || services.isEmpty()) {
            builder.append("  Không phát sinh dịch vụ.\n");
        } else {
            for (ServiceDisplayRow service : services) {
                builder.append("  - ")
                        .append(service.serviceName)
                        .append(" | SL: ")
                        .append(formatQuantity(service.quantity))
                        .append(" | Đơn giá: ")
                        .append(formatMoneyPlain(service.unitPrice))
                        .append(" | Thành tiền: ")
                        .append(formatMoneyPlain(service.lineTotal))
                        .append('\n');
            }
        }
        builder.append(SEPARATOR).append('\n');
    }

    private void appendMoneySummary(
            StringBuilder builder,
            BigDecimal roomTotal,
            BigDecimal serviceTotal,
            BigDecimal surcharge,
            BigDecimal discount,
            BigDecimal total) {

        builder.append(String.format("%-19s %18s%n", "Tiền phòng:", formatMoneyPlain(roomTotal)));
        builder.append(String.format("%-19s %18s%n", "Tiền dịch vụ:", formatMoneyPlain(serviceTotal)));
        builder.append(String.format("%-19s %18s%n", "Phụ thu:", formatMoneyPlain(surcharge)));
        builder.append(String.format("%-19s %18s%n", "Giảm giá:", formatMoneyPlain(discount)));
        builder.append(SEPARATOR).append('\n');
        builder.append(String.format("%-19s %18s%n", "TỔNG THANH TOÁN:", formatMoneyPlain(total)));
        builder.append(SEPARATOR).append('\n');
    }

    private void appendInvoiceFooter(StringBuilder builder) {
        builder.append("\nCảm ơn Quý khách đã sử dụng dịch vụ của khách sạn!\n");
        builder.append("Thời gian in: ").append(formatDateTime(LocalDateTime.now())).append('\n');
    }

    private void showInvoiceDialog(String invoiceText) {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        JDialog dialog = new JDialog(owner, "Hóa đơn", true);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setLayout(new BorderLayout(0, 12));

        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(PRIMARY_COLOR);
        titlePanel.setBorder(new EmptyBorder(14, 18, 14, 18));
        JLabel title = new JLabel("XEM & IN HÓA ĐƠN");
        title.setForeground(Color.WHITE);
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        titlePanel.add(title, BorderLayout.WEST);

        JTextArea invoiceArea = new JTextArea(invoiceText, 32, 82);
        invoiceArea.setEditable(false);
        invoiceArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        invoiceArea.setBackground(Color.WHITE);
        invoiceArea.setForeground(new Color(25, 30, 38));
        invoiceArea.setMargin(new Insets(16, 18, 16, 18));
        invoiceArea.setCaretPosition(0);

        JScrollPane scrollPane = new JScrollPane(invoiceArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));

        JButton btnPrint = new JButton("In bằng máy in");
        JButton btnClose = new JButton("Đóng");
        ButtonUtils.primary(btnPrint);
        ButtonUtils.neutral(btnClose);

        btnPrint.addActionListener(event -> {
            try {
                boolean completed = invoiceArea.print(
                        new MessageFormat("HÓA ĐƠN KHÁCH SẠN"),
                        new MessageFormat("Trang {0}")
                );
                if (completed) {
                    JOptionPane.showMessageDialog(
                            dialog,
                            "Đã gửi hóa đơn tới hệ thống in.",
                            "In hóa đơn",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }
            } catch (PrinterException exception) {
                JOptionPane.showMessageDialog(
                        dialog,
                        "Không thể in hóa đơn.\nChi tiết: " + exception.getMessage(),
                        "Lỗi in hóa đơn",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });
        btnClose.addActionListener(event -> dialog.dispose());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        buttonPanel.add(btnPrint);
        buttonPanel.add(btnClose);

        dialog.add(titlePanel, BorderLayout.NORTH);
        dialog.add(scrollPane, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setMinimumSize(new Dimension(760, 650));
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void clearSelectionDetails() {
        selectedRow = null;
        currentCalculation = null;
        tblPhongDangO.clearSelection();

        lblMaBooking.setText("-");
        lblKhachHang.setText("-");
        lblSoPhong.setText("-");
        lblLoaiPhong.setText("-");
        lblThoiGianNhan.setText("-");
        lblThoiGianTra.setText("-");
        lblSoNgay.setText("0");
        lblTienCoc.setText("0 VNĐ");
        lblTienPhong.setText("0 VNĐ");
        lblTienDichVu.setText("0 VNĐ");
        lblTongThanhToan.setText("0 VNĐ");
        lblHoaDonHienTai.setText("Chưa lập hóa đơn");
        lblDaThanhToan.setText("0 VNĐ");
        serviceTableModel.setRowCount(0);
        txtPhuThu.setText("0");
        txtGiamGia.setText("0");
        txtMaThamChieu.setText("");
        txtGhiChu.setText("");
        lastCalculatedSurcharge = BigDecimal.ZERO;
        lastCalculatedDiscount = BigDecimal.ZERO;
        updateReferenceFieldState();
        ButtonUtils.applyEnabledState(btnInHoaDon, false);
        ButtonUtils.applyEnabledState(btnThanhToan, false);
    }

    private BigDecimal parseMoney(JTextField field, String fieldName) {
        String text = field.getText() == null ? "" : field.getText().trim();
        if (text.isBlank()) {
            return BigDecimal.ZERO;
        }

        String normalized = text.replace(" ", "")
                .replace(".", "")
                .replace(",", "");

        if (!normalized.matches("\\d+")) {
            throw new IllegalArgumentException(fieldName + " phải là số tiền hợp lệ, ví dụ 100000 hoặc 100.000.");
        }

        try {
            BigDecimal value = new BigDecimal(normalized);
            if (value.compareTo(BigDecimal.ZERO) < 0) {
                throw new IllegalArgumentException(fieldName + " không được âm.");
            }
            return value;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(fieldName + " vượt quá giới hạn số hợp lệ.");
        }
    }

    private void updateReferenceFieldState() {
        PhuongThucThanhToan method =
                (PhuongThucThanhToan) cboPhuongThucThanhToan.getSelectedItem();
        boolean cash = method == null || method == PhuongThucThanhToan.TIEN_MAT;
        txtMaThamChieu.setEnabled(!cash);
        if (cash) {
            txtMaThamChieu.setText("");
            txtMaThamChieu.setBackground(new Color(246, 248, 251));
        } else {
            txtMaThamChieu.setBackground(Color.WHITE);
        }
    }

    private Integer getCurrentEmployeeId() {
        if (loginSession == null || loginSession.getTaiKhoan() == null) {
            return null;
        }
        return loginSession.getTaiKhoan().getId();
    }

    private String getCurrentEmployeeName() {
        if (loginSession == null || loginSession.getTaiKhoan() == null) {
            return "Không xác định";
        }
        return loginSession.getTaiKhoan().getHoTen();
    }

    private KhachHang getCustomer(Integer customerId) throws SQLException {
        if (customerId == null) {
            return null;
        }
        KhachHang cached = customerCache.get(customerId);
        if (cached != null) {
            return cached;
        }
        KhachHang customer = khachHangDAO.findById(customerId).orElse(null);
        if (customer != null) {
            customerCache.put(customerId, customer);
        }
        return customer;
    }

    private Phong getRoom(Integer roomId) throws SQLException {
        if (roomId == null) {
            return null;
        }
        Phong cached = roomCache.get(roomId);
        if (cached != null) {
            return cached;
        }
        Phong room = phongDAO.findById(roomId).orElse(null);
        if (room != null) {
            roomCache.put(roomId, room);
        }
        return room;
    }

    private LoaiPhong getRoomType(Integer roomTypeId) throws SQLException {
        if (roomTypeId == null) {
            return null;
        }
        LoaiPhong cached = roomTypeCache.get(roomTypeId);
        if (cached != null) {
            return cached;
        }
        LoaiPhong roomType = loaiPhongDAO.findById(roomTypeId).orElse(null);
        if (roomType != null) {
            roomTypeCache.put(roomTypeId, roomType);
        }
        return roomType;
    }

    private DichVu getService(Integer serviceId) throws SQLException {
        if (serviceId == null) {
            return null;
        }
        DichVu cached = serviceCache.get(serviceId);
        if (cached != null) {
            return cached;
        }
        DichVu service = dichVuDAO.findById(serviceId).orElse(null);
        if (service != null) {
            serviceCache.put(serviceId, service);
        }
        return service;
    }

    private void setBusy(boolean busy, String message) {
        this.busy = busy;
        setCursor(busy
                ? Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR)
                : Cursor.getDefaultCursor());

        ButtonUtils.applyEnabledState(btnTaiLai, !busy);
        ButtonUtils.applyEnabledState(btnTimKiem, !busy);
        txtTimKiem.setEnabled(!busy);
        ButtonUtils.applyEnabledState(btnTinhLai, !busy && selectedRow != null);
        ButtonUtils.applyEnabledState(btnInHoaDon, !busy && currentCalculation != null);
        ButtonUtils.applyEnabledState(
                btnThanhToan,
                !busy && paymentPermission && currentCalculation != null
        );
        lblTrangThai.setText(message);
    }

    private void showDatabaseError(String message, Throwable cause) {
        String detail;
        if (cause instanceof SQLException sqlException) {
            detail = sqlException.getMessage();
        } else if (cause instanceof IllegalArgumentException illegalArgumentException) {
            detail = illegalArgumentException.getMessage();
        } else if (cause == null) {
            detail = "Không xác định";
        } else {
            detail = cause.getMessage() == null ? cause.getClass().getSimpleName() : cause.getMessage();
        }

        JOptionPane.showMessageDialog(
                this,
                message + "\n\nChi tiết: " + detail,
                "Lỗi xử lý dữ liệu",
                JOptionPane.ERROR_MESSAGE
        );
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Kiểm tra dữ liệu",
                JOptionPane.WARNING_MESSAGE
        );
    }

    private JPanel createCardPanel(java.awt.LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(CARD_COLOR);
        return panel;
    }

    private static JLabel createValueLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(TEXT_COLOR);
        label.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        return label;
    }

    private static JLabel createMoneyValueLabel() {
        JLabel label = createValueLabel("0 VNĐ");
        label.setForeground(PRIMARY_COLOR);
        return label;
    }

    private static JLabel createTotalValueLabel() {
        JLabel label = createValueLabel("0 VNĐ");
        label.setForeground(SUCCESS_COLOR);
        label.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        return label;
    }

    private JLabel createFieldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(SECONDARY_TEXT_COLOR);
        label.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        return label;
    }

    private GridBagConstraints createGridConstraints() {
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(4, 4, 4, 8);
        constraints.anchor = GridBagConstraints.WEST;
        return constraints;
    }

    private void addInformationRow(
            JPanel panel,
            GridBagConstraints constraints,
            int row,
            String title,
            JLabel value) {

        constraints.gridx = 0;
        constraints.gridy = row;
        constraints.weightx = 0;
        constraints.weighty = 0;
        constraints.fill = GridBagConstraints.NONE;
        panel.add(createFieldLabel(title), constraints);

        constraints.gridx = 1;
        constraints.weightx = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        panel.add(value, constraints);
    }

    private void addInputRow(
            JPanel panel,
            GridBagConstraints constraints,
            int row,
            String title,
            Component input) {

        constraints.gridx = 0;
        constraints.gridy = row;
        constraints.weightx = 0;
        constraints.weighty = 0;
        constraints.fill = GridBagConstraints.NONE;
        panel.add(createFieldLabel(title), constraints);

        constraints.gridx = 1;
        constraints.weightx = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        panel.add(input, constraints);
    }

    private void configureMoneyColumn(JTable table, int columnIndex) {
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(SwingConstants.RIGHT);
        table.getColumnModel().getColumn(columnIndex).setCellRenderer(renderer);
    }

    private void styleMoneyInput(JTextField field) {
        field.setHorizontalAlignment(SwingConstants.RIGHT);
        field.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        field.setBackground(INPUT_BACKGROUND);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(7, 10, 7, 10)
        ));
    }

    private String formatDateTime(LocalDateTime value) {
        return value == null ? "-" : value.format(DATE_TIME_FORMATTER);
    }

    private String formatMoney(BigDecimal value) {
        return MONEY_FORMAT.format(nonNull(value)) + " VNĐ";
    }

    private String formatMoneyPlain(BigDecimal value) {
        return MONEY_FORMAT.format(nonNull(value)) + " VNĐ";
    }

    private String formatQuantity(BigDecimal value) {
        if (value == null) {
            return "0";
        }
        return value.stripTrailingZeros().toPlainString();
    }

    private BigDecimal nonNull(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }

    private static final class OccupiedRoomRow {
        private final DatPhong booking;
        private final ChiTietDatPhong detail;
        private final Phong room;
        private final LoaiPhong roomType;
        private final KhachHang customer;

        private OccupiedRoomRow(
                DatPhong booking,
                ChiTietDatPhong detail,
                Phong room,
                LoaiPhong roomType,
                KhachHang customer) {
            this.booking = booking;
            this.detail = detail;
            this.room = room;
            this.roomType = roomType;
            this.customer = customer;
        }
    }

    private static final class ServiceDisplayRow {
        private final String serviceName;
        private final BigDecimal quantity;
        private final BigDecimal unitPrice;
        private final BigDecimal lineTotal;

        private ServiceDisplayRow(
                String serviceName,
                BigDecimal quantity,
                BigDecimal unitPrice,
                BigDecimal lineTotal) {
            this.serviceName = serviceName;
            this.quantity = quantity;
            this.unitPrice = unitPrice;
            this.lineTotal = lineTotal;
        }
    }

    private static final class CheckoutCalculation {
        private final DatPhong booking;
        private final KhachHang customer;
        private final List<String> roomNumbers;
        private final LocalDateTime checkIn;
        private final LocalDateTime checkoutTime;
        private final int billableDays;
        private final BigDecimal roomTotal;
        private final BigDecimal serviceTotal;
        private final BigDecimal surcharge;
        private final BigDecimal discount;
        private final BigDecimal total;
        private final BigDecimal deposit;
        private final HoaDon existingInvoice;
        private final BigDecimal paidAmount;
        private final List<ServiceDisplayRow> services;

        private CheckoutCalculation(
                DatPhong booking,
                KhachHang customer,
                List<String> roomNumbers,
                LocalDateTime checkIn,
                LocalDateTime checkoutTime,
                int billableDays,
                BigDecimal roomTotal,
                BigDecimal serviceTotal,
                BigDecimal surcharge,
                BigDecimal discount,
                BigDecimal total,
                BigDecimal deposit,
                HoaDon existingInvoice,
                BigDecimal paidAmount,
                List<ServiceDisplayRow> services) {
            this.booking = booking;
            this.customer = customer;
            this.roomNumbers = List.copyOf(roomNumbers);
            this.checkIn = checkIn;
            this.checkoutTime = checkoutTime;
            this.billableDays = billableDays;
            this.roomTotal = roomTotal;
            this.serviceTotal = serviceTotal;
            this.surcharge = surcharge;
            this.discount = discount;
            this.total = total;
            this.deposit = deposit;
            this.existingInvoice = existingInvoice;
            this.paidAmount = paidAmount;
            this.services = List.copyOf(services);
        }

        private CheckoutCalculation withMoney(BigDecimal newSurcharge, BigDecimal newDiscount, BigDecimal newTotal) {
            return new CheckoutCalculation(
                    booking,
                    customer,
                    roomNumbers,
                    checkIn,
                    LocalDateTime.now(),
                    billableDays,
                    roomTotal,
                    serviceTotal,
                    newSurcharge,
                    newDiscount,
                    newTotal,
                    deposit,
                    existingInvoice,
                    paidAmount,
                    services
            );
        }
    }

    /**
     * Cho phép chạy thử riêng màn hình khi đang phát triển giao diện.
     * Khi chạy trong ứng dụng thật, MainView sẽ truyền LoginSession vào constructor.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (Exception ignored) {
            }

            JFrame frame = new JFrame("Hotel Management - Trả phòng & Thanh toán");
            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            frame.setContentPane(new HoaDonView());
            frame.setMinimumSize(new Dimension(1280, 780));
            frame.setSize(1450, 880);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
