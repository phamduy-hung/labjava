-- ============================================================
-- KIỂM TRA BẢO MẬT DỮ LIỆU KHÁCH HÀNG
-- Không giải mã dữ liệu trong MySQL Workbench.
-- Khóa AES-256-GCM chỉ nằm ở lớp ứng dụng Java.
-- ============================================================
USE hotel_management_db;

SELECT
    COUNT(*) AS tong_khach,
    SUM(ho_ten LIKE 'v1:%') AS ho_ten_da_ma_hoa,
    SUM(so_giay_to LIKE 'v1:%') AS giay_to_da_ma_hoa,
    SUM(COALESCE(so_dien_thoai, '') = '' OR so_dien_thoai LIKE 'v1:%') AS dien_thoai_da_bao_ve,
    SUM(COALESCE(email, '') = '' OR email LIKE 'v1:%') AS email_da_bao_ve,
    SUM(COALESCE(dia_chi, '') = '' OR dia_chi LIKE 'v1:%') AS dia_chi_da_bao_ve
FROM khach_hang;

-- Dữ liệu dưới đây phải có dạng v1:<IV>:<ciphertext+tag>, không phải plaintext.
SELECT
    id,
    ma_khach_hang,
    LEFT(ho_ten, 36) AS ho_ten_ma_hoa,
    LEFT(so_giay_to, 36) AS giay_to_ma_hoa,
    LEFT(COALESCE(so_dien_thoai, ''), 36) AS dien_thoai_ma_hoa,
    LEFT(COALESCE(email, ''), 36) AS email_ma_hoa,
    LEFT(COALESCE(dia_chi, ''), 36) AS dia_chi_ma_hoa
FROM khach_hang
ORDER BY id
LIMIT 20;

-- Cảnh báo: nếu bất kỳ trường PII bên dưới > 0, dữ liệu seed chưa được mã hóa đầy đủ.
SELECT
    SUM(ho_ten IS NOT NULL AND ho_ten NOT LIKE 'v1:%') AS plaintext_ho_ten,
    SUM(so_giay_to IS NOT NULL AND so_giay_to NOT LIKE 'v1:%') AS plaintext_giay_to,
    SUM(so_dien_thoai IS NOT NULL AND so_dien_thoai <> '' AND so_dien_thoai NOT LIKE 'v1:%') AS plaintext_dien_thoai,
    SUM(email IS NOT NULL AND email <> '' AND email NOT LIKE 'v1:%') AS plaintext_email,
    SUM(dia_chi IS NOT NULL AND dia_chi <> '' AND dia_chi NOT LIKE 'v1:%') AS plaintext_dia_chi
FROM khach_hang;
