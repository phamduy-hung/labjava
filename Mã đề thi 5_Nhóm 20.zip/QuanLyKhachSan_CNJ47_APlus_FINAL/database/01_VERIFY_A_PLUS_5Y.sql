USE hotel_management_db;
SET NAMES utf8mb4;
-- QUY MO
SELECT 'Khach hang' chi_tieu,COUNT(*) so_luong FROM khach_hang
UNION ALL SELECT 'Booking',COUNT(*) FROM dat_phong
UNION ALL SELECT 'Chi tiet dat phong',COUNT(*) FROM chi_tiet_dat_phong
UNION ALL SELECT 'Hoa don',COUNT(*) FROM hoa_don
UNION ALL SELECT 'Thanh toan',COUNT(*) FROM thanh_toan
UNION ALL SELECT 'Dich vu phat sinh',COUNT(*) FROM su_dung_dich_vu
UNION ALL SELECT 'Nhiem vu buong phong',COUNT(*) FROM nhiem_vu_buong_phong
UNION ALL SELECT 'Nhat ky he thong',COUNT(*) FROM nhat_ky_he_thong;

-- BOOKING THEO NAM
SELECT YEAR(ngay_du_kien_nhan) nam,COUNT(*) so_booking,ROUND(AVG(DATEDIFF(ngay_du_kien_tra,ngay_du_kien_nhan)),1) ngay_luu_tru_tb
FROM dat_phong WHERE ma_dat_phong LIKE 'DP%' GROUP BY YEAR(ngay_du_kien_nhan) ORDER BY nam;

-- TRANG THAI BOOKING
SELECT trang_thai,COUNT(*) so_luong FROM dat_phong GROUP BY trang_thai ORDER BY so_luong DESC;

-- TRANG THAI PHONG HIEN TAI
SELECT so_phong,trang_thai,ghi_chu FROM phong WHERE dang_hoat_dong=TRUE ORDER BY tang,so_phong;

-- DOANH THU THEO THANG: phai co nhieu thang co doanh thu, khong phai 1 cot don le.
SELECT DATE_FORMAT(thoi_gian_lap,'%Y-%m') thang,COUNT(*) so_hoa_don,ROUND(SUM(tong_thanh_toan),0) doanh_thu
FROM hoa_don WHERE trang_thai='DA_THANH_TOAN' GROUP BY DATE_FORMAT(thoi_gian_lap,'%Y-%m') ORDER BY thang;

-- CONG NO
SELECT hd.ma_hoa_don,hd.trang_thai,hd.tong_thanh_toan,COALESCE(SUM(tt.so_tien),0) da_thu,(hd.tong_thanh_toan-COALESCE(SUM(tt.so_tien),0)) con_no
FROM hoa_don hd LEFT JOIN thanh_toan tt ON tt.hoa_don_id=hd.id
WHERE hd.trang_thai IN ('CHUA_THANH_TOAN','THANH_TOAN_MOT_PHAN')
GROUP BY hd.id,hd.ma_hoa_don,hd.trang_thai,hd.tong_thanh_toan ORDER BY con_no DESC LIMIT 20;

-- KHACH QUAY LAI
SELECT kh.ma_khach_hang,kh.ho_ten,COUNT(dp.id) so_lan_luu_tru
FROM khach_hang kh JOIN dat_phong dp ON dp.khach_hang_id=kh.id
GROUP BY kh.id,kh.ma_khach_hang,kh.ho_ten HAVING COUNT(dp.id)>=3 ORDER BY so_lan_luu_tru DESC LIMIT 20;

-- STAFF TURNOVER
SELECT ten_dang_nhap,ho_ten,dang_hoat_dong,ngay_tao FROM tai_khoan ORDER BY ngay_tao,id;

-- LOI TOAN VEN: 0 la tot.
SELECT COUNT(*) loi_booking_khong_khach FROM dat_phong dp LEFT JOIN khach_hang kh ON kh.id=dp.khach_hang_id WHERE kh.id IS NULL;
SELECT COUNT(*) loi_booking_khong_phong FROM dat_phong dp LEFT JOIN chi_tiet_dat_phong ct ON ct.dat_phong_id=dp.id WHERE ct.id IS NULL;
SELECT COUNT(*) loi_thanh_toan_vuot FROM (SELECT hd.id FROM hoa_don hd LEFT JOIN thanh_toan tt ON tt.hoa_don_id=hd.id GROUP BY hd.id,hd.tong_thanh_toan HAVING COALESCE(SUM(tt.so_tien),0)>hd.tong_thanh_toan) x;
