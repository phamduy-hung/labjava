# CHẠY DỮ LIỆU A+ – KHÁCH SẠN ĐÃ VẬN HÀNH 5 NĂM

## CHỈ CẦN CHẠY 1 FILE
Mở MySQL Workbench → chọn schema `hotel_management_db` → mở `00_A_PLUS_5Y_RESET_AND_SEED.sql` → Execute toàn bộ.

Sau đó chạy `01_VERIFY_A_PLUS_5Y.sql` để kiểm tra.

**Không chạy các seed cũ.** Bản FINAL chỉ giữ đúng dataset này để tránh nạp nhầm dữ liệu demo cũ.

## KẾT QUẢ MONG ĐỢI
- 800 hồ sơ khách hàng.
- Khoảng 4.000 booking lịch sử từ 2021 đến 09/2026.
- Booking tăng theo các năm, có mùa vụ và thay đổi giá.
- Có khách quay lại nhiều lần, khách doanh nghiệp, gia đình, khách quốc tế.
- Có hủy và no-show.
- Có hóa đơn đã thanh toán, thanh toán một phần và còn nợ.
- Có nhiều phương thức thanh toán.
- Có dịch vụ phát sinh không đồng đều.
- Có hàng nghìn nhiệm vụ buồng phòng và lịch sử bảo trì.
- Có nhân sự cũ đã nghỉ và nhân sự hiện tại.
- Có hàng nghìn nhật ký nghiệp vụ.

## SNAPSHOT 08/10/2026
- 5 phòng đang ở.
- 1 phòng đã đặt, khách đến 14:00.
- 1 phòng đang dọn.
- 1 phòng bảo trì.
- 1 phòng trống.
- Có khách checkout hôm nay.
- Có khách check-in hôm nay.
- Có folio chưa thanh toán và thanh toán một phần.
- Có doanh thu đã thu trong tháng 10/2026.

## NẾU CHẠY XONG MÀ VẪN THẤY 5 KHÁCH / 6 BOOKING / 0 VNĐ
Kiểm tra NetBeans và MySQL Workbench có dùng cùng schema/server:

```sql
SELECT DATABASE(), @@hostname, @@port;
SELECT COUNT(*) AS so_khach FROM hotel_management_db.khach_hang;
SELECT COUNT(*) AS so_booking FROM hotel_management_db.dat_phong;
```

Nếu hai câu đếm không trả về khoảng 800 khách và hơn 4.000 booking, file seed chưa được thực thi trên đúng CSDL mà ứng dụng đang kết nối.

## BẢO MẬT DỮ LIỆU KHÁCH HÀNG

Sau khi nạp dữ liệu, ứng dụng Java tự động bảo vệ PII bằng **AES-256-GCM**. Các trường họ tên, CCCD/Hộ chiếu, điện thoại, email và địa chỉ được lưu dạng ciphertext trong MySQL. Chạy `02_KIEM_TRA_BAO_MAT_KHACH_HANG.sql` để kiểm tra.

Khóa demo nằm trong `src/main/resources/database.properties`; khi triển khai thật nên dùng biến môi trường `HOTEL_CUSTOMER_ENCRYPTION_KEY`.
