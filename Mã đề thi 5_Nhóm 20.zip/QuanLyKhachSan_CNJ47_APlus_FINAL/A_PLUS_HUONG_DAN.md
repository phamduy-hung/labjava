# HOTEL MANAGEMENT – A+ FINAL DATASET

## Mục tiêu
Bản này giữ nguyên kiến trúc Java Swing/JDBC/MySQL của đồ án và thay dữ liệu demo bằng một dataset mô phỏng khách sạn boutique 9 phòng đã vận hành từ 2021 đến 08/10/2026.

## Chạy dữ liệu – chỉ dùng 1 file
Mở MySQL Workbench → database → mở `00_A_PLUS_5Y_RESET_AND_SEED.sql` → Execute toàn bộ.
Sau đó chạy `01_VERIFY_A_PLUS_5Y.sql`.

**Không chạy các file seed cũ. Bản FINAL đã loại bỏ chúng để tránh nạp nhầm dataset.**

## Snapshot ngày 08/10/2026
- 5 phòng đang ở
- 1 phòng đã đặt, khách đến 14:00
- 1 phòng đang dọn
- 1 phòng bảo trì
- 1 phòng trống
- Có khách checkout trong ngày
- Có khách check-in trong ngày
- Có folio chưa thanh toán và thanh toán một phần
- Có doanh thu đã thu trong tháng 10

## Lịch sử
- Khách hàng: 800 hồ sơ
- Booking: khoảng 4.000+ hồ sơ, trải dài 2021–09/2026
- Có khách quay lại, khách doanh nghiệp, khách gia đình, khách quốc tế
- Có hủy và no-show
- Hóa đơn + thanh toán + dịch vụ phát sinh
- Housekeeping + bảo trì nhiều năm
- Nhân sự có lịch sử nghỉ việc và nhân sự hiện tại
- Audit log trải dài theo nghiệp vụ và ca trực

## Tài khoản
- admin / mật khẩu hiện có của CSDL
- letan1 / mật khẩu hiện có của CSDL
- buongphong1 / mật khẩu hiện có của CSDL
- ketoan1 / mật khẩu hiện có của CSDL

## Lưu ý
File seed xóa dữ liệu nghiệp vụ hiện có trong các bảng booking/khách hàng/hóa đơn/thanh toán/dịch vụ phát sinh/buồng phòng/nhật ký để tạo dataset đồng nhất. Không xóa vai trò và tài khoản.
