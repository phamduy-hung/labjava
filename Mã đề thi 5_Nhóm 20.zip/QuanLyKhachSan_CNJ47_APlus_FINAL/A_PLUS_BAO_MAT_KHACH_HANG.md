# Bảo mật dữ liệu khách hàng – A+

## Thiết kế

Các trường dữ liệu cá nhân quan trọng của khách hàng được bảo vệ ở lớp ứng dụng:

- Họ tên
- Số CCCD/Hộ chiếu
- Số điện thoại
- Email
- Địa chỉ

Thuật toán: **AES-256-GCM** với IV ngẫu nhiên cho từng giá trị.

Dữ liệu lưu trong MySQL có dạng:

`v1:<IV>:<ciphertext+authentication-tag>`

Khóa mã hóa **không lưu trong MySQL**. Ứng dụng Java lấy khóa theo thứ tự ưu tiên:

1. System property `customer.encryption.key`.
2. Environment variable `HOTEL_CUSTOMER_ENCRYPTION_KEY`.
3. `customer.encryption.key` trong `database.properties` (phương án demo/local).

## Vì sao tìm kiếm vẫn hoạt động?

AES-GCM dùng IV ngẫu nhiên nên không thể dùng `LIKE` trực tiếp trên ciphertext. Vì vậy `KhachHangDAO` đọc dữ liệu cần thiết, giải mã trong JVM và thực hiện tìm kiếm trong bộ nhớ. Với quy mô 800 hồ sơ của đồ án, cách này đủ nhanh và không làm lộ plaintext trong CSDL.

Các màn hình Đặt phòng và Hóa đơn tìm theo khách hàng thông qua ID khách hàng đã tìm được bởi `KhachHangDAO`, nên không cần lưu thêm bản plaintext.

## Tự động chuyển đổi dữ liệu cũ

`CustomerDataSecurity.initialize()` chạy trước màn hình đăng nhập. Nếu database còn dữ liệu plaintext từ seed/phiên bản cũ, ứng dụng tự động mã hóa một lần. Nếu dữ liệu đã có tiền tố `v1:` thì không mã hóa lại.

## Kiểm tra bằng MySQL Workbench

Chạy:

`database/02_KIEM_TRA_BAO_MAT_KHACH_HANG.sql`

Kết quả mong đợi:

- `ho_ten_da_ma_hoa = tong_khach`
- `giay_to_da_ma_hoa = tong_khach`
- Các trường điện thoại/email/địa chỉ có dữ liệu đều bắt đầu bằng `v1:`.
- `plaintext_ho_ten = 0`
- `plaintext_giay_to = 0`
- `plaintext_dien_thoai = 0`
- `plaintext_email = 0`
- `plaintext_dia_chi = 0`

## Lưu ý triển khai thật

File `database.properties` trong đồ án chứa khóa demo để cô có thể chạy ngay. Khi triển khai thật, nên xóa khóa khỏi file và đặt `HOTEL_CUSTOMER_ENCRYPTION_KEY` ở môi trường máy chủ/secret manager.
