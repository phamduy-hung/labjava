Ảnh trong thư mục evidence dùng để minh họa và kiểm tra giao diện/chức năng dựa trên chính source code của project.
Để có ảnh runtime Tomcat/MySQL thật, chạy project theo HUONG_DAN_CHAY.txt rồi chụp lại cùng các trạng thái tương ứng.
