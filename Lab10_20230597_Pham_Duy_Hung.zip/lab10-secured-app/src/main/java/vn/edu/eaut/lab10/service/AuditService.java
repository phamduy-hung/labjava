package vn.edu.eaut.lab10.service;
import vn.edu.eaut.lab10.model.AuditLog; import vn.edu.eaut.lab10.repository.AuditLogRepository;
public class AuditService {private final AuditLogRepository repo=new AuditLogRepository(); public void log(String email,String action,String detail){try{repo.save(new AuditLog(email,action,detail));}catch(Exception ignored){System.out.println("Audit log error: "+ignored.getMessage());}}}
