package vn.edu.eaut.lab10.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity @Table(name="audit_log")
public class AuditLog {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(name="user_email", length=100) private String userEmail;
    @Column(nullable=false, length=50) private String action;
    @Column(length=500) private String detail;
    @Column(name="created_at", nullable=false) private LocalDateTime createdAt;
    public AuditLog(){}
    public AuditLog(String userEmail,String action,String detail){this.userEmail=userEmail;this.action=action;this.detail=detail;this.createdAt=LocalDateTime.now();}
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getUserEmail(){return userEmail;} public void setUserEmail(String userEmail){this.userEmail=userEmail;}
    public String getAction(){return action;} public void setAction(String action){this.action=action;}
    public String getDetail(){return detail;} public void setDetail(String detail){this.detail=detail;}
    public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime createdAt){this.createdAt=createdAt;}
}
