package vn.edu.eaut.lab10.repository;
import jakarta.persistence.*; import java.util.*; import vn.edu.eaut.lab10.model.Sach;
public class SachRepository extends BaseRepository<Sach,Integer>{
 public SachRepository(){super(Sach.class);} public List<Sach> search(String key){EntityManager em=em();try{String k=key==null?"":key.trim().toLowerCase();return em.createQuery("SELECT s FROM Sach s WHERE LOWER(s.tenSach) LIKE :kw OR LOWER(s.tacGia) LIKE :kw ORDER BY s.id DESC",Sach.class).setParameter("kw","%"+k+"%").getResultList();}finally{em.close();}}
}
