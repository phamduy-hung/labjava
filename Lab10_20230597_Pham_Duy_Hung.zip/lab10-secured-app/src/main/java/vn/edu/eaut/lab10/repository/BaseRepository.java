package vn.edu.eaut.lab10.repository;
import jakarta.persistence.*;
import vn.edu.eaut.lab10.config.JPAUtil;
import java.util.List;
public abstract class BaseRepository<T,ID> {
    private final Class<T> type;
    protected BaseRepository(Class<T> type){this.type=type;}
    protected EntityManager em(){return JPAUtil.getEntityManagerFactory().createEntityManager();}
    public T findById(ID id){EntityManager em=em();try{return em.find(type,id);}finally{em.close();}}
    public List<T> findAll(){EntityManager em=em();try{return em.createQuery("SELECT e FROM "+type.getSimpleName()+" e",type).getResultList();}finally{em.close();}}
    public void save(T entity){executeWrite(em->em.persist(entity));}
    public T update(T entity){final Object[] out=new Object[1];executeWrite(em->out[0]=em.merge(entity));return type.cast(out[0]);}
    public void delete(ID id){executeWrite(em->{T entity=em.find(type,id);if(entity!=null)em.remove(entity);});}
    protected void executeWrite(java.util.function.Consumer<EntityManager> work){EntityManager em=em();EntityTransaction tx=em.getTransaction();try{tx.begin();work.accept(em);tx.commit();}catch(RuntimeException ex){if(tx.isActive())tx.rollback();throw ex;}finally{em.close();}}
}
