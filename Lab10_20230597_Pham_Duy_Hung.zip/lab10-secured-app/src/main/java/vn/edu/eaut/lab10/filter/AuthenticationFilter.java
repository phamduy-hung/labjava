package vn.edu.eaut.lab10.filter;
import jakarta.servlet.*; import jakarta.servlet.annotation.WebFilter; import jakarta.servlet.http.*; import java.io.IOException;
@WebFilter(urlPatterns={"/dashboard","/dashboard.jsp","/admin/*","/staff/*","/user/*"})
public class AuthenticationFilter implements Filter {public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain)throws IOException,ServletException{HttpServletRequest r=(HttpServletRequest)req;HttpServletResponse p=(HttpServletResponse)res;HttpSession s=r.getSession(false);if(s==null||s.getAttribute("currentUser")==null){p.sendRedirect(r.getContextPath()+"/login.jsp");return;}chain.doFilter(req,res);}}
