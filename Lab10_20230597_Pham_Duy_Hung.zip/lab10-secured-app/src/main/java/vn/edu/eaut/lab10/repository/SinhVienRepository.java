package vn.edu.eaut.lab10.repository;
import jakarta.persistence.*; import java.util.*; import vn.edu.eaut.lab10.model.SinhVien;
public class SinhVienRepository extends BaseRepository<SinhVien,Integer>{
 public SinhVienRepository(){super(SinhVien.class);} public List<SinhVien> search(String key){EntityManager em=em();try{String k=key==null?"":key.trim().toLowerCase();return em.createQuery("SELECT s FROM SinhVien s WHERE LOWER(s.hoTen) LIKE :kw OR LOWER(s.lop) LIKE :kw ORDER BY s.id DESC",SinhVien.class).setParameter("kw","%"+k+"%").getResultList();}finally{em.close();}}
 public boolean codeExists(String code,Integer exceptId){EntityManager em=em();try{Long c=em.createQuery("SELECT COUNT(s) FROM SinhVien s WHERE s.maSinhVien=:code AND (:id IS NULL OR s.id<>:id)",Long.class).setParameter("code",code).setParameter("id",exceptId).getSingleResult();return c>0;}finally{em.close();}}
}
