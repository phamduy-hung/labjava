package vn.edu.eaut.lab10.controller;
import jakarta.servlet.*; import jakarta.servlet.annotation.WebServlet; import jakarta.servlet.http.*; import java.io.IOException;
@WebServlet("/dashboard") public class DashboardController extends HttpServlet {protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{req.getRequestDispatcher("/dashboard.jsp").forward(req,resp);}}
