package vn.edu.eaut.lab10.controller;
import jakarta.servlet.*; import jakarta.servlet.annotation.WebServlet; import jakarta.servlet.http.*; import java.io.IOException;
import vn.edu.eaut.lab10.model.User; import vn.edu.eaut.lab10.service.*;
@WebServlet("/auth") public class AuthController extends HttpServlet {
 private final AuthService auth=new AuthService(); private final AuditService audit=new AuditService();
 protected void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{request.setCharacterEncoding("UTF-8");String email=request.getParameter("email");User user=auth.login(email,request.getParameter("password"));if(user==null){audit.log(email,"LOGIN_FAILED","Đăng nhập thất bại");request.setAttribute("error","Email hoặc mật khẩu không đúng, hoặc tài khoản đã bị khóa");request.getRequestDispatcher("/login.jsp").forward(request,response);return;}request.getSession(true).setAttribute("currentUser",user);audit.log(user.getEmail(),"LOGIN","Đăng nhập thành công");response.sendRedirect(request.getContextPath()+"/dashboard");}
 protected void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException{HttpSession session=request.getSession(false);if(session!=null){User u=(User)session.getAttribute("currentUser");if(u!=null)audit.log(u.getEmail(),"LOGOUT","Đăng xuất hệ thống");session.invalidate();}response.sendRedirect(request.getContextPath()+"/login.jsp");}
}
