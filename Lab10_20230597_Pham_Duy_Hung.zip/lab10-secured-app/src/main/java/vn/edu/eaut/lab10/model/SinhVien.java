package vn.edu.eaut.lab10.model;
import jakarta.persistence.*;
@Entity @Table(name="sinh_vien")
public class SinhVien {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Integer id;
    @Column(name="ma_sinh_vien", nullable=false, unique=true, length=20) private String maSinhVien;
    @Column(name="ho_ten", nullable=false, length=100) private String hoTen;
    @Column(length=100) private String email;
    @Column(length=50) private String lop;
    public SinhVien(){}
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getMaSinhVien(){return maSinhVien;} public void setMaSinhVien(String v){maSinhVien=v;}
    public String getHoTen(){return hoTen;} public void setHoTen(String v){hoTen=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getLop(){return lop;} public void setLop(String v){lop=v;}
}
