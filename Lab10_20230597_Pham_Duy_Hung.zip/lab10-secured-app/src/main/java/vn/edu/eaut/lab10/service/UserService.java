package vn.edu.eaut.lab10.service;
import vn.edu.eaut.lab10.model.*; import vn.edu.eaut.lab10.repository.UserRepository; import java.util.*;
public class UserService {
 private final UserRepository repo=new UserRepository(); public List<User> search(String key){return repo.searchByEmail(key);} public User findById(Integer id){return repo.findById(id);}
 public void save(User u){validate(u);User old=repo.findByEmail(u.getEmail());if(old!=null&&(u.getId()==null||!old.getId().equals(u.getId())))throw new IllegalArgumentException("Email đã tồn tại");if(u.getId()==null){if(u.getPassword()==null||u.getPassword().length()<6)throw new IllegalArgumentException("Mật khẩu tối thiểu 6 ký tự");repo.save(u);}else{User db=repo.findById(u.getId());db.setFullName(u.getFullName());db.setEmail(u.getEmail());db.setRole(u.getRole());db.setPhone(u.getPhone());if(u.getPassword()!=null&&!u.getPassword().isBlank())db.setPassword(u.getPassword());repo.update(db);}}
 public void toggle(Integer id){User u=repo.findById(id);if(u!=null){u.setActive(!u.isActive());repo.update(u);}}
 public void delete(Integer id,Integer currentId){if(id.equals(currentId))throw new IllegalArgumentException("Không thể xóa chính tài khoản đang đăng nhập");repo.delete(id);}
 private void validate(User u){if(u.getFullName()==null||u.getFullName().isBlank())throw new IllegalArgumentException("Họ tên không được để trống");if(u.getEmail()==null||!u.getEmail().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))throw new IllegalArgumentException("Email không đúng định dạng");if(u.getRole()==null)throw new IllegalArgumentException("Vai trò không hợp lệ");}
}
