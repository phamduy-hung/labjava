package vn.edu.eaut.lab10.service;
import vn.edu.eaut.lab10.model.User; import vn.edu.eaut.lab10.repository.UserRepository;
public class AuthService {
 private final UserRepository repo=new UserRepository();
 public User login(String email,String password){if(email==null||password==null)return null;User u=repo.findByEmail(email.trim());if(u==null||!u.isActive())return null;return u.getPassword().equals(password)?u:null;}
 public User updateProfile(User current,String fullName,String email,String phone,String address){if(fullName==null||fullName.isBlank())throw new IllegalArgumentException("Họ tên không được để trống");if(email==null||!email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))throw new IllegalArgumentException("Email không đúng định dạng");User other=repo.findByEmail(email);if(other!=null&&!other.getId().equals(current.getId()))throw new IllegalArgumentException("Email đã được sử dụng");current.setFullName(fullName.trim());current.setEmail(email.trim());current.setPhone(phone);current.setAddress(address);return repo.update(current);}
 public User changePassword(User current,String oldPass,String newPass,String confirm){if(!current.getPassword().equals(oldPass))throw new IllegalArgumentException("Mật khẩu cũ không đúng");if(newPass==null||newPass.length()<6)throw new IllegalArgumentException("Mật khẩu mới phải có ít nhất 6 ký tự");if(!newPass.equals(confirm))throw new IllegalArgumentException("Xác nhận mật khẩu không khớp");current.setPassword(newPass);return repo.update(current);}
}
