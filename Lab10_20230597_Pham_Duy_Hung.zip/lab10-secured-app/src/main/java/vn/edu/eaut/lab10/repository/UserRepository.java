package vn.edu.eaut.lab10.repository;
import jakarta.persistence.*;
import vn.edu.eaut.lab10.model.User;
import java.util.List;
public class UserRepository extends BaseRepository<User,Integer>{
    public UserRepository(){super(User.class);}
    public User findByEmail(String email){EntityManager em=em();try{return em.createQuery("SELECT u FROM User u WHERE LOWER(u.email)=:email",User.class).setParameter("email",email.toLowerCase()).getResultStream().findFirst().orElse(null);}finally{em.close();}}
    public List<User> searchByEmail(String key){EntityManager em=em();try{return em.createQuery("SELECT u FROM User u WHERE LOWER(u.email) LIKE :kw ORDER BY u.id",User.class).setParameter("kw","%"+(key==null?"":key.toLowerCase())+"%").getResultList();}finally{em.close();}}
}
