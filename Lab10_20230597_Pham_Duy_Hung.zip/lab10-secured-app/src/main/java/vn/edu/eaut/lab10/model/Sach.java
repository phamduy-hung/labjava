package vn.edu.eaut.lab10.model;
import jakarta.persistence.*;
@Entity @Table(name="sach")
public class Sach {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Integer id;
    @Column(name="ma_sach", nullable=false, unique=true, length=20) private String maSach;
    @Column(name="ten_sach", nullable=false, length=150) private String tenSach;
    @Column(name="tac_gia", nullable=false, length=100) private String tacGia;
    @Column(name="nha_xuat_ban", length=100) private String nhaXuatBan;
    @Column(name="nam_xuat_ban") private Integer namXuatBan;
    public Sach(){}
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getMaSach(){return maSach;} public void setMaSach(String v){maSach=v;}
    public String getTenSach(){return tenSach;} public void setTenSach(String v){tenSach=v;}
    public String getTacGia(){return tacGia;} public void setTacGia(String v){tacGia=v;}
    public String getNhaXuatBan(){return nhaXuatBan;} public void setNhaXuatBan(String v){nhaXuatBan=v;}
    public Integer getNamXuatBan(){return namXuatBan;} public void setNamXuatBan(Integer v){namXuatBan=v;}
}
