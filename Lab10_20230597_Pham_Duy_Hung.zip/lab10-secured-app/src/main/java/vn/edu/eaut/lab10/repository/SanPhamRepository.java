package vn.edu.eaut.lab10.repository;
import jakarta.persistence.*; import java.util.*; import vn.edu.eaut.lab10.model.SanPham;
public class SanPhamRepository extends BaseRepository<SanPham,Integer>{
 public SanPhamRepository(){super(SanPham.class);} public List<SanPham> search(String key){EntityManager em=em();try{String k=key==null?"":key.trim().toLowerCase();return em.createQuery("SELECT s FROM SanPham s WHERE LOWER(s.ten) LIKE :kw OR LOWER(s.maSanPham) LIKE :kw ORDER BY s.id DESC",SanPham.class).setParameter("kw","%"+k+"%").getResultList();}finally{em.close();}}
}
