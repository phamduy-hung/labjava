package vn.edu.eaut.lab10.model;
import jakarta.persistence.*;
import java.math.BigDecimal;
@Entity @Table(name="san_pham")
public class SanPham {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Integer id;
    @Column(name="ma_san_pham", nullable=false, unique=true, length=20) private String maSanPham;
    @Column(nullable=false, length=120) private String ten;
    @Column(length=255) private String moTa;
    @Column(nullable=false, precision=12, scale=2) private BigDecimal gia;
    @Column(nullable=false) private Integer soLuong;
    public SanPham(){}
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getMaSanPham(){return maSanPham;} public void setMaSanPham(String v){maSanPham=v;}
    public String getTen(){return ten;} public void setTen(String v){ten=v;}
    public String getMoTa(){return moTa;} public void setMoTa(String v){moTa=v;}
    public BigDecimal getGia(){return gia;} public void setGia(BigDecimal v){gia=v;}
    public Integer getSoLuong(){return soLuong;} public void setSoLuong(Integer v){soLuong=v;}
}
