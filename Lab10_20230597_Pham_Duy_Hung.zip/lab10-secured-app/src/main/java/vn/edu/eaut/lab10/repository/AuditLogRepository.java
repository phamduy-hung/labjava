package vn.edu.eaut.lab10.repository;
import vn.edu.eaut.lab10.model.AuditLog;
public class AuditLogRepository extends BaseRepository<AuditLog,Long>{public AuditLogRepository(){super(AuditLog.class);}}
