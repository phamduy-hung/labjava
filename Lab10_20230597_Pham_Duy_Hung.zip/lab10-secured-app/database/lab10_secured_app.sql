CREATE DATABASE IF NOT EXISTS lab10_secured_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lab10_secured_app;

DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS san_pham;
DROP TABLE IF EXISTS sach;
DROP TABLE IF EXISTS sinh_vien;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  phone VARCHAR(20),
  address VARCHAR(255),
  role VARCHAR(20) NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE sinh_vien (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ma_sinh_vien VARCHAR(20) NOT NULL UNIQUE,
  ho_ten VARCHAR(100) NOT NULL,
  email VARCHAR(100),
  lop VARCHAR(50)
);
CREATE TABLE sach (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ma_sach VARCHAR(20) NOT NULL UNIQUE,
  ten_sach VARCHAR(150) NOT NULL,
  tac_gia VARCHAR(100) NOT NULL,
  nha_xuat_ban VARCHAR(100),
  nam_xuat_ban INT
);
CREATE TABLE san_pham (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ma_san_pham VARCHAR(20) NOT NULL UNIQUE,
  ten VARCHAR(120) NOT NULL,
  mo_ta VARCHAR(255),
  gia DECIMAL(12,2) NOT NULL,
  so_luong INT NOT NULL
);
CREATE TABLE audit_log (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_email VARCHAR(100),
  action VARCHAR(50) NOT NULL,
  detail VARCHAR(500),
  created_at DATETIME NOT NULL
);

INSERT INTO users(email,password,full_name,phone,address,role,active) VALUES
('admin@eaut.edu.vn','123456','Quản trị hệ thống','0900000001','Hà Nội','ADMIN',TRUE),
('staff@eaut.edu.vn','123456','Nhân viên nghiệp vụ','0900000002','Hà Nội','STAFF',TRUE),
('user@eaut.edu.vn','123456','Người dùng','0900000003','Hà Nội','USER',TRUE);
INSERT INTO sinh_vien(ma_sinh_vien,ho_ten,email,lop) VALUES
('20230597','Phạm Duy Hưng','hung20230597@eaut.edu.vn','DCCNTT14.2'),
('20240002','Nguyễn Văn An','an@eaut.edu.vn','DCCNTT15.1'),
('20240003','Trần Thị Bình','binh@eaut.edu.vn','DCCNTT15.2');
INSERT INTO sach(ma_sach,ten_sach,tac_gia,nha_xuat_ban,nam_xuat_ban) VALUES
('S001','Lập trình Java','Nguyễn Minh','Giáo dục',2025),
('S002','Jakarta EE căn bản','Trần An','Khoa học Kỹ thuật',2026);
INSERT INTO san_pham(ma_san_pham,ten,mo_ta,gia,so_luong) VALUES
('SP001','Bàn phím Logitech K120','Bàn phím USB',180000,50),
('SP002','Chuột không dây Rapoo','Chuột văn phòng',220000,40);
