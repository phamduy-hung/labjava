ẢNH MINH CHỨNG - LAB 6
Sinh viên: Phạm Duy Hưng - MSSV 20230597 - DCCNTT14.2

- 00_compile_check.png: kiểm tra cú pháp Java target 17 trong môi trường tạo bài.
- 01 đến 12: ảnh giao diện/minh họa từng chức năng theo chính JSP/CSS và luồng của project.

Lưu ý: môi trường tạo bài không có sẵn Apache Tomcat 10 và Maven để deploy WAR trực tiếp.
Nếu giảng viên yêu cầu ảnh chụp từ server Tomcat thật, chạy project theo README.md rồi chụp lại các màn hình tương ứng.
