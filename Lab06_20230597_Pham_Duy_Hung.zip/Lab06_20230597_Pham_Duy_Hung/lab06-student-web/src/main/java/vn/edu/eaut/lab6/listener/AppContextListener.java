package vn.edu.eaut.lab6.listener;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import vn.edu.eaut.lab6.store.StudentStore;

@WebListener
public class AppContextListener implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        StudentStore.initializeSampleData();
        sce.getServletContext().setAttribute("students", StudentStore.findAll());
        System.out.println("Ung dung Lab 6 da khoi dong");
        System.out.println("Khoi tao du lieu mau: " + StudentStore.count() + " sinh vien");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Ung dung Lab 6 da dung");
        System.out.println("So sinh vien tai thoi diem dung: " + StudentStore.count());
    }
}
