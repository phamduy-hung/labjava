package vn.edu.eaut.lab6.store;

import vn.edu.eaut.lab6.model.Student;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StudentStore {
    private static final List<Student> students = new ArrayList<>();

    private StudentStore() {
    }

    public static synchronized void initializeSampleData() {
        if (!students.isEmpty()) {
            return;
        }
        students.add(new Student("SV001", "Nguyen Van An", "DCCNTT12", "an@example.com"));
        students.add(new Student("SV002", "Tran Thi Binh", "DCCNTT12", "binh@example.com"));
        students.add(new Student("SV003", "Le Minh Chau", "DCCNTT13", "chau@example.com"));
        students.add(new Student("SV004", "Pham Hoang Dung", "DCCNTT14.2", "dung@example.com"));
        students.add(new Student("SV005", "Vu Thu Ha", "DCCNTT14.2", "ha@example.com"));
    }

    public static synchronized List<Student> findAll() {
        return new ArrayList<>(students);
    }

    public static synchronized void add(Student student) {
        if (student == null || student.getId() == null || student.getId().isBlank()) {
            throw new IllegalArgumentException("Ma sinh vien khong duoc rong");
        }
        if (findById(student.getId()) != null) {
            throw new IllegalArgumentException("Ma sinh vien da ton tai");
        }
        students.add(student);
    }

    public static synchronized Student findById(String id) {
        if (id == null) {
            return null;
        }
        return students.stream()
                .filter(s -> id.equalsIgnoreCase(s.getId()))
                .findFirst()
                .orElse(null);
    }

    public static synchronized List<Student> searchByName(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return findAll();
        }
        String key = keyword.trim().toLowerCase();
        return students.stream()
                .filter(s -> s.getName() != null && s.getName().toLowerCase().contains(key))
                .collect(Collectors.toList());
    }

    public static synchronized boolean delete(String id) {
        return students.removeIf(s -> s.getId().equalsIgnoreCase(id));
    }

    public static synchronized boolean update(String id, String name, String className, String email) {
        Student student = findById(id);
        if (student == null) {
            return false;
        }
        student.setName(name);
        student.setClassName(className);
        student.setEmail(email);
        return true;
    }

    public static synchronized int count() {
        return students.size();
    }

    public static synchronized Map<String, Long> countByClass() {
        return students.stream().collect(Collectors.groupingBy(
                Student::getClassName,
                LinkedHashMap::new,
                Collectors.counting()
        ));
    }
}
