package vn.edu.eaut.lab6.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import vn.edu.eaut.lab6.model.Student;
import vn.edu.eaut.lab6.store.StudentStore;

import java.io.IOException;
import java.util.List;

@WebServlet("/students")
public class StudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        if (action == null || action.isBlank()) {
            action = "list";
        }

        if (("delete".equals(action) || "edit".equals(action) || "add".equals(action)) && !isAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/403.jsp");
            return;
        }

        switch (action) {
            case "delete" -> deleteStudent(request, response);
            case "edit" -> showEditForm(request, response);
            case "add" -> response.sendRedirect(request.getContextPath() + "/student-form.jsp");
            default -> showList(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        if (!isAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/403.jsp");
            return;
        }

        String mode = request.getParameter("mode");
        if ("update".equals(mode)) {
            updateStudent(request, response);
        } else {
            addStudent(request, response);
        }
    }

    private void showList(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String keyword = request.getParameter("keyword");
        List<Student> students = StudentStore.searchByName(keyword);
        request.setAttribute("students", students);
        request.setAttribute("keyword", keyword == null ? "" : keyword);
        if (students.isEmpty()) {
            request.setAttribute("message", "Không tìm thấy sinh viên phù hợp");
        }
        request.getRequestDispatcher("/student-list.jsp").forward(request, response);
    }

    private void addStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String className = request.getParameter("className");
        String email = request.getParameter("email");

        if (isBlank(id) || isBlank(name) || isBlank(className) || isBlank(email)) {
            request.setAttribute("error", "Vui lòng nhập đầy đủ thông tin sinh viên");
            request.getRequestDispatcher("/student-form.jsp").forward(request, response);
            return;
        }

        try {
            StudentStore.add(new Student(id.trim(), name.trim(), className.trim(), email.trim()));
            response.sendRedirect(request.getContextPath() + "/students?message=added");
        } catch (IllegalArgumentException e) {
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("/student-form.jsp").forward(request, response);
        }
    }

    private void deleteStudent(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String id = request.getParameter("id");
        StudentStore.delete(id);
        response.sendRedirect(request.getContextPath() + "/students?message=deleted");
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Student student = StudentStore.findById(request.getParameter("id"));
        if (student == null) {
            response.sendRedirect(request.getContextPath() + "/students");
            return;
        }
        request.setAttribute("student", student);
        request.getRequestDispatcher("/student-edit.jsp").forward(request, response);
    }

    private void updateStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String className = request.getParameter("className");
        String email = request.getParameter("email");

        if (isBlank(name) || isBlank(className) || isBlank(email)) {
            Student student = new Student(id, name, className, email);
            request.setAttribute("student", student);
            request.setAttribute("error", "Vui lòng nhập đầy đủ thông tin cần cập nhật");
            request.getRequestDispatcher("/student-edit.jsp").forward(request, response);
            return;
        }

        StudentStore.update(id, name.trim(), className.trim(), email.trim());
        response.sendRedirect(request.getContextPath() + "/students?message=updated");
    }

    private boolean isAdmin(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return session != null && "ADMIN".equals(session.getAttribute("role"));
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
