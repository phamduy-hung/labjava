<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>403 - Không có quyền truy cập</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css">
</head>
<body>
<div class="container">
    <div class="card center" style="margin-top:70px">
        <h1>403</h1>
        <h2>Không có quyền truy cập</h2>
        <p>Tài khoản hiện tại chỉ có quyền xem danh sách sinh viên.</p>
        <a class="btn" href="${pageContext.request.contextPath}/students">Quay lại danh sách</a>
    </div>
</div>
</body>
</html>
