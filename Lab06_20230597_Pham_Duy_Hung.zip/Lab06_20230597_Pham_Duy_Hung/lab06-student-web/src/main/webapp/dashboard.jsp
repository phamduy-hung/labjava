<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html>
<head>
    <title>Dashboard - Lab 6</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css">
</head>
<body>
<div class="topbar"><div class="inner"><strong>Mini Student Web</strong><div class="nav"><a href="${pageContext.request.contextPath}/students">Sinh viên</a><a href="${pageContext.request.contextPath}/welcome.jsp">Trang chủ</a><a href="${pageContext.request.contextPath}/logout">Đăng xuất</a></div></div></div>
<div class="container">
    <div class="card">
        <h2>Dashboard</h2>
        <p>Người dùng: <strong>${sessionScope.username}</strong> | Vai trò: ${sessionScope.role}</p>
        <p>Thời gian đăng nhập: ${sessionScope.loginTime}</p>
        <div class="grid">
            <div class="stat">Tổng số sinh viên<strong>${totalStudents}</strong></div>
            <c:forEach var="item" items="${classStats}"><div class="stat">Lớp ${item.key}<strong>${item.value}</strong></div></c:forEach>
        </div>
    </div>
</div>
</body>
</html>
