<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html>
<head>
    <title>Danh sách sinh viên</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css">
</head>
<body>
<div class="topbar"><div class="inner"><strong>Mini Student Web</strong><div class="nav"><a href="${pageContext.request.contextPath}/welcome.jsp">Trang chủ</a><a href="${pageContext.request.contextPath}/dashboard">Dashboard</a><a href="${pageContext.request.contextPath}/logout">Đăng xuất</a></div></div></div>
<div class="container">
    <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:12px"><div><h2>Danh sách sinh viên</h2><p class="muted">Đăng nhập: ${sessionScope.username} - ${sessionScope.role}</p></div><c:if test="${sessionScope.role == 'ADMIN'}"><a class="btn success" href="${pageContext.request.contextPath}/students?action=add">+ Thêm sinh viên</a></c:if></div>
        <form class="search" action="${pageContext.request.contextPath}/students" method="get">
            <input type="text" name="keyword" value="${keyword}" placeholder="Tìm theo họ tên...">
            <button class="btn" type="submit">Tìm kiếm</button>
            <a class="btn secondary" href="${pageContext.request.contextPath}/students">Làm mới</a>
        </form>
        <c:if test="${not empty message}"><p class="alert info">${message}</p></c:if>
        <table>
            <tr><th>Mã SV</th><th>Họ tên</th><th>Lớp</th><th>Email</th><c:if test="${sessionScope.role == 'ADMIN'}"><th>Thao tác</th></c:if></tr>
            <c:forEach var="sv" items="${students}">
                <tr>
                    <td>${sv.id}</td><td>${sv.name}</td><td>${sv.className}</td><td>${sv.email}</td>
                    <c:if test="${sessionScope.role == 'ADMIN'}"><td><div class="actions"><a class="btn" href="${pageContext.request.contextPath}/students?action=edit&id=${sv.id}">Sửa</a><a class="btn danger" href="${pageContext.request.contextPath}/students?action=delete&id=${sv.id}" onclick="return confirm('Xóa sinh viên ${sv.id}?')">Xóa</a></div></td></c:if>
                </tr>
            </c:forEach>
        </table>
    </div>
</div>
</body>
</html>
