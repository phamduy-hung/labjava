<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Đăng nhập - Lab 6</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css">
</head>
<body>
<div class="login-wrap">
    <div class="card">
        <div class="center">
            <h1>Mini Student Web</h1>
            <p class="muted">Lab 6 - Servlet, JSP, JSTL, Filter, Listener</p>
        </div>
        <h2>Đăng nhập hệ thống</h2>
        <form action="${pageContext.request.contextPath}/login" method="post">
            <label>Tên đăng nhập</label>
            <input type="text" name="username" placeholder="admin hoặc user" required>
            <label>Mật khẩu</label>
            <input type="password" name="password" placeholder="123456" required>
            <button class="btn" type="submit">Đăng nhập</button>
        </form>
        <p class="muted">Tài khoản mẫu: admin / 123456; user / 123456</p>
        <p class="alert error" style="${empty error ? 'display:none' : ''}">${error}</p>
    </div>
</div>
</body>
</html>
