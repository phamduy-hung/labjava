<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Cập nhật sinh viên</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css">
</head>
<body>
<div class="topbar"><div class="inner"><strong>Mini Student Web</strong><div class="nav"><a href="${pageContext.request.contextPath}/students">Danh sách</a><a href="${pageContext.request.contextPath}/logout">Đăng xuất</a></div></div></div>
<div class="container">
    <div class="card">
        <h2>Cập nhật thông tin sinh viên</h2>
        <p class="alert error" style="${empty error ? 'display:none' : ''}">${error}</p>
        <form action="${pageContext.request.contextPath}/students" method="post">
            <input type="hidden" name="mode" value="update">
            <label>Mã sinh viên (không cho sửa)</label>
            <input type="text" name="id" value="${student.id}" readonly>
            <label>Họ tên</label>
            <input type="text" name="name" value="${student.name}" required>
            <label>Lớp</label>
            <input type="text" name="className" value="${student.className}" required>
            <label>Email</label>
            <input type="email" name="email" value="${student.email}" required>
            <button class="btn success" type="submit">Cập nhật</button>
            <a class="btn secondary" href="${pageContext.request.contextPath}/students">Hủy</a>
        </form>
    </div>
</div>
</body>
</html>
