<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Trang quản trị - Lab 6</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css">
</head>
<body>
<div class="topbar"><div class="inner"><strong>Mini Student Web</strong><div class="nav"><a href="${pageContext.request.contextPath}/students">Sinh viên</a><a href="${pageContext.request.contextPath}/dashboard">Dashboard</a><a href="${pageContext.request.contextPath}/logout">Đăng xuất</a></div></div></div>
<div class="container">
    <div class="card">
        <h2>Xin chào, ${sessionScope.username}</h2>
        <p>Vai trò: <span class="tag ${sessionScope.role == 'USER' ? 'user' : ''}">${sessionScope.role}</span></p>
        <p>Ứng dụng đang sử dụng Session để lưu trạng thái đăng nhập.</p>
        <div class="actions"><a class="btn" href="${pageContext.request.contextPath}/students">Quản lý sinh viên</a><a class="btn secondary" href="${pageContext.request.contextPath}/dashboard">Xem Dashboard</a></div>
    </div>
</div>
</body>
</html>
